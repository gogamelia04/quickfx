Quick FX 1.2 — ეფექტებისა და პრესეტების სწრაფი ძებნა Premiere-ისთვის (Mac)
=====================================================================

დაყენება და განახლება (2 წუთი)
------------------------------
1. გახსენი Terminal (⌘Space → „Terminal“), ჩასვი ეს ერთი ხაზი და დააჭირე Enter-ს:

    curl -fsSL https://raw.githubusercontent.com/gogamelia04/quickfx/main/install.sh | bash

2. გაიხსნება System Settings-ის ფანჯარა (Accessibility) — ჩართე „Hammerspoon“.
   (ეს უფასო დამხმარეა, რომელიც ⌥Space-ს იჭერს. ინსტალერი თვითონ იწერს და აყენებს.
   თუ ჩართვის მერეც არ მუშაობს, Hammerspoon დახურე და თავიდან გახსენი.)
3. Premiere სრულად დახურე (⌘Q) და თავიდან გახსენი.

ახალი ვერსიის მისაღებად იგივე ხაზი თავიდან გაუშვი.


გამოყენება
----------
  • timeline-ზე მონიშნე კლიპები → ⌥Space → აკრიფე → Enter
  • ↑ ↓  არჩევა      Enter  დადება და დახურვა
    ⇧Enter  დადება, ფანჯარა რჩება      Esc  გასუფთავება / დახურვა
  • ძებნა ჭკვიანია: „gb“ → Gaussian Blur, „w s“ → Warp Stabilizer, „lumtri“ → Lumetri Color
  • ქართულ განლაგებაზე დარჩენილი კლავიატურითაც მუშაობს („გაუს“ → Gaussian Blur)
  • რასაც ხშირად იყენებ, ზემოთ ამოდის
  • ვიდეო ეფექტი ედება ვიდეო კლიპებს, აუდიო ეფექტი — აუდიოს
  • ⋯ მენიუ: სიების განახლება (⌘R), დიაგნოსტიკის კოპირება
  • ⌥Space მხოლოდ Premiere-ში მუშაობს; სხვა პროგრამებში არაფერს ცვლის
  • კლავიშის გარეშეც იხსნება: Window → Extensions → Quick FX


შენი პრესეტები
--------------
პლაგინი თავად კითხულობს ფაილს:
  Documents/Adobe/Premiere Pro/<ვერსია>/Profile-<სახელი>/Effect Presets and Custom Items.prfpset

ახალი პრესეტი თუ არ ჩანს → ⋯ → სიების განახლება.

რა გადმოდის: ეფექტები, მნიშვნელობები და keyframe-ები (Motion, Opacity, Transform,
Blur და ა.შ.), პრესეტის ტიპი (Scale / Anchor to In / Anchor to Out), third-party
ეფექტები — თუ დაყენებულია.
რა ვერ გადმოდის (Premiere-ის API-ის შეზღუდვაა): Lumetri-ს curves / color wheels / LUT,
მასკები, ფერის keyframe-ები, ტრანზიციის პრესეტები.


ფონტი
-----
ინტერფეისი იყენებს BOG 2023 ფონტს, თუ ის კომპიუტერზე აყენია (Font Book).
თუ არ აყენია, ყველაფერი მუშაობს, უბრალოდ სისტემური ფონტით ჩანს.


სხვა კლავიში თუ გინდა
---------------------
მენიუ-ბარში Hammerspoon-ის ხატულა → Open Config → იმავე საქაღალდეში გახსენი
quickfx.lua → ზედა ორი ხაზი (MODS და KEY) შეცვალე → ხატულა → Reload Config.


თუ რამე არ მუშაობს
------------------
  • ⌥Space-ზე არაფერი ხდება → System Settings → Privacy & Security → Accessibility →
    Hammerspoon ჩართულია? მენიუ-ბარში Hammerspoon-ის ხატულა ჩანს? (თუ არა, გახსენი
    Applications-იდან)
  • მენიუში Quick FX არ ჩანს → დაყენების ხაზი თავიდან გაუშვი და Premiere ⌘Q-ით გადატვირთე
  • შეცდომა გამოჩნდა → ⋯ → დიაგნოსტიკის კოპირება → გაუგზავნე გოგას
  • წაშლა:  curl -fsSL https://raw.githubusercontent.com/gogamelia04/quickfx/main/install.sh | bash -s -- uninstall
