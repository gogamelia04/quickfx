#!/bin/bash
# Quick FX — one-step installer for Adobe Premiere Pro on macOS.
#   1) copies the plugin into Premiere's extensions folder
#   2) sets up the ⌥Space hotkey (through the free Hammerspoon helper)
# Run:  bash install.command

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/com.goga.quickfx"
DEST_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$DEST_DIR/com.goga.quickfx"
HS_DIR="$HOME/.hammerspoon"
HS_REPO="Hammerspoon/hammerspoon"

echo ""
echo "  Quick FX — ინსტალაცია"
echo "  ─────────────────────"

# ------------------------------------------------------------------ 1. plugin
if [ ! -f "$SRC/CSXS/manifest.xml" ]; then
  echo "  ✗ com.goga.quickfx საქაღალდე ვერ ვიპოვე install.command-ის გვერდით."
  echo "    ჯერ ZIP გახსენი, მერე ეს ფაილი იმავე საქაღალდიდან გაუშვი."
  exit 1
fi

mkdir -p "$DEST_DIR" || { echo "  ✗ საქაღალდე ვერ შეიქმნა: $DEST_DIR"; exit 1; }
rm -rf "$DEST"
cp -R "$SRC" "$DEST" || { echo "  ✗ ფაილები ვერ დაკოპირდა"; exit 1; }
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null
echo "  ✓ პლაგინი დაყენდა"

# Allow unsigned (self-made) CEP extensions — every CEP version Premiere may use.
for v in 9 10 11 12 13 14; do
  defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1
done

# ------------------------------------------------------------------ 2. hotkey helper
find_hammerspoon() {
  for p in "/Applications/Hammerspoon.app" "$HOME/Applications/Hammerspoon.app"; do
    [ -d "$p" ] && { echo "$p"; return 0; }
  done
  return 1
}

download_hammerspoon() {
  local tmp url tag app target
  tmp="$(mktemp -d)" || return 1

  url="$(curl -fsSL --max-time 20 "https://api.github.com/repos/$HS_REPO/releases/latest" 2>/dev/null \
        | grep -o '"browser_download_url": *"[^"]*"' | grep -o 'https://[^"]*' \
        | grep -i '\.zip$' | grep -vi 'dsym' | head -1)"
  if [ -z "$url" ]; then
    tag="$(curl -fsSLI -o /dev/null -w '%{url_effective}' --max-time 20 "https://github.com/$HS_REPO/releases/latest" 2>/dev/null | sed 's#.*/tag/##')"
    [ -n "$tag" ] && url="https://github.com/$HS_REPO/releases/download/$tag/Hammerspoon-$tag.zip"
  fi
  [ -z "$url" ] && { rm -rf "$tmp"; return 1; }

  curl -fL --progress-bar --max-time 300 -o "$tmp/hs.zip" "$url" || { rm -rf "$tmp"; return 1; }
  ditto -x -k "$tmp/hs.zip" "$tmp/x" || { rm -rf "$tmp"; return 1; }
  app="$(find "$tmp/x" -maxdepth 2 -name 'Hammerspoon.app' -type d | head -1)"
  [ -z "$app" ] && { rm -rf "$tmp"; return 1; }

  # Only install a properly signed, Apple-notarized build.
  if ! spctl --assess --type execute "$app" >/dev/null 2>&1; then
    echo "  ✗ გადმოწერილმა Hammerspoon-მა ხელმოწერის შემოწმება ვერ გაიარა — არ ვაყენებ."
    rm -rf "$tmp"; return 1
  fi

  target="/Applications/Hammerspoon.app"
  if ! ditto "$app" "$target" 2>/dev/null; then
    mkdir -p "$HOME/Applications"
    target="$HOME/Applications/Hammerspoon.app"
    ditto "$app" "$target" || { rm -rf "$tmp"; return 1; }
  fi
  rm -rf "$tmp"
  return 0
}

HOTKEY_OK=0
FRESH_HS=0
HS_APP="$(find_hammerspoon)"

if [ -z "$HS_APP" ]; then
  echo "  … კლავიშის დამხმარე (Hammerspoon, უფასო) იწერება"
  if download_hammerspoon; then
    HS_APP="$(find_hammerspoon)"
    FRESH_HS=1
    # menu-bar icon only, no Dock icon
    defaults write org.hammerspoon.Hammerspoon MJShowDockIconKey -bool false
  fi
fi

if [ -n "$HS_APP" ] && [ -f "$HERE/hotkey/quickfx.lua" ]; then
  mkdir -p "$HS_DIR"
  cp "$HERE/hotkey/quickfx.lua" "$HS_DIR/quickfx.lua"
  touch "$HS_DIR/init.lua"
  if ! grep -q 'require, *"quickfx"' "$HS_DIR/init.lua"; then
    printf '\npcall(require, "quickfx") -- Quick FX hotkey for Premiere\n' >> "$HS_DIR/init.lua"
  fi
  # (re)start the helper so it picks the hotkey up
  pkill -x Hammerspoon >/dev/null 2>&1 && sleep 1
  open -a "$HS_APP"
  HOTKEY_OK=1
  echo "  ✓ კლავიში ⌥Space მომზადდა"
fi

# ------------------------------------------------------------------ 3. what is left for a human
echo ""
if [ "$HOTKEY_OK" = "1" ]; then
  if [ "$FRESH_HS" = "1" ]; then
    sleep 2
    open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility" 2>/dev/null
    echo "  დარჩა ერთი ნაბიჯი (macOS ამას მხოლოდ ადამიანს ანდობს):"
    echo "    გახსნილ ფანჯარაში (Privacy & Security → Accessibility) ჩართე  Hammerspoon"
    echo ""
  fi
  echo "  მზადაა:"
  echo "    1. Premiere სრულად დახურე (⌘Q) და თავიდან გახსენი"
  echo "    2. მონიშნე კლიპი → ⌥Space → აკრიფე ეფექტი → Enter"
else
  echo "  ! კლავიშის დამხმარე ვერ დაყენდა (ინტერნეტი?). პლაგინი მაინც მუშაობს:"
  echo "      Premiere → Window → Extensions → Quick FX"
  echo "    კლავიშისთვის ეს ბრძანება მოგვიანებით თავიდან გაუშვი."
fi
echo ""
