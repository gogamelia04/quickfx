-- Quick FX — hotkey for Adobe Premiere Pro (runs inside Hammerspoon).
-- Premiere gives plugins no keyboard shortcut of their own, so this catches
-- the key at system level and presses Window > Extensions > Quick FX.
-- The key is active ONLY while Premiere is the front app.

-- ▼ To change the key, edit these two lines, then Hammerspoon menu > Reload Config.
local MODS = { "alt" }        -- "alt" = ⌥ Option, "cmd" = ⌘, "ctrl" = ⌃, "shift" = ⇧
local KEY  = "space"

local MENU_PATH = { "Window", "Extensions", "Quick FX" }
local MENU_NAME = "Quick FX"

local M = {}

local function isPremiere(app)
  if not app then return false end
  local id = app:bundleID() or ""
  if id:find("com.adobe.PremierePro", 1, true) then return true end
  local name = app:name() or ""
  return name:find("Premiere", 1, true) ~= nil
end

local function openQuickFX()
  local app = hs.application.frontmostApplication()
  if not isPremiere(app) then return end

  if not hs.accessibilityState() then
    hs.alert.show("Quick FX: System Settings → Privacy & Security → Accessibility → Hammerspoon ჩართე", 5)
    hs.accessibilityState(true)
    return
  end

  if app:selectMenuItem(MENU_PATH) then return end
  if app:selectMenuItem(MENU_NAME) then return end
  hs.alert.show("Quick FX მენიუში ვერ მოიძებნა — Window → Extensions-ში ჩანს?", 4)
end

M.hotkey = hs.hotkey.new(MODS, KEY, openQuickFX)

M.watcher = hs.application.watcher.new(function(_, event, app)
  if event == hs.application.watcher.activated then
    if isPremiere(app) then M.hotkey:enable() else M.hotkey:disable() end
  end
end)
M.watcher:start()

if isPremiere(hs.application.frontmostApplication()) then M.hotkey:enable() end

-- Keep the helper running after a restart, and ask for the one permission it needs.
pcall(function() hs.autoLaunch(true) end)
if not hs.accessibilityState() then hs.accessibilityState(true) end

return M
