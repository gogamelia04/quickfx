#!/bin/bash
# Quick FX — remove from Adobe Premiere (macOS). Hammerspoon itself is left installed.
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.goga.quickfx"
HS_DIR="$HOME/.hammerspoon"

if [ -d "$DEST" ]; then
  rm -rf "$DEST"
  echo "  ✓ Quick FX პლაგინი წაიშალა"
else
  echo "  Quick FX პლაგინი დაყენებული არ არის"
fi

if [ -f "$HS_DIR/quickfx.lua" ]; then
  rm -f "$HS_DIR/quickfx.lua"
  if [ -f "$HS_DIR/init.lua" ]; then
    grep -v 'require, *"quickfx"' "$HS_DIR/init.lua" > "$HS_DIR/init.lua.qfxtmp"
    mv "$HS_DIR/init.lua.qfxtmp" "$HS_DIR/init.lua"
  fi
  pkill -x Hammerspoon >/dev/null 2>&1 && sleep 1 && open -a Hammerspoon 2>/dev/null
  echo "  ✓ კლავიში ⌥Space მოიხსნა (Hammerspoon დარჩა — თუ არ გჭირდება, Applications-იდან წაშალე)"
fi
echo "  Premiere გადატვირთე."
