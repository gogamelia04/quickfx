/*
 * Quick FX — ExtendScript side (runs inside Premiere).
 * ES3 only: no JSON, no Array#indexOf/forEach, no String#trim, no Date.now.
 *
 * Effects are added through the (unofficial) QE DOM, because Premiere's public
 * ExtendScript API cannot add effects. Parameter values and keyframes are then set
 * through the public API (Component / ComponentParam).
 */
var QuickFX = (function () {
  var Q = {};
  Q.version = '1.15.0';

  var TPS = 254016000000;            // ticks per second

  // ------------------------------------------------------------------ JSON (ES3)
  function quote(s) {
    var out = '"';
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i), code = s.charCodeAt(i);
      if (c === '"') { out += '\\"'; }
      else if (c === '\\') { out += '\\\\'; }
      else if (c === '\n') { out += '\\n'; }
      else if (c === '\r') { out += '\\r'; }
      else if (c === '\t') { out += '\\t'; }
      else if (code < 32 || code === 0x2028 || code === 0x2029) {
        var h = code.toString(16);
        while (h.length < 4) { h = '0' + h; }
        out += '\\u' + h;
      } else { out += c; }
    }
    return out + '"';
  }

  function stringify(v) {
    if (v === null || v === undefined) { return 'null'; }
    var t = typeof v;
    if (t === 'number') { return isFinite(v) ? String(v) : 'null'; }
    if (t === 'boolean') { return v ? 'true' : 'false'; }
    if (t === 'string') { return quote(v); }
    var i, parts = [];
    if (v instanceof Array) {
      for (i = 0; i < v.length; i++) { parts.push(stringify(v[i])); }
      return '[' + parts.join(',') + ']';
    }
    if (t === 'object') {
      for (var k in v) {
        if (v.hasOwnProperty(k)) {
          var val = v[k];
          if (val === undefined || typeof val === 'function') { continue; }
          parts.push(quote(String(k)) + ':' + stringify(val));
        }
      }
      return '{' + parts.join(',') + '}';
    }
    return 'null';
  }

  function parseJSON(text) {
    var s = String(text);
    var probe = s.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')
                 .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
                 .replace(/(?:^|:|,)(?:\s*\[)+/g, '');
    if (/^[\],:{}\s]*$/.test(probe)) { return eval('(' + s + ')'); }
    throw new Error('Invalid JSON from panel');
  }

  Q.stringify = stringify;
  Q.parseJSON = parseJSON;

  // ------------------------------------------------------------------ small helpers
  function ok(data) { return stringify({ ok: true, data: data }); }
  function fail(code, message, extra) {
    return stringify({ ok: false, code: code, message: message || '', extra: extra === undefined ? null : extra });
  }
  function arg(encoded) { return parseJSON(decodeURIComponent(String(encoded))); }
  function guard(fn) {
    return function (a) {
      try { return fn(a); }
      catch (e) {
        var msg = String(e);
        try { if (e && e.line) { msg += ' (line ' + e.line + ')'; } } catch (e2) {}
        return fail('exception', msg);
      }
    };
  }
  function strTrim(s) { return String(s === null || s === undefined ? '' : s).replace(/^\s+|\s+$/g, ''); }
  function normName(s) { return strTrim(s).toLowerCase().replace(/\s+/g, ' '); }
  function contains(arr, v) { for (var i = 0; i < arr.length; i++) { if (arr[i] === v) { return true; } } return false; }
  function addUnique(arr, v) { if (!contains(arr, v)) { arr.push(v); } }
  function toArray(list) {
    var out = [];
    if (!list) { return out; }
    var n = 0;
    try { n = list.length; } catch (e) { n = 0; }
    for (var i = 0; i < n; i++) { out.push(String(list[i])); }
    return out;
  }
  function uniqSorted(arr) {
    var seen = {}, out = [];
    for (var i = 0; i < arr.length; i++) {
      var s = strTrim(arr[i]);
      if (!s || seen['$' + s]) { continue; }
      seen['$' + s] = true;
      out.push(s);
    }
    out.sort(function (a, b) { var x = a.toLowerCase(), y = b.toLowerCase(); return x < y ? -1 : (x > y ? 1 : 0); });
    return out;
  }

  function hasQE() {
    try { app.enableQE(); } catch (e) {}
    try { return (typeof qe !== 'undefined') && !!qe && !!qe.project; } catch (e2) { return false; }
  }

  function activeSeq() {
    try { return app.project ? app.project.activeSequence : null; } catch (e) { return null; }
  }

  function frameTicks(seq) {
    var f = 0;
    try { f = Number(seq.timebase); } catch (e) {}
    return (f && f > 0) ? f : TPS / 25;
  }

  // ------------------------------------------------------------------ preset files on disk
  function findPresetFiles() {
    var out = [];
    var docs = null;
    try { docs = Folder.myDocuments; } catch (e) {}
    if (!docs) { return out; }
    var bases = ['Adobe/Premiere Pro', 'Adobe/Premiere', 'Adobe/Adobe Premiere Pro', 'Adobe/Adobe Premiere'];
    for (var b = 0; b < bases.length; b++) {
      var base = new Folder(docs.fsName + '/' + bases[b]);
      if (!base.exists) { continue; }
      var versions = base.getFiles();
      for (var i = 0; i < versions.length; i++) {
        var vf = versions[i];
        if (!(vf instanceof Folder)) { continue; }
        var profiles = vf.getFiles();
        for (var j = 0; j < profiles.length; j++) {
          var pf = profiles[j];
          if (!(pf instanceof Folder)) { continue; }
          var pname = decodeURI(pf.name);
          if (pname.indexOf('Profile') !== 0) { continue; }
          var f = new File(pf.fsName + '/Effect Presets and Custom Items.prfpset');
          if (!f.exists) { continue; }
          var mod = 0;
          try { mod = f.modified ? f.modified.getTime() : 0; } catch (e3) {}
          out.push({ path: f.fsName, version: decodeURI(vf.name), profile: pname, modified: mod, size: f.length });
        }
      }
    }
    return out;
  }

  // ------------------------------------------------------------------ selection
  function scanTracks(tracks, isVideo, out) {
    var nt = 0;
    try { nt = tracks.numTracks; } catch (e) {}
    for (var t = 0; t < nt; t++) {
      var clips = tracks[t].clips;
      var nc = clips.numItems;
      for (var c = 0; c < nc; c++) {
        var cl = clips[c], sel = false;
        try { sel = cl.isSelected(); } catch (e2) {}
        if (sel) {
          out.push({ clip: cl, track: t, index: c, video: isVideo, startTicks: String(cl.start.ticks), name: String(cl.name) });
        }
      }
    }
  }

  function collectSelected(seq, wantVideo, wantAudio) {
    var out = [];
    if (wantVideo) { scanTracks(seq.videoTracks, true, out); }
    if (wantAudio) { scanTracks(seq.audioTracks, false, out); }
    return out;
  }

  function noTargetsError(seq, wantVideo, wantAudio) {
    var any = collectSelected(seq, true, true).length;
    if (!any) { return fail('noSelection'); }
    if (wantVideo && !wantAudio) { return fail('noVideoSelected'); }
    if (wantAudio && !wantVideo) { return fail('noAudioSelected'); }
    return fail('noSelection');
  }

  /** Same clip, re-read after the QE DOM changed it (the old object can be stale). */
  function refetch(seq, sel) {
    try {
      var tracks = sel.video ? seq.videoTracks : seq.audioTracks;
      var clips = tracks[sel.track].clips;
      for (var c = 0; c < clips.numItems; c++) {
        if (String(clips[c].start.ticks) === sel.startTicks) { return clips[c]; }
      }
    } catch (e) {}
    return sel.clip;
  }

  /** QE track item for a selected clip: match by start time, fall back to position on the track. */
  function qeItemFor(qeSeq, sel, frame) {
    var qt = null;
    try { qt = sel.video ? qeSeq.getVideoTrackAt(sel.track) : qeSeq.getAudioTrackAt(sel.track); } catch (e) {}
    if (!qt) { return null; }
    var target = Number(sel.startTicks);
    var best = null, bestD = -1, ord = -1, byOrd = null, n = 0;
    try { n = qt.numItems; } catch (e2) {}
    for (var i = 0; i < n; i++) {
      var it = null;
      try { it = qt.getItemAt(i); } catch (e3) {}
      if (!it) { continue; }
      var ty = '';
      try { ty = String(it.type); } catch (e4) {}
      if (ty === 'Empty' || ty === 'Transition') { continue; }
      ord++;
      if (ord === sel.index) { byOrd = it; }
      var st = NaN;
      try { st = Number(it.start.ticks); } catch (e5) {}
      if (!isNaN(st)) {
        var d = Math.abs(st - target);
        if (best === null || d < bestD) { best = it; bestD = d; }
      }
    }
    if (best !== null && bestD <= frame / 2) { return best; }
    if (byOrd) { return byOrd; }
    return (best !== null && bestD <= frame * 2) ? best : null;
  }

  // ------------------------------------------------------------------ effect lookup
  function getAudioFx(name, byMatchName) {
    var fx = null;
    try { fx = byMatchName ? qe.project.getAudioEffectByName(name, 1, true) : qe.project.getAudioEffectByName(name); } catch (e) {}
    if (!fx && !byMatchName) {
      try { fx = qe.project.getAudioEffectByName(name, 1); } catch (e2) {}
    }
    return fx || null;
  }

  function getVideoFx(name, byMatchName) {
    var fx = null;
    try { fx = byMatchName ? qe.project.getVideoEffectByName(name, true) : qe.project.getVideoEffectByName(name); } catch (e) {}
    return fx || null;
  }

  function addFxObject(qeIt, fxObj, isVideo) {
    var r;
    try { r = isVideo ? qeIt.addVideoEffect(fxObj) : qeIt.addAudioEffect(fxObj); }
    catch (e) { return false; }
    return r !== false;
  }

  /** "AE.ADBE Gaussian Blur 2" -> "Gaussian Blur" */
  function derivedName(matchName) {
    var s = strTrim(matchName).replace(/^(AE|PR)\.ADBE\s+/, '').replace(/^ADBE\s+/, '');
    return s.replace(/\s+\d+$/, '');
  }

  /** Add the effect a preset needs; try the saved display name first, then the match name. */
  function addPresetFx(qeIt, fx, isVideo) {
    var tries = [];
    if (fx.displayName) { tries.push([fx.displayName, false]); }
    var d = derivedName(fx.matchName);
    if (d && d !== fx.displayName) { tries.push([d, false]); }
    if (fx.matchName) { tries.push([fx.matchName, true]); }
    for (var i = 0; i < tries.length; i++) {
      var obj = isVideo ? getVideoFx(tries[i][0], tries[i][1]) : getAudioFx(tries[i][0], tries[i][1]);
      if (!obj) { continue; }
      if (addFxObject(qeIt, obj, isVideo)) { return true; }
    }
    return false;
  }

  function componentCount(clip) {
    try { return clip.components.numItems; } catch (e) { return 0; }
  }

  function findComponent(clip, fx, fromEnd) {
    var comps = clip.components, n = componentCount(clip), i, c;
    var wantMatch = strTrim(fx.matchName), wantName = normName(fx.displayName);
    for (var pass = 0; pass < 2; pass++) {
      for (var k = 0; k < n; k++) {
        i = fromEnd ? n - 1 - k : k;
        c = comps[i];
        try {
          if (pass === 0 && wantMatch && String(c.matchName) === wantMatch) { return c; }
          if (pass === 1 && wantName && normName(c.displayName) === wantName) { return c; }
        } catch (e) {}
      }
    }
    return null;
  }

  // ------------------------------------------------------------------ parameter replay
  function clipTiming(clip) {
    var inS = 0, outS = 0, speed = 1;
    try { inS = clip.inPoint.seconds; outS = clip.outPoint.seconds; } catch (e) {}
    try { speed = Math.abs(Number(clip.getSpeed())); } catch (e2) { speed = 1; }
    if (!(speed > 0.01 && speed < 100)) { speed = 1; }
    return { inSec: inS, outSec: outS, dur: Math.max(0, outS - inS), speed: speed };
  }

  /**
   * Keyframe times live in source-media time (they stretch with clip speed), so offsets
   * are converted by targetSpeed / presetSpeed to keep the same on-timeline timing.
   * Preset "Type": 0 = scale to clip length, 1 = anchor to In point, 2 = anchor to Out point.
   */
  function mapTime(rel, timing, preset) {
    var type = preset.type || 0;
    var pd = preset.duration || 0;
    var ps = preset.speed > 0 ? preset.speed : 1;
    var k = (timing.speed || 1) / ps;
    if (type === 2) { return timing.outSec - (pd - rel) * k; }
    if (type === 0 && pd > 0 && timing.dur > 0) { return timing.inSec + rel * (timing.dur / pd); }
    return timing.inSec + rel * k;
  }

  /** Premiere keyframe interpolation codes: 0 linear, 4 hold, 5 bezier (1–3 are legacy eases). */
  function interpCode(code) {
    if (code === 0 || code === 4 || code === 5) { return code; }
    if (code === 1 || code === 2 || code === 3) { return 5; }
    return 0;
  }

  function toValue(kind, v) {
    if (kind === 'point') { return [Number(v[0]), Number(v[1])]; }
    if (kind === 'bool') { return !!v; }
    return Number(v);
  }

  function makeTime(sec) { var t = new Time(); t.seconds = sec; return t; }

  function setStatic(prop, kind, v, updateUI) {
    if (v === null || v === undefined) { return false; }
    if (kind === 'color') {
      prop.setColorValue(v.a, v.r, v.g, v.b, updateUI);
      return true;
    }
    prop.setValue(toValue(kind, v), updateUI);
    return true;
  }

  function cleanupKeys(prop, placed) {
    var ks = null;
    try { ks = prop.getKeys(); } catch (e) { return; }
    if (!ks || !ks.length) { return; }
    for (var i = 0; i < ks.length; i++) {
      var s = NaN;
      try { s = ks[i].seconds; } catch (e2) {}
      if (isNaN(s)) { continue; }
      var keep = false;
      for (var j = 0; j < placed.length; j++) { if (Math.abs(placed[j] - s) < 0.0005) { keep = true; break; } }
      if (!keep) { try { prop.removeKey(ks[i]); } catch (e3) {} }
    }
  }

  function setOne(prop, p, timing, preset, updateUI) {
    var keys = p.keys || [];
    var canKey = false;
    try { canKey = prop.areKeyframesSupported(); } catch (e) {}
    var animate = keys.length > 0 && canKey && p.kind !== 'color';

    // A preset replaces what is there: drop existing animation first.
    try { if (prop.isTimeVarying()) { prop.setTimeVarying(false); } } catch (e2) {}

    if (!animate) {
      return setStatic(prop, p.kind, keys.length ? keys[0].v : p.value, updateUI);
    }

    prop.setTimeVarying(true);
    var placed = [];
    for (var i = 0; i < keys.length; i++) {
      var sec = mapTime(keys[i].t, timing, preset);
      var tm = makeTime(sec);
      prop.addKey(tm);
      prop.setValueAtKey(tm, toValue(p.kind, keys[i].v), updateUI);
      try { prop.setInterpolationTypeAtKey(tm, interpCode(keys[i].interp), updateUI); } catch (e3) {}
      placed.push(sec);
    }
    cleanupKeys(prop, placed);
    return true;
  }

  function setParams(comp, fx, timing, preset) {
    var res = { set: 0, skipped: 0 };
    var props = comp.properties;
    var n = 0;
    try { n = props.numItems; } catch (e) {}
    var byName = {}, i;
    for (i = 0; i < n; i++) {
      var dn = '';
      try { dn = normName(props[i].displayName); } catch (e2) {}
      if (dn) {
        if (!byName['$' + dn]) { byName['$' + dn] = []; }
        byName['$' + dn].push(i);
      }
    }
    var list = fx.params || [];
    var aligned = list.length === n;
    var seen = {};
    var lastSettable = -1;
    for (i = 0; i < list.length; i++) {
      if (list[i].kind !== 'arb' && list[i].kind !== 'ui' && list[i].kind !== 'unknown') { lastSettable = i; }
    }
    for (i = 0; i < list.length; i++) {
      var p = list[i];
      var key = normName(p.name);
      if (key) { seen['$' + key] = (seen['$' + key] || 0) + 1; }
      if (p.kind === 'ui') { continue; }
      if (p.kind === 'arb' || p.kind === 'unknown') { res.skipped++; continue; }
      var idx = -1;
      var occ = key ? byName['$' + key] : null;
      if (occ && occ.length >= seen['$' + key]) { idx = occ[seen['$' + key] - 1]; }
      if (idx < 0 && aligned && p.index >= 0 && p.index < n) { idx = p.index; }
      if (idx < 0) { res.skipped++; continue; }
      var ok2 = false;
      try { ok2 = setOne(props[idx], p, timing, preset, i === lastSettable ? 1 : 0); } catch (e3) { ok2 = false; }
      if (ok2) { res.set++; } else { res.skipped++; }
    }
    return res;
  }

  // ------------------------------------------------------------------ public API
  Q.ping = guard(function () {
    return ok({ version: Q.version, app: String(app.version), qe: hasQE() });
  });

  Q.info = guard(function () {
    var files = [];
    try { files = findPresetFiles(); } catch (e) {}
    var seq = activeSeq();
    return ok({
      version: Q.version,
      appVersion: String(app.version),
      os: String($.os),
      qe: hasQE(),
      hasSequence: !!seq,
      presetFiles: files
    });
  });

  Q.listEffects = guard(function () {
    if (!hasQE()) { return fail('noQE'); }
    var v = [], a = [];
    try { v = toArray(qe.project.getVideoEffectList()); } catch (e) {}
    try { a = toArray(qe.project.getAudioEffectList()); } catch (e2) {}
    return ok({ video: uniqSorted(v), audio: uniqSorted(a) });
  });

  Q.selection = guard(function () {
    var seq = activeSeq();
    if (!seq) { return ok({ hasSequence: false, video: 0, audio: 0 }); }
    var v = 0, a = 0, sel = null;
    try { sel = seq.getSelection(); } catch (e) {}
    if (sel && sel.length !== undefined) {
      for (var i = 0; i < sel.length; i++) {
        var mt = '';
        try { mt = String(sel[i].mediaType); } catch (e2) {}
        if (mt === 'Audio') { a++; } else if (mt === 'Video') { v++; }
      }
    } else {
      var all = collectSelected(seq, true, true);
      for (var j = 0; j < all.length; j++) { if (all[j].video) { v++; } else { a++; } }
    }
    return ok({ hasSequence: true, sequence: String(seq.name), video: v, audio: a });
  });

  /** {kind: 'video'|'audio', name: '<display name>'} */
  Q.applyEffect = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    if (!hasQE()) { return fail('noQE'); }
    var isAudio = a.kind === 'audio';
    var targets = collectSelected(seq, !isAudio, isAudio);
    if (!targets.length) { return noTargetsError(seq, !isAudio, isAudio); }

    var fx = isAudio ? getAudioFx(a.name, false) : getVideoFx(a.name, false);
    if (!fx) { return fail('effectNotFound', a.name); }

    var qeSeq = qe.project.getActiveSequence();
    var frame = frameTicks(seq);
    var applied = 0, failed = 0;
    for (var i = 0; i < targets.length; i++) {
      var it = qeItemFor(qeSeq, targets[i], frame);
      if (!it) { failed++; continue; }
      if (addFxObject(it, fx, !isAudio)) { applied++; } else { failed++; }
    }
    if (!applied) { return fail('applyFailed', a.name, { total: targets.length }); }
    return ok({ applied: applied, failed: failed, total: targets.length });
  });

  /** {preset: {name, type, duration, effects: [...]}} as produced by presets.js */
  Q.applyPreset = guard(function (encoded) {
    var a = arg(encoded);
    var preset = a.preset;
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }

    var needVideo = false, needAudio = false, i, j;
    for (i = 0; i < preset.effects.length; i++) {
      if (preset.effects[i].media === 'audio') { needAudio = true; } else { needVideo = true; }
    }
    var targets = collectSelected(seq, needVideo, needAudio);
    if (!targets.length) { return noTargetsError(seq, needVideo, needAudio); }

    var useQE = hasQE();
    var qeSeq = useQE ? qe.project.getActiveSequence() : null;
    var frame = frameTicks(seq);
    var report = { clips: 0, total: targets.length, effectsAdded: 0, paramsSet: 0, paramsSkipped: 0, missing: [], warnings: [] };

    for (i = 0; i < targets.length; i++) {
      var t = targets[i];
      var media = t.video ? 'video' : 'audio';
      var clip = t.clip;
      var timing = clipTiming(clip);
      var qeIt = null, touched = false;

      for (j = 0; j < preset.effects.length; j++) {
        var fx = preset.effects[j];
        if ((fx.media || 'video') !== media) { continue; }
        var label = fx.displayName || derivedName(fx.matchName) || fx.matchName;
        var comp = null;

        if (fx.intrinsic) {
          comp = findComponent(clip, fx, false);
          if (!comp) { addUnique(report.warnings, 'intrinsic:' + label); continue; }
        } else {
          if (!useQE) { addUnique(report.missing, label); continue; }
          if (!qeIt) { qeIt = qeItemFor(qeSeq, t, frame); }
          if (!qeIt) { addUnique(report.warnings, 'clip:' + t.name); break; }
          var before = componentCount(clip);
          if (!addPresetFx(qeIt, fx, t.video)) { addUnique(report.missing, label); continue; }
          clip = refetch(seq, t);
          comp = findComponent(clip, fx, true);
          if (!comp && componentCount(clip) > before) { comp = clip.components[componentCount(clip) - 1]; }
          if (!comp) { addUnique(report.warnings, 'nocomp:' + label); continue; }
          report.effectsAdded++;
        }

        touched = true;
        var r = setParams(comp, fx, timing, preset);
        report.paramsSet += r.set;
        report.paramsSkipped += r.skipped;
      }
      if (touched) { report.clips++; }
    }

    if (!report.clips) { return fail('presetFailed', preset.name, report); }
    return ok(report);
  });

  // ------------------------------------------------------------------ collect files
  // Finds media used by the project that lives outside the project folder, and re-points
  // project items to the copies the panel makes under <project folder>/Imported/.
  var SKIP_EXT = { aep: 1, aepx: 1, prproj: 1, aegraphic: 1, mogrt: 1, plb: 1 };
  var STILL_EXT = { png: 1, jpg: 1, jpeg: 1, tif: 1, tiff: 1, exr: 1, tga: 1, dpx: 1, bmp: 1, gif: 1, psd: 1, webp: 1, heic: 1 };
  var SEQ_EXT = { png: 1, tif: 1, tiff: 1, exr: 1, tga: 1, dpx: 1 };

  function extOf(name) { var m = /\.([A-Za-z0-9]+)$/.exec(String(name)); return m ? m[1].toLowerCase() : ''; }
  function baseOf(p) { var s = String(p); var i = s.lastIndexOf('/'); return i < 0 ? s : s.substring(i + 1); }
  function dirOf(p) { var s = String(p); var i = s.lastIndexOf('/'); return i <= 0 ? '/' : s.substring(0, i); }

  function projectDir() {
    var p = '';
    try { p = String(app.project.path || ''); } catch (e) {}
    if (!p) { return ''; }
    return dirOf(p.replace(/\\/g, '/'));
  }

  function walkItems(item, fn, depth) {
    if (!item || depth > 40) { return; }
    var isBin = false;
    try { isBin = (item.type === 2 || item.type === 3); } catch (e0) { isBin = false; }   // ProjectItemType.BIN / ROOT
    var kids = null, n = 0;
    try { kids = item.children; n = kids ? kids.numItems : 0; } catch (e) { n = 0; }
    if (n) {
      for (var i = 0; i < n; i++) { walkItems(kids[i], fn, depth + 1); }
      return;
    }
    if (!isBin) { fn(item); }
  }

  function mediaPathOf(item) {
    try { if (item.isSequence && item.isSequence()) { return ''; } } catch (e) {}
    var p = '';
    try { p = String(item.getMediaPath() || ''); } catch (e2) { p = ''; }
    return p.replace(/\\/g, '/');
  }

  /** A numbered-stills sequence is one project item for many files: copying just the first file would break it. */
  function isImageSequence(item, path) {
    var ext = extOf(path);
    if (!STILL_EXT[ext]) { return false; }
    var meta = '';
    try { meta = String(item.getProjectMetadata() || ''); } catch (e) { meta = ''; }
    var m = /Column\.Intrinsic\.MediaType>([^<]*)</.exec(meta);
    if (m) {
      if (/still/i.test(m[1])) { return false; }
      if (/movie|video/i.test(m[1])) { return true; }
    }
    if (!SEQ_EXT[ext]) { return false; }
    var mm = /^(.*?)(\d{3,})(\.[A-Za-z0-9]+)$/.exec(baseOf(path));
    if (!mm) { return false; }
    var next = String(Number(mm[2]) + 1);
    while (next.length < mm[2].length) { next = '0' + next; }
    return new File(dirOf(path) + '/' + mm[1] + next + mm[3]).exists;
  }

  Q.scanMedia = guard(function () {
    var dir = projectDir();
    if (!dir) { return fail('noProject'); }
    var dirLow = dir.toLowerCase() + '/';
    var seen = {}, files = [], skipped = [], inside = 0, total = 0;

    walkItems(app.project.rootItem, function (item) {
      var p = mediaPathOf(item);
      if (!p) { return; }
      total++;
      var name = baseOf(p);
      try { if (item.isOffline && item.isOffline()) { skipped.push({ name: name, reason: 'offline' }); return; } } catch (e) {}
      if (p.toLowerCase().indexOf(dirLow) === 0) { inside++; return; }
      if (/QFX-SafeZone-/i.test(name)) { return; }                     // Quick FX's own overlay stills
      if (seen['$' + p]) { return; }
      seen['$' + p] = true;
      if (SKIP_EXT[extOf(p)]) { skipped.push({ name: name, reason: 'linked' }); return; }
      var f = new File(p);
      if (!f.exists) { skipped.push({ name: name, reason: 'missing' }); return; }
      if (isImageSequence(item, p)) { skipped.push({ name: name, reason: 'sequence' }); return; }
      files.push({ path: p, name: name, size: f.length });
    }, 0);

    return ok({ projectDir: dir, importedDir: dir + '/Imported', files: files, skipped: skipped, inside: inside, total: total });
  });

  /** {pairs: [{from, to}]} — point every project item that uses `from` at `to`. */
  Q.relinkMedia = guard(function (encoded) {
    var a = arg(encoded);
    var pairs = a.pairs || [], relinked = 0, failed = 0;
    walkItems(app.project.rootItem, function (item) {
      var p = mediaPathOf(item);
      if (!p) { return; }
      for (var i = 0; i < pairs.length; i++) {
        if (pairs[i].from !== p) { continue; }
        var done = false;
        try {
          var can = true;
          try { if (item.canChangeMediaPath) { can = item.canChangeMediaPath(); } } catch (e1) { can = true; }
          if (can) { item.changeMediaPath(pairs[i].to, true); done = true; }
        } catch (e2) { done = false; }
        if (done) { relinked++; } else { failed++; }
        break;
      }
    }, 0);
    return ok({ relinked: relinked, failed: failed });
  });

  /** {from, dir, name} — copy on the Premiere side. Only used when the panel has no Node; blocks Premiere while it copies. */
  Q.copyInto = guard(function (encoded) {
    var a = arg(encoded);
    var src = new File(a.from);
    if (!src.exists) { return fail('missing', a.from); }
    var folder = new Folder(a.dir);
    if (!folder.exists && !folder.create()) { return fail('mkdirFailed', a.dir); }
    var total = src.length, name = a.name, n = 2;
    var m = /^(.*?)(\.[A-Za-z0-9]+)?$/.exec(a.name);
    var dst = new File(a.dir + '/' + name);
    while (dst.exists) {
      if (dst.length === total) { return ok({ to: a.dir + '/' + name, reused: true, bytes: 0 }); }
      name = m[1] + ' (' + (n++) + ')' + (m[2] || '');
      dst = new File(a.dir + '/' + name);
      if (n > 500) { return fail('copyFailed', a.name); }
    }
    if (!src.copy(a.dir + '/' + name)) { return fail('copyFailed', a.name); }
    dst = new File(a.dir + '/' + name);
    if (!dst.exists || dst.length !== total) { try { dst.remove(); } catch (e) {} return fail('copyFailed', a.name); }
    return ok({ to: a.dir + '/' + name, reused: false, bytes: total });
  });

  // ------------------------------------------------------------------ auto collect (background watcher)
  // State lives on $.global, because every Quick FX window re-evaluates this file in the same engine.
  var W = $.global.__QFX_WATCH;
  if (!W) { W = $.global.__QFX_WATCH = { known: {}, dirty: false, bound: false, bindTried: false, events: 0 }; }
  if (!$.global.__QFX_onItemAdded) {
    $.global.__QFX_onItemAdded = function () {
      var w = $.global.__QFX_WATCH;
      if (w) { w.dirty = true; w.events++; }
    };
  }

  /** Cheap: is there a saved project, and did Premiere tell us something was imported? */
  Q.watchPoll = guard(function () {
    if (!W.bindTried) {
      W.bindTried = true;
      try { W.bound = !!app.bind('onItemAddedToProject', $.global.__QFX_onItemAdded); } catch (e) { W.bound = false; }
    }
    var path = '';
    try { path = String(app.project.path || ''); } catch (e2) { path = ''; }
    return ok({ project: path, dirty: !!W.dirty, bound: !!W.bound, events: W.events });
  });

  /**
   * Returns only files that appeared since the previous call. The first call for a project is a
   * baseline: what is already in the project is left alone (the manual command collects those),
   * except paths listed in `pending` — files a previous session found but did not finish.
   */
  Q.watchScan = guard(function (encoded) {
    var a = encoded ? arg(encoded) : {};
    var dir = projectDir();
    if (!dir) { return fail('noProject'); }
    var key = '$' + String(app.project.path);
    var known = W.known[key], baseline = !known, i;
    if (!known) { known = W.known[key] = {}; }
    var pending = {}, plist = a.pending || [];
    for (i = 0; i < plist.length; i++) { pending['$' + plist[i]] = true; }
    W.dirty = false;

    // Count project items per outside file. A file is "new" when more items use it than at the
    // baseline, so importing a baseline file again is noticed too. Files handed to the panel are not
    // remembered here: once relinked they are inside the project folder and drop out by themselves.
    var dirLow = dir.toLowerCase() + '/', files = [], items = 0, order = [], info = {};
    walkItems(app.project.rootItem, function (item) {
      var p = mediaPathOf(item);
      if (!p) { return; }
      items++;
      if (p.toLowerCase().indexOf(dirLow) === 0) { return; }
      if (/QFX-SafeZone-/i.test(p)) { return; }                        // Quick FX's own overlay stills
      var k = '$' + p;
      if (!info[k]) { info[k] = { n: 0, item: item, path: p }; order.push(k); }
      info[k].n++;
    }, 0);

    var NEVER = 1000000000;
    for (i = 0; i < order.length; i++) {
      var k = order[i], e = info[k], p = e.path;
      if (baseline && !pending[k]) { known[k] = e.n; continue; }
      if (known[k]) {
        if (e.n <= known[k]) { if (known[k] !== NEVER) { known[k] = e.n; } continue; }
      }
      try { if (e.item.isOffline && e.item.isOffline()) { continue; } } catch (e1) {}   // may come online later: look again next time
      if (SKIP_EXT[extOf(p)]) { known[k] = NEVER; continue; }
      var f = new File(p);
      if (!f.exists) { continue; }
      if (isImageSequence(e.item, p)) { known[k] = NEVER; continue; }
      files.push({ path: p, name: baseOf(p), size: f.length });
    }

    return ok({ project: String(app.project.path), projectDir: dir, importedDir: dir + '/Imported', files: files, baseline: baseline, items: items });
  });

  /** {text, kind: info|warning|error} — a line in Premiere's Events panel (and its status-bar indicator). */
  Q.notify = guard(function (encoded) {
    var a = arg(encoded);
    var kind = (a.kind === 'warning' || a.kind === 'error') ? a.kind : 'info';
    try { app.setSDKEventMessage(String(a.text), kind); } catch (e) { return fail('notifyFailed', String(e)); }
    return ok({});
  });

  // ------------------------------------------------------------------ safe zones
  // An overlay is an ordinary still (a transparent PNG the panel draws at the sequence's frame size)
  // placed on the top video track: 10 seconds from the playhead, trimmed by hand like any clip.
  var ZONE_RE = /QFX-SafeZone-([a-z0-9]+)-\d+x\d+/i;
  var ZONE_BIN = 'Quick FX';

  function secOf(t) { var n = NaN; try { n = Number(t.seconds); } catch (e) { n = NaN; } return n; }
  function makeTime(sec) { var t = new Time(); t.seconds = sec; return t; }

  function zoneIdOf(clip) {
    var m = null;
    try { m = ZONE_RE.exec(String(clip.name)); } catch (e) { m = null; }
    if (!m) { try { m = ZONE_RE.exec(String(clip.projectItem.name)); } catch (e2) { m = null; } }
    return m ? m[1].toLowerCase() : '';
  }

  function zoneClips(seq) {
    var out = [], nt = 0;
    try { nt = seq.videoTracks.numTracks; } catch (e) { nt = 0; }
    for (var ti = 0; ti < nt; ti++) {
      var clips = seq.videoTracks[ti].clips, n = 0;
      try { n = clips.numItems; } catch (e2) { n = 0; }
      for (var ci = 0; ci < n; ci++) {
        var id = zoneIdOf(clips[ci]);
        if (!id) { continue; }
        var dis = false;
        try { dis = !!clips[ci].disabled; } catch (e3) { dis = false; }
        out.push({ clip: clips[ci], track: ti, id: id, start: secOf(clips[ci].start), end: secOf(clips[ci].end), disabled: dis });
      }
    }
    return out;
  }

  function playheadOf(seq) {
    var s = NaN;
    try { s = secOf(seq.getPlayerPosition()); } catch (e) { s = NaN; }
    return isNaN(s) ? 0 : s;
  }

  function zoneAt(list, sec) {
    for (var i = 0; i < list.length; i++) { if (list[i].start - 0.0005 <= sec && sec < list[i].end - 0.0005) { return list[i]; } }
    return null;
  }

  Q.zoneState = guard(function () {
    var seq = activeSeq();
    if (!seq) { return ok({ hasSequence: false, zones: [], visible: 0, hidden: 0 }); }
    var list = zoneClips(seq), zones = [], visible = 0, hidden = 0, ph = playheadOf(seq);
    for (var i = 0; i < list.length; i++) {
      zones.push({ id: list[i].id, start: list[i].start, end: list[i].end, disabled: list[i].disabled, track: list[i].track + 1 });
      if (list[i].disabled) { hidden++; } else { visible++; }
    }
    var under = zoneAt(list, ph), w = 0, h = 0;
    try { w = Number(seq.frameSizeHorizontal); h = Number(seq.frameSizeVertical); } catch (e) { w = 0; h = 0; }
    return ok({ hasSequence: true, sequence: String(seq.name), width: w, height: h, playhead: ph,
      zones: zones, visible: visible, hidden: hidden, under: under ? under.id : '', projectDir: projectDir() });
  });

  function zoneBin(create) {
    var rootItem = app.project.rootItem, kids = rootItem.children, n = kids ? kids.numItems : 0;
    for (var i = 0; i < n; i++) {
      var isBin = false;
      try { isBin = kids[i].type === 2; } catch (e) { isBin = false; }
      if (isBin && String(kids[i].name) === ZONE_BIN) { return kids[i]; }
    }
    if (!create) { return null; }
    var made = null;
    try { made = rootItem.createBin(ZONE_BIN); } catch (e2) { made = null; }
    return made || zoneBin(false);
  }

  function zoneItem(path) {
    var want = baseOf(path);
    function find(bin) {
      if (!bin) { return null; }
      var kids = bin.children, n = kids ? kids.numItems : 0;
      for (var i = 0; i < n; i++) {
        var p = '';
        try { p = String(kids[i].getMediaPath() || '').replace(/\\/g, '/'); } catch (e) { p = ''; }
        if (p === path || (p && baseOf(p) === want)) { return kids[i]; }
      }
      return null;
    }
    var bin = zoneBin(true);
    var item = find(bin);
    if (item) { return item; }
    try { app.project.importFiles([path], true, bin || app.project.rootItem, false); } catch (e2) { return null; }
    return find(zoneBin(false)) || find(app.project.rootItem);
  }

  /** How far a clip may run on this track starting at `from`: 0 when something already sits there. */
  function freeUntil(track, from, to) {
    var clips = track.clips, n = 0, limit = to;
    try { n = clips.numItems; } catch (e) { n = 0; }
    for (var i = 0; i < n; i++) {
      var s = secOf(clips[i].start), e2 = secOf(clips[i].end);
      if (s - 0.0005 <= from && from < e2 - 0.0005) { return 0; }
      if (s > from && s < limit) { limit = s; }
    }
    return limit;
  }

  function addTopTrack(seq) {
    var before = seq.videoTracks.numTracks;
    try {
      app.enableQE();
      var qs = qe.project.getActiveSequence();
      qs.addTracks(1, before, 0);                       // one video track above the last, no audio tracks
    } catch (e) { return false; }
    return seq.videoTracks.numTracks > before;
  }

  /** {path, id, seconds} — put the overlay at the playhead (or swap the one already under it). */
  Q.zoneApply = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var path = String(a.path).replace(/\\/g, '/');
    if (!new File(path).exists) { return fail('zoneFileMissing', path); }
    var seconds = Number(a.seconds) > 0 ? Number(a.seconds) : 10;
    var ph = playheadOf(seq), list = zoneClips(seq);
    var old = zoneAt(list, ph), start, end, ti, replaced = false, addedTrack = false;

    if (old) {
      // same place, another platform: keep the length the editor gave it
      start = old.start; end = old.end; ti = old.track; replaced = true;
      var wasDisabled = old.disabled;
      try { old.clip.remove(false, false); } catch (e) { return fail('zoneReplaceFailed', String(e)); }
    } else {
      start = ph; end = ph + seconds;
      ti = seq.videoTracks.numTracks - 1;
      var lim = ti >= 0 ? freeUntil(seq.videoTracks[ti], start, end) : 0;
      if (lim - start < 1) {
        if (!addTopTrack(seq)) { return fail('noFreeTrack'); }
        addedTrack = true;
        ti = seq.videoTracks.numTracks - 1;
        lim = end;
      }
      end = lim;
    }

    var item = zoneItem(path);
    if (!item) { return fail('zoneImportFailed', path); }
    try { item.setInPoint(0, 4); item.setOutPoint(end - start, 4); } catch (e2) {}

    var track = seq.videoTracks[ti];
    try { track.overwriteClip(item, start); }
    catch (e3) {
      try { track.overwriteClip(item, makeTime(start)); } catch (e4) { return fail('zonePlaceFailed', String(e4)); }
    }

    var placed = null, now = zoneClips(seq);
    for (var i = 0; i < now.length; i++) {
      if (now[i].track === ti && Math.abs(now[i].start - start) < 0.06) { placed = now[i]; break; }
    }
    if (!placed) { return fail('zonePlaceFailed'); }
    if (Math.abs(placed.end - end) > 0.06) {
      try { placed.clip.end = makeTime(end); } catch (e5) {}
      placed.end = secOf(placed.clip.end);
    }
    if (replaced && wasDisabled) { try { placed.clip.disabled = true; } catch (e6) {} }

    return ok({ id: String(a.id || placed.id), start: placed.start, end: placed.end, seconds: placed.end - placed.start,
      track: ti + 1, replaced: replaced, addedTrack: addedTrack, exact: Math.abs(placed.end - end) <= 0.06 });
  });

  /** {hidden: true|false} — switch every overlay in the sequence off or on (the clips stay where they are). */
  Q.zoneToggle = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var list = zoneClips(seq), changed = 0, failed = 0, want = !!a.hidden;
    for (var i = 0; i < list.length; i++) {
      var okSet = false;
      try { list[i].clip.disabled = want; okSet = (!!list[i].clip.disabled) === want; } catch (e) { okSet = false; }
      if (okSet) { changed++; } else { failed++; }
    }
    if (!list.length) { return fail('noZones'); }
    if (failed && !changed) { return fail('zoneToggleFailed'); }
    return ok({ hidden: want, count: changed, failed: failed });
  });

  /** Remove every overlay from the sequence (the PNGs stay in the "Quick FX" bin). */
  Q.zoneRemoveAll = guard(function () {
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var list = zoneClips(seq), removed = 0;
    for (var i = list.length - 1; i >= 0; i--) {
      try { list[i].clip.remove(false, false); removed++; } catch (e) {}
    }
    if (!list.length) { return fail('noZones'); }
    return ok({ removed: removed, failed: list.length - removed });
  });

  // ------------------------------------------------------------------ keyframe easing
  // Premiere's scripting can neither read which keyframes are selected nor set bezier handles.
  // So the target is "the move under the playhead" (or every move) on the selected clips, in every
  // animated parameter of every effect, and the curve is written as in-between keyframes.
  // `records` (kept by the panel) remember which stretches were written that way, so applying
  // another curve replaces the in-betweens instead of easing between them.
  var EASE_MAX_KEYS = 4000, EASE_MAX_PER_SEG = 120, EPS = 0.0005;

  function easeClipKey(sel) {
    var id = '';
    try { id = String(sel.clip.nodeId || ''); } catch (e) { id = ''; }
    return id || ((sel.video ? 'v' : 'a') + sel.track + '@' + sel.startTicks + ':' + sel.name);
  }

  function keyList(prop) {
    var ks = null, out = [];
    try { ks = prop.getKeys(); } catch (e) { ks = null; }
    if (!ks) { return out; }
    for (var i = 0; i < ks.length; i++) {
      var s = secOf(ks[i]);
      if (!isNaN(s)) { out.push({ s: s, t: ks[i] }); }
    }
    out.sort(function (a, b) { return a.s - b.s; });
    return out;
  }

  function hasKeyAt(keys, sec) {
    for (var i = 0; i < keys.length; i++) { if (Math.abs(keys[i].s - sec) < EPS) { return true; } }
    return false;
  }

  function mixValue(a, b, y) {
    if (typeof a === 'number' && typeof b === 'number') { return a + (b - a) * y; }
    if (a && b && typeof a === 'object' && typeof b === 'object' && a.length !== undefined && a.length === b.length && a.length > 0 && a.length <= 4) {
      var out = [];
      for (var i = 0; i < a.length; i++) {
        if (typeof a[i] !== 'number' || typeof b[i] !== 'number') { return undefined; }
        out.push(a[i] + (b[i] - a[i]) * y);
      }
      return out;
    }
    return undefined;
  }

  function sameValue(a, b) {
    if (typeof a === 'number') { return Math.abs(a - b) < 1e-9; }
    for (var i = 0; i < a.length; i++) { if (Math.abs(a[i] - b[i]) >= 1e-9) { return false; } }
    return true;
  }

  function lutAt(lut, x) {
    var n = lut.length - 1, f = x * n, i = Math.floor(f);
    if (i >= n) { return lut[n]; }
    if (i < 0) { return lut[0]; }
    return lut[i] + (lut[i + 1] - lut[i]) * (f - i);
  }

  /** Every animated parameter on the selected clips, with the keyframe pairs the request is about. */
  function easeTargets(seq, mode, records) {
    var recMap = {}, i;
    for (i = 0; i < (records || []).length; i++) {
      var r = records[i], rk = '$' + r.c + '|' + r.k + '|' + r.p;
      (recMap[rk] || (recMap[rk] = [])).push(r);
    }
    var sels = collectSelected(seq, true, true), ph = playheadOf(seq), out = [];
    for (var si = 0; si < sels.length; si++) {
      var sel = sels[si], clip = sel.clip, timing = clipTiming(clip), cKey = easeClipKey(sel);
      var phKey = timing.inSec + (ph - secOf(clip.start)) * timing.speed;
      var comps = null, nc = 0;
      try { comps = clip.components; nc = comps.numItems; } catch (e) { nc = 0; }
      for (var ci = 0; ci < nc; ci++) {
        var comp = comps[ci], props = null, np = 0, cName = '', cMatch = '';
        try { props = comp.properties; np = props.numItems; cName = String(comp.displayName); cMatch = String(comp.matchName); } catch (e2) { np = 0; }
        for (var pi = 0; pi < np; pi++) {
          var prop = props[pi], tv = false;
          try { tv = prop.isTimeVarying(); } catch (e3) { tv = false; }
          if (!tv) { continue; }
          var keys = keyList(prop);
          if (keys.length < 2) { continue; }
          var pName = '';
          try { pName = String(prop.displayName); } catch (e4) { pName = ''; }
          var kKey = cMatch + '#' + ci, pKey = pName + '#' + pi;
          // stretches written earlier: still valid only while both end keyframes are where they were
          var recs = recMap['$' + cKey + '|' + kKey + '|' + pKey] || [], valid = [];
          for (i = 0; i < recs.length; i++) { if (hasKeyAt(keys, recs[i].a) && hasKeyAt(keys, recs[i].b)) { valid.push(recs[i]); } }
          var anchors = [];
          for (i = 0; i < keys.length; i++) {
            var inner = false;
            for (var v = 0; v < valid.length; v++) { if (keys[i].s > valid[v].a + EPS && keys[i].s < valid[v].b - EPS) { inner = true; break; } }
            if (!inner) { anchors.push(keys[i]); }
          }
          var segs = [];
          for (i = 0; i + 1 < anchors.length; i++) {
            var a = anchors[i], b = anchors[i + 1];
            if (mode === 'all') { segs.push([a, b]); continue; }
            var last = i + 2 === anchors.length;
            if (phKey >= a.s - EPS && (phKey < b.s - EPS || (last && phKey <= b.s + EPS))) { segs.push([a, b]); break; }
          }
          if (!segs.length) { continue; }
          out.push({ clipKey: cKey, compKey: kKey, paramKey: pKey, ident: cMatch + '|' + pName, comp: cName, param: pName,
            name: cName + ' · ' + pName, prop: prop, keys: keys, segs: segs, timing: timing });
        }
      }
    }
    return { targets: out, clips: sels.length };
  }

  /** {mode: 'playhead'|'all', records} — what an Apply would touch right now. */
  Q.easeInfo = guard(function (encoded) {
    var a = encoded ? arg(encoded) : {};
    var seq = activeSeq(), project = '';
    try { project = String(app.project.path || ''); } catch (e) { project = ''; }
    if (!seq) { return ok({ hasSequence: false, project: project, clips: 0, params: [], segments: 0 }); }
    var found = easeTargets(seq, a.mode === 'all' ? 'all' : 'playhead', a.records), list = [], byId = {}, segments = 0, seconds = 0;
    for (var i = 0; i < found.targets.length; i++) {
      var t = found.targets[i], e = byId['$' + t.ident];
      // the same parameter on several selected clips is one line in the panel
      if (!e) { e = byId['$' + t.ident] = { id: t.ident, comp: t.comp, param: t.param, name: t.name, moves: 0, clips: 0 }; list.push(e); }
      e.moves += t.segs.length; e.clips++;
      segments += t.segs.length;
      if (!seconds) { seconds = (t.segs[0][1].s - t.segs[0][0].s) / (t.timing.speed || 1); }
    }
    return ok({ hasSequence: true, project: project, clips: found.clips, params: list, segments: segments, seconds: seconds });
  });

  /** {mode, lut: [0…1] | null (= back to linear), records, only: [parameter ids] — the ones ticked in the panel} */
  Q.easeApply = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var mode = a.mode === 'all' ? 'all' : 'playhead', lut = a.lut && a.lut.length > 2 ? a.lut : null;
    var found = easeTargets(seq, mode, a.records);
    if (!found.clips) { return fail('noSelection'); }
    if (!found.targets.length) { return fail(mode === 'all' ? 'noKeyframes' : 'noEaseTarget'); }
    if (a.only) {
      // Premiere cannot tell a script which keyframes are selected, so the panel sends the ticked parameters
      var want = {}, kept = [], oi;
      for (oi = 0; oi < a.only.length; oi++) { want['$' + a.only[oi]] = true; }
      for (oi = 0; oi < found.targets.length; oi++) { if (want['$' + found.targets[oi].ident]) { kept.push(found.targets[oi]); } }
      if (!kept.length) { return fail('noParams'); }
      found.targets = kept;
    }

    var frame = 0;
    try { frame = Number(seq.timebase) / 254016000000; } catch (e) { frame = 0; }
    if (!(frame > 0.001 && frame < 1)) { frame = 1 / 25; }

    var added = 0, removed = 0, segments = 0, params = 0, partial = false;
    var skipped = { unsupported: 0, flat: 0, tooShort: 0 }, add = [], drop = [], undo = [];

    for (var ti = 0; ti < found.targets.length && !partial; ti++) {
      var t = found.targets[ti], prop = t.prop, touched = false, step = frame * (t.timing.speed || 1);
      var op = { c: t.clipKey, k: t.compKey, p: t.paramKey, added: [], removed: [] };     // enough to put this parameter back
      for (var si = 0; si < t.segs.length; si++) {
        var A = t.segs[si][0], B = t.segs[si][1], v0, v1;
        try { v0 = prop.getValueAtKey(A.t); v1 = prop.getValueAtKey(B.t); } catch (e2) { v0 = undefined; v1 = undefined; }
        if (mixValue(v0, v1, 0.5) === undefined) { skipped.unsupported++; continue; }
        var rec = { c: t.clipKey, k: t.compKey, p: t.paramKey, a: A.s, b: B.s };

        // whatever sat between the two keyframes goes first
        for (var ki = 0; ki < t.keys.length; ki++) {
          if (t.keys[ki].s > A.s + EPS && t.keys[ki].s < B.s - EPS) {
            var was;
            try { was = prop.getValueAtKey(t.keys[ki].t); } catch (e7) { was = undefined; }
            try { prop.removeKey(t.keys[ki].t); removed++; if (was !== undefined) { op.removed.push([t.keys[ki].s, was]); } } catch (e3) {}
          }
        }
        drop.push(rec);

        if (!lut) {
          try { prop.setInterpolationTypeAtKey(A.t, 0, 0); prop.setInterpolationTypeAtKey(B.t, 0, 1); } catch (e4) {}
          segments++; touched = true;
          continue;
        }
        if (sameValue(v0, v1)) { skipped.flat++; continue; }
        var n = Math.round((B.s - A.s) / step);
        if (n < 2) { skipped.tooShort++; continue; }
        var stride = Math.max(1, Math.ceil(n / EASE_MAX_PER_SEG));
        for (var k = stride; k < n; k += stride) {
          var tm = makeTime(A.s + k * step);
          try {
            prop.addKey(tm);
            prop.setValueAtKey(tm, mixValue(v0, v1, lutAt(lut, k / n)), (k + stride >= n) ? 1 : 0);
            try { prop.setInterpolationTypeAtKey(tm, 0, 0); } catch (e5) {}
            added++;
            op.added.push(A.s + k * step);
          } catch (e6) {}
        }
        add.push(rec);
        segments++; touched = true;
        if (added >= EASE_MAX_KEYS) { partial = true; break; }
      }
      if (touched) { params++; }
      if (op.added.length || op.removed.length) { undo.push(op); }
    }

    if (!segments) { return fail('easeNothing', '', { skipped: skipped }); }
    return ok({ segments: segments, params: params, clips: found.clips, added: added, removed: removed,
      skipped: skipped, partial: partial, linear: !lut, add: add, drop: drop, undo: undo });
  });


  /** Every clip of the sequence under the same key easeTargets() used — selection may have changed since. */
  function findClipByKey(seq, key) {
    var groups = [[seq.videoTracks, true], [seq.audioTracks, false]];
    for (var g = 0; g < groups.length; g++) {
      var tracks = groups[g][0], nt = 0;
      try { nt = tracks.numTracks; } catch (e) { nt = 0; }
      for (var t = 0; t < nt; t++) {
        var clips = tracks[t].clips, nc = 0;
        try { nc = clips.numItems; } catch (e2) { nc = 0; }
        for (var c = 0; c < nc; c++) {
          var sel = { clip: clips[c], track: t, index: c, video: groups[g][1], startTicks: String(clips[c].start.ticks), name: String(clips[c].name) };
          if (easeClipKey(sel) === key) { return clips[c]; }
        }
      }
    }
    return null;
  }

  function findParam(clip, compKey, paramKey) {
    var comps = null, nc = 0;
    try { comps = clip.components; nc = comps.numItems; } catch (e) { nc = 0; }
    for (var ci = 0; ci < nc; ci++) {
      var m = '';
      try { m = String(comps[ci].matchName); } catch (e2) { m = ''; }
      if (m + '#' + ci !== compKey) { continue; }
      var props = comps[ci].properties, np = 0;
      try { np = props.numItems; } catch (e3) { np = 0; }
      for (var pi = 0; pi < np; pi++) {
        var n = '';
        try { n = String(props[pi].displayName); } catch (e4) { n = ''; }
        if (n + '#' + pi === paramKey) { return props[pi]; }
      }
    }
    return null;
  }

  /** {ops: [{c,k,p, added:[sec…], removed:[[sec, value]…]}]} — take back one Apply: its in-betweens out, what it removed back in. */
  Q.easeUndo = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var ops = a.ops || [], params = 0, missing = 0, removed = 0, restored = 0;
    for (var i = 0; i < ops.length; i++) {
      var op = ops[i], clip = findClipByKey(seq, op.c), prop = clip ? findParam(clip, op.k, op.p) : null;
      if (!prop) { missing++; continue; }
      var keys = keyList(prop), j, k;
      for (j = 0; j < (op.added || []).length; j++) {
        for (k = 0; k < keys.length; k++) {
          if (Math.abs(keys[k].s - op.added[j]) < EPS) { try { prop.removeKey(keys[k].t); removed++; } catch (e) {} break; }
        }
      }
      var back = op.removed || [];
      for (j = 0; j < back.length; j++) {
        var tm = makeTime(back[j][0]);
        try {
          prop.addKey(tm);
          prop.setValueAtKey(tm, back[j][1], j === back.length - 1 ? 1 : 0);
          try { prop.setInterpolationTypeAtKey(tm, 0, 0); } catch (e2) {}
          restored++;
        } catch (e3) {}
      }
      params++;
    }
    if (!params) { return fail('undoMissing'); }
    return ok({ params: params, missing: missing, removed: removed, restored: restored });
  });

  // ------------------------------------------------------------------ downloads (YouTube …)
  var YT_BIN = 'YouTube';

  function rootBin(name, create) {
    var rootItem = app.project.rootItem, kids = rootItem.children, n = kids ? kids.numItems : 0;
    for (var i = 0; i < n; i++) {
      var isBin = false;
      try { isBin = kids[i].type === 2; } catch (e) { isBin = false; }
      if (isBin && String(kids[i].name) === name) { return kids[i]; }
    }
    if (!create) { return null; }
    var made = null;
    try { made = rootItem.createBin(name); } catch (e2) { made = null; }
    return made || rootBin(name, false);
  }

  function itemWithPath(bin, path) {
    if (!bin) { return null; }
    var kids = bin.children, n = kids ? kids.numItems : 0, low = String(path).toLowerCase();
    for (var i = 0; i < n; i++) {
      var p = '';
      try { p = String(kids[i].getMediaPath() || '').replace(/\\/g, '/'); } catch (e) { p = ''; }
      if (p && p.toLowerCase() === low) { return kids[i]; }
    }
    return null;
  }

  /** Where a download goes: <project folder>/Imported/YouTube (empty when the project is not saved yet). */
  Q.ytTarget = guard(function () {
    var dir = projectDir();
    return ok({ saved: !!dir, projectDir: dir, dir: dir ? dir + '/Imported/YouTube' : '' });
  });

  /** {path, bin} — the downloaded file into its site's bin of the Project panel ("YouTube", "TikTok" …); the same file is not imported twice. */
  Q.ytImport = guard(function (encoded) {
    var a = arg(encoded), path = String(a.path || '').replace(/\\/g, '/');
    var f = new File(path);
    if (!f.exists) { return fail('ytFileMissing', path); }
    var binName = strTrim(String(a.bin || '').replace(/[\\\/:*?"<>|]/g, ' ')).substring(0, 40) || YT_BIN;
    var bin = rootBin(binName, true);
    var item = itemWithPath(bin, path), existed = !!item;
    if (!item) {
      try { app.project.importFiles([path], true, bin || app.project.rootItem, false); } catch (e) { return fail('ytImportFailed', String(e)); }
      item = itemWithPath(rootBin(binName, false), path) || itemWithPath(app.project.rootItem, path);
    }
    if (!item) { return fail('ytImportFailed', baseOf(path)); }
    try { if (item.select) { item.select(); } } catch (e2) {}
    return ok({ name: String(item.name), bin: bin ? binName : '', existed: existed });
  });

  return Q;
})();
