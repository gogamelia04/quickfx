/*
 * Quick FX — ExtendScript side (runs inside Premiere).
 * ES3 only: no JSON, no Array#indexOf/forEach, no String#trim, no Date.now.
 *
 * Effects are added through the (unofficial) QE DOM, because Premiere's public
 * ExtendScript API cannot add effects. Parameter values and keyframes are then set
 * through the public API (Component / ComponentParam).
 */
var QuickFX = (function () {
  var Q = {};
  Q.version = '1.2.0';

  var TPS = 254016000000;            // ticks per second

  // ------------------------------------------------------------------ JSON (ES3)
  function quote(s) {
    var out = '"';
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i), code = s.charCodeAt(i);
      if (c === '"') { out += '\\"'; }
      else if (c === '\\') { out += '\\\\'; }
      else if (c === '\n') { out += '\\n'; }
      else if (c === '\r') { out += '\\r'; }
      else if (c === '\t') { out += '\\t'; }
      else if (code < 32 || code === 0x2028 || code === 0x2029) {
        var h = code.toString(16);
        while (h.length < 4) { h = '0' + h; }
        out += '\\u' + h;
      } else { out += c; }
    }
    return out + '"';
  }

  function stringify(v) {
    if (v === null || v === undefined) { return 'null'; }
    var t = typeof v;
    if (t === 'number') { return isFinite(v) ? String(v) : 'null'; }
    if (t === 'boolean') { return v ? 'true' : 'false'; }
    if (t === 'string') { return quote(v); }
    var i, parts = [];
    if (v instanceof Array) {
      for (i = 0; i < v.length; i++) { parts.push(stringify(v[i])); }
      return '[' + parts.join(',') + ']';
    }
    if (t === 'object') {
      for (var k in v) {
        if (v.hasOwnProperty(k)) {
          var val = v[k];
          if (val === undefined || typeof val === 'function') { continue; }
          parts.push(quote(String(k)) + ':' + stringify(val));
        }
      }
      return '{' + parts.join(',') + '}';
    }
    return 'null';
  }

  function parseJSON(text) {
    var s = String(text);
    var probe = s.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')
                 .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
                 .replace(/(?:^|:|,)(?:\s*\[)+/g, '');
    if (/^[\],:{}\s]*$/.test(probe)) { return eval('(' + s + ')'); }
    throw new Error('Invalid JSON from panel');
  }

  Q.stringify = stringify;
  Q.parseJSON = parseJSON;

  // ------------------------------------------------------------------ small helpers
  function ok(data) { return stringify({ ok: true, data: data }); }
  function fail(code, message, extra) {
    return stringify({ ok: false, code: code, message: message || '', extra: extra === undefined ? null : extra });
  }
  function arg(encoded) { return parseJSON(decodeURIComponent(String(encoded))); }
  function guard(fn) {
    return function (a) {
      try { return fn(a); }
      catch (e) {
        var msg = String(e);
        try { if (e && e.line) { msg += ' (line ' + e.line + ')'; } } catch (e2) {}
        return fail('exception', msg);
      }
    };
  }
  function strTrim(s) { return String(s === null || s === undefined ? '' : s).replace(/^\s+|\s+$/g, ''); }
  function normName(s) { return strTrim(s).toLowerCase().replace(/\s+/g, ' '); }
  function contains(arr, v) { for (var i = 0; i < arr.length; i++) { if (arr[i] === v) { return true; } } return false; }
  function addUnique(arr, v) { if (!contains(arr, v)) { arr.push(v); } }
  function toArray(list) {
    var out = [];
    if (!list) { return out; }
    var n = 0;
    try { n = list.length; } catch (e) { n = 0; }
    for (var i = 0; i < n; i++) { out.push(String(list[i])); }
    return out;
  }
  function uniqSorted(arr) {
    var seen = {}, out = [];
    for (var i = 0; i < arr.length; i++) {
      var s = strTrim(arr[i]);
      if (!s || seen['$' + s]) { continue; }
      seen['$' + s] = true;
      out.push(s);
    }
    out.sort(function (a, b) { var x = a.toLowerCase(), y = b.toLowerCase(); return x < y ? -1 : (x > y ? 1 : 0); });
    return out;
  }

  function hasQE() {
    try { app.enableQE(); } catch (e) {}
    try { return (typeof qe !== 'undefined') && !!qe && !!qe.project; } catch (e2) { return false; }
  }

  function activeSeq() {
    try { return app.project ? app.project.activeSequence : null; } catch (e) { return null; }
  }

  function frameTicks(seq) {
    var f = 0;
    try { f = Number(seq.timebase); } catch (e) {}
    return (f && f > 0) ? f : TPS / 25;
  }

  // ------------------------------------------------------------------ preset files on disk
  function findPresetFiles() {
    var out = [];
    var docs = null;
    try { docs = Folder.myDocuments; } catch (e) {}
    if (!docs) { return out; }
    var bases = ['Adobe/Premiere Pro', 'Adobe/Premiere', 'Adobe/Adobe Premiere Pro', 'Adobe/Adobe Premiere'];
    for (var b = 0; b < bases.length; b++) {
      var base = new Folder(docs.fsName + '/' + bases[b]);
      if (!base.exists) { continue; }
      var versions = base.getFiles();
      for (var i = 0; i < versions.length; i++) {
        var vf = versions[i];
        if (!(vf instanceof Folder)) { continue; }
        var profiles = vf.getFiles();
        for (var j = 0; j < profiles.length; j++) {
          var pf = profiles[j];
          if (!(pf instanceof Folder)) { continue; }
          var pname = decodeURI(pf.name);
          if (pname.indexOf('Profile') !== 0) { continue; }
          var f = new File(pf.fsName + '/Effect Presets and Custom Items.prfpset');
          if (!f.exists) { continue; }
          var mod = 0;
          try { mod = f.modified ? f.modified.getTime() : 0; } catch (e3) {}
          out.push({ path: f.fsName, version: decodeURI(vf.name), profile: pname, modified: mod, size: f.length });
        }
      }
    }
    return out;
  }

  // ------------------------------------------------------------------ selection
  function scanTracks(tracks, isVideo, out) {
    var nt = 0;
    try { nt = tracks.numTracks; } catch (e) {}
    for (var t = 0; t < nt; t++) {
      var clips = tracks[t].clips;
      var nc = clips.numItems;
      for (var c = 0; c < nc; c++) {
        var cl = clips[c], sel = false;
        try { sel = cl.isSelected(); } catch (e2) {}
        if (sel) {
          out.push({ clip: cl, track: t, index: c, video: isVideo, startTicks: String(cl.start.ticks), name: String(cl.name) });
        }
      }
    }
  }

  function collectSelected(seq, wantVideo, wantAudio) {
    var out = [];
    if (wantVideo) { scanTracks(seq.videoTracks, true, out); }
    if (wantAudio) { scanTracks(seq.audioTracks, false, out); }
    return out;
  }

  function noTargetsError(seq, wantVideo, wantAudio) {
    var any = collectSelected(seq, true, true).length;
    if (!any) { return fail('noSelection'); }
    if (wantVideo && !wantAudio) { return fail('noVideoSelected'); }
    if (wantAudio && !wantVideo) { return fail('noAudioSelected'); }
    return fail('noSelection');
  }

  /** Same clip, re-read after the QE DOM changed it (the old object can be stale). */
  function refetch(seq, sel) {
    try {
      var tracks = sel.video ? seq.videoTracks : seq.audioTracks;
      var clips = tracks[sel.track].clips;
      for (var c = 0; c < clips.numItems; c++) {
        if (String(clips[c].start.ticks) === sel.startTicks) { return clips[c]; }
      }
    } catch (e) {}
    return sel.clip;
  }

  /** QE track item for a selected clip: match by start time, fall back to position on the track. */
  function qeItemFor(qeSeq, sel, frame) {
    var qt = null;
    try { qt = sel.video ? qeSeq.getVideoTrackAt(sel.track) : qeSeq.getAudioTrackAt(sel.track); } catch (e) {}
    if (!qt) { return null; }
    var target = Number(sel.startTicks);
    var best = null, bestD = -1, ord = -1, byOrd = null, n = 0;
    try { n = qt.numItems; } catch (e2) {}
    for (var i = 0; i < n; i++) {
      var it = null;
      try { it = qt.getItemAt(i); } catch (e3) {}
      if (!it) { continue; }
      var ty = '';
      try { ty = String(it.type); } catch (e4) {}
      if (ty === 'Empty' || ty === 'Transition') { continue; }
      ord++;
      if (ord === sel.index) { byOrd = it; }
      var st = NaN;
      try { st = Number(it.start.ticks); } catch (e5) {}
      if (!isNaN(st)) {
        var d = Math.abs(st - target);
        if (best === null || d < bestD) { best = it; bestD = d; }
      }
    }
    if (best !== null && bestD <= frame / 2) { return best; }
    if (byOrd) { return byOrd; }
    return (best !== null && bestD <= frame * 2) ? best : null;
  }

  // ------------------------------------------------------------------ effect lookup
  function getAudioFx(name, byMatchName) {
    var fx = null;
    try { fx = byMatchName ? qe.project.getAudioEffectByName(name, 1, true) : qe.project.getAudioEffectByName(name); } catch (e) {}
    if (!fx && !byMatchName) {
      try { fx = qe.project.getAudioEffectByName(name, 1); } catch (e2) {}
    }
    return fx || null;
  }

  function getVideoFx(name, byMatchName) {
    var fx = null;
    try { fx = byMatchName ? qe.project.getVideoEffectByName(name, true) : qe.project.getVideoEffectByName(name); } catch (e) {}
    return fx || null;
  }

  function addFxObject(qeIt, fxObj, isVideo) {
    var r;
    try { r = isVideo ? qeIt.addVideoEffect(fxObj) : qeIt.addAudioEffect(fxObj); }
    catch (e) { return false; }
    return r !== false;
  }

  /** "AE.ADBE Gaussian Blur 2" -> "Gaussian Blur" */
  function derivedName(matchName) {
    var s = strTrim(matchName).replace(/^(AE|PR)\.ADBE\s+/, '').replace(/^ADBE\s+/, '');
    return s.replace(/\s+\d+$/, '');
  }

  /** Add the effect a preset needs; try the saved display name first, then the match name. */
  function addPresetFx(qeIt, fx, isVideo) {
    var tries = [];
    if (fx.displayName) { tries.push([fx.displayName, false]); }
    var d = derivedName(fx.matchName);
    if (d && d !== fx.displayName) { tries.push([d, false]); }
    if (fx.matchName) { tries.push([fx.matchName, true]); }
    for (var i = 0; i < tries.length; i++) {
      var obj = isVideo ? getVideoFx(tries[i][0], tries[i][1]) : getAudioFx(tries[i][0], tries[i][1]);
      if (!obj) { continue; }
      if (addFxObject(qeIt, obj, isVideo)) { return true; }
    }
    return false;
  }

  function componentCount(clip) {
    try { return clip.components.numItems; } catch (e) { return 0; }
  }

  function findComponent(clip, fx, fromEnd) {
    var comps = clip.components, n = componentCount(clip), i, c;
    var wantMatch = strTrim(fx.matchName), wantName = normName(fx.displayName);
    for (var pass = 0; pass < 2; pass++) {
      for (var k = 0; k < n; k++) {
        i = fromEnd ? n - 1 - k : k;
        c = comps[i];
        try {
          if (pass === 0 && wantMatch && String(c.matchName) === wantMatch) { return c; }
          if (pass === 1 && wantName && normName(c.displayName) === wantName) { return c; }
        } catch (e) {}
      }
    }
    return null;
  }

  // ------------------------------------------------------------------ parameter replay
  function clipTiming(clip) {
    var inS = 0, outS = 0, speed = 1;
    try { inS = clip.inPoint.seconds; outS = clip.outPoint.seconds; } catch (e) {}
    try { speed = Math.abs(Number(clip.getSpeed())); } catch (e2) { speed = 1; }
    if (!(speed > 0.01 && speed < 100)) { speed = 1; }
    return { inSec: inS, outSec: outS, dur: Math.max(0, outS - inS), speed: speed };
  }

  /**
   * Keyframe times live in source-media time (they stretch with clip speed), so offsets
   * are converted by targetSpeed / presetSpeed to keep the same on-timeline timing.
   * Preset "Type": 0 = scale to clip length, 1 = anchor to In point, 2 = anchor to Out point.
   */
  function mapTime(rel, timing, preset) {
    var type = preset.type || 0;
    var pd = preset.duration || 0;
    var ps = preset.speed > 0 ? preset.speed : 1;
    var k = (timing.speed || 1) / ps;
    if (type === 2) { return timing.outSec - (pd - rel) * k; }
    if (type === 0 && pd > 0 && timing.dur > 0) { return timing.inSec + rel * (timing.dur / pd); }
    return timing.inSec + rel * k;
  }

  /** Premiere keyframe interpolation codes: 0 linear, 4 hold, 5 bezier (1–3 are legacy eases). */
  function interpCode(code) {
    if (code === 0 || code === 4 || code === 5) { return code; }
    if (code === 1 || code === 2 || code === 3) { return 5; }
    return 0;
  }

  function toValue(kind, v) {
    if (kind === 'point') { return [Number(v[0]), Number(v[1])]; }
    if (kind === 'bool') { return !!v; }
    return Number(v);
  }

  function makeTime(sec) { var t = new Time(); t.seconds = sec; return t; }

  function setStatic(prop, kind, v, updateUI) {
    if (v === null || v === undefined) { return false; }
    if (kind === 'color') {
      prop.setColorValue(v.a, v.r, v.g, v.b, updateUI);
      return true;
    }
    prop.setValue(toValue(kind, v), updateUI);
    return true;
  }

  function cleanupKeys(prop, placed) {
    var ks = null;
    try { ks = prop.getKeys(); } catch (e) { return; }
    if (!ks || !ks.length) { return; }
    for (var i = 0; i < ks.length; i++) {
      var s = NaN;
      try { s = ks[i].seconds; } catch (e2) {}
      if (isNaN(s)) { continue; }
      var keep = false;
      for (var j = 0; j < placed.length; j++) { if (Math.abs(placed[j] - s) < 0.0005) { keep = true; break; } }
      if (!keep) { try { prop.removeKey(ks[i]); } catch (e3) {} }
    }
  }

  function setOne(prop, p, timing, preset, updateUI) {
    var keys = p.keys || [];
    var canKey = false;
    try { canKey = prop.areKeyframesSupported(); } catch (e) {}
    var animate = keys.length > 0 && canKey && p.kind !== 'color';

    // A preset replaces what is there: drop existing animation first.
    try { if (prop.isTimeVarying()) { prop.setTimeVarying(false); } } catch (e2) {}

    if (!animate) {
      return setStatic(prop, p.kind, keys.length ? keys[0].v : p.value, updateUI);
    }

    prop.setTimeVarying(true);
    var placed = [];
    for (var i = 0; i < keys.length; i++) {
      var sec = mapTime(keys[i].t, timing, preset);
      var tm = makeTime(sec);
      prop.addKey(tm);
      prop.setValueAtKey(tm, toValue(p.kind, keys[i].v), updateUI);
      try { prop.setInterpolationTypeAtKey(tm, interpCode(keys[i].interp), updateUI); } catch (e3) {}
      placed.push(sec);
    }
    cleanupKeys(prop, placed);
    return true;
  }

  function setParams(comp, fx, timing, preset) {
    var res = { set: 0, skipped: 0 };
    var props = comp.properties;
    var n = 0;
    try { n = props.numItems; } catch (e) {}
    var byName = {}, i;
    for (i = 0; i < n; i++) {
      var dn = '';
      try { dn = normName(props[i].displayName); } catch (e2) {}
      if (dn) {
        if (!byName['$' + dn]) { byName['$' + dn] = []; }
        byName['$' + dn].push(i);
      }
    }
    var list = fx.params || [];
    var aligned = list.length === n;
    var seen = {};
    var lastSettable = -1;
    for (i = 0; i < list.length; i++) {
      if (list[i].kind !== 'arb' && list[i].kind !== 'ui' && list[i].kind !== 'unknown') { lastSettable = i; }
    }
    for (i = 0; i < list.length; i++) {
      var p = list[i];
      var key = normName(p.name);
      if (key) { seen['$' + key] = (seen['$' + key] || 0) + 1; }
      if (p.kind === 'ui') { continue; }
      if (p.kind === 'arb' || p.kind === 'unknown') { res.skipped++; continue; }
      var idx = -1;
      var occ = key ? byName['$' + key] : null;
      if (occ && occ.length >= seen['$' + key]) { idx = occ[seen['$' + key] - 1]; }
      if (idx < 0 && aligned && p.index >= 0 && p.index < n) { idx = p.index; }
      if (idx < 0) { res.skipped++; continue; }
      var ok2 = false;
      try { ok2 = setOne(props[idx], p, timing, preset, i === lastSettable ? 1 : 0); } catch (e3) { ok2 = false; }
      if (ok2) { res.set++; } else { res.skipped++; }
    }
    return res;
  }

  // ------------------------------------------------------------------ public API
  Q.ping = guard(function () {
    return ok({ version: Q.version, app: String(app.version), qe: hasQE() });
  });

  Q.info = guard(function () {
    var files = [];
    try { files = findPresetFiles(); } catch (e) {}
    var seq = activeSeq();
    return ok({
      version: Q.version,
      appVersion: String(app.version),
      os: String($.os),
      qe: hasQE(),
      hasSequence: !!seq,
      presetFiles: files
    });
  });

  Q.listEffects = guard(function () {
    if (!hasQE()) { return fail('noQE'); }
    var v = [], a = [];
    try { v = toArray(qe.project.getVideoEffectList()); } catch (e) {}
    try { a = toArray(qe.project.getAudioEffectList()); } catch (e2) {}
    return ok({ video: uniqSorted(v), audio: uniqSorted(a) });
  });

  Q.selection = guard(function () {
    var seq = activeSeq();
    if (!seq) { return ok({ hasSequence: false, video: 0, audio: 0 }); }
    var v = 0, a = 0, sel = null;
    try { sel = seq.getSelection(); } catch (e) {}
    if (sel && sel.length !== undefined) {
      for (var i = 0; i < sel.length; i++) {
        var mt = '';
        try { mt = String(sel[i].mediaType); } catch (e2) {}
        if (mt === 'Audio') { a++; } else if (mt === 'Video') { v++; }
      }
    } else {
      var all = collectSelected(seq, true, true);
      for (var j = 0; j < all.length; j++) { if (all[j].video) { v++; } else { a++; } }
    }
    return ok({ hasSequence: true, sequence: String(seq.name), video: v, audio: a });
  });

  /** {kind: 'video'|'audio', name: '<display name>'} */
  Q.applyEffect = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    if (!hasQE()) { return fail('noQE'); }
    var isAudio = a.kind === 'audio';
    var targets = collectSelected(seq, !isAudio, isAudio);
    if (!targets.length) { return noTargetsError(seq, !isAudio, isAudio); }

    var fx = isAudio ? getAudioFx(a.name, false) : getVideoFx(a.name, false);
    if (!fx) { return fail('effectNotFound', a.name); }

    var qeSeq = qe.project.getActiveSequence();
    var frame = frameTicks(seq);
    var applied = 0, failed = 0;
    for (var i = 0; i < targets.length; i++) {
      var it = qeItemFor(qeSeq, targets[i], frame);
      if (!it) { failed++; continue; }
      if (addFxObject(it, fx, !isAudio)) { applied++; } else { failed++; }
    }
    if (!applied) { return fail('applyFailed', a.name, { total: targets.length }); }
    return ok({ applied: applied, failed: failed, total: targets.length });
  });

  /** {preset: {name, type, duration, effects: [...]}} as produced by presets.js */
  Q.applyPreset = guard(function (encoded) {
    var a = arg(encoded);
    var preset = a.preset;
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }

    var needVideo = false, needAudio = false, i, j;
    for (i = 0; i < preset.effects.length; i++) {
      if (preset.effects[i].media === 'audio') { needAudio = true; } else { needVideo = true; }
    }
    var targets = collectSelected(seq, needVideo, needAudio);
    if (!targets.length) { return noTargetsError(seq, needVideo, needAudio); }

    var useQE = hasQE();
    var qeSeq = useQE ? qe.project.getActiveSequence() : null;
    var frame = frameTicks(seq);
    var report = { clips: 0, total: targets.length, effectsAdded: 0, paramsSet: 0, paramsSkipped: 0, missing: [], warnings: [] };

    for (i = 0; i < targets.length; i++) {
      var t = targets[i];
      var media = t.video ? 'video' : 'audio';
      var clip = t.clip;
      var timing = clipTiming(clip);
      var qeIt = null, touched = false;

      for (j = 0; j < preset.effects.length; j++) {
        var fx = preset.effects[j];
        if ((fx.media || 'video') !== media) { continue; }
        var label = fx.displayName || derivedName(fx.matchName) || fx.matchName;
        var comp = null;

        if (fx.intrinsic) {
          comp = findComponent(clip, fx, false);
          if (!comp) { addUnique(report.warnings, 'intrinsic:' + label); continue; }
        } else {
          if (!useQE) { addUnique(report.missing, label); continue; }
          if (!qeIt) { qeIt = qeItemFor(qeSeq, t, frame); }
          if (!qeIt) { addUnique(report.warnings, 'clip:' + t.name); break; }
          var before = componentCount(clip);
          if (!addPresetFx(qeIt, fx, t.video)) { addUnique(report.missing, label); continue; }
          clip = refetch(seq, t);
          comp = findComponent(clip, fx, true);
          if (!comp && componentCount(clip) > before) { comp = clip.components[componentCount(clip) - 1]; }
          if (!comp) { addUnique(report.warnings, 'nocomp:' + label); continue; }
          report.effectsAdded++;
        }

        touched = true;
        var r = setParams(comp, fx, timing, preset);
        report.paramsSet += r.set;
        report.paramsSkipped += r.skipped;
      }
      if (touched) { report.clips++; }
    }

    if (!report.clips) { return fail('presetFailed', preset.name, report); }
    return ok(report);
  });

  return Q;
})();
