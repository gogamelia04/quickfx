/*
 * Quick FX — ExtendScript side (runs inside Premiere).
 * ES3 only: no JSON, no Array#indexOf/forEach, no String#trim, no Date.now.
 *
 * Effects are added through the (unofficial) QE DOM, because Premiere's public
 * ExtendScript API cannot add effects. Parameter values and keyframes are then set
 * through the public API (Component / ComponentParam).
 */
var QuickFX = (function () {
  var Q = {};
  Q.version = '1.30.0';

  var TPS = 254016000000;            // ticks per second

  // ------------------------------------------------------------------ JSON (ES3)
  function quote(s) {
    var out = '"';
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i), code = s.charCodeAt(i);
      if (c === '"') { out += '\\"'; }
      else if (c === '\\') { out += '\\\\'; }
      else if (c === '\n') { out += '\\n'; }
      else if (c === '\r') { out += '\\r'; }
      else if (c === '\t') { out += '\\t'; }
      else if (code < 32 || code === 0x2028 || code === 0x2029) {
        var h = code.toString(16);
        while (h.length < 4) { h = '0' + h; }
        out += '\\u' + h;
      } else { out += c; }
    }
    return out + '"';
  }

  function stringify(v) {
    if (v === null || v === undefined) { return 'null'; }
    var t = typeof v;
    if (t === 'number') { return isFinite(v) ? String(v) : 'null'; }
    if (t === 'boolean') { return v ? 'true' : 'false'; }
    if (t === 'string') { return quote(v); }
    var i, parts = [];
    if (v instanceof Array) {
      for (i = 0; i < v.length; i++) { parts.push(stringify(v[i])); }
      return '[' + parts.join(',') + ']';
    }
    if (t === 'object') {
      for (var k in v) {
        if (v.hasOwnProperty(k)) {
          var val = v[k];
          if (val === undefined || typeof val === 'function') { continue; }
          parts.push(quote(String(k)) + ':' + stringify(val));
        }
      }
      return '{' + parts.join(',') + '}';
    }
    return 'null';
  }

  function parseJSON(text) {
    var s = String(text);
    var probe = s.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')
                 .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
                 .replace(/(?:^|:|,)(?:\s*\[)+/g, '');
    if (/^[\],:{}\s]*$/.test(probe)) { return eval('(' + s + ')'); }
    throw new Error('Invalid JSON from panel');
  }

  Q.stringify = stringify;
  Q.parseJSON = parseJSON;

  // ------------------------------------------------------------------ small helpers
  function ok(data) { return stringify({ ok: true, data: data }); }
  function fail(code, message, extra) {
    return stringify({ ok: false, code: code, message: message || '', extra: extra === undefined ? null : extra });
  }
  function arg(encoded) { return parseJSON(decodeURIComponent(String(encoded))); }
  function guard(fn) {
    return function (a) {
      try { return fn(a); }
      catch (e) {
        var msg = String(e);
        try { if (e && e.line) { msg += ' (line ' + e.line + ')'; } } catch (e2) {}
        return fail('exception', msg);
      }
    };
  }
  function strTrim(s) { return String(s === null || s === undefined ? '' : s).replace(/^\s+|\s+$/g, ''); }
  function normName(s) { return strTrim(s).toLowerCase().replace(/\s+/g, ' '); }
  function contains(arr, v) { for (var i = 0; i < arr.length; i++) { if (arr[i] === v) { return true; } } return false; }
  function addUnique(arr, v) { if (!contains(arr, v)) { arr.push(v); } }
  function toArray(list) {
    var out = [];
    if (!list) { return out; }
    var n = 0;
    try { n = list.length; } catch (e) { n = 0; }
    for (var i = 0; i < n; i++) { out.push(String(list[i])); }
    return out;
  }
  function uniqSorted(arr) {
    var seen = {}, out = [];
    for (var i = 0; i < arr.length; i++) {
      var s = strTrim(arr[i]);
      if (!s || seen['$' + s]) { continue; }
      seen['$' + s] = true;
      out.push(s);
    }
    out.sort(function (a, b) { var x = a.toLowerCase(), y = b.toLowerCase(); return x < y ? -1 : (x > y ? 1 : 0); });
    return out;
  }

  function hasQE() {
    try { app.enableQE(); } catch (e) {}
    try { return (typeof qe !== 'undefined') && !!qe && !!qe.project; } catch (e2) { return false; }
  }

  function activeSeq() {
    try { return app.project ? app.project.activeSequence : null; } catch (e) { return null; }
  }

  function frameTicks(seq) {
    var f = 0;
    try { f = Number(seq.timebase); } catch (e) {}
    return (f && f > 0) ? f : TPS / 25;
  }

  // ------------------------------------------------------------------ preset files on disk
  function findPresetFiles() {
    var out = [];
    var docs = null;
    try { docs = Folder.myDocuments; } catch (e) {}
    if (!docs) { return out; }
    var bases = ['Adobe/Premiere Pro', 'Adobe/Premiere', 'Adobe/Adobe Premiere Pro', 'Adobe/Adobe Premiere'];
    for (var b = 0; b < bases.length; b++) {
      var base = new Folder(docs.fsName + '/' + bases[b]);
      if (!base.exists) { continue; }
      var versions = base.getFiles();
      for (var i = 0; i < versions.length; i++) {
        var vf = versions[i];
        if (!(vf instanceof Folder)) { continue; }
        var profiles = vf.getFiles();
        for (var j = 0; j < profiles.length; j++) {
          var pf = profiles[j];
          if (!(pf instanceof Folder)) { continue; }
          var pname = decodeURI(pf.name);
          if (pname.indexOf('Profile') !== 0) { continue; }
          var f = new File(pf.fsName + '/Effect Presets and Custom Items.prfpset');
          if (!f.exists) { continue; }
          var mod = 0;
          try { mod = f.modified ? f.modified.getTime() : 0; } catch (e3) {}
          out.push({ path: f.fsName, version: decodeURI(vf.name), profile: pname, modified: mod, size: f.length });
        }
      }
    }
    return out;
  }

  // ------------------------------------------------------------------ selection
  function scanTracks(tracks, isVideo, out) {
    var nt = 0;
    try { nt = tracks.numTracks; } catch (e) {}
    for (var t = 0; t < nt; t++) {
      var clips = tracks[t].clips;
      var nc = clips.numItems;
      for (var c = 0; c < nc; c++) {
        var cl = clips[c], sel = false;
        try { sel = cl.isSelected(); } catch (e2) {}
        if (sel) {
          out.push({ clip: cl, track: t, index: c, video: isVideo, startTicks: String(cl.start.ticks), name: String(cl.name) });
        }
      }
    }
  }

  function collectSelected(seq, wantVideo, wantAudio) {
    var out = [];
    if (wantVideo) { scanTracks(seq.videoTracks, true, out); }
    if (wantAudio) { scanTracks(seq.audioTracks, false, out); }
    return out;
  }

  function noTargetsError(seq, wantVideo, wantAudio) {
    var any = collectSelected(seq, true, true).length;
    if (!any) { return fail('noSelection'); }
    if (wantVideo && !wantAudio) { return fail('noVideoSelected'); }
    if (wantAudio && !wantVideo) { return fail('noAudioSelected'); }
    return fail('noSelection');
  }

  /** Same clip, re-read after the QE DOM changed it (the old object can be stale). */
  function refetch(seq, sel) {
    try {
      var tracks = sel.video ? seq.videoTracks : seq.audioTracks;
      var clips = tracks[sel.track].clips;
      for (var c = 0; c < clips.numItems; c++) {
        if (String(clips[c].start.ticks) === sel.startTicks) { return clips[c]; }
      }
    } catch (e) {}
    return sel.clip;
  }

  /** QE track item for a selected clip: match by start time, fall back to position on the track. */
  function qeItemFor(qeSeq, sel, frame) {
    var qt = null;
    try { qt = sel.video ? qeSeq.getVideoTrackAt(sel.track) : qeSeq.getAudioTrackAt(sel.track); } catch (e) {}
    if (!qt) { return null; }
    var target = Number(sel.startTicks);
    var best = null, bestD = -1, ord = -1, byOrd = null, n = 0;
    try { n = qt.numItems; } catch (e2) {}
    for (var i = 0; i < n; i++) {
      var it = null;
      try { it = qt.getItemAt(i); } catch (e3) {}
      if (!it) { continue; }
      var ty = '';
      try { ty = String(it.type); } catch (e4) {}
      if (ty === 'Empty' || ty === 'Transition') { continue; }
      ord++;
      if (ord === sel.index) { byOrd = it; }
      var st = NaN;
      try { st = Number(it.start.ticks); } catch (e5) {}
      if (!isNaN(st)) {
        var d = Math.abs(st - target);
        if (best === null || d < bestD) { best = it; bestD = d; }
      }
    }
    if (best !== null && bestD <= frame / 2) { return best; }
    if (byOrd) { return byOrd; }
    return (best !== null && bestD <= frame * 2) ? best : null;
  }

  // ------------------------------------------------------------------ effect lookup
  function getAudioFx(name, byMatchName) {
    var fx = null;
    try { fx = byMatchName ? qe.project.getAudioEffectByName(name, 1, true) : qe.project.getAudioEffectByName(name); } catch (e) {}
    if (!fx && !byMatchName) {
      try { fx = qe.project.getAudioEffectByName(name, 1); } catch (e2) {}
    }
    return fx || null;
  }

  function getVideoFx(name, byMatchName) {
    var fx = null;
    try { fx = byMatchName ? qe.project.getVideoEffectByName(name, true) : qe.project.getVideoEffectByName(name); } catch (e) {}
    return fx || null;
  }

  function addFxObject(qeIt, fxObj, isVideo) {
    var r;
    try { r = isVideo ? qeIt.addVideoEffect(fxObj) : qeIt.addAudioEffect(fxObj); }
    catch (e) { return false; }
    return r !== false;
  }

  /** "AE.ADBE Gaussian Blur 2" -> "Gaussian Blur" */
  function derivedName(matchName) {
    var s = strTrim(matchName).replace(/^(AE|PR)\.ADBE\s+/, '').replace(/^ADBE\s+/, '');
    return s.replace(/\s+\d+$/, '');
  }

  /** Add the effect a preset needs; try the saved display name first, then the match name. */
  function addPresetFx(qeIt, fx, isVideo) {
    var tries = [];
    if (fx.displayName) { tries.push([fx.displayName, false]); }
    var d = derivedName(fx.matchName);
    if (d && d !== fx.displayName) { tries.push([d, false]); }
    if (fx.matchName) { tries.push([fx.matchName, true]); }
    for (var i = 0; i < tries.length; i++) {
      var obj = isVideo ? getVideoFx(tries[i][0], tries[i][1]) : getAudioFx(tries[i][0], tries[i][1]);
      if (!obj) { continue; }
      if (addFxObject(qeIt, obj, isVideo)) { return true; }
    }
    return false;
  }

  function componentCount(clip) {
    try { return clip.components.numItems; } catch (e) { return 0; }
  }

  function findComponent(clip, fx, fromEnd) {
    var comps = clip.components, n = componentCount(clip), i, c;
    var wantMatch = strTrim(fx.matchName), wantName = normName(fx.displayName);
    for (var pass = 0; pass < 2; pass++) {
      for (var k = 0; k < n; k++) {
        i = fromEnd ? n - 1 - k : k;
        c = comps[i];
        try {
          if (pass === 0 && wantMatch && String(c.matchName) === wantMatch) { return c; }
          if (pass === 1 && wantName && normName(c.displayName) === wantName) { return c; }
        } catch (e) {}
      }
    }
    return null;
  }

  // ------------------------------------------------------------------ parameter replay
  function clipTiming(clip) {
    var inS = 0, outS = 0, speed = 1;
    try { inS = clip.inPoint.seconds; outS = clip.outPoint.seconds; } catch (e) {}
    try { speed = Math.abs(Number(clip.getSpeed())); } catch (e2) { speed = 1; }
    if (!(speed > 0.01 && speed < 100)) { speed = 1; }
    return { inSec: inS, outSec: outS, dur: Math.max(0, outS - inS), speed: speed };
  }

  /**
   * Keyframe times live in source-media time (they stretch with clip speed), so offsets
   * are converted by targetSpeed / presetSpeed to keep the same on-timeline timing.
   * Preset "Type": 0 = scale to clip length, 1 = anchor to In point, 2 = anchor to Out point.
   */
  function mapTime(rel, timing, preset) {
    var type = preset.type || 0;
    var pd = preset.duration || 0;
    var ps = preset.speed > 0 ? preset.speed : 1;
    var k = (timing.speed || 1) / ps;
    if (type === 2) { return timing.outSec - (pd - rel) * k; }
    if (type === 0 && pd > 0 && timing.dur > 0) { return timing.inSec + rel * (timing.dur / pd); }
    return timing.inSec + rel * k;
  }

  /** Premiere keyframe interpolation codes: 0 linear, 4 hold, 5 bezier (1–3 are legacy eases). */
  function interpCode(code) {
    if (code === 0 || code === 4 || code === 5) { return code; }
    if (code === 1 || code === 2 || code === 3) { return 5; }
    return 0;
  }

  function toValue(kind, v) {
    if (kind === 'point') { return [Number(v[0]), Number(v[1])]; }
    if (kind === 'bool') { return !!v; }
    return Number(v);
  }

  function makeTime(sec) { var t = new Time(); t.seconds = sec; return t; }

  function setStatic(prop, kind, v, updateUI) {
    if (v === null || v === undefined) { return false; }
    if (kind === 'color') {
      prop.setColorValue(v.a, v.r, v.g, v.b, updateUI);
      return true;
    }
    prop.setValue(toValue(kind, v), updateUI);
    return true;
  }

  function cleanupKeys(prop, placed) {
    var ks = null;
    try { ks = prop.getKeys(); } catch (e) { return; }
    if (!ks || !ks.length) { return; }
    for (var i = 0; i < ks.length; i++) {
      var s = NaN;
      try { s = ks[i].seconds; } catch (e2) {}
      if (isNaN(s)) { continue; }
      var keep = false;
      for (var j = 0; j < placed.length; j++) { if (Math.abs(placed[j] - s) < 0.0005) { keep = true; break; } }
      if (!keep) { try { prop.removeKey(ks[i]); } catch (e3) {} }
    }
  }

  function setOne(prop, p, timing, preset, updateUI) {
    var keys = p.keys || [];
    var canKey = false;
    try { canKey = prop.areKeyframesSupported(); } catch (e) {}
    var animate = keys.length > 0 && canKey && p.kind !== 'color';

    // A preset replaces what is there: drop existing animation first.
    try { if (prop.isTimeVarying()) { prop.setTimeVarying(false); } } catch (e2) {}

    if (!animate) {
      return setStatic(prop, p.kind, keys.length ? keys[0].v : p.value, updateUI);
    }

    prop.setTimeVarying(true);
    var placed = [];
    for (var i = 0; i < keys.length; i++) {
      var sec = mapTime(keys[i].t, timing, preset);
      var tm = makeTime(sec);
      prop.addKey(tm);
      prop.setValueAtKey(tm, toValue(p.kind, keys[i].v), updateUI);
      try { prop.setInterpolationTypeAtKey(tm, interpCode(keys[i].interp), updateUI); } catch (e3) {}
      placed.push(sec);
    }
    cleanupKeys(prop, placed);
    return true;
  }

  function setParams(comp, fx, timing, preset) {
    var res = { set: 0, skipped: 0 };
    var props = comp.properties;
    var n = 0;
    try { n = props.numItems; } catch (e) {}
    var byName = {}, i;
    for (i = 0; i < n; i++) {
      var dn = '';
      try { dn = normName(props[i].displayName); } catch (e2) {}
      if (dn) {
        if (!byName['$' + dn]) { byName['$' + dn] = []; }
        byName['$' + dn].push(i);
      }
    }
    var list = fx.params || [];
    var aligned = list.length === n;
    var seen = {};
    var lastSettable = -1;
    for (i = 0; i < list.length; i++) {
      if (list[i].kind !== 'arb' && list[i].kind !== 'ui' && list[i].kind !== 'unknown') { lastSettable = i; }
    }
    for (i = 0; i < list.length; i++) {
      var p = list[i];
      var key = normName(p.name);
      if (key) { seen['$' + key] = (seen['$' + key] || 0) + 1; }
      if (p.kind === 'ui') { continue; }
      if (p.kind === 'arb' || p.kind === 'unknown') { res.skipped++; continue; }
      var idx = -1;
      var occ = key ? byName['$' + key] : null;
      if (occ && occ.length >= seen['$' + key]) { idx = occ[seen['$' + key] - 1]; }
      if (idx < 0 && aligned && p.index >= 0 && p.index < n) { idx = p.index; }
      if (idx < 0) { res.skipped++; continue; }
      var ok2 = false;
      try { ok2 = setOne(props[idx], p, timing, preset, i === lastSettable ? 1 : 0); } catch (e3) { ok2 = false; }
      if (ok2) { res.set++; } else { res.skipped++; }
    }
    return res;
  }

  // ------------------------------------------------------------------ public API
  Q.ping = guard(function () {
    return ok({ version: Q.version, app: String(app.version), qe: hasQE() });
  });

  Q.info = guard(function () {
    var files = [];
    try { files = findPresetFiles(); } catch (e) {}
    var seq = activeSeq();
    return ok({
      version: Q.version,
      appVersion: String(app.version),
      os: String($.os),
      qe: hasQE(),
      hasSequence: !!seq,
      presetFiles: files
    });
  });

  Q.listEffects = guard(function () {
    if (!hasQE()) { return fail('noQE'); }
    var v = [], a = [];
    try { v = toArray(qe.project.getVideoEffectList()); } catch (e) {}
    try { a = toArray(qe.project.getAudioEffectList()); } catch (e2) {}
    return ok({ video: uniqSorted(v), audio: uniqSorted(a) });
  });

  Q.selection = guard(function () {
    var seq = activeSeq();
    if (!seq) { return ok({ hasSequence: false, video: 0, audio: 0 }); }
    var v = 0, a = 0, sel = null;
    try { sel = seq.getSelection(); } catch (e) {}
    if (sel && sel.length !== undefined) {
      for (var i = 0; i < sel.length; i++) {
        var mt = '';
        try { mt = String(sel[i].mediaType); } catch (e2) {}
        if (mt === 'Audio') { a++; } else if (mt === 'Video') { v++; }
      }
    } else {
      var all = collectSelected(seq, true, true);
      for (var j = 0; j < all.length; j++) { if (all[j].video) { v++; } else { a++; } }
    }
    return ok({ hasSequence: true, sequence: String(seq.name), video: v, audio: a });
  });

  /** {kind: 'video'|'audio', name: '<display name>'} */
  Q.applyEffect = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    if (!hasQE()) { return fail('noQE'); }
    var isAudio = a.kind === 'audio';
    var targets = collectSelected(seq, !isAudio, isAudio);
    if (!targets.length) { return noTargetsError(seq, !isAudio, isAudio); }

    var fx = isAudio ? getAudioFx(a.name, false) : getVideoFx(a.name, false);
    if (!fx) { return fail('effectNotFound', a.name); }

    var qeSeq = qe.project.getActiveSequence();
    var frame = frameTicks(seq);
    var applied = 0, failed = 0;
    for (var i = 0; i < targets.length; i++) {
      var it = qeItemFor(qeSeq, targets[i], frame);
      if (!it) { failed++; continue; }
      if (addFxObject(it, fx, !isAudio)) { applied++; } else { failed++; }
    }
    if (!applied) { return fail('applyFailed', a.name, { total: targets.length }); }
    return ok({ applied: applied, failed: failed, total: targets.length });
  });

  /** {preset: {name, type, duration, effects: [...]}} as produced by presets.js */
  Q.applyPreset = guard(function (encoded) {
    var a = arg(encoded);
    var preset = a.preset;
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }

    var needVideo = false, needAudio = false, i, j;
    for (i = 0; i < preset.effects.length; i++) {
      if (preset.effects[i].media === 'audio') { needAudio = true; } else { needVideo = true; }
    }
    var targets = collectSelected(seq, needVideo, needAudio);
    if (!targets.length) { return noTargetsError(seq, needVideo, needAudio); }

    var useQE = hasQE();
    var qeSeq = useQE ? qe.project.getActiveSequence() : null;
    var frame = frameTicks(seq);
    var report = { clips: 0, total: targets.length, effectsAdded: 0, paramsSet: 0, paramsSkipped: 0, missing: [], warnings: [] };

    for (i = 0; i < targets.length; i++) {
      var t = targets[i];
      var media = t.video ? 'video' : 'audio';
      var clip = t.clip;
      var timing = clipTiming(clip);
      var qeIt = null, touched = false;

      for (j = 0; j < preset.effects.length; j++) {
        var fx = preset.effects[j];
        if ((fx.media || 'video') !== media) { continue; }
        var label = fx.displayName || derivedName(fx.matchName) || fx.matchName;
        var comp = null;

        if (fx.intrinsic) {
          comp = findComponent(clip, fx, false);
          if (!comp) { addUnique(report.warnings, 'intrinsic:' + label); continue; }
        } else {
          if (!useQE) { addUnique(report.missing, label); continue; }
          if (!qeIt) { qeIt = qeItemFor(qeSeq, t, frame); }
          if (!qeIt) { addUnique(report.warnings, 'clip:' + t.name); break; }
          var before = componentCount(clip);
          if (!addPresetFx(qeIt, fx, t.video)) { addUnique(report.missing, label); continue; }
          clip = refetch(seq, t);
          comp = findComponent(clip, fx, true);
          if (!comp && componentCount(clip) > before) { comp = clip.components[componentCount(clip) - 1]; }
          if (!comp) { addUnique(report.warnings, 'nocomp:' + label); continue; }
          report.effectsAdded++;
        }

        touched = true;
        var r = setParams(comp, fx, timing, preset);
        report.paramsSet += r.set;
        report.paramsSkipped += r.skipped;
      }
      if (touched) { report.clips++; }
    }

    if (!report.clips) { return fail('presetFailed', preset.name, report); }
    return ok(report);
  });

  // ------------------------------------------------------------------ collect files
  // Finds media used by the project that lives outside the project folder, and re-points
  // project items to the copies the panel makes under <project folder>/Imported/.
  var SKIP_EXT = { aep: 1, aepx: 1, prproj: 1, aegraphic: 1, mogrt: 1, plb: 1 };
  var STILL_EXT = { png: 1, jpg: 1, jpeg: 1, tif: 1, tiff: 1, exr: 1, tga: 1, dpx: 1, bmp: 1, gif: 1, psd: 1, webp: 1, heic: 1 };
  var SEQ_EXT = { png: 1, tif: 1, tiff: 1, exr: 1, tga: 1, dpx: 1 };

  function extOf(name) { var m = /\.([A-Za-z0-9]+)$/.exec(String(name)); return m ? m[1].toLowerCase() : ''; }
  function baseOf(p) { var s = String(p); var i = s.lastIndexOf('/'); return i < 0 ? s : s.substring(i + 1); }
  function dirOf(p) { var s = String(p); var i = s.lastIndexOf('/'); return i <= 0 ? '/' : s.substring(0, i); }

  function projectDir() {
    var p = '';
    try { p = String(app.project.path || ''); } catch (e) {}
    if (!p) { return ''; }
    return dirOf(p.replace(/\\/g, '/'));
  }

  function walkItems(item, fn, depth) {
    if (!item || depth > 40) { return; }
    var isBin = false;
    try { isBin = (item.type === 2 || item.type === 3); } catch (e0) { isBin = false; }   // ProjectItemType.BIN / ROOT
    var kids = null, n = 0;
    try { kids = item.children; n = kids ? kids.numItems : 0; } catch (e) { n = 0; }
    if (n) {
      for (var i = 0; i < n; i++) { walkItems(kids[i], fn, depth + 1); }
      return;
    }
    if (!isBin) { fn(item); }
  }

  function mediaPathOf(item) {
    try { if (item.isSequence && item.isSequence()) { return ''; } } catch (e) {}
    var p = '';
    try { p = String(item.getMediaPath() || ''); } catch (e2) { p = ''; }
    return p.replace(/\\/g, '/');
  }

  /** A numbered-stills sequence is one project item for many files: copying just the first file would break it. */
  function isImageSequence(item, path) {
    var ext = extOf(path);
    if (!STILL_EXT[ext]) { return false; }
    var meta = '';
    try { meta = String(item.getProjectMetadata() || ''); } catch (e) { meta = ''; }
    var m = /Column\.Intrinsic\.MediaType>([^<]*)</.exec(meta);
    if (m) {
      if (/still/i.test(m[1])) { return false; }
      if (/movie|video/i.test(m[1])) { return true; }
    }
    if (!SEQ_EXT[ext]) { return false; }
    var mm = /^(.*?)(\d{3,})(\.[A-Za-z0-9]+)$/.exec(baseOf(path));
    if (!mm) { return false; }
    var next = String(Number(mm[2]) + 1);
    while (next.length < mm[2].length) { next = '0' + next; }
    return new File(dirOf(path) + '/' + mm[1] + next + mm[3]).exists;
  }

  Q.scanMedia = guard(function () {
    var dir = projectDir();
    if (!dir) { return fail('noProject'); }
    var dirLow = dir.toLowerCase() + '/';
    var seen = {}, files = [], skipped = [], inside = 0, total = 0;

    walkItems(app.project.rootItem, function (item) {
      var p = mediaPathOf(item);
      if (!p) { return; }
      total++;
      var name = baseOf(p);
      try { if (item.isOffline && item.isOffline()) { skipped.push({ name: name, reason: 'offline' }); return; } } catch (e) {}
      if (p.toLowerCase().indexOf(dirLow) === 0) { inside++; return; }
      if (/QFX-SafeZone-/i.test(name)) { return; }                     // Quick FX's own overlay stills
      if (seen['$' + p]) { return; }
      seen['$' + p] = true;
      if (SKIP_EXT[extOf(p)]) { skipped.push({ name: name, reason: 'linked' }); return; }
      var f = new File(p);
      if (!f.exists) { skipped.push({ name: name, reason: 'missing' }); return; }
      if (isImageSequence(item, p)) { skipped.push({ name: name, reason: 'sequence' }); return; }
      files.push({ path: p, name: name, size: f.length });
    }, 0);

    return ok({ projectDir: dir, importedDir: dir + '/Imported', files: files, skipped: skipped, inside: inside, total: total });
  });

  /** {pairs: [{from, to}]} — point every project item that uses `from` at `to`. */
  Q.relinkMedia = guard(function (encoded) {
    var a = arg(encoded);
    var pairs = a.pairs || [], relinked = 0, failed = 0;
    walkItems(app.project.rootItem, function (item) {
      var p = mediaPathOf(item);
      if (!p) { return; }
      for (var i = 0; i < pairs.length; i++) {
        if (pairs[i].from !== p) { continue; }
        var done = false;
        try {
          var can = true;
          try { if (item.canChangeMediaPath) { can = item.canChangeMediaPath(); } } catch (e1) { can = true; }
          if (can) { item.changeMediaPath(pairs[i].to, true); done = true; }
        } catch (e2) { done = false; }
        if (done) { relinked++; } else { failed++; }
        break;
      }
    }, 0);
    return ok({ relinked: relinked, failed: failed });
  });

  /** {from, dir, name} — copy on the Premiere side. Only used when the panel has no Node; blocks Premiere while it copies. */
  Q.copyInto = guard(function (encoded) {
    var a = arg(encoded);
    var src = new File(a.from);
    if (!src.exists) { return fail('missing', a.from); }
    var folder = new Folder(a.dir);
    if (!folder.exists && !folder.create()) { return fail('mkdirFailed', a.dir); }
    var total = src.length, name = a.name, n = 2;
    var m = /^(.*?)(\.[A-Za-z0-9]+)?$/.exec(a.name);
    var dst = new File(a.dir + '/' + name);
    while (dst.exists) {
      if (dst.length === total) { return ok({ to: a.dir + '/' + name, reused: true, bytes: 0 }); }
      name = m[1] + ' (' + (n++) + ')' + (m[2] || '');
      dst = new File(a.dir + '/' + name);
      if (n > 500) { return fail('copyFailed', a.name); }
    }
    if (!src.copy(a.dir + '/' + name)) { return fail('copyFailed', a.name); }
    dst = new File(a.dir + '/' + name);
    if (!dst.exists || dst.length !== total) { try { dst.remove(); } catch (e) {} return fail('copyFailed', a.name); }
    return ok({ to: a.dir + '/' + name, reused: false, bytes: total });
  });

  // ------------------------------------------------------------------ auto collect (background watcher)
  // State lives on $.global, because every Quick FX window re-evaluates this file in the same engine.
  var W = $.global.__QFX_WATCH;
  if (!W) { W = $.global.__QFX_WATCH = { known: {}, dirty: false, bound: false, bindTried: false, events: 0 }; }
  if (!$.global.__QFX_onItemAdded) {
    $.global.__QFX_onItemAdded = function () {
      var w = $.global.__QFX_WATCH;
      if (w) { w.dirty = true; w.events++; }
    };
  }

  /** Cheap: is there a saved project, and did Premiere tell us something was imported? */
  Q.watchPoll = guard(function () {
    if (!W.bindTried) {
      W.bindTried = true;
      try { W.bound = !!app.bind('onItemAddedToProject', $.global.__QFX_onItemAdded); } catch (e) { W.bound = false; }
    }
    var path = '';
    try { path = String(app.project.path || ''); } catch (e2) { path = ''; }
    return ok({ project: path, dirty: !!W.dirty, bound: !!W.bound, events: W.events });
  });

  /**
   * Returns only files that appeared since the previous call. The first call for a project is a
   * baseline: what is already in the project is left alone (the manual command collects those),
   * except paths listed in `pending` — files a previous session found but did not finish.
   */
  Q.watchScan = guard(function (encoded) {
    var a = encoded ? arg(encoded) : {};
    var dir = projectDir();
    if (!dir) { return fail('noProject'); }
    var key = '$' + String(app.project.path);
    var known = W.known[key], baseline = !known, i;
    if (!known) { known = W.known[key] = {}; }
    var pending = {}, plist = a.pending || [];
    for (i = 0; i < plist.length; i++) { pending['$' + plist[i]] = true; }
    W.dirty = false;

    // Count project items per outside file. A file is "new" when more items use it than at the
    // baseline, so importing a baseline file again is noticed too. Files handed to the panel are not
    // remembered here: once relinked they are inside the project folder and drop out by themselves.
    var dirLow = dir.toLowerCase() + '/', files = [], items = 0, order = [], info = {};
    walkItems(app.project.rootItem, function (item) {
      var p = mediaPathOf(item);
      if (!p) { return; }
      items++;
      if (p.toLowerCase().indexOf(dirLow) === 0) { return; }
      if (/QFX-SafeZone-/i.test(p)) { return; }                        // Quick FX's own overlay stills
      var k = '$' + p;
      if (!info[k]) { info[k] = { n: 0, item: item, path: p }; order.push(k); }
      info[k].n++;
    }, 0);

    var NEVER = 1000000000;
    for (i = 0; i < order.length; i++) {
      var k = order[i], e = info[k], p = e.path;
      if (baseline && !pending[k]) { known[k] = e.n; continue; }
      if (known[k]) {
        if (e.n <= known[k]) { if (known[k] !== NEVER) { known[k] = e.n; } continue; }
      }
      try { if (e.item.isOffline && e.item.isOffline()) { continue; } } catch (e1) {}   // may come online later: look again next time
      if (SKIP_EXT[extOf(p)]) { known[k] = NEVER; continue; }
      var f = new File(p);
      if (!f.exists) { continue; }
      if (isImageSequence(e.item, p)) { known[k] = NEVER; continue; }
      files.push({ path: p, name: baseOf(p), size: f.length });
    }

    return ok({ project: String(app.project.path), projectDir: dir, importedDir: dir + '/Imported', files: files, baseline: baseline, items: items });
  });

  /** {text, kind: info|warning|error} — a line in Premiere's Events panel (and its status-bar indicator). */
  Q.notify = guard(function (encoded) {
    var a = arg(encoded);
    var kind = (a.kind === 'warning' || a.kind === 'error') ? a.kind : 'info';
    try { app.setSDKEventMessage(String(a.text), kind); } catch (e) { return fail('notifyFailed', String(e)); }
    return ok({});
  });

  // ------------------------------------------------------------------ safe zones
  // An overlay is an ordinary still (a transparent PNG the panel draws at the sequence's frame size)
  // placed on the top video track: 10 seconds from the playhead, trimmed by hand like any clip.
  var ZONE_RE = /QFX-SafeZone-([a-z0-9]+)-\d+x\d+/i;
  var ZONE_BIN = 'Quick FX';

  function secOf(t) { var n = NaN; try { n = Number(t.seconds); } catch (e) { n = NaN; } return n; }
  function makeTime(sec) { var t = new Time(); t.seconds = sec; return t; }

  function zoneIdOf(clip) {
    var m = null;
    try { m = ZONE_RE.exec(String(clip.name)); } catch (e) { m = null; }
    if (!m) { try { m = ZONE_RE.exec(String(clip.projectItem.name)); } catch (e2) { m = null; } }
    return m ? m[1].toLowerCase() : '';
  }

  function zoneClips(seq) {
    var out = [], nt = 0;
    try { nt = seq.videoTracks.numTracks; } catch (e) { nt = 0; }
    for (var ti = 0; ti < nt; ti++) {
      var clips = seq.videoTracks[ti].clips, n = 0;
      try { n = clips.numItems; } catch (e2) { n = 0; }
      for (var ci = 0; ci < n; ci++) {
        var id = zoneIdOf(clips[ci]);
        if (!id) { continue; }
        var dis = false;
        try { dis = !!clips[ci].disabled; } catch (e3) { dis = false; }
        out.push({ clip: clips[ci], track: ti, id: id, start: secOf(clips[ci].start), end: secOf(clips[ci].end), disabled: dis });
      }
    }
    return out;
  }

  function playheadOf(seq) {
    var s = NaN;
    try { s = secOf(seq.getPlayerPosition()); } catch (e) { s = NaN; }
    return isNaN(s) ? 0 : s;
  }

  function zoneAt(list, sec) {
    for (var i = 0; i < list.length; i++) { if (list[i].start - 0.0005 <= sec && sec < list[i].end - 0.0005) { return list[i]; } }
    return null;
  }

  Q.zoneState = guard(function () {
    var seq = activeSeq();
    if (!seq) { return ok({ hasSequence: false, zones: [], visible: 0, hidden: 0 }); }
    var list = zoneClips(seq), zones = [], visible = 0, hidden = 0, ph = playheadOf(seq);
    for (var i = 0; i < list.length; i++) {
      zones.push({ id: list[i].id, start: list[i].start, end: list[i].end, disabled: list[i].disabled, track: list[i].track + 1 });
      if (list[i].disabled) { hidden++; } else { visible++; }
    }
    var under = zoneAt(list, ph), w = 0, h = 0;
    try { w = Number(seq.frameSizeHorizontal); h = Number(seq.frameSizeVertical); } catch (e) { w = 0; h = 0; }
    return ok({ hasSequence: true, sequence: String(seq.name), width: w, height: h, playhead: ph,
      zones: zones, visible: visible, hidden: hidden, under: under ? under.id : '', projectDir: projectDir() });
  });

  function zoneBin(create) {
    var rootItem = app.project.rootItem, kids = rootItem.children, n = kids ? kids.numItems : 0;
    for (var i = 0; i < n; i++) {
      var isBin = false;
      try { isBin = kids[i].type === 2; } catch (e) { isBin = false; }
      if (isBin && String(kids[i].name) === ZONE_BIN) { return kids[i]; }
    }
    if (!create) { return null; }
    var made = null;
    try { made = rootItem.createBin(ZONE_BIN); } catch (e2) { made = null; }
    return made || zoneBin(false);
  }

  function zoneItem(path) {
    var want = baseOf(path);
    function find(bin) {
      if (!bin) { return null; }
      var kids = bin.children, n = kids ? kids.numItems : 0;
      for (var i = 0; i < n; i++) {
        var p = '';
        try { p = String(kids[i].getMediaPath() || '').replace(/\\/g, '/'); } catch (e) { p = ''; }
        if (p === path || (p && baseOf(p) === want)) { return kids[i]; }
      }
      return null;
    }
    var bin = zoneBin(true);
    var item = find(bin);
    if (item) { return item; }
    try { app.project.importFiles([path], true, bin || app.project.rootItem, false); } catch (e2) { return null; }
    return find(zoneBin(false)) || find(app.project.rootItem);
  }

  /** How far a clip may run on this track starting at `from`: 0 when something already sits there. */
  function freeUntil(track, from, to) {
    var clips = track.clips, n = 0, limit = to;
    try { n = clips.numItems; } catch (e) { n = 0; }
    for (var i = 0; i < n; i++) {
      var s = secOf(clips[i].start), e2 = secOf(clips[i].end);
      if (s - 0.0005 <= from && from < e2 - 0.0005) { return 0; }
      if (s > from && s < limit) { limit = s; }
    }
    return limit;
  }

  function addTopTrack(seq) {
    var before = seq.videoTracks.numTracks;
    try {
      app.enableQE();
      var qs = qe.project.getActiveSequence();
      qs.addTracks(1, before, 0);                       // one video track above the last, no audio tracks
    } catch (e) { return false; }
    return seq.videoTracks.numTracks > before;
  }

  /** {path, id, seconds} — put the overlay at the playhead (or swap the one already under it). */
  Q.zoneApply = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var path = String(a.path).replace(/\\/g, '/');
    if (!new File(path).exists) { return fail('zoneFileMissing', path); }
    var seconds = Number(a.seconds) > 0 ? Number(a.seconds) : 10;
    var ph = playheadOf(seq), list = zoneClips(seq);
    var old = zoneAt(list, ph), start, end, ti, replaced = false, addedTrack = false;

    if (old) {
      // same place, another platform: keep the length the editor gave it
      start = old.start; end = old.end; ti = old.track; replaced = true;
      var wasDisabled = old.disabled;
      try { old.clip.remove(false, false); } catch (e) { return fail('zoneReplaceFailed', String(e)); }
    } else {
      start = ph; end = ph + seconds;
      ti = seq.videoTracks.numTracks - 1;
      var lim = ti >= 0 ? freeUntil(seq.videoTracks[ti], start, end) : 0;
      if (lim - start < 1) {
        if (!addTopTrack(seq)) { return fail('noFreeTrack'); }
        addedTrack = true;
        ti = seq.videoTracks.numTracks - 1;
        lim = end;
      }
      end = lim;
    }

    var item = zoneItem(path);
    if (!item) { return fail('zoneImportFailed', path); }
    try { item.setInPoint(0, 4); item.setOutPoint(end - start, 4); } catch (e2) {}

    var track = seq.videoTracks[ti];
    try { track.overwriteClip(item, start); }
    catch (e3) {
      try { track.overwriteClip(item, makeTime(start)); } catch (e4) { return fail('zonePlaceFailed', String(e4)); }
    }

    var placed = null, now = zoneClips(seq);
    for (var i = 0; i < now.length; i++) {
      if (now[i].track === ti && Math.abs(now[i].start - start) < 0.06) { placed = now[i]; break; }
    }
    if (!placed) { return fail('zonePlaceFailed'); }
    if (Math.abs(placed.end - end) > 0.06) {
      try { placed.clip.end = makeTime(end); } catch (e5) {}
      placed.end = secOf(placed.clip.end);
    }
    if (replaced && wasDisabled) { try { placed.clip.disabled = true; } catch (e6) {} }

    return ok({ id: String(a.id || placed.id), start: placed.start, end: placed.end, seconds: placed.end - placed.start,
      track: ti + 1, replaced: replaced, addedTrack: addedTrack, exact: Math.abs(placed.end - end) <= 0.06 });
  });

  /** {hidden: true|false} — switch every overlay in the sequence off or on (the clips stay where they are). */
  Q.zoneToggle = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var list = zoneClips(seq), changed = 0, failed = 0, want = !!a.hidden;
    for (var i = 0; i < list.length; i++) {
      var okSet = false;
      try { list[i].clip.disabled = want; okSet = (!!list[i].clip.disabled) === want; } catch (e) { okSet = false; }
      if (okSet) { changed++; } else { failed++; }
    }
    if (!list.length) { return fail('noZones'); }
    if (failed && !changed) { return fail('zoneToggleFailed'); }
    return ok({ hidden: want, count: changed, failed: failed });
  });

  /** Remove every overlay from the sequence (the PNGs stay in the "Quick FX" bin). */
  Q.zoneRemoveAll = guard(function () {
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var list = zoneClips(seq), removed = 0;
    for (var i = list.length - 1; i >= 0; i--) {
      try { list[i].clip.remove(false, false); removed++; } catch (e) {}
    }
    if (!list.length) { return fail('noZones'); }
    return ok({ removed: removed, failed: list.length - removed });
  });

  // ------------------------------------------------------------------ keyframe easing
  // Premiere's scripting can neither read which keyframes are selected nor set bezier handles.
  // So the target is "the move under the playhead" (or every move) on the selected clips, in every
  // animated parameter of every effect, and the curve is written as in-between keyframes.
  // `records` (kept by the panel) remember which stretches were written that way, so applying
  // another curve replaces the in-betweens instead of easing between them.
  var EASE_MAX_KEYS = 4000, EASE_MAX_PER_SEG = 120, EPS = 0.0005;

  function easeClipKey(sel) {
    var id = '';
    try { id = String(sel.clip.nodeId || ''); } catch (e) { id = ''; }
    return id || ((sel.video ? 'v' : 'a') + sel.track + '@' + sel.startTicks + ':' + sel.name);
  }

  function keyList(prop) {
    var ks = null, out = [];
    try { ks = prop.getKeys(); } catch (e) { ks = null; }
    if (!ks) { return out; }
    for (var i = 0; i < ks.length; i++) {
      var s = secOf(ks[i]);
      if (!isNaN(s)) { out.push({ s: s, t: ks[i] }); }
    }
    out.sort(function (a, b) { return a.s - b.s; });
    return out;
  }

  function hasKeyAt(keys, sec) {
    for (var i = 0; i < keys.length; i++) { if (Math.abs(keys[i].s - sec) < EPS) { return true; } }
    return false;
  }

  function mixValue(a, b, y) {
    if (typeof a === 'number' && typeof b === 'number') { return a + (b - a) * y; }
    if (a && b && typeof a === 'object' && typeof b === 'object' && a.length !== undefined && a.length === b.length && a.length > 0 && a.length <= 4) {
      var out = [];
      for (var i = 0; i < a.length; i++) {
        if (typeof a[i] !== 'number' || typeof b[i] !== 'number') { return undefined; }
        out.push(a[i] + (b[i] - a[i]) * y);
      }
      return out;
    }
    return undefined;
  }

  function sameValue(a, b) {
    if (typeof a === 'number') { return Math.abs(a - b) < 1e-9; }
    for (var i = 0; i < a.length; i++) { if (Math.abs(a[i] - b[i]) >= 1e-9) { return false; } }
    return true;
  }

  function lutAt(lut, x) {
    var n = lut.length - 1, f = x * n, i = Math.floor(f);
    if (i >= n) { return lut[n]; }
    if (i < 0) { return lut[0]; }
    return lut[i] + (lut[i + 1] - lut[i]) * (f - i);
  }

  /** Every animated parameter on the selected clips, with the keyframe pairs the request is about. */
  function easeTargets(seq, mode, records) {
    var recMap = {}, i;
    for (i = 0; i < (records || []).length; i++) {
      var r = records[i], rk = '$' + r.c + '|' + r.k + '|' + r.p;
      (recMap[rk] || (recMap[rk] = [])).push(r);
    }
    var sels = collectSelected(seq, true, true), ph = playheadOf(seq), out = [];
    for (var si = 0; si < sels.length; si++) {
      var sel = sels[si], clip = sel.clip, timing = clipTiming(clip), cKey = easeClipKey(sel);
      var phKey = timing.inSec + (ph - secOf(clip.start)) * timing.speed;
      var comps = null, nc = 0;
      try { comps = clip.components; nc = comps.numItems; } catch (e) { nc = 0; }
      for (var ci = 0; ci < nc; ci++) {
        var comp = comps[ci], props = null, np = 0, cName = '', cMatch = '';
        try { props = comp.properties; np = props.numItems; cName = String(comp.displayName); cMatch = String(comp.matchName); } catch (e2) { np = 0; }
        for (var pi = 0; pi < np; pi++) {
          var prop = props[pi], tv = false;
          try { tv = prop.isTimeVarying(); } catch (e3) { tv = false; }
          if (!tv) { continue; }
          var keys = keyList(prop);
          if (keys.length < 2) { continue; }
          var pName = '';
          try { pName = String(prop.displayName); } catch (e4) { pName = ''; }
          var kKey = cMatch + '#' + ci, pKey = pName + '#' + pi;
          // stretches written earlier: still valid only while both end keyframes are where they were
          var recs = recMap['$' + cKey + '|' + kKey + '|' + pKey] || [], valid = [];
          for (i = 0; i < recs.length; i++) { if (hasKeyAt(keys, recs[i].a) && hasKeyAt(keys, recs[i].b)) { valid.push(recs[i]); } }
          var anchors = [];
          for (i = 0; i < keys.length; i++) {
            var inner = false;
            for (var v = 0; v < valid.length; v++) { if (keys[i].s > valid[v].a + EPS && keys[i].s < valid[v].b - EPS) { inner = true; break; } }
            if (!inner) { anchors.push(keys[i]); }
          }
          var segs = [];
          for (i = 0; i + 1 < anchors.length; i++) {
            var a = anchors[i], b = anchors[i + 1];
            if (mode === 'all') { segs.push([a, b]); continue; }
            var last = i + 2 === anchors.length;
            if (phKey >= a.s - EPS && (phKey < b.s - EPS || (last && phKey <= b.s + EPS))) { segs.push([a, b]); break; }
          }
          if (!segs.length) { continue; }
          out.push({ clipKey: cKey, compKey: kKey, paramKey: pKey, ident: cMatch + '|' + pName, comp: cName, param: pName,
            name: cName + ' · ' + pName, prop: prop, keys: keys, segs: segs, timing: timing });
        }
      }
    }
    return { targets: out, clips: sels.length };
  }

  /** {mode: 'playhead'|'all', records} — what an Apply would touch right now. */
  Q.easeInfo = guard(function (encoded) {
    var a = encoded ? arg(encoded) : {};
    var seq = activeSeq(), project = '';
    try { project = String(app.project.path || ''); } catch (e) { project = ''; }
    if (!seq) { return ok({ hasSequence: false, project: project, clips: 0, params: [], segments: 0 }); }
    var found = easeTargets(seq, a.mode === 'all' ? 'all' : 'playhead', a.records), list = [], byId = {}, segments = 0, seconds = 0;
    for (var i = 0; i < found.targets.length; i++) {
      var t = found.targets[i], e = byId['$' + t.ident];
      // the same parameter on several selected clips is one line in the panel
      if (!e) { e = byId['$' + t.ident] = { id: t.ident, comp: t.comp, param: t.param, name: t.name, moves: 0, clips: 0 }; list.push(e); }
      e.moves += t.segs.length; e.clips++;
      segments += t.segs.length;
      if (!seconds) { seconds = (t.segs[0][1].s - t.segs[0][0].s) / (t.timing.speed || 1); }
    }
    return ok({ hasSequence: true, project: project, clips: found.clips, params: list, segments: segments, seconds: seconds });
  });

  /** {mode, lut: [0…1] | null (= back to linear), records, only: [parameter ids] — the ones ticked in the panel} */
  Q.easeApply = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var mode = a.mode === 'all' ? 'all' : 'playhead', lut = a.lut && a.lut.length > 2 ? a.lut : null;
    var found = easeTargets(seq, mode, a.records);
    if (!found.clips) { return fail('noSelection'); }
    if (!found.targets.length) { return fail(mode === 'all' ? 'noKeyframes' : 'noEaseTarget'); }
    if (a.only) {
      // Premiere cannot tell a script which keyframes are selected, so the panel sends the ticked parameters
      var want = {}, kept = [], oi;
      for (oi = 0; oi < a.only.length; oi++) { want['$' + a.only[oi]] = true; }
      for (oi = 0; oi < found.targets.length; oi++) { if (want['$' + found.targets[oi].ident]) { kept.push(found.targets[oi]); } }
      if (!kept.length) { return fail('noParams'); }
      found.targets = kept;
    }

    var frame = 0;
    try { frame = Number(seq.timebase) / 254016000000; } catch (e) { frame = 0; }
    if (!(frame > 0.001 && frame < 1)) { frame = 1 / 25; }

    var added = 0, removed = 0, segments = 0, params = 0, partial = false;
    var skipped = { unsupported: 0, flat: 0, tooShort: 0 }, add = [], drop = [], undo = [];

    for (var ti = 0; ti < found.targets.length && !partial; ti++) {
      var t = found.targets[ti], prop = t.prop, touched = false, step = frame * (t.timing.speed || 1);
      var op = { c: t.clipKey, k: t.compKey, p: t.paramKey, added: [], removed: [] };     // enough to put this parameter back
      for (var si = 0; si < t.segs.length; si++) {
        var A = t.segs[si][0], B = t.segs[si][1], v0, v1;
        try { v0 = prop.getValueAtKey(A.t); v1 = prop.getValueAtKey(B.t); } catch (e2) { v0 = undefined; v1 = undefined; }
        if (mixValue(v0, v1, 0.5) === undefined) { skipped.unsupported++; continue; }
        var rec = { c: t.clipKey, k: t.compKey, p: t.paramKey, a: A.s, b: B.s };

        // whatever sat between the two keyframes goes first
        for (var ki = 0; ki < t.keys.length; ki++) {
          if (t.keys[ki].s > A.s + EPS && t.keys[ki].s < B.s - EPS) {
            var was;
            try { was = prop.getValueAtKey(t.keys[ki].t); } catch (e7) { was = undefined; }
            try { prop.removeKey(t.keys[ki].t); removed++; if (was !== undefined) { op.removed.push([t.keys[ki].s, was]); } } catch (e3) {}
          }
        }
        drop.push(rec);

        if (!lut) {
          try { prop.setInterpolationTypeAtKey(A.t, 0, 0); prop.setInterpolationTypeAtKey(B.t, 0, 1); } catch (e4) {}
          segments++; touched = true;
          continue;
        }
        if (sameValue(v0, v1)) { skipped.flat++; continue; }
        var n = Math.round((B.s - A.s) / step);
        if (n < 2) { skipped.tooShort++; continue; }
        var stride = Math.max(1, Math.ceil(n / EASE_MAX_PER_SEG));
        for (var k = stride; k < n; k += stride) {
          var tm = makeTime(A.s + k * step);
          try {
            prop.addKey(tm);
            prop.setValueAtKey(tm, mixValue(v0, v1, lutAt(lut, k / n)), (k + stride >= n) ? 1 : 0);
            try { prop.setInterpolationTypeAtKey(tm, 0, 0); } catch (e5) {}
            added++;
            op.added.push(A.s + k * step);
          } catch (e6) {}
        }
        add.push(rec);
        segments++; touched = true;
        if (added >= EASE_MAX_KEYS) { partial = true; break; }
      }
      if (touched) { params++; }
      if (op.added.length || op.removed.length) { undo.push(op); }
    }

    if (!segments) { return fail('easeNothing', '', { skipped: skipped }); }
    return ok({ segments: segments, params: params, clips: found.clips, added: added, removed: removed,
      skipped: skipped, partial: partial, linear: !lut, add: add, drop: drop, undo: undo });
  });


  /** Every clip of the sequence under the same key easeTargets() used — selection may have changed since. */
  function findClipByKey(seq, key) {
    var groups = [[seq.videoTracks, true], [seq.audioTracks, false]];
    for (var g = 0; g < groups.length; g++) {
      var tracks = groups[g][0], nt = 0;
      try { nt = tracks.numTracks; } catch (e) { nt = 0; }
      for (var t = 0; t < nt; t++) {
        var clips = tracks[t].clips, nc = 0;
        try { nc = clips.numItems; } catch (e2) { nc = 0; }
        for (var c = 0; c < nc; c++) {
          var sel = { clip: clips[c], track: t, index: c, video: groups[g][1], startTicks: String(clips[c].start.ticks), name: String(clips[c].name) };
          if (easeClipKey(sel) === key) { return clips[c]; }
        }
      }
    }
    return null;
  }

  function findParam(clip, compKey, paramKey) {
    var comps = null, nc = 0;
    try { comps = clip.components; nc = comps.numItems; } catch (e) { nc = 0; }
    for (var ci = 0; ci < nc; ci++) {
      var m = '';
      try { m = String(comps[ci].matchName); } catch (e2) { m = ''; }
      if (m + '#' + ci !== compKey) { continue; }
      var props = comps[ci].properties, np = 0;
      try { np = props.numItems; } catch (e3) { np = 0; }
      for (var pi = 0; pi < np; pi++) {
        var n = '';
        try { n = String(props[pi].displayName); } catch (e4) { n = ''; }
        if (n + '#' + pi === paramKey) { return props[pi]; }
      }
    }
    return null;
  }

  /** {ops: [{c,k,p, added:[sec…], removed:[[sec, value]…]}]} — take back one Apply: its in-betweens out, what it removed back in. */
  Q.easeUndo = guard(function (encoded) {
    var a = arg(encoded);
    var seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var ops = a.ops || [], params = 0, missing = 0, removed = 0, restored = 0;
    for (var i = 0; i < ops.length; i++) {
      var op = ops[i], clip = findClipByKey(seq, op.c), prop = clip ? findParam(clip, op.k, op.p) : null;
      if (!prop) { missing++; continue; }
      var keys = keyList(prop), j, k;
      for (j = 0; j < (op.added || []).length; j++) {
        for (k = 0; k < keys.length; k++) {
          if (Math.abs(keys[k].s - op.added[j]) < EPS) { try { prop.removeKey(keys[k].t); removed++; } catch (e) {} break; }
        }
      }
      var back = op.removed || [];
      for (j = 0; j < back.length; j++) {
        var tm = makeTime(back[j][0]);
        try {
          prop.addKey(tm);
          prop.setValueAtKey(tm, back[j][1], j === back.length - 1 ? 1 : 0);
          try { prop.setInterpolationTypeAtKey(tm, 0, 0); } catch (e2) {}
          restored++;
        } catch (e3) {}
      }
      params++;
    }
    if (!params) { return fail('undoMissing'); }
    return ok({ params: params, missing: missing, removed: removed, restored: restored });
  });

  // ------------------------------------------------------------------ downloads (YouTube …)
  var YT_BIN = 'YouTube';

  function rootBin(name, create) {
    var rootItem = app.project.rootItem, kids = rootItem.children, n = kids ? kids.numItems : 0;
    for (var i = 0; i < n; i++) {
      var isBin = false;
      try { isBin = kids[i].type === 2; } catch (e) { isBin = false; }
      if (isBin && String(kids[i].name) === name) { return kids[i]; }
    }
    if (!create) { return null; }
    var made = null;
    try { made = rootItem.createBin(name); } catch (e2) { made = null; }
    return made || rootBin(name, false);
  }

  function itemWithPath(bin, path) {
    if (!bin) { return null; }
    var kids = bin.children, n = kids ? kids.numItems : 0, low = String(path).toLowerCase();
    for (var i = 0; i < n; i++) {
      var p = '';
      try { p = String(kids[i].getMediaPath() || '').replace(/\\/g, '/'); } catch (e) { p = ''; }
      if (p && p.toLowerCase() === low) { return kids[i]; }
    }
    return null;
  }

  /** Where a download goes: <project folder>/Imported/YouTube (empty when the project is not saved yet). */
  Q.ytTarget = guard(function () {
    var dir = projectDir();
    return ok({ saved: !!dir, projectDir: dir, dir: dir ? dir + '/Imported/YouTube' : '' });
  });

  /** {path, bin} — the downloaded file into its site's bin of the Project panel ("YouTube", "TikTok" …); the same file is not imported twice. */
  Q.ytImport = guard(function (encoded) {
    var a = arg(encoded), path = String(a.path || '').replace(/\\/g, '/');
    var f = new File(path);
    if (!f.exists) { return fail('ytFileMissing', path); }
    var binName = strTrim(String(a.bin || '').replace(/[\\\/:*?"<>|]/g, ' ')).substring(0, 40) || YT_BIN;
    var bin = rootBin(binName, true);
    var item = itemWithPath(bin, path), existed = !!item;
    if (!item) {
      try { app.project.importFiles([path], true, bin || app.project.rootItem, false); } catch (e) { return fail('ytImportFailed', String(e)); }
      item = itemWithPath(rootBin(binName, false), path) || itemWithPath(app.project.rootItem, path);
    }
    if (!item) { return fail('ytImportFailed', baseOf(path)); }
    try { if (item.select) { item.select(); } } catch (e2) {}
    return ok({ name: String(item.name), bin: bin ? binName : '', existed: existed });
  });

  // ------------------------------------------------------------------ paste: a copied picture (or file) straight into the project
  var PASTE_BIN = 'Pasted';
  var PASTE_STILL = /\.(png|jpe?g|psd|tiff?|bmp|gif|tga|exr|dpx|ai|eps)$/i;
  var PASTE_AUDIO = /\.(wav|mp3|m4a|aac|aif|aiff|flac|ogg|wma|opus)$/i;

  /** Where pasted pictures are kept: <project folder>/Imported/Pasted (empty when the project is not saved yet). */
  Q.pasteTarget = guard(function () {
    var dir = projectDir(), seq = activeSeq(), w = 0, h = 0;
    if (seq) { try { w = Number(seq.frameSizeHorizontal) || 0; h = Number(seq.frameSizeVertical) || 0; } catch (e) { w = 0; h = 0; } }
    return ok({ saved: !!dir, projectDir: dir, dir: dir ? dir + '/Imported/Pasted' : '', hasSequence: !!seq, width: w, height: h });
  });

  /**
   * {paths: [...], place: true|false, seconds: 5, fit: ''|'fit'|'fill', sizes: [[w, h] …]}
   * The files go into the "Pasted" bin (the same file is not imported twice). With place they are laid at the playhead, one after
   * another, on the first track that is free above whatever is there. A picture stays "seconds" long.
   * fit: the whole picture inside the frame (Premiere's own "Scale to Frame Size"); fill: the frame covered, the rest cropped.
   */
  Q.pasteAdd = guard(function (encoded) {
    var a = arg(encoded), paths = a.paths || [], bin = rootBin(PASTE_BIN, true), items = [], i;
    for (i = 0; i < paths.length; i++) {
      var path = String(paths[i] || '').replace(/\\/g, '/');
      if (!path || !new File(path).exists) { continue; }
      var item = itemWithPath(bin, path), existed = !!item;
      if (!item) {
        try { app.project.importFiles([path], true, bin || app.project.rootItem, false); } catch (e) { continue; }
        item = itemWithPath(rootBin(PASTE_BIN, false), path) || itemWithPath(app.project.rootItem, path);
      }
      if (item) { items.push({ item: item, path: path, size: a.sizes && a.sizes[i] ? a.sizes[i] : null, existed: existed }); }
    }
    if (!items.length) { return fail('pasteImportFailed', paths.length ? baseOf(String(paths[0])) : ''); }
    var out = { imported: items.length, bin: bin ? PASTE_BIN : '', name: String(items[0].item.name), clips: [], placed: 0, why: '', addedTrack: false, scaled: '' };
    var seq = a.place ? activeSeq() : null;
    if (a.place && !seq) { out.why = 'noSequence'; }
    if (seq) {
      var still = Number(a.seconds) > 0 ? Number(a.seconds) : 5, total = 0, plan = [], k;
      for (k = 0; k < items.length; k++) {
        var it = items[k], dur = 0;
        if (PASTE_AUDIO.test(it.path)) { continue; }                      // a sound is only imported
        if (PASTE_STILL.test(it.path)) { dur = still; it.still = true; }
        else {
          try { it.item.clearInPoint(); it.item.clearOutPoint(); } catch (e1) {}
          try { dur = secOf(it.item.getOutPoint()) - secOf(it.item.getInPoint()); } catch (e2) { dur = 0; }
          if (!(dur > 0)) { dur = still; }
        }
        it.dur = dur; total += dur; plan.push(it);
      }
      var ph = playheadOf(seq), slot = plan.length ? textTrackFor(seq, ph, ph + total) : null, t = ph, last = null;
      if (plan.length && !slot) { out.why = 'noFreeTrack'; }
      if (slot) {
        out.addedTrack = slot.added;
        var track = seq.videoTracks[slot.index], sw = 0, sh = 0;
        try { sw = Number(seq.frameSizeHorizontal) || 0; sh = Number(seq.frameSizeVertical) || 0; } catch (e3) { sw = 0; sh = 0; }
        for (k = 0; k < plan.length; k++) {
          var p = plan[k], fitted = false;
          if (p.still) { try { p.item.setInPoint(0, 4); p.item.setOutPoint(p.dur, 4); } catch (e4) {} }
          if (a.fit === 'fit' || a.fit === 'fill') { try { p.item.setScaleToFrameSize(); fitted = true; } catch (e5) { fitted = false; } }
          try { track.overwriteClip(p.item, t); }
          catch (e6) { try { track.overwriteClip(p.item, makeTime(t)); } catch (e7) { out.why = String(e7); break; } }
          var made = null, cs = track.clips, c;
          for (c = 0; c < cs.numItems; c++) { if (Math.abs(secOf(cs[c].start) - t) < 0.06) { made = cs[c]; } }
          if (!made) { out.why = out.why || 'not placed'; break; }
          if (p.still && Math.abs(secOf(made.end) - (t + p.dur)) > 0.06) { try { made.end = makeTime(t + p.dur); } catch (e8) {} }
          if (fitted) { out.scaled = 'fit'; }
          if (fitted && a.fit === 'fill' && p.size && p.size[0] > 0 && p.size[1] > 0 && sw > 0 && sh > 0) {
            // the picture now fits inside the frame; to cover it, grow by the ratio of the two shapes
            var ra = (p.size[0] / p.size[1]) / (sw / sh), grow = (ra > 1 ? ra : 1 / ra) * 100;
            try {
              var mo = animIntrinsic(made, 'AE.ADBE Motion', 'Motion'), sc = mo ? animNamed(mo, MOTION_PARAMS.scaleH) : null;
              if (sc && grow > 100.5) { sc.setValue(Math.round(grow * 10) / 10, 1); out.scaled = 'fill'; }
            } catch (e9) {}
          }
          var endNow = secOf(made.end);
          out.clips.push({ track: slot.index, start: t, dur: endNow - t, name: String(p.item.name) });
          out.placed++; last = made; t = endNow > t ? endNow : t + p.dur;
        }
        if (last) { textSelectOnly(seq, last); }
      }
    }
    if (!out.placed) { try { if (items[items.length - 1].item.select) { items[items.length - 1].item.select(); } } catch (e10) {} }
    return ok(out);
  });

  // ------------------------------------------------------------------ pauses: a copy of the sequence with the silences cut out
  //
  // Premiere's scripting cannot split a clip, and the unofficial razor is unreliable in Premiere 2026, so nothing is cut:
  // the sequence is duplicated, the duplicate is emptied, and what remains of every clip is laid down again piece by
  // piece from its source (in/out points + overwrite), back to back. The original sequence is never touched.
  var SIL_MARK = 'QFX პაუზა';
  var SIL_AUDIO_EXT = /\.(wav|mp3|m4a|aac|aif|aiff|flac|ogg|wma|opus)$/i;
  var SIL_STILL_EXT = /\.(png|jpe?g|psd|tiff?|bmp|gif|tga|exr|dpx|ai|eps|svg|webp|heic)$/i;

  function silState() {
    if (!$.global.__QFX_SIL) { $.global.__QFX_SIL = { saved: {} }; }
    return $.global.__QFX_SIL;
  }

  function seqById(id) {
    var list = app.project.sequences, n = list ? list.numSequences : 0;
    for (var i = 0; i < n; i++) { if (String(list[i].sequenceID) === String(id)) { return list[i]; } }
    return null;
  }

  function seqItems(seq) {
    var n = 0, i;
    for (i = 0; i < seq.videoTracks.numTracks; i++) { n += seq.videoTracks[i].clips.numItems; }
    for (i = 0; i < seq.audioTracks.numTracks; i++) { n += seq.audioTracks[i].clips.numItems; }
    return n;
  }

  function itemByNode(node, path) {
    var found = null, low = String(path || '').toLowerCase();
    walkItems(app.project.rootItem, function (it) {
      if (found) { return; }
      var id = '';
      try { id = String(it.nodeId); } catch (e) { id = ''; }
      if (node && id === String(node)) { found = it; return; }
      if (!node && low) {
        var mp = '';
        try { mp = String(it.getMediaPath() || '').replace(/\\/g, '/').toLowerCase(); } catch (e2) { mp = ''; }
        if (mp === low) { found = it; }
      }
    }, 0);
    return found;
  }

  /** Static Position and Scale of a clip's Motion (by position in the list: names are translated) — null when animated or unreadable. */
  function motionOf(clip) {
    try {
      var comps = clip.components;
      for (var i = 0; i < comps.numItems; i++) {
        if (String(comps[i].matchName) !== 'AE.ADBE Motion') { continue; }
        var pr = comps[i].properties, pos = pr[0], sc = pr[1];
        if (pos.isTimeVarying() || sc.isTimeVarying()) { return null; }
        var pv = pos.getValue(), sv = Number(sc.getValue());
        if (isNaN(sv) || !pv || pv.length < 2) { return null; }
        return { x: Number(pv[0]), y: Number(pv[1]), s: sv };
      }
    } catch (e) {}
    return null;
  }
  function setMotion(clip, m) {
    try {
      var comps = clip.components;
      for (var i = 0; i < comps.numItems; i++) {
        if (String(comps[i].matchName) !== 'AE.ADBE Motion') { continue; }
        var pr = comps[i].properties, cur = motionOf(clip);
        if (cur && Math.abs(cur.s - m.s) < 0.01 && Math.abs(cur.x - m.x) < 0.0001 && Math.abs(cur.y - m.y) < 0.0001) { return false; }
        pr[1].setValue(m.s, true);
        pr[0].setValue([m.x, m.y], true);
        return true;
      }
    } catch (e) {}
    return false;
  }

  /** What would be cut: the selected clips, or (nothing selected) every clip of the first track that has footage. */
  Q.silenceTargets = guard(function () {
    var seq = activeSeq();
    if (!seq) { return ok({ hasSequence: false, units: [], skipped: [] }); }
    var frame = frameTicks(seq) / TPS, picked = [], scope = 'selection', i, t;
    var sel = null;
    try { sel = seq.getSelection(); } catch (e) { sel = null; }
    if (sel && sel.length) { for (i = 0; i < sel.length; i++) { picked.push(sel[i]); } }
    if (!picked.length) {
      scope = 'track';
      var groups = [seq.videoTracks, seq.audioTracks];
      for (var g = 0; g < groups.length && !picked.length; g++) {
        for (t = 0; t < groups[g].numTracks && !picked.length; t++) {
          var cl = groups[g][t].clips, usable = false;
          for (i = 0; i < cl.numItems && !usable; i++) {
            var nm = '';
            try { nm = String(cl[i].projectItem.getMediaPath() || ''); } catch (e1) { nm = ''; }
            usable = !!nm && !SIL_STILL_EXT.test(nm) && !ZONE_RE.test(nm);
          }
          if (usable) { for (i = 0; i < cl.numItems; i++) { picked.push(cl[i]); } }
        }
      }
    }
    var units = [], skipped = [], seen = {};
    for (i = 0; i < picked.length; i++) {
      var c = picked[i], pi = null, path = '', name = '';
      try { name = String(c.name); } catch (e2) { name = ''; }
      try { pi = c.projectItem; } catch (e3) { pi = null; }
      if (!pi) { continue; }                                        // a transition, a gap, a graphic
      var nested = false, offline = false;
      try { nested = !!pi.isSequence(); } catch (e4) { nested = false; }
      if (nested) { skipped.push({ name: name, why: 'nested' }); continue; }
      try { path = String(pi.getMediaPath() || '').replace(/\\/g, '/'); } catch (e5) { path = ''; }
      if (!path || ZONE_RE.test(path) || SIL_STILL_EXT.test(path)) { continue; }
      try { offline = !!pi.isOffline(); } catch (e6) { offline = false; }
      if (offline || !new File(path).exists) { skipped.push({ name: name, why: 'offline' }); continue; }
      var st = secOf(c.start), en = secOf(c.end), si = secOf(c.inPoint), so = secOf(c.outPoint);
      if (isNaN(st) || isNaN(en) || isNaN(si) || isNaN(so) || en - st < frame * 2) { continue; }
      var node = '';
      try { node = String(pi.nodeId); } catch (e7) { node = ''; }
      // a clip and its linked sound are one thing; so is the same clip picked twice
      var key = (node || path) + '|' + Math.round(si * 1000) + '|' + Math.round(st * 1000);
      var isVideo = false;
      try { isVideo = String(c.mediaType) === 'Video'; } catch (e8) { isVideo = false; }
      if (seen['$' + key]) {
        // the sound half of a linked clip carries no Motion: take it from the picture half when that one comes second
        if (seen['$' + key] !== true && isVideo && !seen['$' + key].motion) { seen['$' + key].motion = motionOf(c); }
        continue;
      }
      seen['$' + key] = true;
      if (Math.abs((en - st) - (so - si)) > frame * 1.5) { skipped.push({ name: name, why: 'speed' }); continue; }
      var unit = { key: key, name: name, path: path, node: node, start: st, end: en, sin: si, sout: so,
        kind: SIL_AUDIO_EXT.test(path) ? 'audio' : 'av', motion: isVideo ? motionOf(c) : null };
      seen['$' + key] = unit;
      units.push(unit);
    }
    units.sort(function (a, b) { return (a.start - b.start) || (a.kind === b.kind ? 0 : (a.kind === 'av' ? -1 : 1)); });   // picture first when two start together
    var sid = '';
    try { sid = String(seq.sequenceID); } catch (e9) { sid = ''; }
    return ok({ hasSequence: true, name: String(seq.name), id: sid, frame: frame, scope: scope, units: units, skipped: skipped });
  });

  /** {name} — duplicates the active sequence; the duplicate is what gets rebuilt. */
  Q.silenceBegin = guard(function (encoded) {
    var a = arg(encoded), seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var list = app.project.sequences, before = {}, i, neu = null;
    for (i = 0; i < list.numSequences; i++) { before['$' + String(list[i].sequenceID)] = true; }
    try { seq.clone(); } catch (e) { return fail('silCloneFailed', String(e)); }
    list = app.project.sequences;
    for (i = list.numSequences - 1; i >= 0; i--) { if (!before['$' + String(list[i].sequenceID)]) { neu = list[i]; break; } }
    if (!neu) { return fail('silCloneFailed', 'the copy did not appear'); }
    try { neu.name = String(a.name || (seq.name + ' — cut')); } catch (e2) {}
    silState().saved = {};
    return ok({ id: String(neu.sequenceID), name: String(neu.name), items: seqItems(neu), from: String(seq.name) });
  });

  /** {id, max} — removes up to max clips from the duplicate (called until nothing is left; long loops in one call are unreliable). */
  Q.silenceClear = guard(function (encoded) {
    var a = arg(encoded), s = seqById(a.id);
    if (!s) { return fail('silSeqMissing'); }
    var max = Number(a.max) > 0 ? Number(a.max) : 40, removed = 0, groups = [s.videoTracks, s.audioTracks];
    for (var g = 0; g < groups.length && removed < max; g++) {
      for (var t = 0; t < groups[g].numTracks && removed < max; t++) {
        var cl = groups[g][t].clips;
        for (var i = cl.numItems - 1; i >= 0 && removed < max; i--) {
          try { cl[i].remove(false, false); removed++; } catch (e) {}
        }
      }
    }
    var left = seqItems(s);
    if (!removed && left) { return fail('silClearFailed', String(left)); }
    return ok({ removed: removed, left: left });
  });

  /** {id, at, pieces: [{n: nodeId, p: path, a: source in, b: source out, k: 'av'|'audio', m: motion|null}]} — lays the pieces down, back to back, from `at`. */
  Q.silencePlace = guard(function (encoded) {
    var a = arg(encoded), s = seqById(a.id);
    if (!s) { return fail('silSeqMissing'); }
    if (!s.videoTracks.numTracks || !s.audioTracks.numTracks) { return fail('silNoTracks'); }
    var vt = s.videoTracks[0], au = s.audioTracks[0], at = Number(a.at) || 0, list = a.pieces || [], placed = 0, moved = 0, st = silState();
    for (var i = 0; i < list.length; i++) {
      var pc = list[i], item = itemByNode(pc.n, pc.p);
      if (!item) { return fail('silItemMissing', baseOf(String(pc.p))); }
      var id = String(pc.n || pc.p);
      if (!st.saved['$' + id]) {
        var keep = { node: pc.n, path: pc.p, a: null, b: null };
        try { keep.a = secOf(item.getInPoint()); keep.b = secOf(item.getOutPoint()); } catch (e0) {}
        st.saved['$' + id] = keep;
      }
      try { item.setInPoint(Number(pc.a), 4); item.setOutPoint(Number(pc.b), 4); } catch (e1) { return fail('silPlaceFailed', 'in/out: ' + String(e1)); }
      var track = pc.k === 'audio' ? au : vt, had = track.clips.numItems;
      try { track.overwriteClip(item, at); }
      catch (e2) {
        try { track.overwriteClip(item, makeTime(at)); } catch (e3) { return fail('silPlaceFailed', String(e3)); }
      }
      var cl = track.clips, last = cl.numItems ? cl[cl.numItems - 1] : null, end = last ? secOf(last.end) : NaN;
      if (cl.numItems <= had || isNaN(end) || end <= at + 0.0005) { return fail('silPlaceFailed', 'piece ' + (placed + 1) + ' did not land'); }
      if (pc.m && pc.k !== 'audio') { if (setMotion(last, pc.m)) { moved++; } }
      at = end;
      placed++;
    }
    return ok({ placed: placed, at: at, video: vt.clips.numItems, audio: au.clips.numItems, motion: moved });
  });

  /** {id} — puts the source clips' own in/out points back and opens the new sequence. */
  Q.silenceEnd = guard(function (encoded) {
    var a = arg(encoded), st = silState(), restored = 0;
    for (var k in st.saved) {
      if (!st.saved.hasOwnProperty(k)) { continue; }
      var keep = st.saved[k], item = itemByNode(keep.node, keep.path);
      if (!item) { continue; }
      try {
        // (an in point at 0 is the same as none; an out point that was never set reads as the end of the media)
        if (keep.a !== null && !isNaN(keep.a) && keep.a > 0.0005) { item.setInPoint(keep.a, 4); } else { item.clearInPoint(); }
        if (keep.b !== null && !isNaN(keep.b) && keep.b > 0) { item.setOutPoint(keep.b, 4); } else { item.clearOutPoint(); }
        restored++;
      } catch (e) {}
    }
    st.saved = {};
    var s = seqById(a.id);
    if (!s) { return ok({ opened: false, restored: restored }); }
    var opened = false, end = 0;
    try { opened = !!app.project.openSequence(String(a.id)); } catch (e2) { opened = false; }
    try { s.setPlayerPosition('0'); } catch (e3) {}
    for (var i = 0; i < s.videoTracks.numTracks; i++) { var c = s.videoTracks[i].clips; if (c.numItems) { end = Math.max(end, secOf(c[c.numItems - 1].end)); } }
    for (i = 0; i < s.audioTracks.numTracks; i++) { var c2 = s.audioTracks[i].clips; if (c2.numItems) { end = Math.max(end, secOf(c2[c2.numItems - 1].end)); } }
    return ok({ opened: opened, restored: restored, name: String(s.name), seconds: end, video: s.videoTracks.numTracks ? s.videoTracks[0].clips.numItems : 0 });
  });

  /** {ranges: [[from, to], …]} — marks the pauses on the active sequence (and removes the marks made before). Empty list = just remove. */
  Q.silenceMark = guard(function (encoded) {
    var a = arg(encoded), seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var marks = seq.markers, old = [], m = null, cleared = 0, added = 0, i;
    try { m = marks.getFirstMarker(); } catch (e) { m = null; }
    var guardN = 0;
    while (m && guardN++ < 5000) {
      var nm = '';
      try { nm = String(m.name); } catch (e1) { nm = ''; }
      if (nm.indexOf(SIL_MARK) === 0) { old.push(m); }
      try { m = marks.getNextMarker(m); } catch (e2) { m = null; }
    }
    for (i = 0; i < old.length; i++) { try { marks.deleteMarker(old[i]); cleared++; } catch (e3) {} }
    var list = a.ranges || [];
    for (i = 0; i < list.length; i++) {
      var from = Number(list[i][0]), to = Number(list[i][1]);
      if (isNaN(from) || isNaN(to) || to <= from) { continue; }
      try {
        var mk = marks.createMarker(from);
        mk.name = SIL_MARK + ' ' + (added + 1);
        mk.end = makeTime(to);
        try { mk.setColorByIndex(1); } catch (e4) {}
        added++;
      } catch (e5) { return fail('silMarkFailed', String(e5)); }
    }
    return ok({ added: added, cleared: cleared });
  });

  // ------------------------------------------------------------------ sound effects: into the project, onto a free track at the playhead
  var SFX_BIN = 'SFX';

  function rangeFree(track, from, to) {
    var clips = track.clips, n = 0;
    try { n = clips.numItems; } catch (e) { n = 0; }
    for (var i = 0; i < n; i++) {
      if (secOf(clips[i].start) < to - 0.0005 && secOf(clips[i].end) > from + 0.0005) { return false; }
    }
    return true;
  }

  function addAudioTrack(seq) {
    var before = seq.audioTracks.numTracks;
    try {
      app.enableQE();
      var qs = qe.project.getActiveSequence();
      qs.addTracks(0, 0, 1, 1, before);                 // no video tracks; one standard audio track below the last
    } catch (e) { return false; }
    return seq.audioTracks.numTracks > before;
  }

  /**
   * {path, bin, seconds, place}
   * Imports the sound into its bin (once), then — when place is not false and a sequence is open — lays it at the
   * playhead on the first audio track that is free there: A2 and below first (A1 is usually the dialogue), then A1,
   * then a new track. Nothing already on the timeline is overwritten.
   */
  Q.sfxInsert = guard(function (encoded) {
    var a = arg(encoded), path = String(a.path || '').replace(/\\/g, '/');
    if (!new File(path).exists) { return fail('sfxFileMissing', path); }
    var binName = strTrim(String(a.bin || '').replace(/[\\\/:*?"<>|]/g, ' ')).substring(0, 40) || SFX_BIN;
    var bin = rootBin(binName, true), item = itemWithPath(bin, path), existed = !!item;
    if (!item) {
      try { app.project.importFiles([path], true, bin || app.project.rootItem, false); } catch (e) { return fail('sfxImportFailed', String(e)); }
      item = itemWithPath(rootBin(binName, false), path) || itemWithPath(app.project.rootItem, path);
    }
    if (!item) { return fail('sfxImportFailed', baseOf(path)); }
    try { if (item.select) { item.select(); } } catch (e2) {}
    var out = { name: String(item.name), bin: bin ? binName : '', existed: existed, placed: false, why: '' };
    var seq = activeSeq();
    if (a.place === false) { out.why = 'importOnly'; return ok(out); }
    if (!seq) { out.why = 'noSequence'; return ok(out); }
    try { item.clearInPoint(); item.clearOutPoint(); } catch (e3) {}
    var dur = NaN;
    try { dur = secOf(item.getOutPoint()) - secOf(item.getInPoint()); } catch (e4) { dur = NaN; }
    if (isNaN(dur) || dur <= 0) { dur = Number(a.seconds) > 0 ? Number(a.seconds) : 1; }
    var ph = playheadOf(seq), n = seq.audioTracks.numTracks, ti = -1, i, added = false;
    for (i = 1; i < n && ti < 0; i++) { if (rangeFree(seq.audioTracks[i], ph, ph + dur)) { ti = i; } }
    if (ti < 0 && n && rangeFree(seq.audioTracks[0], ph, ph + dur)) { ti = 0; }
    if (ti < 0) {
      if (!addAudioTrack(seq)) { out.why = 'noFreeTrack'; return ok(out); }
      added = true; ti = seq.audioTracks.numTracks - 1;
    }
    var track = seq.audioTracks[ti];
    try { track.overwriteClip(item, ph); }
    catch (e5) {
      try { track.overwriteClip(item, makeTime(ph)); } catch (e6) { out.why = 'placeFailed'; out.detail = String(e6); return ok(out); }
    }
    // where did it really land? (Premiere decides the track for some files)
    var order = [ti];
    for (i = 0; i < seq.audioTracks.numTracks; i++) { if (i !== ti) { order.push(i); } }
    for (var oi = 0; oi < order.length && !out.placed; oi++) {
      var t = order[oi], cl = seq.audioTracks[t].clips;
      for (i = 0; i < cl.numItems; i++) {
        var same = false;
        try { same = Math.abs(secOf(cl[i].start) - ph) < 0.06 && String(cl[i].projectItem.getMediaPath() || '').replace(/\\/g, '/').toLowerCase() === path.toLowerCase(); } catch (e7) { same = false; }
        if (same) { out.placed = true; out.track = t + 1; out.start = secOf(cl[i].start); out.end = secOf(cl[i].end); break; }
      }
    }
    if (!out.placed) { out.why = 'placeFailed'; }
    out.addedTrack = added;
    return ok(out);
  });

  // ------------------------------------------------------------------ text animations
  // One "rig" per clip: a Transform effect, plus Gaussian Blur and Crop when the animation needs them. The panel
  // sends ready keyframes; this side only finds or adds the effects and writes the values.
  // Applying another animation re-uses the rig instead of piling effects up. The rig is recognised by a mark that
  // changes nothing on screen: its Transform has Skew Axis set to 20 or more whole turns (Skew itself stays 0);
  // the turns above 20 say which of the other two effects belong to it (1 = blur, 2 = crop).
  var ANIM_FX = {
    t: { matchName: 'AE.ADBE Geometry2', displayName: 'Transform' },
    b: { matchName: 'AE.ADBE Gaussian Blur 2', displayName: 'Gaussian Blur' },
    c: { matchName: 'AE.ADBE AECrop', displayName: 'Crop' }
  };
  var ANIM_BIT = { b: 1, c: 2 };
  var ANIM_MARK = 20;
  // id → [names to look for], position in the effect (used when no name matches, e.g. another UI language), kind
  var ANIM_PARAMS = {
    anchor: [['Anchor Point'], 0, 'point'], position: [['Position'], 1, 'point'], uniform: [['Uniform Scale'], 2, 'bool'],
    scaleH: [['Scale Height', 'Scale'], 3, 'number'], scaleW: [['Scale Width'], 4, 'number'], skewAxis: [['Skew Axis'], 6, 'number'],
    rotation: [['Rotation'], 7, 'number'], opacity: [['Opacity'], 8, 'number'],
    useComp: [["Use Composition's Shutter Angle", 'Use Composition’s Shutter Angle'], 9, 'bool'], shutter: [['Shutter Angle'], 10, 'number'],
    blur: [['Blurriness'], 0, 'number'],
    left: [['Left'], 0, 'number'], top: [['Top'], 1, 'number'], right: [['Right'], 2, 'number'], bottom: [['Bottom'], 3, 'number']
  };

  function animProp(comp, id, report) {
    var d = ANIM_PARAMS[id];
    if (!d) { return null; }
    var props = comp.properties, n = 0, i, j;
    try { n = props.numItems; } catch (e) {}
    for (j = 0; j < d[0].length; j++) {
      var want = normName(d[0][j]);
      for (i = 0; i < n; i++) {
        var dn = '';
        try { dn = normName(props[i].displayName); } catch (e2) {}
        if (dn === want) { return props[i]; }
      }
    }
    if (d[1] < n) { if (report) { report.byIndex++; } return props[d[1]]; }
    return null;
  }

  function animIsFx(comp, role) {
    var fx = ANIM_FX[role], mn = '', dn = '';
    try { mn = String(comp.matchName); } catch (e) {}
    if (mn === fx.matchName) { return true; }
    try { dn = normName(comp.displayName); } catch (e2) {}
    if (dn !== normName(fx.displayName)) { return false; }
    if (!mn) { return true; }
    if (role !== 't') { return false; }
    // same name under another match name: ours only if it has the Transform effect's long parameter list
    var np = 0;
    try { np = comp.properties.numItems; } catch (e3) {}
    return np >= 11 && np <= 13;
  }

  /** −1 when this Transform is not ours, otherwise the bits of the effects that go with it. */
  function animMark(comp) {
    var p = animProp(comp, 'skewAxis'), v = NaN;
    if (!p) { return -1; }
    try { v = Number(p.getValue()); } catch (e) {}
    if (isNaN(v)) { return -1; }
    var turns = Math.round(v / 360);
    return (turns >= ANIM_MARK && turns < ANIM_MARK + 4 && Math.abs(v - turns * 360) < 1) ? turns - ANIM_MARK : -1;
  }
  function animSetMark(comp, bits) {
    var p = animProp(comp, 'skewAxis');
    if (!p) { return false; }
    try { if (p.isTimeVarying()) { p.setTimeVarying(false); } } catch (e) {}
    try { p.setValue((ANIM_MARK + bits) * 360, 1); } catch (e2) { return false; }
    return animMark(comp) === bits;
  }
  /** In case Premiere does not keep the mark: what this session did, by clip. */
  function animMem() { if (!$.global.__qfxAnim) { $.global.__qfxAnim = {}; } return $.global.__qfxAnim; }
  function animClipId(clip) { var id = ''; try { id = String(clip.nodeId || ''); } catch (e) {} return id; }

  function animFindRig(clip) {
    var n = componentCount(clip), i, last = -1;
    for (i = 0; i < n; i++) {
      var c = clip.components[i];
      if (!animIsFx(c, 't')) { continue; }
      last = i;
      var b = animMark(c);
      if (b >= 0) { return { index: i, bits: b }; }
    }
    var id = animClipId(clip), mem = id ? animMem()['$' + id] : undefined;
    if (mem !== undefined && last >= 0) { return { index: last, bits: mem, remembered: true }; }
    return null;
  }
  function animAfter(clip, from, role) {
    var n = componentCount(clip);
    for (var i = from + 1; i < n; i++) { if (animIsFx(clip.components[i], role)) { return i; } }
    return -1;
  }
  function animLast(clip, role) {
    for (var i = componentCount(clip) - 1; i >= 0; i--) { if (animIsFx(clip.components[i], role)) { return i; } }
    return -1;
  }
  function animSel(seq, track, startTicks) {
    var clips = null;
    try { clips = seq.videoTracks[track].clips; } catch (e) { return null; }
    for (var c = 0; c < clips.numItems; c++) {
      if (String(clips[c].start.ticks) === String(startTicks)) {
        return { clip: clips[c], track: track, index: c, video: true, startTicks: String(startTicks), name: String(clips[c].name) };
      }
    }
    return null;
  }
  function animKeys(p) {
    var out = [];
    if (!p.k) { return out; }
    for (var i = 0; i < p.k.length; i++) { out.push({ t: p.k[i][0], v: p.k[i][1], interp: p.hold ? 4 : 0 }); }
    return out;
  }

  /** The QE effect object for one of the rig's effects: by its name, by its match name, then by looking through the list. */
  function animGetFx(role) {
    var fx = ANIM_FX[role], obj = getVideoFx(fx.displayName, false), d = derivedName(fx.matchName), i;
    if (!obj && d && d !== fx.displayName) { obj = getVideoFx(d, false); }
    if (!obj) { obj = getVideoFx(fx.matchName, true); }
    if (!obj) {
      var list = [], want = normName(fx.displayName);
      try { list = toArray(qe.project.getVideoEffectList()); } catch (e) { list = []; }
      for (i = 0; i < list.length && !obj; i++) { if (normName(list[i]) === want) { obj = getVideoFx(String(list[i]), false); } }
    }
    return obj;
  }
  /**
   * The QE item of exactly this clip. The QE side can lag behind the timeline (right after a drop or an import it may
   * still show what was there before), so the item must agree with the clip by start and by name or end — otherwise
   * an effect could land on the wrong clip. Returns null when QE does not show the clip (yet).
   */
  function animQeItem(sel, clip, frame, diag) {
    var qt = null, n = 0, i, best = null, bestRank = 0;
    try { qt = qe.project.getActiveSequence().getVideoTrackAt(sel.track); } catch (e) {}
    if (!qt) { diag.qe = 'no track'; return null; }
    try { n = qt.numItems; } catch (e2) {}
    var cs = Number(sel.startTicks), ce = NaN, cn = '';
    try { ce = Number(clip.end.ticks); } catch (e3) {}
    try { cn = String(clip.name); } catch (e4) {}
    var seen = [];
    for (i = 0; i < n; i++) {
      var it = null, ty = '', st = NaN, en = NaN, nm = '';
      try { it = qt.getItemAt(i); } catch (e5) {}
      if (!it) { continue; }
      try { ty = String(it.type); } catch (e6) {}
      if (ty === 'Empty' || ty === 'Transition') { continue; }
      try { st = Number(it.start.ticks); } catch (e7) {}
      try { en = Number(it.end.ticks); } catch (e8) {}
      try { nm = String(it.name === undefined || it.name === null ? '' : it.name); } catch (e9) {}
      if (seen.length < 6) { seen.push(nm + '@' + (isNaN(st) ? '?' : Math.round(st / TPS * 100) / 100)); }
      if (isNaN(st) || Math.abs(st - cs) > frame / 2) { continue; }
      var sameName = nm !== '' && nm === cn, sameEnd = !isNaN(en) && !isNaN(ce) && Math.abs(en - ce) <= frame;
      var rank = (sameName ? 2 : 0) + (sameEnd ? 1 : 0);
      if (!rank && nm === '' && isNaN(en)) { rank = 1; }               // QE tells nothing but the start: take it
      if (rank > bestRank) { best = it; bestRank = rank; }
    }
    diag.qe = n + ' items: ' + seen.join(', ');
    return best;
  }
  function animCompNames(clip) {
    var out = [], n = componentCount(clip);
    for (var i = 0; i < n && i < 12; i++) {
      var m = '';
      try { m = String(clip.components[i].matchName || clip.components[i].displayName); } catch (e) {}
      out.push(m);
    }
    return out;
  }
  /**
   * Put one of the rig's effects on the clip and say where it ended up. Success is judged by the clip itself
   * (one more effect than before), not by what QE answers.
   * → {index, clip} or {index: -1, why: 'noEffect' | 'noQeItem' | 'addFailed' | 'notSeen'}
   */
  function animSig(clip) {
    var out = [], n = componentCount(clip);
    for (var i = 0; i < n; i++) {
      var m = '', d = '';
      try { m = String(clip.components[i].matchName); } catch (e) {}
      try { d = String(clip.components[i].displayName); } catch (e2) {}
      out.push(m + '|' + d);
    }
    return out;
  }
  function animAdd(seq, sel, clip, role, frame, diag) {
    var sig = animSig(clip), before = sig.length, obj = animGetFx(role);
    if (!obj) { return { index: -1, why: 'noEffect', clip: clip }; }
    var it = animQeItem(sel, clip, frame, diag);
    if (!it) { return { index: -1, why: 'noQeItem', clip: clip }; }
    var r = false, err = '';
    try { r = it.addVideoEffect(obj); } catch (e) { r = false; err = String(e); }
    var now = refetch(seq, sel), sig2 = animSig(now), after = sig2.length;
    if (after <= before) {
      if (err) { diag.err = err; }
      return { index: -1, why: r === false ? 'addFailed' : 'notSeen', clip: now };
    }
    // Premiere does not always put a new effect last (on a text clip it goes above the ones added before):
    // the new one is where the list stops matching the old one
    var idx = 0;
    while (idx < before && sig2[idx] === sig[idx]) { idx++; }
    if (!animIsFx(now.components[idx], role)) {
      var want = role === 't' ? 11 : (role === 'c' ? 4 : 1), np = 0;
      try { np = now.components[idx].properties.numItems; } catch (e2) {}
      if (np < want) { diag.comps = animCompNames(now); return { index: -1, why: 'notSeen', clip: now }; }
    }
    return { index: idx, clip: now };
  }
  /** The effect of this kind closest to the rig's Transform, on either side of it. */
  function animNear(clip, at, role) {
    var n = componentCount(clip);
    for (var d = 1; d < n; d++) {
      if (at + d < n && animIsFx(clip.components[at + d], role)) { return at + d; }
      if (at - d >= 0 && animIsFx(clip.components[at - d], role)) { return at - d; }
    }
    return -1;
  }

  // When Premiere will not take the Transform effect, the animation can still be written on the clip's own Motion
  // and Opacity (same numbers, same meaning) — only blur, masks and motion blur are lost. Used for clips this
  // plugin has just made, whose Motion is still untouched.
  var MOTION_PARAMS = {
    position: [['Position'], 0, 'point'], scaleH: [['Scale Height', 'Scale'], 1, 'number'], scaleW: [['Scale Width'], 2, 'number'],
    uniform: [['Uniform Scale'], 3, 'bool'], rotation: [['Rotation'], 4, 'number'], anchor: [['Anchor Point'], 5, 'point']
  };
  function animIntrinsic(clip, matchName, displayName) {
    var n = componentCount(clip), i, mn, dn;
    for (i = 0; i < n; i++) { mn = ''; try { mn = String(clip.components[i].matchName); } catch (e) {} if (mn === matchName) { return clip.components[i]; } }
    for (i = 0; i < n; i++) { dn = ''; try { dn = normName(clip.components[i].displayName); } catch (e2) {} if (dn === normName(displayName)) { return clip.components[i]; } }
    return null;
  }
  function animNamed(comp, d) {
    var props = comp.properties, n = 0, i, j;
    try { n = props.numItems; } catch (e) {}
    for (j = 0; j < d[0].length; j++) {
      var want = normName(d[0][j]);
      for (i = 0; i < n; i++) { var dn = ''; try { dn = normName(props[i].displayName); } catch (e2) {} if (dn === want) { return props[i]; } }
    }
    return d[1] < n ? props[d[1]] : null;
  }
  function animMotion(clip, effects, timing, report) {
    var mo = animIntrinsic(clip, 'AE.ADBE Motion', 'Motion'), op = animIntrinsic(clip, 'AE.ADBE Opacity', 'Opacity');
    if (!mo) { return false; }
    var e, i, done = 0;
    for (e = 0; e < effects.length; e++) {
      var fx = effects[e], list = fx.params || [];
      if (fx.role !== 't') { if (fx.use) { addUnique(report.lost, ANIM_FX[fx.role] ? ANIM_FX[fx.role].displayName : fx.role); } continue; }
      // the switch first: with Uniform Scale on, Premiere ignores the width
      var order = [];
      for (i = 0; i < list.length; i++) { if (list[i].id === 'uniform') { order.unshift(list[i]); } else { order.push(list[i]); } }
      for (i = 0; i < order.length; i++) {
        var p = order[i], prop = null, kind = 'number';
        if (p.id === 'opacity') { prop = op ? animNamed(op, [['Opacity'], 0]) : null; }
        else if (MOTION_PARAMS[p.id]) { prop = animNamed(mo, MOTION_PARAMS[p.id]); kind = MOTION_PARAMS[p.id][2]; }
        else { continue; }                                             // shutter angle and the like: Motion has none
        if (!prop) { addUnique(report.notFound, p.id); continue; }
        var keys = animKeys(p), okSet = false;
        try { okSet = setOne(prop, { kind: kind, value: p.v, keys: keys }, timing, { type: 1, speed: 1 }, i === order.length - 1 ? 1 : 0); } catch (e3) { okSet = false; }
        if (okSet) { report.keys += keys.length; done++; } else { addUnique(report.notFound, p.id); }
      }
    }
    return done > 0;
  }
  function animMotionReset(clip) {
    var mo = animIntrinsic(clip, 'AE.ADBE Motion', 'Motion'), op = animIntrinsic(clip, 'AE.ADBE Opacity', 'Opacity');
    var rest = { position: [0.5, 0.5], scaleH: 100, scaleW: 100, uniform: true, rotation: 0, anchor: [0.5, 0.5] }, id, prop;
    for (id in rest) {
      if (!rest.hasOwnProperty(id) || !mo) { continue; }
      prop = animNamed(mo, MOTION_PARAMS[id]);
      if (prop) { try { setOne(prop, { kind: MOTION_PARAMS[id][2], value: rest[id], keys: [] }, null, null, 0); } catch (e) {} }
    }
    prop = op ? animNamed(op, [['Opacity'], 0]) : null;
    if (prop) { try { setOne(prop, { kind: 'number', value: 100, keys: [] }, null, null, 1); } catch (e2) {} }
  }

  /** The selected video clips an animation would go on, with what the panel needs to build it. */
  Q.animTargets = guard(function () {
    var seq = activeSeq();
    if (!seq) { return ok({ hasSequence: false, clips: [] }); }
    var ft = frameTicks(seq), w = 1920, h = 1080;
    try { w = Number(seq.frameSizeHorizontal) || w; h = Number(seq.frameSizeVertical) || h; } catch (e) {}
    var sel = collectSelected(seq, true, false), out = [];
    for (var i = 0; i < sel.length; i++) {
      var c = sel[i].clip, d = 0, rig = null;
      try { d = Number(c.end.seconds) - Number(c.start.seconds); } catch (e2) { d = 0; }
      try { rig = animFindRig(c); } catch (e3) { rig = null; }
      out.push({ track: sel[i].track, start: sel[i].startTicks, name: sel[i].name, dur: d, rig: !!rig });
    }
    return ok({ hasSequence: true, qe: hasQE(), fps: ft > 0 ? TPS / ft : 25, width: w, height: h, clips: out });
  });

  /**
   * {jobs: [{track, start, effects: [{role: 't'|'b'|'c', use, params: [{id, v | k: [[seconds, value]…], hold}]}]}], onlyExisting}
   * Times are seconds from the clip's start on the timeline.
   */
  Q.animApply = guard(function (encoded) {
    var a = arg(encoded), seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    if (!hasQE()) { return fail('noQE'); }
    var frame = frameTicks(seq), jobs = a.jobs || [];
    var report = { clips: 0, total: jobs.length, gone: 0, added: [], missing: [], notFound: [], byIndex: 0, keys: 0, marked: true, skipped: 0,
      retry: [], why: '', diag: {}, motion: 0, lost: [], moved: false };
    for (var j = 0; j < jobs.length; j++) {
      var job = jobs[j], sel = animSel(seq, job.track, job.start), e, i, got;
      if (!sel) { report.gone++; continue; }
      var clip = sel.clip, timing = clipTiming(clip), rig = animFindRig(clip), id = animClipId(clip), mem = animMem();
      if (!rig) {
        if (a.onlyExisting) { report.skipped++; continue; }
        got = animAdd(seq, sel, clip, 't', frame, report.diag);
        clip = got.clip;
        if (got.index < 0) {
          report.why = got.why;
          // last resort for a clip this plugin made: the clip's own Motion and Opacity
          if (a.motion && (job.fresh || (id && mem['m$' + id])) && animMotion(clip, job.effects, timing, report)) {
            if (id) { mem['m$' + id] = true; }
            report.motion++; report.clips++;
            animShow(seq, clip, job, report);
            continue;
          }
          report.retry.push(j);
          addUnique(report.missing, ANIM_FX.t.displayName);
          continue;
        }
        // marked at once: every later step finds the Transform again by its mark, wherever Premiere moves it
        if (!animSetMark(clip.components[got.index], 0)) { report.marked = false; }
        if (id) { mem['$' + id] = 0; }
        rig = { index: got.index, bits: 0 };
        addUnique(report.added, ANIM_FX.t.displayName);
      }
      if (id && mem['m$' + id]) { animMotionReset(clip); mem['m$' + id] = false; }   // an earlier fallback: do not move twice
      // make sure the other effects this animation needs are there
      var bits = rig.bits, where = { t: rig.index, b: -1, c: -1 }, fresh = {};
      for (e = 0; e < job.effects.length; e++) {
        var role = job.effects[e].role;
        if (role === 't' || !ANIM_FX[role]) { continue; }
        if (bits & ANIM_BIT[role]) { where[role] = animNear(clip, where.t, role); }
        if (where[role] < 0 && job.effects[e].use) {
          got = animAdd(seq, sel, clip, role, frame, report.diag);
          clip = got.clip;
          if (got.index >= 0) {
            bits = bits | ANIM_BIT[role]; fresh[role] = true; addUnique(report.added, ANIM_FX[role].displayName);
            // adding one may have moved the others: find the Transform again
            var again = animFindRig(clip);
            if (again) { where.t = again.index; }
            else if (got.index <= where.t) { where.t++; }
          } else { addUnique(report.missing, ANIM_FX[role].displayName); if (!report.why) { report.why = got.why || 'notSeen'; } }
        }
        if (where[role] < 0 && !fresh[role]) { bits = bits & ~ANIM_BIT[role]; }
      }
      // where everything is now
      for (e = 0; e < job.effects.length; e++) {
        var ro = job.effects[e].role;
        if (ro !== 't' && (bits & ANIM_BIT[ro])) { where[ro] = animNear(clip, where.t, ro); if (where[ro] < 0) { bits = bits & ~ANIM_BIT[ro]; } }
      }
      // write the values
      var comps = clip.components, lastE = -1;
      for (e = 0; e < job.effects.length; e++) { if (where[job.effects[e].role] >= 0) { lastE = e; } }
      for (e = 0; e < job.effects.length; e++) {
        var fx = job.effects[e], ci = where[fx.role];
        if (ci === undefined || ci < 0) { continue; }
        var comp = comps[ci], list = fx.params || [];
        for (i = 0; i < list.length; i++) {
          var p = list[i], def = ANIM_PARAMS[p.id];
          if (!def) { continue; }
          var prop = animProp(comp, p.id, report);
          if (!prop) { addUnique(report.notFound, p.id); continue; }
          var keys = animKeys(p), okSet = false;
          try { okSet = setOne(prop, { kind: def[2], value: p.v, keys: keys }, timing, { type: 1, speed: 1 }, (e === lastE && i === list.length - 1) ? 1 : 0); }
          catch (e4) { okSet = false; if (!report.diag.set) { report.diag.set = p.id + ': ' + String(e4); } }
          if (okSet) { report.keys += keys.length; } else { addUnique(report.notFound, p.id); }
        }
      }
      if (!animSetMark(comps[where.t], bits)) { report.marked = false; }
      if (id) { mem['$' + id] = bits; }
      report.diag.comps = animCompNames(clip);
      report.diag.at = [where.t, where.b, where.c];
      report.clips++;
      animShow(seq, clip, job, report);
    }
    if (!report.clips) {
      if (report.skipped === jobs.length && jobs.length) { return fail('animNothing'); }
      return fail(report.missing.length ? 'animFxMissing' : 'animFailed', report.missing.join(', '), report);
    }
    return ok(report);
  });

  /**
   * A new text sits on the first frame of its entrance, where most entrances show nothing at all. So after putting
   * an animation on a clip this plugin made, the playhead goes to where the text stands fully visible
   * (job.show = {from, to}: that stretch, in seconds from the clip's start) unless it is already there.
   */
  function animShow(seq, clip, job, report) {
    if (!job.show) { return; }
    try {
      var st = secOf(clip.start), en = secOf(clip.end), ph = playheadOf(seq), fr = frameTicks(seq) / TPS;
      var from = st + Math.max(0, Number(job.show.from) || 0), to = st + Math.max(0, Number(job.show.to) || 0);
      if (!(to > from)) { to = en; }
      if (ph >= from - fr / 2 && ph < Math.min(to, en) - fr / 2) { return; }
      var at = Math.min(from + fr, en - fr);
      if (!(at > st)) { return; }
      seq.setPlayerPosition(String(Math.round(Math.round(at / fr) * fr * TPS)));
      report.moved = true;
    } catch (e) {}
  }

  /** For finding out how Premiere really arranges a clip's effects: every effect of the selected clips, with its values. */
  Q.debugDump = guard(function () {
    var seq = activeSeq();
    if (!seq) { return ok({ clips: [] }); }
    var sel = collectSelected(seq, true, false), out = [];
    for (var s2 = 0; s2 < sel.length && s2 < 3; s2++) {
      var c = sel[s2].clip, comps = [], n = componentCount(c);
      for (var i = 0; i < n && i < 24; i++) {
        var m = c.components[i], props = [], np = 0;
        try { np = m.properties.numItems; } catch (e) {}
        for (var k = 0; k < np && k < 16; k++) {
          var pr = m.properties[k], v = '', tv = false, nk = 0;
          try { v = String(pr.getValue()); } catch (e2) { v = '!' + String(e2); }
          try { tv = !!pr.isTimeVarying(); } catch (e3) {}
          if (tv) { try { nk = pr.getKeys().length; } catch (e4) {} }
          if (v.length > 60) { v = v.substr(0, 60) + '…'; }
          props.push(String(pr.displayName) + '=' + v + (tv ? ' [' + nk + ' keys]' : ''));
        }
        var mn = '', dn = '';
        try { mn = String(m.matchName); } catch (e5) {}
        try { dn = String(m.displayName); } catch (e6) {}
        comps.push({ i: i, match: mn, name: dn, props: props });
      }
      out.push({ name: sel[s2].name, track: sel[s2].track, start: secOf(c.start), end: secOf(c.end), comps: comps });
    }
    return ok({ clips: out, playhead: playheadOf(seq) });
  });

  /**
   * {names: [...], atEnd, frames} — experimental: puts one of Premiere's own per-letter tools (the built-in
   * "Text Animator" / "Typewriter" transitions, Premiere 25.5+) on the start or end of the selected clips.
   * Scripting cannot set a transition's options, so it arrives with its default look.
   */
  Q.animNative = guard(function (encoded) {
    var a = arg(encoded), seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    if (!hasQE()) { return fail('noQE'); }
    var targets = collectSelected(seq, true, false);
    if (!targets.length) { return noTargetsError(seq, true, false); }
    var names = a.names || [], tr = null, used = '', i, list = [];
    for (i = 0; i < names.length && !tr; i++) {
      try { tr = qe.project.getVideoTransitionByName(names[i]); } catch (e) { tr = null; }
      if (tr) { used = names[i]; }
    }
    if (!tr && names.length) {
      try { list = toArray(qe.project.getVideoTransitionList()); } catch (e2) { list = []; }
      var want = normName(names[0]);
      for (i = 0; i < list.length && !tr; i++) {
        if (normName(list[i]).indexOf(want) >= 0) {
          try { tr = qe.project.getVideoTransitionByName(list[i]); } catch (e3) { tr = null; }
          if (tr) { used = String(list[i]); }
        }
      }
    }
    if (!tr) { return fail('animNoNative', names.length ? names[0] : ''); }
    var qeSeq = qe.project.getActiveSequence(), frame = frameTicks(seq), done = 0, err = '';
    var frames = String(Math.max(2, Math.round(Number(a.frames) || 20)));
    for (i = 0; i < targets.length; i++) {
      var it = qeItemFor(qeSeq, targets[i], frame), r = false;
      if (!it) { continue; }
      try { r = it.addTransition(tr, !a.atEnd, frames, '0:00', a.atEnd ? 1 : 0, true, true); } catch (e4) { r = false; err = String(e4); }
      if (r !== false) { done++; }
    }
    if (!done) { return fail('animNativeFailed', err || used, { name: used }); }
    return ok({ applied: done, total: targets.length, name: used });
  });

  // ------------------------------------------------------------------ new text clips
  // Premiere's scripting cannot make a text layer from nothing; it can only put a Motion Graphics template
  // (.mogrt) on the timeline. So a new text is a plain text template of the editor's own (or one that came with
  // Premiere), placed like any graphic: afterwards it is an ordinary text clip — font, size, wording all editable.
  function textTrackFor(seq, start, end) {
    var n = seq.videoTracks.numTracks, top = -1, i;
    for (i = 0; i < n; i++) { if (!rangeFree(seq.videoTracks[i], start, end)) { top = i; } }
    if (top + 1 < n) { return { index: top + 1, added: false }; }
    if (!addTopTrack(seq)) { return null; }
    return { index: seq.videoTracks.numTracks - 1, added: true };
  }
  function textStarts(seq) {
    var out = {}, n = seq.videoTracks.numTracks;
    for (var t = 0; t < n; t++) {
      var cl = seq.videoTracks[t].clips;
      for (var c = 0; c < cl.numItems; c++) { out[t + ':' + String(cl[c].start.ticks)] = true; }
    }
    return out;
  }
  /** The clip importMGT made: on the asked track at the asked time, otherwise whatever is new around that time. */
  function textFindNew(seq, before, track, start) {
    var n = seq.videoTracks.numTracks, order = [track], t, c;
    for (t = 0; t < n; t++) { if (t !== track) { order.push(t); } }
    for (var pass = 0; pass < 2; pass++) {
      for (var o = 0; o < order.length; o++) {
        t = order[o];
        if (t < 0 || t >= n) { continue; }
        var cl = seq.videoTracks[t].clips;
        for (c = 0; c < cl.numItems; c++) {
          var isNew = !before[t + ':' + String(cl[c].start.ticks)];
          if (Math.abs(secOf(cl[c].start) - start) < 0.06 && (isNew || (pass === 1 && t === track))) { return { clip: cl[c], track: t }; }
        }
      }
    }
    return null;
  }
  function textPlace(seq, path, track, start, seconds) {
    var before = textStarts(seq), err = '';
    try { seq.importMGT(path, String(Math.round(start * TPS)), track, 0); } catch (e) { err = String(e); }
    var got = textFindNew(seq, before, track, start);
    if (!got) { return { error: err || 'no clip' }; }
    var clip = got.clip, len = secOf(clip.end) - secOf(clip.start);
    if (seconds > 0 && Math.abs(len - seconds) > 0.02) {
      try { clip.end = makeTime(start + seconds); } catch (e2) {}
      len = secOf(clip.end) - secOf(clip.start);
    }
    return { clip: clip, track: got.track, start: String(clip.start.ticks), dur: len, name: String(clip.name) };
  }
  function textSelectOnly(seq, clip) {
    try {
      var sel = collectSelected(seq, true, true);
      for (var i = 0; i < sel.length; i++) { try { sel[i].clip.setSelected(false, false); } catch (e) {} }
      clip.setSelected(true, true);
    } catch (e2) {}
  }

  /** {path, seconds} → a new text clip at the playhead, on the first track above whatever is there. */
  Q.textInsert = guard(function (encoded) {
    var a = arg(encoded), seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var path = String(a.path || '').replace(/\\/g, '/');
    if (!path || !new File(path).exists) { return fail('textNoTemplate', path); }
    var seconds = Number(a.seconds) > 0 ? Number(a.seconds) : 3, start = playheadOf(seq);
    var tt = textTrackFor(seq, start, start + seconds);
    if (!tt) { return fail('noFreeTrack'); }
    var r = textPlace(seq, path, tt.index, start, seconds);
    if (r.error) { return fail('textImportFailed', r.error); }
    textSelectOnly(seq, r.clip);
    return ok({ clips: [{ track: r.track, start: r.start, dur: r.dur, name: r.name }], addedTrack: tt.added, track: r.track + 1 });
  });

  /**
   * {marker, path, seconds} — the other half of drag and drop. The panel lets the editor drag a tiny placeholder
   * picture onto the timeline (the only thing a panel is allowed to drag there); this finds where it landed,
   * takes it away and puts the text template in its place. found: 0 = Premiere has not placed it yet, ask again.
   */
  Q.textDrop = guard(function (encoded) {
    var a = arg(encoded), seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var marker = String(a.marker || '').replace(/\\/g, '/').toLowerCase(), path = String(a.path || '').replace(/\\/g, '/');
    var hits = [], n = seq.videoTracks.numTracks, t, c;
    for (t = 0; t < n; t++) {
      var cl = seq.videoTracks[t].clips;
      for (c = 0; c < cl.numItems; c++) {
        var mp = '';
        try { mp = String(cl[c].projectItem.getMediaPath() || '').replace(/\\/g, '/').toLowerCase(); } catch (e) { mp = ''; }
        if (mp && mp === marker) { hits.push({ clip: cl[c], track: t, start: secOf(cl[c].start), end: secOf(cl[c].end) }); }
      }
    }
    if (!hits.length) { return ok({ found: 0, clips: [] }); }
    if (!path || !new File(path).exists) { return fail('textNoTemplate', path); }
    var out = [], failed = '', last = null;
    for (var i = hits.length - 1; i >= 0; i--) {
      var h = hits[i], want = Number(a.seconds) > 0 ? Number(a.seconds) : (h.end - h.start);
      try { h.clip.remove(false, false); } catch (e2) { failed = String(e2); continue; }
      var r = textPlace(seq, path, h.track, h.start, want);
      if (r.error) { failed = r.error; continue; }
      out.push({ track: r.track, start: r.start, dur: r.dur, name: r.name });
      last = r.clip;
    }
    // the placeholder also became a project item: take it out again (a bin can be deleted, a single item cannot)
    try {
      var stray = [];
      walkItems(app.project.rootItem, function (it) { if (mediaPathOf(it).toLowerCase() === marker) { stray.push(it); } }, 0);
      if (stray.length) {
        var tmp = app.project.rootItem.createBin('Quick FX tmp');
        if (tmp) { for (var s2 = 0; s2 < stray.length; s2++) { stray[s2].moveBin(tmp); } tmp.deleteBin(); }
      }
    } catch (e3) {}
    if (!out.length) { return fail('textImportFailed', failed); }
    if (last) { textSelectOnly(seq, last); }
    return ok({ found: hits.length, clips: out });
  });

  // ------------------------------------------------------------------ graphics: timers and lower thirds the panel has rendered
  // The panel draws the animation itself and hands over a finished transparent movie; this side only brings it
  // into the project and puts it on the timeline — at the playhead, or where a dragged placeholder was dropped.
  var GFX_BIN = 'Quick FX Graphics';
  Q.gfxPlace = guard(function (encoded) {
    var a = arg(encoded), seq = activeSeq();
    if (!seq) { return fail('noSequence'); }
    var path = String(a.path || '').replace(/\\/g, '/'), marker = String(a.marker || '').replace(/\\/g, '/').toLowerCase();
    var spots = [], t, c, i, n = seq.videoTracks.numTracks;
    if (marker) {
      for (t = 0; t < n; t++) {
        var cl = seq.videoTracks[t].clips;
        for (c = 0; c < cl.numItems; c++) {
          var mp = '';
          try { mp = String(cl[c].projectItem.getMediaPath() || '').replace(/\\/g, '/').toLowerCase(); } catch (e) { mp = ''; }
          if (mp && mp === marker) { spots.push({ clip: cl[c], track: t, start: secOf(cl[c].start) }); }
        }
      }
      if (!spots.length) { return ok({ found: 0, clips: [] }); }
      if (a.probe) { return ok({ found: spots.length, clips: [] }); }       // only asked whether the drop has happened
    }
    if (!path || !new File(path).exists) { return fail('gfxFileMissing', path); }
    var bin = rootBin(GFX_BIN, true), item = itemWithPath(bin, path);
    if (!item) {
      try { app.project.importFiles([path], true, bin || app.project.rootItem, false); } catch (e2) { return fail('gfxImportFailed', String(e2)); }
      item = itemWithPath(rootBin(GFX_BIN, false), path) || itemWithPath(app.project.rootItem, path);
    }
    if (!item) { return fail('gfxImportFailed', baseOf(path)); }
    try { item.clearInPoint(); item.clearOutPoint(); } catch (e3) {}
    var dur = Number(a.seconds) > 0 ? Number(a.seconds) : 0;
    if (!dur) { try { dur = secOf(item.getOutPoint()) - secOf(item.getInPoint()); } catch (e4) { dur = 0; } }
    if (!(dur > 0)) { dur = 5; }
    var addedTrack = false;
    if (!marker) {
      var ph = playheadOf(seq), slot = textTrackFor(seq, ph, ph + dur);
      if (!slot) { return fail('noFreeTrack'); }
      addedTrack = slot.added;
      spots.push({ clip: null, track: slot.index, start: ph });
    }
    var out = [], failed = '', last = null;
    for (i = spots.length - 1; i >= 0; i--) {
      var sp = spots[i];
      if (sp.clip) { try { sp.clip.remove(false, false); } catch (e5) { failed = String(e5); continue; } }
      var track = seq.videoTracks[sp.track];
      try { track.overwriteClip(item, sp.start); }
      catch (e6) { try { track.overwriteClip(item, makeTime(sp.start)); } catch (e7) { failed = String(e7); continue; } }
      var made = null, order = [sp.track];
      for (t = 0; t < seq.videoTracks.numTracks; t++) { if (t !== sp.track) { order.push(t); } }
      for (var oi = 0; oi < order.length && !made; oi++) {
        var cs = seq.videoTracks[order[oi]].clips;
        for (c = 0; c < cs.numItems; c++) {
          var same = false;
          try { same = Math.abs(secOf(cs[c].start) - sp.start) < 0.06 && String(cs[c].projectItem.getMediaPath() || '').replace(/\\/g, '/').toLowerCase() === path.toLowerCase(); } catch (e8) { same = false; }
          if (same) { made = { clip: cs[c], track: order[oi] }; break; }
        }
      }
      if (!made) { failed = failed || 'not placed'; continue; }
      var moved = false;
      if (a.pos && a.pos.length === 2) {                                 // where on the picture it belongs (0…1 of the frame)
        try {
          var mo = animIntrinsic(made.clip, 'AE.ADBE Motion', 'Motion'), pp = mo ? animNamed(mo, MOTION_PARAMS.position) : null;
          if (pp) { pp.setValue([Number(a.pos[0]), Number(a.pos[1])], 1); moved = true; }
        } catch (e9) { moved = false; }
      }
      out.push({ track: made.track, start: secOf(made.clip.start), dur: secOf(made.clip.end) - secOf(made.clip.start), moved: moved });
      last = made.clip;
    }
    if (marker) {
      try {
        var stray = [];
        walkItems(app.project.rootItem, function (it) { if (mediaPathOf(it).toLowerCase() === marker) { stray.push(it); } }, 0);
        if (stray.length) {
          var tmp = app.project.rootItem.createBin('Quick FX tmp');
          if (tmp) { for (var s2 = 0; s2 < stray.length; s2++) { stray[s2].moveBin(tmp); } tmp.deleteBin(); }
        }
      } catch (e10) {}
    }
    if (!out.length) { return fail('gfxPlaceFailed', failed); }
    if (last) { textSelectOnly(seq, last); }
    return ok({ found: spots.length, clips: out, addedTrack: addedTrack, name: String(item.name) });
  });

  return Q;
})();
