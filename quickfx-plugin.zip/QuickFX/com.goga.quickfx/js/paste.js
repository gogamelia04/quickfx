/*
 * Quick FX — paste: what is on the macOS clipboard (a copied picture, files copied in Finder, a link) and where it goes.
 * No DOM and no Premiere here: the clipboard is read through commands that every Mac has (osascript, sips, pbpaste),
 * and the function that runs them is handed in, so all of it can be tested.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  if (root) { root.QFXPaste = api; }
})(this, function () {
  'use strict';

  var OSA = '/usr/bin/osascript', SIPS = '/usr/bin/sips', PBPASTE = '/usr/bin/pbpaste';
  var IMAGE = { png: 1, jpg: 1, jpeg: 1, gif: 1, tif: 1, tiff: 1, bmp: 1, psd: 1, tga: 1, webp: 1, heic: 1, heif: 1, avif: 1 };
  var VIDEO = { mov: 1, mp4: 1, m4v: 1, mxf: 1, avi: 1, mkv: 1, webm: 1, mts: 1, m2ts: 1, mpg: 1, mpeg: 1 };
  var AUDIO = { wav: 1, mp3: 1, m4a: 1, aac: 1, aif: 1, aiff: 1, flac: 1, ogg: 1 };
  /** Pictures Premiere does not open as they are; they are turned into PNG / JPG first. */
  var CONVERT = { webp: 'canvas', avif: 'canvas', heic: 'sips', heif: 'sips' };

  function extOf(name) { var m = /\.([A-Za-z0-9]+)$/.exec(String(name || '')); return m ? m[1].toLowerCase() : ''; }
  function baseOf(path) { var s = String(path || '').replace(/\\/g, '/'), i = s.lastIndexOf('/'); return i < 0 ? s : s.substring(i + 1); }
  function kindOf(name) { var e = extOf(name); return IMAGE[e] ? 'image' : (VIDEO[e] ? 'video' : (AUDIO[e] ? 'audio' : '')); }
  function convertOf(name) { return CONVERT[extOf(name)] || ''; }

  function two(n) { return (n < 10 ? '0' : '') + n; }
  /** "Paste 2026-11-18 00.15.32" — Latin letters and no colons, safe for Premiere and for the Finder. */
  function stamp(d) {
    d = d || new Date();
    return 'Paste ' + d.getFullYear() + '-' + two(d.getMonth() + 1) + '-' + two(d.getDate()) + ' ' + two(d.getHours()) + '.' + two(d.getMinutes()) + '.' + two(d.getSeconds());
  }
  /** A file name that is not in "taken" yet: "photo.png" → "photo 2.png" → "photo 3.png". */
  function uniqueName(taken, name) {
    var low = {}, i;
    for (i = 0; i < taken.length; i++) { low[String(taken[i]).toLowerCase()] = true; }
    if (!low[name.toLowerCase()]) { return name; }
    var e = extOf(name), stem = e ? name.substring(0, name.length - e.length - 1) : name;
    for (i = 2; i < 10000; i++) { var c = stem + ' ' + i + (e ? '.' + e : ''); if (!low[c.toLowerCase()]) { return c; } }
    return stem + ' ' + Date.now() + (e ? '.' + e : '');
  }
  /** Names that are awkward in a project (slashes, colons, emoji) made plain. */
  function safeName(name) {
    var e = extOf(name), stem = e ? String(name).substring(0, String(name).length - e.length - 1) : String(name || '');
    stem = stem.replace(/[\uD800-\uDFFF︀-️‍⃣]/g, '').replace(/[\/\\:*?"<>|\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').replace(/^[\s.]+|[\s.]+$/g, '');
    if (stem.length > 80) { stem = stem.substring(0, 80).replace(/\s+$/, ''); }
    return (stem || 'file') + (e ? '.' + e : '');
  }

  /** Every file copied in Finder, one path per line (AppleScript with the AppKit pasteboard). */
  var SCRIPT_FILES = [
    'use framework "AppKit"',
    'use scripting additions',
    'set pb to current application\'s NSPasteboard\'s generalPasteboard()',
    'set urls to pb\'s readObjectsForClasses:{current application\'s NSURL} options:{NSPasteboardURLReadingFileURLsOnly:true}',
    'if urls is missing value then return ""',
    'set out to ""',
    'repeat with u in urls',
    'set out to out & ((u\'s |path|()) as text) & linefeed',
    'end repeat',
    'return out'
  ];
  /** The plain way, if the one above is refused: the first copied file only. */
  var SCRIPT_FILE_ONE = ['POSIX path of (the clipboard as «class furl»)'];
  /** A copied picture written to <argument>.png / .tiff / .jpg / .gif — whichever form the clipboard holds; prints the path, or nothing. */
  var SCRIPT_IMAGE = [
    'on run argv',
    'set p to item 1 of argv',
    'set d to missing value',
    'set x to ""',
    'try',
    'set d to the clipboard as «class PNGf»',
    'set x to "png"',
    'end try',
    'if d is missing value then',
    'try',
    'set d to the clipboard as «class TIFF»',
    'set x to "tiff"',
    'end try',
    'end if',
    'if d is missing value then',
    'try',
    'set d to the clipboard as «class JPEG»',
    'set x to "jpg"',
    'end try',
    'end if',
    'if d is missing value then',
    'try',
    'set d to the clipboard as «class GIFf»',
    'set x to "gif"',
    'end try',
    'end if',
    'if d is missing value then return ""',
    'set fp to p & "." & x',
    'set f to open for access (POSIX file fp) with write permission',
    'set eof f to 0',
    'write d to f',
    'close access f',
    'return fp',
    'end run'
  ];
  /** The shortest known way to save a copied PNG, used when the script above is refused: the path is written into the script itself. */
  function scriptPng(path) {
    var q = String(path).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    return ['set d to the clipboard as \u00ABclass PNGf\u00BB', 'set f to open for access POSIX file "' + q + '" with write permission', 'set eof f to 0', 'write d to f', 'close access f'];
  }
  function osaArgs(lines, argv) { var a = [], i; for (i = 0; i < lines.length; i++) { a.push('-e', lines[i]); } return a.concat(argv || []); }
  function parseFiles(out) {
    var lines = String(out || '').split(/\r?\n/), res = [], i;
    for (i = 0; i < lines.length; i++) { var s = lines[i].replace(/^\s+|\s+$/g, ''); if (s && s.charAt(0) === '/') { res.push(s); } }
    return res;
  }

  /**
   * What is on the clipboard: { files: [paths], image: path of a picture written to io.tmp.<ext>, text, log: [what failed] }.
   * Files come first — a file copied in Finder also carries its icon as a picture and its name as text.
   * io: { run(cmd, args) → stdout (throws on failure), exists(path) → bool, tmp: path without extension }
   */
  function read(io) {
    var out = { files: [], image: '', text: '', log: [] };
    function attempt(label, cmd, args) {
      try { var r = io.run(cmd, args); return r === null || r === undefined ? '' : String(r); }
      catch (e) { out.log.push(label + ': ' + String(e && e.message ? e.message : e).replace(/\s+/g, ' ').substring(0, 220)); return null; }
    }
    var s = attempt('files', OSA, osaArgs(SCRIPT_FILES)), i, list;
    if (s === null) { s = attempt('file', OSA, osaArgs(SCRIPT_FILE_ONE)); }
    list = parseFiles(s);
    for (i = 0; i < list.length; i++) { if (io.exists(list[i])) { out.files.push(list[i]); } }
    if (out.files.length) { return out; }
    s = attempt('image', OSA, osaArgs(SCRIPT_IMAGE, [io.tmp]));
    var img = s ? s.replace(/^\s+|\s+$/g, '') : '';
    if (s === null) {                                                   // the long script was refused: the plain one (fails quietly when there is no picture)
      var was = out.log.length;
      if (attempt('png', OSA, osaArgs(scriptPng(io.tmp + '.png'))) !== null && io.exists(io.tmp + '.png')) { img = io.tmp + '.png'; } else { out.log.length = was; }
    }
    if (img && io.exists(img)) {
      if (/\.tiff$/i.test(img)) {                                       // smaller, and every program reads it
        var png = img.replace(/\.tiff$/i, '.png');
        if (attempt('sips', SIPS, ['-s', 'format', 'png', img, '--out', png]) !== null && io.exists(png)) { img = png; }
      }
      out.image = img;
      return out;
    }
    s = attempt('text', PBPASTE, []);
    out.text = s ? s.replace(/^\s+|\s+$/g, '') : '';
    return out;
  }

  /** A link straight to a picture. */
  function isImageUrl(text) {
    var t = String(text || '').replace(/^\s+|\s+$/g, '');
    return /^https?:\/\/[^\s]+$/i.test(t) && /\.(png|jpe?g|gif|webp|avif|bmp|tiff?)(\?[^\s]*)?(#[^\s]*)?$/i.test(t);
  }
  function isUrl(text) { return /^https?:\/\/[^\s/]+\.[^\s/]+\/?\S*$/i.test(String(text || '').replace(/^\s+|\s+$/g, '')); }
  function extOfType(type) {
    var t = String(type || '').toLowerCase().split(';')[0].replace(/\s+/g, '');
    return { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp', 'image/avif': 'avif', 'image/bmp': 'bmp', 'image/tiff': 'tiff' }[t] || '';
  }
  /** How big the picture has to be for Premiere's Scale value: the whole of it inside the frame ("fit") or the frame covered ("fill"), in percent. */
  function scaleFor(mode, iw, ih, sw, sh) {
    if (!(iw > 0 && ih > 0 && sw > 0 && sh > 0)) { return 100; }
    var a = sw / iw, b = sh / ih;
    return Math.round((mode === 'fill' ? Math.max(a, b) : Math.min(a, b)) * 1000) / 10;
  }

  return { OSA: OSA, SIPS: SIPS, PBPASTE: PBPASTE, extOf: extOf, baseOf: baseOf, kindOf: kindOf, convertOf: convertOf, stamp: stamp, uniqueName: uniqueName, safeName: safeName,
    SCRIPT_FILES: SCRIPT_FILES, SCRIPT_FILE_ONE: SCRIPT_FILE_ONE, SCRIPT_IMAGE: SCRIPT_IMAGE, scriptPng: scriptPng, osaArgs: osaArgs, parseFiles: parseFiles, read: read,
    isImageUrl: isImageUrl, isUrl: isUrl, extOfType: extOfType, scaleFor: scaleFor };
});
