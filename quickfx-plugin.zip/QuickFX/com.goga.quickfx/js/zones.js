/*
 * Quick FX — safe-zone overlays.
 * Each platform is described once, in the pixels of its native frame (1080×1920 or 1920×1080).
 * draw() paints it onto any canvas size: the platform frame is fitted (contain) into the sequence
 * frame, so a 9:16 platform on a 16:9 sequence also shows where the vertical crop falls.
 *
 * The margins are what stays covered by the app's own interface. Platforms do not publish one
 * official set for ordinary posts and third-party measurements differ, so these lean cautious.
 * The drawn interface is a generic silhouette (bars and circles), not a copy of any app.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  if (root) { root.QFXZones = api; }
})(this, function () {
  'use strict';

  var FILE_PREFIX = 'QFX-SafeZone-';

  var YT_SAFE = { top: 108, bottom: 108, left: 192, right: 192 };     // title safe: the middle 80%

  var PLATFORMS = [
    { id: 'tiktok', name: 'TikTok', group: 'v', base: [1080, 1920], safe: { top: 160, bottom: 480, left: 60, right: 160 },
      ghost: 'feed', feed: { tabs: true, search: true, avatarInColumn: true, actions: 4, disc: true, lines: 3, nav: true },
      alt: 'tiktok ტიკტოკი თიქთოქი' },
    { id: 'reels', name: 'Instagram Reels', group: 'v', base: [1080, 1920], safe: { top: 220, bottom: 420, left: 60, right: 140 },
      ghost: 'feed', feed: { title: true, camera: true, actions: 4, thumb: true, profileRow: true, lines: 2, nav: true }, grid34: true,
      note: '+ grid 3:4', alt: 'instagram reels ინსტაგრამი რილსი' },
    { id: 'stories', name: 'Instagram Stories', group: 'v', base: [1080, 1920], safe: { top: 250, bottom: 340, left: 48, right: 48 },
      ghost: 'story', alt: 'instagram stories story ინსტაგრამი სთორი' },
    { id: 'fbreels', name: 'Facebook Reels', group: 'v', base: [1080, 1920], safe: { top: 220, bottom: 450, left: 60, right: 140 },
      ghost: 'feed', feed: { title: true, camera: true, actions: 4, thumb: true, profileRow: true, lines: 2, nav: true },
      alt: 'facebook reels ფეისბუქი რილსი' },
    { id: 'shorts', name: 'YouTube Shorts', group: 'v', base: [1080, 1920], safe: { top: 200, bottom: 400, left: 48, right: 192 },
      ghost: 'feed', feed: { search: true, more: true, actions: 5, thumb: true, profileRow: true, lines: 2, nav: true },
      alt: 'youtube shorts იუთუბი შორთსი' },
    { id: 'all', name: 'ყველა ერთად', group: 'v', base: [1080, 1920], safe: { top: 250, bottom: 480, left: 60, right: 192 },
      ghost: 'none', note: 'რაც ყველგან ჩანს', label: 'ALL', alt: 'all universal ყველა უნივერსალური' },
    // YouTube 16:9 — several overlays, so the frame only carries what you are checking at the moment
    { id: 'ytsafe', name: 'YouTube — Safe zone', group: 'h', base: [1920, 1080], safe: YT_SAFE, ghost: 'youtube',
      yt: { action: true }, note: 'title + action safe', label: 'YouTube · TITLE SAFE', alt: 'youtube იუთუბი safe title action 16:9 horizontal' },
    { id: 'ytplayer', name: 'YouTube — პლეერი', group: 'h', base: [1920, 1080], safe: YT_SAFE, ghost: 'youtube',
      yt: { player: true }, note: 'ღილაკები, სუბტიტრები, ლოგო', label: 'YouTube · TITLE SAFE', alt: 'youtube იუთუბი player პლეერი subtitles სუბტიტრები cc watermark ლოგო' },
    { id: 'ytend1', name: 'YouTube — End screen · 1 ვიდეო', group: 'h', base: [1920, 1080], safe: YT_SAFE, ghost: 'youtube',
      yt: { end: 1 }, note: 'ვიდეო + Subscribe', label: 'YouTube · TITLE SAFE', alt: 'youtube იუთუბი end screen endscreen ენდსქრინი ბოლო subscribe' },
    { id: 'ytend2', name: 'YouTube — End screen · 2 ვიდეო', group: 'h', base: [1920, 1080], safe: YT_SAFE, ghost: 'youtube',
      yt: { end: 2 }, note: '2 ვიდეო + Subscribe', label: 'YouTube · TITLE SAFE', alt: 'youtube იუთუბი end screen endscreen ენდსქრინი ბოლო subscribe' },
    { id: 'youtube', name: 'YouTube — ყველა ერთად', group: 'h', base: [1920, 1080], safe: YT_SAFE, ghost: 'youtube',
      yt: { action: true, player: true, end: 1 }, note: 'ყველაფერი ერთ კადრზე', label: 'YouTube · TITLE SAFE', alt: 'youtube იუთუბი all ყველა 16:9 horizontal end screen' }
  ];

  function get(id) {
    for (var i = 0; i < PLATFORMS.length; i++) { if (PLATFORMS[i].id === id) { return PLATFORMS[i]; } }
    return null;
  }

  /** Where the platform's frame sits inside a W×H sequence frame (fitted, centred) and the scale used. */
  function fit(p, W, H) {
    var bw = p.base[0], bh = p.base[1];
    var s = Math.min(W / bw, H / bh);
    var w = bw * s, h = bh * s;
    return { x: (W - w) / 2, y: (H - h) / 2, w: w, h: h, s: s, cropped: Math.abs(W / H - bw / bh) > 0.01 };
  }

  /** The safe rectangle in sequence pixels, rounded. */
  function safeRect(p, W, H) {
    var f = fit(p, W, H), m = p.safe;
    var x = f.x + m.left * f.s, y = f.y + m.top * f.s;
    var w = (p.base[0] - m.left - m.right) * f.s, h = (p.base[1] - m.top - m.bottom) * f.s;
    return { x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) };
  }

  function label(p, W, H) {
    var r = safeRect(p, W, H);
    return (p.label || p.name) + (p.ghost === 'youtube' ? ' 80%' : ' · SAFE ' + r.w + ' × ' + r.h);
  }

  function fileName(id, W, H) { return FILE_PREFIX + id + '-' + W + 'x' + H + '.png'; }

  /** 'QFX-SafeZone-tiktok-1080x1920.png' → 'tiktok' (null when it is not one of ours). */
  function idFromName(name) {
    var m = /QFX-SafeZone-([a-z0-9]+)-\d+x\d+/i.exec(String(name || ''));
    return m ? m[1].toLowerCase() : null;
  }

  // ------------------------------------------------------------------ drawing
  function draw(ctx, id, W, H, opts) {
    var p = get(id);
    if (!p) { return null; }
    opts = opts || {};
    var accent = opts.accent || '#FD4A00';
    var f = fit(p, W, H), s = f.s;
    var BW = p.base[0], BH = p.base[1], m = p.safe;

    ctx.save();
    ctx.clearRect(0, 0, W, H);
    if (opts.background) { ctx.fillStyle = opts.background; ctx.fillRect(0, 0, W, H); }

    // the part of the sequence frame this platform would crop away
    if (f.cropped) {
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      if (f.x > 0.5) { ctx.fillRect(0, 0, f.x, H); ctx.fillRect(f.x + f.w, 0, W - f.x - f.w, H); }
      if (f.y > 0.5) { ctx.fillRect(0, 0, W, f.y); ctx.fillRect(0, f.y + f.h, W, H - f.y - f.h); }
      ctx.strokeStyle = 'rgba(255,255,255,0.9)';
      ctx.lineWidth = Math.max(1, 3 * s);
      ctx.strokeRect(f.x, f.y, f.w, f.h);
    }

    ctx.translate(f.x, f.y);
    ctx.scale(s, s);                                   // from here on: the platform's own pixels

    function white(a) { return 'rgba(255,255,255,' + a + ')'; }
    function rr(x, y, w, h, r, fill) {
      r = Math.min(r, w / 2, h / 2);
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r);
      ctx.closePath();
      ctx.fillStyle = fill; ctx.fill();
    }
    function dot(cx, cy, r, fill) { ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fillStyle = fill; ctx.fill(); }
    function ring(cx, cy, r, lw, stroke, fill) {
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.stroke();
    }
    function dashedRect(x, y, w, h, lw, color, dash) {
      ctx.save();
      ctx.lineWidth = lw; ctx.strokeStyle = color;
      if (ctx.setLineDash) { ctx.setLineDash(dash || [lw * 3.5, lw * 2.5]); }
      ctx.strokeRect(x, y, w, h);
      ctx.restore();
    }
    function chip(text, x, y, bg, fg, size) {
      size = size || 30;
      ctx.font = '600 ' + size + 'px -apple-system, "Helvetica Neue", "Noto Sans Georgian", Arial, sans-serif';
      ctx.textBaseline = 'middle';
      var tw = ctx.measureText(text).width;
      rr(x, y, tw + size * 0.9, size * 1.55, size * 0.3, bg);
      ctx.fillStyle = fg;
      ctx.fillText(text, x + size * 0.45, y + size * 0.8);
    }

    var sx = m.left, sy = m.top, sw = BW - m.left - m.right, sh = BH - m.top - m.bottom;

    if (p.ghost === 'feed') {
      var g = p.feed;
      // top bar
      if (g.tabs) { rr(BW / 2 - 186 - 21, 66, 186, 27, 14, white(0.45)); rr(BW / 2 + 21, 66, 150, 27, 14, white(0.8)); }
      if (g.title) { rr(54, 96, 210, 36, 18, white(0.8)); }
      if (g.search) { ring(1008, 82, 28, 6, white(0.7)); }
      if (g.camera) { rr(966, 84, 66, 54, 14, white(0.7)); }
      if (g.more) { dot(906, 82, 9, white(0.7)); dot(906, 54, 9, white(0.7)); dot(906, 110, 9, white(0.7)); }
      // bottom navigation
      var navH = g.nav ? 138 : 0;
      if (g.nav) {
        ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(0, BH - navH, BW, navH);
        var nx = [120, 330, 540, 750, 960];
        for (var n = 0; n < nx.length; n++) {
          if (n === 2) { rr(nx[n] - 60, BH - navH / 2 - 39, 120, 78, 24, white(0.85)); }
          else { rr(nx[n] - 33, BH - navH / 2 - 33, 66, 66, n === 4 ? 33 : 18, white(n === 0 ? 0.75 : 0.45)); }
        }
      }
      // right action column, stacked upwards from just above the navigation
      var cx = BW - Math.max(78, m.right / 2 + 6), y = BH - navH - 36;
      if (g.disc) { ring(cx, y - 45, 36, 18, white(0.7)); y -= 90 + 45; }
      if (g.thumb) { rr(cx - 39, y - 78, 78, 78, 14, white(0.7)); y -= 78 + 45; }
      for (var a = 0; a < g.actions; a++) {
        rr(cx - 30, y - 15, 60, 15, 8, white(0.7));
        dot(cx, y - 15 - 12 - 42, 42, white(0.7));
        y -= 15 + 12 + 84 + 45;
      }
      if (g.avatarInColumn) { ring(cx, y - 57, 54, 6, white(0.8), white(0.25)); }
      // caption block, bottom left
      var by = BH - m.bottom + 40;
      if (g.profileRow) {
        ring(42 + 39, by + 39, 36, 6, white(0.8), white(0.25));
        rr(42 + 96, by + 22, 240, 33, 16, white(0.85));
        rr(42 + 360, by + 12, 168, 54, 14, white(0.45));
        by += 78 + 30;
      } else {
        rr(42, by, 288, 33, 16, white(0.85));
        by += 33 + 24;
      }
      var widths = [708, 540, 396];
      for (var l = 0; l < g.lines; l++) { rr(42, by, widths[l], 24, 12, white(l === g.lines - 1 && g.lines > 2 ? 0.45 : 0.6)); by += 24 + 24; }
    } else if (p.ghost === 'story') {
      for (var b = 0; b < 3; b++) { rr(30 + b * 344, 42, 332, 9, 5, white(b === 0 ? 0.85 : 0.4)); }
      ring(84, 132, 42, 6, white(0.8), white(0.25));
      rr(150, 108, 250, 30, 15, white(0.85));
      rr(150, 150, 150, 21, 10, white(0.5));
      rr(990, 111, 48, 9, 5, white(0.7)); rr(990, 132, 48, 9, 5, white(0.7));
      ctx.save(); ctx.lineWidth = 6; ctx.strokeStyle = white(0.75);
      ctx.beginPath();
      var fx = 42, fy = BH - 228, fw = 720, fh = 120, fr = 60;
      ctx.moveTo(fx + fr, fy); ctx.arcTo(fx + fw, fy, fx + fw, fy + fh, fr); ctx.arcTo(fx + fw, fy + fh, fx, fy + fh, fr);
      ctx.arcTo(fx, fy + fh, fx, fy, fr); ctx.arcTo(fx, fy, fx + fw, fy, fr); ctx.closePath(); ctx.stroke(); ctx.restore();
      rr(96, BH - 180, 300, 24, 12, white(0.5));
      dot(858, BH - 168, 45, white(0.7)); dot(984, BH - 168, 45, white(0.7));
    } else if (p.ghost === 'youtube') {
      var yt = p.yt || {};
      if (yt.player) {
        // player controls along the bottom
        ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(0, BH - 144, BW, 144);
        rr(42, BH - 114, BW - 84, 9, 5, white(0.75));
        var ix = [42, 114];
        for (var q = 0; q < ix.length; q++) { rr(ix[q], BH - 84, 42, 42, 10, white(q === 0 ? 0.8 : 0.6)); }
        rr(186, BH - 72, 180, 21, 10, white(0.6));
        var rx = [BW - 84, BW - 156, BW - 228];
        for (var w2 = 0; w2 < rx.length; w2++) { rr(rx[w2], BH - 84, 42, 42, 10, white(w2 === 0 ? 0.8 : 0.6)); }
        // info card (top right) + channel watermark (bottom right)
        ring(BW - 78, 72, 33, 6, white(0.8));
        dashedRect(BW - 222, BH - 324, 150, 150, 4, white(0.9), [14, 10]);
        chip('LOGO', BW - 222 + 12, BH - 324 + 12, 'rgba(0,0,0,0.6)', '#FFFFFF', 22);
        // subtitles
        dashedRect(480, BH - 300, 960, 120, 4, white(0.9), [14, 10]);
        chip('CC', 480 + 18, BH - 300 + 18, 'rgba(0,0,0,0.6)', '#FFFFFF', 26);
      }
      if (yt.end) {
        // a typical end-screen layout (last 5–20 seconds): subscribe button + suggested videos
        var cards = yt.end === 2
          ? { sub: [470, 540, 150], vids: [[1010, 150, 640, 360], [1010, 570, 640, 360]] }
          : { sub: [500, 500, 150], vids: [[930, 290, 760, 428]] };
        ctx.save(); ctx.lineWidth = 4; ctx.strokeStyle = white(0.9); if (ctx.setLineDash) { ctx.setLineDash([14, 10]); }
        ctx.beginPath(); ctx.arc(cards.sub[0], cards.sub[1], cards.sub[2], 0, Math.PI * 2); ctx.stroke(); ctx.restore();
        chip('SUBSCRIBE', cards.sub[0] - 92, cards.sub[1] - 20, 'rgba(0,0,0,0.6)', '#FFFFFF', 24);
        for (var v = 0; v < cards.vids.length; v++) {
          var cv = cards.vids[v];
          dashedRect(cv[0], cv[1], cv[2], cv[3], 4, white(0.9), [14, 10]);
          chip(cards.vids.length > 1 ? 'VIDEO ' + (v + 1) : 'VIDEO', cv[0] + 18, cv[1] + 18, 'rgba(0,0,0,0.6)', '#FFFFFF', 24);
        }
        if (!yt.player) { chip('END SCREEN · 5–20 s', 192 + 24, BH - 108 - 64, 'rgba(0,0,0,0.75)', '#FFFFFF', 24); }
      }
      if (yt.action) {
        ctx.lineWidth = 3; ctx.strokeStyle = white(0.7); ctx.strokeRect(96, 54, BW - 192, BH - 108);
        chip('ACTION SAFE 90%', 96 + 12, 54 + 10, 'rgba(0,0,0,0.75)', '#FFFFFF', 24);
      }
    } else {
      // no single interface to show: dim everything outside the shared safe area
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      ctx.fillRect(0, 0, BW, sy); ctx.fillRect(0, sy + sh, BW, BH - sy - sh);
      ctx.fillRect(0, sy, sx, sh); ctx.fillRect(sx + sw, sy, BW - sx - sw, sh);
    }

    // Instagram shows a Reel as a 3:4 tile on the profile grid: mark what that keeps
    if (p.grid34) {
      var cut = (BH - BW * 4 / 3) / 2;
      ctx.save(); ctx.lineWidth = 3; ctx.strokeStyle = white(0.85); if (ctx.setLineDash) { ctx.setLineDash([6, 12]); }
      ctx.beginPath(); ctx.moveTo(0, cut); ctx.lineTo(BW, cut); ctx.moveTo(0, BH - cut); ctx.lineTo(BW, BH - cut); ctx.stroke(); ctx.restore();
      chip('GRID 3:4', BW - m.right - 170, cut - 50, 'rgba(0,0,0,0.75)', '#FFFFFF', 24);
    }

    // the safe area itself
    dashedRect(sx, sy, sw, sh, 6, accent);
    chip(label(p, W, H), sx + 24, sy + 24, accent, '#000000', 32);

    ctx.restore();
    return { fit: f, safe: safeRect(p, W, H) };
  }

  return {
    PLATFORMS: PLATFORMS,
    FILE_PREFIX: FILE_PREFIX,
    get: get,
    fit: fit,
    safeRect: safeRect,
    label: label,
    fileName: fileName,
    idFromName: idFromName,
    draw: draw
  };
});
