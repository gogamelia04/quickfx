/*
 * Quick FX — reader for Premiere effect presets (.prfpset, incl. "Effect Presets and Custom Items.prfpset").
 *
 * A .prfpset is an XML <PremiereData> object graph:
 *   Tree -> RootBin -> BinTreeItem (folders) -> TreeItem -> FilterPresetItem
 *   FilterPresetItem -> FilterPreset (one per effect) -> VideoFilterComponent / AudioFilterComponent
 *   component -> Params -> *ComponentParam (value in StartKeyframe, animation in Keyframes)
 *
 * Output is plain JSON that the ExtendScript side replays onto the selected clips.
 * Uses only basic DOM calls, so it runs in CEP (DOMParser) and in Node tests (@xmldom/xmldom).
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  if (root) { root.QFXPresets = api; }
})(this, function () {
  'use strict';

  var TPS = 254016000000;                       // Premiere ticks per second
  var VIDEO_MT = '228cda18-3625-4d2d-951e-348879e4ed93';
  var AUDIO_MT = '80b8e3d5-6dca-4195-aefb-cb5f407ab009';
  var PRESETS_BIN_NAMES = [
    'presets', 'ajustes preestablecidos', 'préconfigurations', 'preconfigurations', 'vorgaben',
    'predefiniti', 'predefinições', 'predefinicoes', 'шаблоны настроек', 'プリセット', '预设', '預設', '사전 설정'
  ];

  // ---------------------------------------------------------------- tiny DOM helpers
  function kids(el, tag) {
    var out = [];
    if (!el) { return out; }
    for (var n = el.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 1 && (!tag || n.nodeName === tag)) { out.push(n); }
    }
    return out;
  }
  function kid(el, tag) {
    if (!el) { return null; }
    for (var n = el.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 1 && n.nodeName === tag) { return n; }
    }
    return null;
  }
  function txt(el, tag) {
    var k = kid(el, tag);
    if (!k) { return null; }
    return k.textContent == null ? '' : String(k.textContent);
  }
  function trim(s) { return String(s == null ? '' : s).replace(/^\s+|\s+$/g, ''); }
  function num(s) {
    var t = trim(s);
    if (!t) { return NaN; }
    var n = Number(t);
    return isFinite(n) ? n : NaN;
  }
  function int(s, dflt) { var n = num(s); return isNaN(n) ? dflt : Math.round(n); }
  function hasDescendant(el, tag) {
    return !!(el && el.getElementsByTagName && el.getElementsByTagName(tag).length);
  }

  // ---------------------------------------------------------------- value decoding
  function divmod(decStr, d) {
    var q = '', r = 0;
    for (var i = 0; i < decStr.length; i++) {
      r = r * 10 + (decStr.charCodeAt(i) - 48);
      var digit = Math.floor(r / d);
      r -= digit * d;
      if (q.length || digit) { q += String(digit); }
    }
    return [q || '0', r];
  }

  /** Premiere stores colours as one unsigned 64-bit integer: A<<48 | R<<32 | G<<16 | B, 0xFF00 = full. */
  function decodeColor(raw) {
    var s = trim(raw);
    if (!/^\d+$/.test(s)) { return null; }
    var parts = [], cur = s;
    for (var i = 0; i < 4; i++) {
      var dm = divmod(cur, 65536);
      parts.push(dm[1]);
      cur = dm[0];
    }
    function to8(v) { var x = Math.round(v / 65280 * 255); return x < 0 ? 0 : (x > 255 ? 255 : x); }
    return { a: parts[3] === 0 ? 255 : to8(parts[3]), r: to8(parts[2]), g: to8(parts[1]), b: to8(parts[0]) };
  }

  function decodePoint(raw) {
    var s = trim(raw);
    if (!s) { return null; }
    var p = s.indexOf(':') >= 0 ? s.split(':') : s.split(',');
    if (p.length < 2) { return null; }
    var x = num(p[0]), y = num(p[1]);
    if (isNaN(x) || isNaN(y)) { return null; }
    return [x, y];
  }

  function decodeBool(raw) {
    var s = trim(raw).toLowerCase();
    return s === 'true' || s === '1';
  }

  function detectKind(tag, ctrl, raw) {
    if (/Arb/i.test(tag)) { return 'arb'; }
    if (ctrl === 11 || ctrl === 12 || ctrl === 16) { return 'ui'; }      // group headers / hidden UI state
    if (ctrl === 9) { return 'arb'; }
    if (/Point/i.test(tag) || ctrl === 6) { return 'point'; }
    if (ctrl === 5) { return 'color'; }
    var r = trim(raw).toLowerCase();
    if (r === 'true' || r === 'false' || ctrl === 4) { return 'bool'; }
    if (r.indexOf(':') >= 0) { return 'point'; }
    if (r !== '' && !isNaN(num(r))) { return ctrl === 3 ? 'angle' : 'number'; }
    return 'unknown';
  }

  function decodeValue(kind, raw) {
    if (raw == null) { return null; }
    switch (kind) {
      case 'number':
      case 'angle': { var n = num(raw); return isNaN(n) ? null : n; }
      case 'bool': return decodeBool(raw);
      case 'point': return decodePoint(raw);
      case 'color': return decodeColor(raw);
      default: return null;
    }
  }

  /** StartKeyframe is "<sentinel>,<value>,<interp>,…" and holds the static value. */
  function startValue(text) {
    if (text == null) { return null; }
    var p = String(text).split(',');
    return p.length > 1 ? trim(p[1]) : null;
  }

  /** Keyframes: "ticks,value,interp,…;ticks,value,interp,…;" */
  function parseKeys(text, kind, anchorIn) {
    var out = [];
    var entries = String(text || '').split(';');
    for (var i = 0; i < entries.length && out.length < 5000; i++) {
      var e = trim(entries[i]);
      if (!e) { continue; }
      var p = e.split(',');
      if (p.length < 2) { continue; }
      var t = num(p[0]);
      if (isNaN(t)) { continue; }
      var v = decodeValue(kind, p[1]);
      if (v === null) { continue; }
      out.push({ t: (t - anchorIn) / TPS, v: v, interp: int(p[2], 0) });
    }
    out.sort(function (a, b) { return a.t - b.t; });
    var dedup = [];
    for (var j = 0; j < out.length; j++) {
      if (!dedup.length || Math.abs(dedup[dedup.length - 1].t - out[j].t) > 1e-7) { dedup.push(out[j]); }
    }
    return dedup;
  }

  // ---------------------------------------------------------------- params / components
  function parseParam(el, index, anchorIn) {
    var tag = el.nodeName;
    var ctrl = int(txt(el, 'ParameterControlType'), -1);
    var name = txt(el, 'Name') || '';
    var id = int(txt(el, 'ParameterID'), -1);
    var raw = startValue(txt(el, 'StartKeyframe'));
    if (raw === null || raw === '') {
      var cur = txt(el, 'CurrentValue');
      raw = cur === null ? null : trim(cur);
    }
    var kind = detectKind(tag, ctrl, raw === null ? '' : raw);
    var p = { index: index, id: id, name: name, ctrl: ctrl, kind: kind, value: null, keys: [] };
    if (kind === 'arb' || kind === 'ui' || kind === 'unknown') { return p; }
    p.value = decodeValue(kind, raw);
    var timeVarying = trim(txt(el, 'IsTimeVarying')).toLowerCase() === 'true';
    var kf = txt(el, 'Keyframes');
    if (timeVarying && kf && trim(kf)) { p.keys = parseKeys(kf, kind, anchorIn); }
    if (p.value === null && !p.keys.length) { p.kind = 'unknown'; }
    return p;
  }

  function mediaOf(fp, comp) {
    var mt = trim(txt(fp, 'MediaType')).toLowerCase();
    if (mt === AUDIO_MT) { return 'audio'; }
    if (mt === VIDEO_MT) { return 'video'; }
    return /Audio/i.test(comp.nodeName) ? 'audio' : 'video';
  }

  // ---------------------------------------------------------------- main entry
  function parse(xmlText, DOMParserImpl) {
    var Parser = DOMParserImpl || (typeof DOMParser !== 'undefined' ? DOMParser : null);
    if (!Parser) { throw new Error('No DOMParser available'); }
    var text = String(xmlText || '').replace(/^﻿/, '');
    var doc = new Parser().parseFromString(text, 'application/xml');
    var rootEl = doc && doc.documentElement;
    if (!rootEl || rootEl.nodeName !== 'PremiereData') {
      throw new Error('Not a Premiere preset file');
    }
    if (doc.getElementsByTagName('parsererror').length) {
      throw new Error('Preset file is not valid XML');
    }

    // ObjectID index (top level first, deep scan as a fallback for unusual files)
    var objects = {};
    var top = kids(rootEl);
    var i;
    for (i = 0; i < top.length; i++) {
      var oid = top[i].getAttribute('ObjectID');
      if (oid) { objects[oid] = top[i]; }
    }
    if (!Object.keys(objects).length) {
      var all = rootEl.getElementsByTagName('*');
      for (i = 0; i < all.length; i++) {
        var id2 = all[i].getAttribute && all[i].getAttribute('ObjectID');
        if (id2) { objects[id2] = all[i]; }
      }
    }
    function deref(el) {
      if (!el) { return null; }
      var ref = el.getAttribute('ObjectRef');
      return ref ? (objects[ref] || null) : (el.getAttribute('ObjectID') ? el : null);
    }

    var result = { presets: [], skipped: [], stats: { effects: 0, keyframes: 0 } };
    var seenItems = {};
    var usedIds = {};

    function itemName(node) {
      var base = kid(node, 'TreeItemBase');
      var n = base ? txt(base, 'Name') : txt(node, 'Name');
      return trim(n);
    }
    function dataOf(node) {
      var base = kid(node, 'TreeItemBase');
      var d = kid(base, 'Data') || kid(node, 'Data');
      return d ? objects[d.getAttribute('ObjectRef')] || null : null;
    }

    function addPreset(name, folder, item) {
      if (!item || item.nodeName !== 'FilterPresetItem') { return; }
      var key = item.getAttribute('ObjectID');
      if (key && seenItems[key]) { return; }
      if (key) { seenItems[key] = true; }

      var effItem = kid(item, 'EffectItem');
      if (effItem && trim(txt(effItem, 'EffectIsShorcut')).toLowerCase() === 'true') { return; } // custom-bin shortcut, not a preset

      var list = kid(item, 'FilterPresets');
      var refs = list ? kids(list, 'FilterPreset') : kids(item, 'FilterPreset');
      var preset = { id: '', name: name || 'Preset', folder: folder, type: 0, speed: 1, duration: 0, description: '', effects: [], notes: [] };
      var first = true, isTransition = false;

      for (var r = 0; r < refs.length; r++) {
        var fp = deref(refs[r]);
        if (!fp) { continue; }
        var comp = deref(kid(fp, 'Component'));
        if (!comp) { continue; }
        if (/Transition/i.test(comp.nodeName) || num(txt(fp, 'TransitionDuration')) > 0) { isTransition = true; continue; }

        var anchorIn = num(txt(fp, 'AnchorInPoint'));
        var anchorOut = num(txt(fp, 'AnchorOutPoint'));
        if (isNaN(anchorIn)) { anchorIn = 0; }
        if (first) {
          preset.type = int(txt(fp, 'Type'), 0);
          var spd = num(txt(fp, 'Speed'));
          preset.speed = spd > 0 ? spd : 1;
          preset.duration = (!isNaN(anchorOut) && anchorOut > anchorIn) ? (anchorOut - anchorIn) / TPS : 0;
          preset.description = trim(txt(fp, 'Description'));
          first = false;
        }

        var inner = kid(comp, 'Component') || comp;
        var fx = {
          matchName: trim(txt(comp, 'MatchName')) || trim(txt(fp, 'FilterMatchName')),
          displayName: trim(txt(inner, 'DisplayName')),
          intrinsic: trim(txt(inner, 'Intrinsic')).toLowerCase() === 'true',
          bypass: trim(txt(inner, 'Bypass')).toLowerCase() === 'true',
          media: mediaOf(fp, comp),
          params: []
        };
        var paramsEl = kid(inner, 'Params');
        var plist = kids(paramsEl, 'Param');
        for (var k = 0; k < plist.length; k++) {
          var pel = deref(plist[k]);
          if (!pel) { continue; }
          var p = parseParam(pel, int(plist[k].getAttribute('Index'), k), anchorIn);
          result.stats.keyframes += p.keys.length;
          fx.params.push(p);
        }
        if (!fx.matchName && !fx.displayName) { continue; }
        preset.effects.push(fx);
        result.stats.effects++;
      }

      if (!preset.effects.length) {
        result.skipped.push({ name: name, folder: folder, reason: isTransition ? 'transition' : 'empty' });
        return;
      }
      var base = (folder ? folder + '/' : '') + preset.name;
      var id = 'p:' + base, n = 2;
      while (usedIds[id]) { id = 'p:' + base + ' #' + (n++); }
      usedIds[id] = true;
      preset.id = id;
      result.presets.push(preset);
    }

    function walk(node, path, depth) {
      if (!node || depth > 64) { return; }
      if (node.nodeName === 'BinTreeItem') {
        var oid = node.getAttribute('ObjectID');
        if (oid && seenItems['bin:' + oid]) { return; }
        if (oid) { seenItems['bin:' + oid] = true; }
        var name = itemName(node);
        var lower = name.toLowerCase();
        var scaffold = lower === 'root' ||
          (path.length === 0 && (hasDescendant(node, 'HandlerEffects.EffectItemTree.PresetsBin') || PRESETS_BIN_NAMES.indexOf(lower) >= 0));
        var pushed = false;
        if (name && !scaffold) { path.push(name); pushed = true; }
        var items = kids(kid(node, 'Items'), 'Item');
        for (var j = 0; j < items.length; j++) { walk(deref(items[j]), path, depth + 1); }
        if (pushed) { path.pop(); }
      } else if (node.nodeName === 'TreeItem') {
        addPreset(itemName(node), path.join(' / '), dataOf(node));
      }
    }

    var tree = null;
    for (i = 0; i < top.length; i++) {
      if (top[i].nodeName === 'Tree' && top[i].getAttribute('ObjectID')) { tree = top[i]; break; }
    }
    if (tree) { walk(deref(kid(tree, 'RootBin')), [], 0); }

    if (!result.presets.length) {
      // No usable tree: recover names from TreeItems that point at FilterPresetItems.
      var treeItems = rootEl.getElementsByTagName('TreeItem');
      for (i = 0; i < treeItems.length; i++) {
        addPreset(itemName(treeItems[i]), '', dataOf(treeItems[i]));
      }
    }
    return result;
  }

  /** Short human summary of what a preset contains ("Motion · Gaussian Blur"). */
  function summary(preset) {
    var names = [];
    for (var i = 0; i < preset.effects.length; i++) {
      var fx = preset.effects[i];
      var n = fx.displayName || String(fx.matchName || '').replace(/^(AE|PR)\.ADBE\s+/, '');
      if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-/i.test(n)) { continue; }      // internal ids of some effects: not a readable name
      if (n && names.indexOf(n) < 0) { names.push(n); }
    }
    return names.join(' · ');
  }

  function keyframeCount(preset) {
    var n = 0;
    for (var i = 0; i < preset.effects.length; i++) {
      for (var j = 0; j < preset.effects[i].params.length; j++) { n += preset.effects[i].params[j].keys.length; }
    }
    return n;
  }

  /** Only what the host needs, to keep the evalScript payload small. */
  function compact(p) {
    var effects = [];
    for (var i = 0; i < p.effects.length; i++) {
      var fx = p.effects[i], params = [];
      for (var j = 0; j < fx.params.length; j++) {
        var q = fx.params[j];
        if (q.kind === 'arb' || q.kind === 'ui' || q.kind === 'unknown') {
          params.push({ index: q.index, name: q.name, kind: q.kind });
        } else {
          params.push({ index: q.index, name: q.name, kind: q.kind, value: q.value, keys: q.keys });
        }
      }
      effects.push({ matchName: fx.matchName, displayName: fx.displayName, intrinsic: fx.intrinsic, media: fx.media, params: params });
    }
    return { name: p.name, type: p.type, speed: p.speed, duration: p.duration, effects: effects };
  }

  return { parse: parse, summary: summary, keyframeCount: keyframeCount, compact: compact, decodeColor: decodeColor, TPS: TPS };
});
