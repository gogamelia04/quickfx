/*
 * Quick FX — the fonts installed on this computer, read straight from the font files (family, style, full and
 * PostScript name), the way Premiere lists them. Only each file's small "name" table is read.
 */
(function (root) {
  'use strict';
  function u16(b, o) { return (b[o] << 8) | b[o + 1]; }
  function u32(b, o) { return ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0; }
  function read(fs, fd, pos, len) {
    var buf = (typeof Buffer !== 'undefined' ? Buffer : root.cep_node.Buffer).alloc(len), got = fs.readSync(fd, buf, 0, len, pos);
    return got < len ? buf.slice(0, got) : buf;
  }
  function str(b, o, len, wide) {
    var s = '', i;
    if (wide) { for (i = 0; i + 1 < len; i += 2) { s += String.fromCharCode(u16(b, o + i)); } }
    else { for (i = 0; i < len; i++) { s += String.fromCharCode(b[o + i]); } }
    return s.replace(/\u0000/g, '');
  }
  /** One font inside a file (at byte `off`): its names, or null. */
  function face(fs, fd, off) {
    var h = read(fs, fd, off, 12);
    if (h.length < 12) { return null; }
    var n = u16(h, 4);
    if (!n || n > 200) { return null; }
    var dir = read(fs, fd, off + 12, n * 16), at = 0, len = 0, i;
    for (i = 0; i + 16 <= dir.length; i += 16) { if (dir[i] === 0x6E && dir[i + 1] === 0x61 && dir[i + 2] === 0x6D && dir[i + 3] === 0x65) { at = u32(dir, i + 8); len = u32(dir, i + 12); } }
    if (!at || !len) { return null; }
    var t = read(fs, fd, at, Math.min(len, 131072));
    if (t.length < 6) { return null; }
    var count = u16(t, 2), so = u16(t, 4), got = {}, rank = {};
    for (i = 0; i < count; i++) {
      var r = 6 + i * 12;
      if (r + 12 > t.length) { break; }
      var pid = u16(t, r), lid = u16(t, r + 4), nid = u16(t, r + 6), l = u16(t, r + 8), o = so + u16(t, r + 10);
      if (!(nid === 1 || nid === 2 || nid === 4 || nid === 6 || nid === 16 || nid === 17) || o + l > t.length || !l) { continue; }
      var rk = pid === 3 ? (lid === 0x409 ? 4 : 2) : (pid === 0 ? 3 : (pid === 1 && lid === 0 ? 1 : 0));
      if (!rk || (rank[nid] || 0) >= rk) { continue; }
      var s = str(t, o, l, pid !== 1);
      if (s) { got[nid] = s; rank[nid] = rk; }
    }
    var fam = got[16] || got[1];
    if (!fam || fam.charAt(0) === '.') { return null; }
    return { family: fam, style: got[17] || got[2] || 'Regular', full: got[4] || (fam + ' ' + (got[2] || '')), ps: got[6] || '' };
  }
  function file(fs, path) {
    var out = [], fd = -1;
    try {
      fd = fs.openSync(path, 'r');
      var h = read(fs, fd, 0, 12);
      if (h.length === 12 && h[0] === 0x74 && h[1] === 0x74 && h[2] === 0x63 && h[3] === 0x66) {
        var n = Math.min(u32(h, 8), 64), offs = read(fs, fd, 12, n * 4);
        for (var i = 0; i + 4 <= offs.length; i += 4) { var f = face(fs, fd, u32(offs, i)); if (f) { out.push(f); } }
      } else { var one = face(fs, fd, 0); if (one) { out.push(one); } }
    } catch (e) { /* not a font, or unreadable: skip */ }
    if (fd >= 0) { try { fs.closeSync(fd); } catch (e2) {} }
    return out;
  }
  var ORDER = ['thin', 'hairline', 'ultralight', 'extralight', 'light', 'book', 'regular', 'roman', 'normal', 'medium', 'demibold', 'semibold', 'bold', 'extrabold', 'ultrabold', 'heavy', 'black'];
  function weightOf(style) { var s = String(style).toLowerCase().replace(/[\s-]/g, ''), best = 6; for (var i = 0; i < ORDER.length; i++) { if (s.indexOf(ORDER[i]) >= 0) { best = i; } } return best + (/italic|oblique/.test(s) ? 0.5 : 0); }
  /**
   * dirs: [{ path, any }] — `any`: files there have no extensions (Adobe Fonts). → [{ family, faces: [{ style, full, ps }] }], by name.
   */
  function scan(fs, dirs) {
    var fams = {}, seen = {}, files = 0;
    for (var d = 0; d < dirs.length; d++) {
      var names = [];
      try { names = fs.readdirSync(dirs[d].path); } catch (e) { names = []; }
      for (var i = 0; i < names.length && files < 4000; i++) {
        if (!dirs[d].any && !/\.(ttf|otf|ttc|otc)$/i.test(names[i])) { continue; }
        if (!dirs[d].any && names[i].charAt(0) === '.') { continue; }
        files++;
        var list = file(fs, dirs[d].path + '/' + names[i]);
        for (var k = 0; k < list.length; k++) {
          var f = list[k], key = f.ps || f.full;
          if (seen[key]) { continue; }
          seen[key] = true;
          if (!fams[f.family]) { fams[f.family] = { family: f.family, faces: [] }; }
          fams[f.family].faces.push({ style: f.style, full: f.full, ps: f.ps });
        }
      }
    }
    var out = [];
    for (var name in fams) { if (fams.hasOwnProperty(name)) { fams[name].faces.sort(function (a, b) { return weightOf(a.style) - weightOf(b.style); }); out.push(fams[name]); } }
    out.sort(function (a, b) { return a.family.toLowerCase() < b.family.toLowerCase() ? -1 : (a.family.toLowerCase() > b.family.toLowerCase() ? 1 : 0); });
    return out;
  }
  function macDirs(home) {
    var a = home + '/Library/Application Support/Adobe/CoreSync/plugins/livetype/';
    return [{ path: home + '/Library/Fonts' }, { path: '/Library/Fonts' }, { path: '/System/Library/Fonts' }, { path: '/System/Library/Fonts/Supplemental' },
      { path: a + '.r', any: true }, { path: a + '.c', any: true }, { path: a + '.e', any: true }, { path: a + '.t', any: true }, { path: a + '.u', any: true }, { path: a + '.w', any: true }, { path: a + '.x', any: true }];
  }
  root.QFXFonts = { scan: scan, file: file, macDirs: macDirs, weightOf: weightOf };
})(typeof window !== 'undefined' ? window : (typeof module !== 'undefined' ? module.exports : this));
