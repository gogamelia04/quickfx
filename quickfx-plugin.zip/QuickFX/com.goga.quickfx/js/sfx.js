/*
 * Quick FX — the sound-effects library, as plain folders:
 *
 *   <library>/<Category>/<Sound> 01 - bright.wav
 *                        <Sound> 02 - low.wav        ← variations of one sound: same name, a number
 *                        Another sound.mp3
 *
 * A category is a folder, a sound is a file — so adding your own is "put a file in a folder",
 * whether through the panel or in Finder, and a library on a shared drive works for the whole team.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  if (root) { root.QFXSfx = api; }
})(this, function () {
  'use strict';

  var AUDIO = /\.(wav|mp3|m4a|aac|aif|aiff|flac|ogg)$/i;

  function isAudio(name) { return AUDIO.test(String(name || '')) && String(name).charAt(0) !== '.'; }
  function stem(name) { return String(name).replace(/\.[^.]+$/, ''); }

  /**
   * "Whoosh 02 - low.wav" → { group: 'Whoosh', n: 2, note: 'low' }
   * "ES_Door Slam.wav"    → { group: 'ES_Door Slam', n: 0, note: '' }      (no number: a sound of its own)
   */
  function parseName(file) {
    var s = stem(file).replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    var m = /^(.*?\D)[\s_.\-]*?(\d{1,3})(?:\s*[\-–—:,]\s*(.+)|\s*\((.+)\))?$/.exec(s);
    if (!m) { return { group: s, n: 0, note: '' }; }
    var group = m[1].replace(/[\s_.\-–—(]+$/, '');
    if (!group) { return { group: s, n: 0, note: '' }; }
    return { group: group, n: Number(m[2]), note: (m[3] || m[4] || '').replace(/^\s+|\s+$/g, '') };
  }

  function byText(a, b) { return String(a).toLowerCase() < String(b).toLowerCase() ? -1 : (String(a).toLowerCase() > String(b).toLowerCase() ? 1 : 0); }

  /** files: names in one category folder → [{ name, items: [{ file, n, note }] }], sounds A→Z, variations 1→n */
  function groups(files) {
    var map = {}, list = [], i;
    for (i = 0; i < files.length; i++) {
      if (!isAudio(files[i])) { continue; }
      var p = parseName(files[i]), key = '$' + p.group.toLowerCase();
      if (!map[key]) { map[key] = { name: p.group, items: [] }; list.push(map[key]); }
      map[key].items.push({ file: files[i], n: p.n, note: p.note });
    }
    for (i = 0; i < list.length; i++) { list[i].items.sort(function (a, b) { return (a.n - b.n) || byText(a.file, b.file); }); }
    list.sort(function (a, b) { return byText(a.name, b.name); });
    return list;
  }

  /** A query over the whole library: every word must be in the category, the sound's name, or a variation's note/file. */
  function search(cats, query) {
    var words = String(query || '').toLowerCase().split(/\s+/), out = [], w = [], i;
    for (i = 0; i < words.length; i++) { if (words[i]) { w.push(words[i]); } }
    if (!w.length) { return out; }
    for (var c = 0; c < cats.length; c++) {
      for (var g = 0; g < cats[c].groups.length; g++) {
        var grp = cats[c].groups[g], hay = (cats[c].name + ' ' + grp.name).toLowerCase(), all = true, items = [];
        for (i = 0; i < w.length && all; i++) { if (hay.indexOf(w[i]) < 0) { all = false; } }
        if (all) { out.push({ cat: cats[c].name, group: grp, items: grp.items }); continue; }
        for (var k = 0; k < grp.items.length; k++) {
          var h2 = (hay + ' ' + grp.items[k].note + ' ' + grp.items[k].file).toLowerCase(), ok = true;
          for (i = 0; i < w.length && ok; i++) { if (h2.indexOf(w[i]) < 0) { ok = false; } }
          if (ok) { items.push(grp.items[k]); }
        }
        if (items.length) { out.push({ cat: cats[c].name, group: grp, items: items }); }
      }
    }
    return out;
  }

  /** A name that is safe as a folder or file name (and keeps Georgian). */
  function cleanName(text) {
    return String(text || '').replace(/[\/\\:*?"<>|\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').replace(/^[\s.]+|[\s.]+$/g, '').slice(0, 60);
  }

  /** A name for a copied file that does not replace what is there: "Pop.wav" → "Pop (2).wav" */
  function freeName(existing, name) {
    var low = {}, i;
    for (i = 0; i < existing.length; i++) { low['$' + String(existing[i]).toLowerCase()] = true; }
    if (!low['$' + name.toLowerCase()]) { return name; }
    var dot = name.lastIndexOf('.'), base = dot > 0 ? name.slice(0, dot) : name, ext = dot > 0 ? name.slice(dot) : '';
    for (i = 2; i < 1000; i++) { var cand = base + ' (' + i + ')' + ext; if (!low['$' + cand.toLowerCase()]) { return cand; } }
    return base + ' ' + Date.now() + ext;
  }

  /** file:// address of a path, for playing it in the panel (#, ?, % and spaces in names are fine). */
  function fileUrl(path) {
    var parts = String(path).replace(/\\/g, '/').split('/'), out = [];
    for (var i = 0; i < parts.length; i++) { out.push(encodeURIComponent(parts[i])); }
    return 'file://' + (out[0] === '' ? '' : '/') + out.join('/');
  }

  function clock(sec) {
    if (!(sec >= 0) || !isFinite(sec)) { return ''; }
    return sec < 10 ? sec.toFixed(1) + ' წმ' : Math.round(sec) + ' წმ';
  }

  return { isAudio: isAudio, parseName: parseName, groups: groups, search: search, cleanName: cleanName, freeName: freeName, fileUrl: fileUrl, clock: clock };
});
