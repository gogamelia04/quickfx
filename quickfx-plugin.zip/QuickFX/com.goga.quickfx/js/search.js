/*
 * Quick FX — search & ranking.
 * Pure functions, no DOM: used by the panel and by the Node tests.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { root.QFXSearch = api; }
})(this, function () {
  'use strict';

  // ---------------------------------------------------------------- keyboard layouts
  // macOS "Georgian – QWERTY": the key you press -> the letter you get.
  var LAT_TO_KA = {
    a: 'ა', b: 'ბ', g: 'გ', d: 'დ', e: 'ე', v: 'ვ', z: 'ზ', t: 'ტ', i: 'ი', k: 'კ',
    l: 'ლ', m: 'მ', n: 'ნ', o: 'ო', p: 'პ', r: 'რ', s: 'ს', u: 'უ', f: 'ფ', q: 'ქ',
    y: 'ყ', c: 'ც', w: 'წ', x: 'ხ', j: 'ჯ', h: 'ჰ'
  };
  var LAT_TO_KA_SHIFT = { T: 'თ', J: 'ჟ', R: 'ღ', S: 'შ', C: 'ჩ', Z: 'ძ', W: 'ჭ' };
  var KA_TO_LAT = {};
  (function () {
    var k;
    for (k in LAT_TO_KA) { if (LAT_TO_KA.hasOwnProperty(k)) { KA_TO_LAT[LAT_TO_KA[k]] = k; } }
    for (k in LAT_TO_KA_SHIFT) { if (LAT_TO_KA_SHIFT.hasOwnProperty(k)) { KA_TO_LAT[LAT_TO_KA_SHIFT[k]] = k.toLowerCase(); } }
  })();

  /** Text typed with the Georgian layout active -> the Latin keys that were pressed. */
  function kaToLat(s) {
    var out = '';
    for (var i = 0; i < s.length; i++) {
      var ch = s.charAt(i);
      out += KA_TO_LAT.hasOwnProperty(ch) ? KA_TO_LAT[ch] : ch;
    }
    return out;
  }

  /** Text typed with the Latin layout active -> what the Georgian layout would have produced. */
  function latToKa(s) {
    var out = '';
    for (var i = 0; i < s.length; i++) {
      var ch = s.charAt(i);
      if (LAT_TO_KA_SHIFT.hasOwnProperty(ch)) { out += LAT_TO_KA_SHIFT[ch]; continue; }
      var low = ch.toLowerCase();
      out += LAT_TO_KA.hasOwnProperty(low) ? LAT_TO_KA[low] : ch;
    }
    return out;
  }

  var RE_KA = /[Ⴀ-ჿᲐ-Ჿ]/;
  var RE_LAT = /[A-Za-z]/;

  // ---------------------------------------------------------------- normalisation
  /** Lower-case and turn separators into spaces WITHOUT changing the length (keeps highlight indices valid). */
  function normText(s) {
    var low = String(s || '').toLowerCase();
    var out = '';
    for (var i = 0; i < low.length; i++) {
      var ch = low.charAt(i);
      out += (ch === '_' || ch === '-' || ch === '/' || ch === '·' || ch === '\t') ? ' ' : ch;
    }
    return out;
  }

  function cleanQuery(q) {
    return normText(q).replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
  }

  var BOUNDARY_PREV = ' ([{.+&,:;|"\'';

  function isBoundary(orig, low, i) {
    if (i === 0) { return true; }
    var p = low.charAt(i - 1);
    if (BOUNDARY_PREV.indexOf(p) >= 0) { return true; }
    var a = orig.charAt(i - 1), b = orig.charAt(i);
    if (/[a-z]/.test(a) && /[A-Z]/.test(b)) { return true; }        // camelCase
    if (/[0-9]/.test(a) !== /[0-9]/.test(b)) { return true; }        // digit run
    return false;
  }

  function range(a, b) { var r = []; for (var i = a; i < b; i++) { r.push(i); } return r; }

  function wordStarts(orig, low) {
    var w = [];
    for (var i = 0; i < low.length; i++) {
      if (low.charAt(i) !== ' ' && isBoundary(orig, low, i)) { w.push(i); }
    }
    return w;
  }

  // ---------------------------------------------------------------- matchers
  function matchSubstring(orig, low, q) {
    var first = low.indexOf(q);
    if (first < 0) { return null; }
    var p = first, boundary = false, from = first;
    while (from >= 0) {
      if (isBoundary(orig, low, from)) { p = from; boundary = true; break; }
      from = low.indexOf(q, from + 1);
    }
    // Inside-a-word hits ("gb" in "RGB") rank below word-start / initials matches.
    var s = p === 0 ? 800 : (boundary ? 720 : 380);
    s -= Math.min(p, 40);
    s -= Math.min(low.length - q.length, 60) * 0.5;
    return { score: s, idx: range(p, p + q.length), boundary: boundary };
  }

  function matchTokens(orig, low, tokens) {
    var idx = [], start = 0, penalty = 0, inOrder = true, i, t, pos;
    for (i = 0; i < tokens.length; i++) {
      t = tokens[i];
      pos = -1;
      var from = low.indexOf(t, start);
      while (from >= 0) {
        if (isBoundary(orig, low, from)) { pos = from; break; }
        from = low.indexOf(t, from + 1);
      }
      if (pos < 0) { pos = low.indexOf(t, start); if (pos >= 0) { penalty += 40; } }
      if (pos < 0) { inOrder = false; break; }
      idx = idx.concat(range(pos, pos + t.length));
      penalty += Math.min(pos - start, 30) * 0.5;
      start = pos + t.length;
    }
    if (inOrder) { return { score: 470 - penalty, idx: idx }; }
    // any order, lower score
    idx = [];
    for (i = 0; i < tokens.length; i++) {
      pos = low.indexOf(tokens[i]);
      if (pos < 0) { return null; }
      idx = idx.concat(range(pos, pos + tokens[i].length));
    }
    return { score: 320, idx: idx };
  }

  /** "gb" -> Gaussian Blur, "gaubl" -> GAUssian BLur, "ls" -> Lumetri ... (word-prefix chaining). */
  function matchWordPrefixes(orig, low, q) {
    var words = wordStarts(orig, low);
    if (!words.length) { return null; }
    var best = null, calls = 0;
    function dfs(qi, wi, used, skipped) {
      if (++calls > 4000) { return; }
      if (best && best.score >= 430) { return; }
      if (qi === q.length) {
        var s = 430 - skipped * 12 - (words.length - wi) * 2;
        if (!best || s > best.score) { best = { score: s, idx: used.slice() }; }
        return;
      }
      if (wi >= words.length) { return; }
      var w = words[wi];
      // take k chars from the start of this word (longest first)
      var k = 0;
      while (qi + k < q.length && w + k < low.length && low.charAt(w + k) === q.charAt(qi + k) && low.charAt(w + k) !== ' ') { k++; }
      for (var take = k; take >= 1; take--) {
        dfs(qi + take, wi + 1, used.concat(range(w, w + take)), skipped);
      }
      // skip this word
      dfs(qi, wi + 1, used, skipped + 1);
    }
    dfs(0, 0, [], 0);
    return best;
  }

  function matchFuzzy(orig, low, q) {
    if (q.length < 3) { return null; }
    var idx = [], j = 0, gaps = 0, bonus = 0, last = -1, runs = 0;
    for (var i = 0; i < low.length && j < q.length; i++) {
      if (low.charAt(i) === q.charAt(j)) {
        if (last >= 0 && i - last > 1) { gaps += i - last - 1; }
        if (last < 0 || i - last > 1) { runs++; }
        if (isBoundary(orig, low, i)) { bonus += 8; }
        idx.push(i); last = i; j++;
      }
    }
    if (j < q.length) { return null; }
    // scattered single letters across a long name are noise, not a match
    var s = 220 + bonus - gaps * 2 - idx[0] * 0.5 - (runs - 1) * 40;
    if (s < 80) { return null; }
    return { score: s, idx: idx };
  }

  /** Score one text against one (already cleaned) query. null = no match. */
  function scoreText(text, q) {
    var orig = String(text || '');
    var low = normText(orig);
    if (!q) { return { score: 0, idx: [] }; }
    if (low === q) { return { score: 1000, idx: range(0, q.length) }; }
    var sub = matchSubstring(orig, low, q);
    if (sub && sub.boundary) { return { score: sub.score, idx: sub.idx }; }
    var best = sub ? { score: sub.score, idx: sub.idx } : null;
    function better(m) { if (m && (!best || m.score > best.score)) { best = m; } }
    var tokens = q.split(' ');
    if (tokens.length > 1) { better(matchTokens(orig, low, tokens)); }
    var qs = q.replace(/ /g, '');
    better(matchWordPrefixes(orig, low, qs));
    if (!best) { best = matchFuzzy(orig, low, qs); }
    return best;
  }

  /** The query as typed, plus what it would be in the other keyboard layout. */
  function queryVariants(raw) {
    var out = [{ q: cleanQuery(raw), w: 1 }];
    if (RE_KA.test(raw)) { out.push({ q: cleanQuery(kaToLat(raw)), w: 0.96 }); }
    if (RE_LAT.test(raw)) { out.push({ q: cleanQuery(latToKa(raw)), w: 0.9 }); }
    return out;
  }

  function usageBoost(item, usage, now) {
    var b = item.kind === 'preset' ? 4 : 0;
    var u = usage && usage[item.id];
    if (u && u.count) {
      b += Math.min(60, 40 * Math.log(1 + u.count) / Math.LN10);
      var ageDays = ((now || Date.now()) - (u.last || 0)) / 86400000;
      if (ageDays < 1) { b += 20; } else if (ageDays < 7) { b += 10; }
    }
    return b;
  }

  /**
   * Rank items for a query.
   * items: [{id, name, kind, alt?}]  (alt = secondary searchable text, e.g. preset folder)
   * returns [{item, score, idx}] best first.
   */
  function rank(items, rawQuery, usage, limit, now) {
    var variants = queryVariants(rawQuery || '');
    var out = [];
    for (var i = 0; i < items.length; i++) {
      var it = items[i], best = null, v, m;
      for (v = 0; v < variants.length; v++) {
        if (!variants[v].q) { continue; }
        m = scoreText(it.name, variants[v].q);
        if (m) {
          m = { score: m.score * variants[v].w, idx: m.idx };
          if (!best || m.score > best.score) { best = m; }
        }
      }
      if (!best && it.alt) {
        for (v = 0; v < variants.length; v++) {
          if (!variants[v].q) { continue; }
          m = scoreText(it.alt, variants[v].q);
          if (m) {
            m = { score: m.score * 0.45 * variants[v].w, idx: [] };
            if (!best || m.score > best.score) { best = m; }
          }
        }
      }
      if (!best) { continue; }
      out.push({ item: it, score: best.score + usageBoost(it, usage, now), idx: best.idx });
    }
    out.sort(function (a, b) {
      if (b.score !== a.score) { return b.score - a.score; }
      return a.item.name < b.item.name ? -1 : (a.item.name > b.item.name ? 1 : 0);
    });
    return limit ? out.slice(0, limit) : out;
  }

  /** Most-used / most-recent items for the empty query. */
  function recents(items, usage, limit) {
    var out = [];
    for (var i = 0; i < items.length; i++) {
      var u = usage && usage[items[i].id];
      if (u && u.count) { out.push({ item: items[i], score: usageBoost(items[i], usage), idx: [] }); }
    }
    out.sort(function (a, b) { return b.score - a.score; });
    return out.slice(0, limit || 8);
  }

  return {
    rank: rank,
    recents: recents,
    scoreText: scoreText,
    cleanQuery: cleanQuery,
    queryVariants: queryVariants,
    kaToLat: kaToLat,
    latToKa: latToKa
  };
});
