/*
 * Quick FX — minimal bridge to CEP (replaces Adobe's CSInterface.js; same underlying calls).
 */
(function (root) {
  'use strict';
  var cep = root.__adobe_cep__ || null;

  function decodePath(p) {
    var s = '';
    try { s = decodeURI(p || ''); } catch (e) { s = String(p || ''); }
    if (/^file:\/\/\/[A-Za-z]:/.test(s)) { return s.replace('file:///', ''); }   // Windows
    return s.replace(/^file:\/\//, '');
  }

  var Bridge = {
    available: !!cep,

    extensionId: function () {
      try { return cep ? cep.getExtensionId() : ''; } catch (e) { return ''; }
    },

    extensionPath: function () {
      try { return cep ? decodePath(cep.getSystemPath('extension')) : ''; } catch (e) { return ''; }
    },

    hostEnvironment: function () {
      try { return cep ? JSON.parse(cep.getHostEnvironment()) : null; } catch (e) { return null; }
    },

    /** Run ExtendScript; resolves with the raw string result. */
    evalScript: function (script) {
      return new Promise(function (resolve) {
        if (!cep) { resolve('EvalScript error.'); return; }
        try { cep.evalScript(script, function (res) { resolve(res); }); }
        catch (e) { resolve('EvalScript error.'); }
      });
    },

    /** Call QuickFX.<fn>(arg) in the host and parse its JSON envelope {ok, data|code}. */
    call: function (fn, payload) {
      var argText = payload === undefined ? '' : '"' + encodeURIComponent(JSON.stringify(payload)) + '"';
      var script = 'QuickFX.' + fn + '(' + argText + ')';
      return Bridge.evalScript(script).then(function (res) {
        if (typeof res !== 'string' || !res || res === 'undefined' || res.indexOf('EvalScript error') === 0) {
          return { ok: false, code: 'hostError', message: String(res) };
        }
        try { return JSON.parse(res); }
        catch (e) { return { ok: false, code: 'badReply', message: res.slice(0, 300) }; }
      });
    },

    readTextFile: function (path) {
      try {
        var r = root.cep && root.cep.fs ? root.cep.fs.readFile(path) : null;
        if (r && r.err === 0) { return r.data; }
      } catch (e) {}
      return null;
    },

    close: function () {
      try { if (cep) { cep.closeExtension(); } } catch (e) {}
    },

    /** Let these keys reach the panel instead of Premiere's shortcuts (macOS key codes). */
    registerKeys: function () {
      if (!cep || !cep.registerKeyEventsInterest) { return; }
      var codes = [36, 76, 53, 48, 125, 126, 123, 124, 51, 117, 115, 119, 116, 121];
      var list = [];
      for (var i = 0; i < codes.length; i++) {
        list.push({ keyCode: codes[i] });
        list.push({ keyCode: codes[i], shiftKey: true });
        list.push({ keyCode: codes[i], metaKey: true });
        list.push({ keyCode: codes[i], altKey: true });
      }
      try { cep.registerKeyEventsInterest(JSON.stringify(list)); } catch (e) {}
    }
  };

  root.QFXBridge = Bridge;
})(this);
