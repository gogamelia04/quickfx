/*
 * Quick FX — minimal bridge to CEP (replaces Adobe's CSInterface.js; same underlying calls).
 */
(function (root) {
  'use strict';
  var cep = root.__adobe_cep__ || null;

  function decodePath(p) {
    var s = '';
    try { s = decodeURI(p || ''); } catch (e) { s = String(p || ''); }
    if (/^file:\/\/\/[A-Za-z]:/.test(s)) { return s.replace('file:///', ''); }   // Windows
    return s.replace(/^file:\/\//, '');
  }

  var Bridge = {
    available: !!cep,

    extensionId: function () {
      try { return cep ? cep.getExtensionId() : ''; } catch (e) { return ''; }
    },

    extensionPath: function () {
      try { return cep ? decodePath(cep.getSystemPath('extension')) : ''; } catch (e) { return ''; }
    },

    hostEnvironment: function () {
      try { return cep ? JSON.parse(cep.getHostEnvironment()) : null; } catch (e) { return null; }
    },

    /** Run ExtendScript; resolves with the raw string result. */
    evalScript: function (script) {
      return new Promise(function (resolve) {
        if (!cep) { resolve('EvalScript error.'); return; }
        try { cep.evalScript(script, function (res) { resolve(res); }); }
        catch (e) { resolve('EvalScript error.'); }
      });
    },

    /** Call QuickFX.<fn>(arg) in the host and parse its JSON envelope {ok, data|code}. */
    call: function (fn, payload) {
      var argText = payload === undefined ? '' : '"' + encodeURIComponent(JSON.stringify(payload)) + '"';
      var script = 'QuickFX.' + fn + '(' + argText + ')';
      return Bridge.evalScript(script).then(function (res) {
        if (typeof res !== 'string' || !res || res === 'undefined' || res.indexOf('EvalScript error') === 0) {
          return { ok: false, code: 'hostError', message: String(res) };
        }
        try { return JSON.parse(res); }
        catch (e) { return { ok: false, code: 'badReply', message: res.slice(0, 300) }; }
      });
    },

    readTextFile: function (path) {
      try {
        var r = root.cep && root.cep.fs ? root.cep.fs.readFile(path) : null;
        if (r && r.err === 0) { return r.data; }
      } catch (e) {}
      return null;
    },

    /** ~/Library/Application Support — where Quick FX keeps its small settings/status files. */
    userDataPath: function () {
      try { return cep ? decodePath(cep.getSystemPath('userData')) : ''; } catch (e) { return ''; }
    },

    writeTextFile: function (path, text) {
      try {
        var r = root.cep && root.cep.fs ? root.cep.fs.writeFile(path, text) : null;
        return !!(r && r.err === 0);
      } catch (e) { return false; }
    },

    makeDir: function (path) {
      try { if (root.cep && root.cep.fs) { root.cep.fs.makedir(path); } } catch (e) {}
    },

    fileExists: function (path) {
      try { var r = root.cep && root.cep.fs ? root.cep.fs.stat(path) : null; return !!(r && r.err === 0); } catch (e) { return false; }
    },

    /** File names in a folder ([] when it is not there). */
    listDir: function (path) {
      try { var r = root.cep && root.cep.fs && root.cep.fs.readdir ? root.cep.fs.readdir(path) : null; return (r && r.err === 0 && r.data) ? r.data : []; } catch (e) { return []; }
    },

    /** mkdir -p */
    makeDirs: function (path) {
      var parts = String(path).split('/'), cur = '';
      for (var i = 1; i < parts.length; i++) {
        cur += '/' + parts[i];
        if (i < 2 || Bridge.fileExists(cur)) { continue; }
        Bridge.makeDir(cur);
      }
    },

    /** Binary file from base64 (used for the PNG overlays). */
    writeBase64File: function (path, b64) {
      try {
        var enc = (root.cep && root.cep.encoding && root.cep.encoding.Base64) || 'Base64';
        var r = root.cep && root.cep.fs ? root.cep.fs.writeFile(path, b64, enc) : null;
        return !!(r && r.err === 0);
      } catch (e) { return false; }
    },

    /** Start another extension of this bundle (used to wake the invisible background watcher). */
    openExtension: function (id) {
      try { if (cep && cep.requestOpenExtension) { cep.requestOpenExtension(id, ''); return true; } } catch (e) {}
      return false;
    },

    close: function () {
      try { if (cep) { cep.closeExtension(); } } catch (e) {}
    },

    /** Let these keys reach the panel instead of Premiere's shortcuts (macOS key codes). */
    registerKeys: function () {
      if (!cep || !cep.registerKeyEventsInterest) { return; }
      var codes = [36, 76, 53, 48, 125, 126, 123, 124, 51, 117, 115, 119, 116, 121, 18, 19, 20, 21, 23, 101];   // …, 1–5 (⌘1…⌘5 switch tools), F9 (Easy Ease)
      var list = [];
      for (var i = 0; i < codes.length; i++) {
        list.push({ keyCode: codes[i] });
        list.push({ keyCode: codes[i], shiftKey: true });
        list.push({ keyCode: codes[i], metaKey: true });
        list.push({ keyCode: codes[i], altKey: true });
      }
      // ⌘V ⌘C ⌘X ⌘A in our text fields (pasting a link) instead of Premiere's timeline paste
      var edit = [9, 8, 7, 0, 2];                                   // …and ⌘D: star the highlighted effect
      for (var j = 0; j < edit.length; j++) { list.push({ keyCode: edit[j], metaKey: true }); }
      try { cep.registerKeyEventsInterest(JSON.stringify(list)); } catch (e) {}
    }
  };

  root.QFXBridge = Bridge;
})(this);
