/*
 * Quick FX — keyframe easing maths.
 *
 * An ease is described the After Effects way, per keyframe pair:
 *   i0, v0 — influence (0..1 of the segment) and speed leaving the first keyframe
 *   i1, v1 — influence and speed arriving at the second keyframe
 * Speeds are relative to the average speed of the move (1 = linear, 0 = at rest).
 * That is exactly a cubic bezier through (0,0) (i0, i0·v0) (1−i1, 1−i1·v1) (1,1).
 *
 * Premiere's scripting cannot set bezier handles on a keyframe, so the host writes the curve as
 * in-between keyframes; lut() is the table it interpolates from.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  if (root) { root.QFXEase = api; }
})(this, function () {
  'use strict';

  var MIN_I = 0.01, MAX_V = 6, MIN_V = -1.5;

  function clamp(n, a, b) { return n < a ? a : (n > b ? b : n); }

  function normalize(e) {
    return {
      i0: clamp(Number(e.i0) || 0, MIN_I, 1), v0: clamp(Number(e.v0) || 0, MIN_V, MAX_V),
      i1: clamp(Number(e.i1) || 0, MIN_I, 1), v1: clamp(Number(e.v1) || 0, MIN_V, MAX_V)
    };
  }

  /** {i0,v0,i1,v1} → [x1,y1,x2,y2] */
  function toBezier(e) {
    e = normalize(e);
    return [e.i0, e.i0 * e.v0, 1 - e.i1, 1 - e.i1 * e.v1];
  }

  function fromBezier(b) {
    var i0 = clamp(b[0], MIN_I, 1), i1 = clamp(1 - b[2], MIN_I, 1);
    return normalize({ i0: i0, v0: b[1] / i0, i1: i1, v1: (1 - b[3]) / i1 });
  }

  function bx(b, u) { var m = 1 - u; return 3 * m * m * u * b[0] + 3 * m * u * u * b[2] + u * u * u; }
  function by(b, u) { var m = 1 - u; return 3 * m * m * u * b[1] + 3 * m * u * u * b[3] + u * u * u; }
  function dbx(b, u) { var m = 1 - u; return 3 * m * m * b[0] + 6 * m * u * (b[2] - b[0]) + 3 * u * u * (1 - b[2]); }
  function dby(b, u) { var m = 1 - u; return 3 * m * m * b[1] + 6 * m * u * (b[3] - b[1]) + 3 * u * u * (1 - b[3]); }

  /** Curve parameter for a given time fraction (x is monotonic because 0 ≤ x1, x2 ≤ 1). */
  function paramAt(b, x) {
    if (x <= 0) { return 0; }
    if (x >= 1) { return 1; }
    var lo = 0, hi = 1, u = x;
    for (var i = 0; i < 40; i++) {
      var cx = bx(b, u);
      if (Math.abs(cx - x) < 1e-7) { break; }
      if (cx < x) { lo = u; } else { hi = u; }
      u = (lo + hi) / 2;
    }
    return u;
  }

  /** Progress (0..1, may overshoot) at time fraction x. */
  function valueAt(b, x) { return by(b, paramAt(b, x)); }

  /** Speed relative to the average speed, at time fraction x. */
  function speedAt(b, x) {
    var u = paramAt(b, x), dx = dbx(b, u);
    if (Math.abs(dx) < 1e-6) {
      u = clamp(u + (u < 0.5 ? 1e-3 : -1e-3), 0, 1);
      dx = dbx(b, u);
      if (Math.abs(dx) < 1e-6) { return 0; }
    }
    return dby(b, u) / dx;
  }

  /** n+1 progress values at x = 0, 1/n, … 1 — what the host interpolates when it writes keyframes. */
  function lut(e, n) {
    var b = toBezier(e), out = [];
    n = n || 256;
    for (var i = 0; i <= n; i++) { out.push(Math.round(valueAt(b, i / n) * 1e6) / 1e6); }
    out[0] = 0; out[n] = 1;
    return out;
  }

  /** Points of the speed graph: [{x, s}], dense enough to draw. */
  function speedCurve(e, n) {
    var b = toBezier(e), pts = [];
    n = n || 120;
    for (var i = 0; i <= n; i++) {
      var u = i / n, dx = dbx(b, u);
      var s = Math.abs(dx) < 1e-6 ? null : dby(b, u) / dx;
      pts.push({ x: bx(b, u), s: s });
    }
    // ends where dx is 0 (influence of 100% on the other side): take the neighbour
    for (var j = 0; j < pts.length; j++) {
      if (pts[j].s === null) { pts[j].s = j > 0 ? pts[j - 1].s : (pts[j + 1] && pts[j + 1].s !== null ? pts[j + 1].s : 0); }
    }
    return pts;
  }

  function range(e) {
    var pts = speedCurve(e, 80), lo = 0, hi = 0;
    for (var i = 0; i < pts.length; i++) { if (pts[i].s > hi) { hi = pts[i].s; } if (pts[i].s < lo) { lo = pts[i].s; } }
    return { min: lo, max: hi };
  }

  function isLinear(e) {
    e = normalize(e);
    return Math.abs(e.v0 - 1) < 1e-3 && Math.abs(e.v1 - 1) < 1e-3;
  }

  function same(a, b) {
    a = normalize(a); b = normalize(b);
    return Math.abs(a.i0 - b.i0) < 0.004 && Math.abs(a.i1 - b.i1) < 0.004 && Math.abs(a.v0 - b.v0) < 0.01 && Math.abs(a.v1 - b.v1) < 0.01;
  }

  function label(e) {
    var b = toBezier(e);
    function r(n) { return String(Math.round(n * 100) / 100); }
    return 'cubic-bezier(' + r(b[0]) + ', ' + r(b[1]) + ', ' + r(b[2]) + ', ' + r(b[3]) + ')';
  }

  // The three "F9" eases use After Effects' own numbers: 33.33% influence, speed 0 on the eased side;
  // the untouched side keeps a linear keyframe's 16.67% influence at average speed.
  var PRESETS = [
    { id: 'easy', name: 'Easy Ease', key: 'F9', i0: 1 / 3, v0: 0, i1: 1 / 3, v1: 0 },
    { id: 'in', name: 'Ease In', i0: 1 / 6, v0: 1, i1: 1 / 3, v1: 0 },
    { id: 'out', name: 'Ease Out', i0: 1 / 3, v0: 0, i1: 1 / 6, v1: 1 },
    { id: 'smooth', name: 'Smooth', i0: 0.5, v0: 0, i1: 0.5, v1: 0 },
    { id: 'strong', name: 'Strong', i0: 0.75, v0: 0, i1: 0.75, v1: 0 },
    { id: 'snappy', name: 'Snappy', i0: 0.1, v0: 0, i1: 0.9, v1: 0 },
    { id: 'slow', name: 'Slow start', i0: 0.9, v0: 0, i1: 0.1, v1: 0 }
  ];

  function builtin(id) {
    for (var i = 0; i < PRESETS.length; i++) { if (PRESETS[i].id === id) { return PRESETS[i]; } }
    return null;
  }

  return {
    PRESETS: PRESETS, builtin: builtin,
    MIN_I: MIN_I, MIN_V: MIN_V, MAX_V: MAX_V,
    normalize: normalize, toBezier: toBezier, fromBezier: fromBezier,
    valueAt: valueAt, speedAt: speedAt, lut: lut, speedCurve: speedCurve, range: range,
    isLinear: isLinear, same: same, label: label
  };
});
