/*
 * Quick FX — graphics: timers, lower thirds and social call-outs.
 *
 * Every design is a small drawing function: draw(ctx, t, P) paints the design at time t (seconds) on a transparent
 * canvas, in "design units" (pixels of a 1080p picture). The panel uses the same function twice — for the live
 * preview and, frame by frame, for the movie it hands to Premiere — so what is seen is what is placed.
 *
 * P: { dur, t1, t2, font, accent, color, bg, noIn, noOut, timer: { total, down, fmt }, fps, logo }
 * No platform logos are drawn here: social designs use the platform's name, its colour and a plain monogram,
 * and show the user's own picture (P.logo) instead of the monogram when one is given.
 */
(function (root) {
  'use strict';

  var TAU = Math.PI * 2;
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function seg(t, a, b) { return b <= a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a), 0, 1); }
  var E = {
    lin: function (p) { return p; },
    out3: function (p) { return 1 - Math.pow(1 - p, 3); },
    out5: function (p) { return 1 - Math.pow(1 - p, 5); },
    in3: function (p) { return p * p * p; },
    io3: function (p) { return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2; },
    bounce: function (p) { var n = 7.5625, d = 2.75; if (p < 1 / d) { return n * p * p; } if (p < 2 / d) { p -= 1.5 / d; return n * p * p + 0.75; } if (p < 2.5 / d) { p -= 2.25 / d; return n * p * p + 0.9375; } p -= 2.625 / d; return n * p * p + 0.984375; },
    back: function (p) { var c = 1.9; return 1 + (c + 1) * Math.pow(p - 1, 3) + c * Math.pow(p - 1, 2); }
  };
  /** Presence of one part: 0 → 1 while it arrives (after `d` seconds, over `len`), back to 0 as the design leaves. */
  function st(t, P, d, len, ease) {
    len = len || 0.5;
    var i = P.noIn ? 1 : (ease || E.out3)(seg(t, d || 0, (d || 0) + len));
    var o = P.noOut ? 0 : E.in3(seg(t, P.dur - 0.5 + Math.min(0.15, (d || 0) * 0.25), P.dur - 0.04));
    return i * (1 - o);
  }

  // ---------------------------------------------------------------- drawing helpers
  function rr(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.arcTo(x + w, y, x + w, y + r, r);
    ctx.lineTo(x + w, y + h - r); ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h); ctx.arcTo(x, y + h, x, y + h - r, r);
    ctx.lineTo(x, y + r); ctx.arcTo(x, y, x + r, y, r);
    ctx.closePath();
  }
  function fill(ctx, color, alpha) { ctx.globalAlpha = alpha === undefined ? 1 : clamp(alpha, 0, 1); ctx.fillStyle = color; ctx.fill(); ctx.globalAlpha = 1; }
  function mix(c1, c2, k) {
    var a = /^#?([0-9a-f]{6})$/i.exec(String(c1 || '')), b = /^#?([0-9a-f]{6})$/i.exec(String(c2 || ''));
    if (!a || !b) { return c1; }
    var x = parseInt(a[1], 16), y = parseInt(b[1], 16), out = '#';
    for (var sh = 16; sh >= 0; sh -= 8) { var v = Math.round(((x >> sh) & 255) * (1 - k) + ((y >> sh) & 255) * k).toString(16); out += v.length < 2 ? '0' + v : v; }
    return out;
  }
  // The "skin" of the design being painted: how its plates are filled. '' flat · grad · soft (drop shadow) · hard (offset shadow) · glow
  var SK = '';
  function box(ctx, x, y, w, h, r, color, alpha) {
    if (w <= 0 || h <= 0) { return; }
    var al = alpha === undefined ? 1 : alpha, big = w > 30 && h > 20;
    if (SK === 'hard' && big) { rr(ctx, x + 8, y + 8, w, h, r); fill(ctx, '#000000', al * 0.6); }
    rr(ctx, x, y, w, h, r);
    if (SK === 'grad' && big && /^#/.test(color)) {
      var g = ctx.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, mix(color, '#FFFFFF', 0.34)); g.addColorStop(0.55, color); g.addColorStop(1, mix(color, '#000000', 0.3));
      ctx.globalAlpha = clamp(al, 0, 1); ctx.fillStyle = g; ctx.fill(); ctx.globalAlpha = 1; return;
    }
    if ((SK === 'soft' || SK === 'glow') && big) { ctx.save(); if (SK === 'glow') { ctx.shadowColor = color; ctx.shadowBlur = 30; } else { shadow(ctx, 26, 0.5); } fill(ctx, color, al); ctx.restore(); return; }
    fill(ctx, color, al);
  }
  // The user's type settings travel in P: font (css family), fs {b, i, caps, sc, u}, ts (text size), track (1/1000 em), geoCaps
  function sty(P) { return P.fs || {}; }
  function px(P, size) { return Math.round(size * (P.ts || 1) * 100) / 100; }
  function fnt(P, size, weight) { return (sty(P).sc ? 'small-caps ' : '') + (weight || 700) + ' ' + px(P, size) + 'px ' + (P.font || 'Helvetica Neue, Arial, sans-serif'); }
  function setFont(ctx, P, size, weight) {
    ctx.font = fnt(P, size, weight);
    if ('letterSpacing' in ctx) { ctx.letterSpacing = (P.track ? Math.round(P.track / 1000 * px(P, size) * 100) / 100 : 0) + 'px'; }
  }
  /** The text as it will be shown: ALL CAPS when asked (Georgian only if the font has its capital letters). */
  function say(P, str) {
    str = String(str === undefined || str === null ? '' : str);
    if (!sty(P).caps) { return str; }
    return P.geoCaps ? str.toUpperCase() : str.replace(/[^\u10D0-\u10FF]+/g, function (m) { return m.toUpperCase(); });
  }
  function width(ctx, str, P, size, weight) { setFont(ctx, P, size, weight); return ctx.measureText(say(P, str)).width; }
  /** fillText with the faux styles (bold = a thin outline in the same colour, italic = a slant). */
  function put(ctx, P, str, x, y, size) {
    var f = sty(P);
    if (f.i) { ctx.save(); ctx.translate(x, y); ctx.transform(1, 0, -0.2, 1, 0, 0); x = 0; y = 0; }
    if (f.b) { ctx.lineJoin = 'round'; ctx.lineWidth = Math.max(1, px(P, size) * 0.05); ctx.strokeStyle = ctx.fillStyle; ctx.strokeText(str, x, y); }
    ctx.fillText(str, x, y);
    if (f.i) { ctx.restore(); }
  }
  /** Text on one line; shrinks to maxW when given. Returns the width it took. */
  function text(ctx, str, x, y, P, size, weight, color, align, maxW, alpha) {
    str = say(P, str);
    if (!str) { return 0; }
    var w = width(ctx, str, P, size, weight);
    if (maxW && w > maxW) { size = Math.max(8, size * maxW / w); w = width(ctx, str, P, size, weight); }
    setFont(ctx, P, size, weight); ctx.textAlign = align || 'left'; ctx.textBaseline = 'middle';
    ctx.globalAlpha = alpha === undefined ? 1 : clamp(alpha, 0, 1); ctx.fillStyle = color;
    put(ctx, P, str, x, y, size);
    if (sty(P).u) { var x0 = align === 'center' ? x - w / 2 : (align === 'right' ? x - w : x), th = Math.max(2, px(P, size) * 0.06); ctx.fillRect(x0, y + px(P, size) * 0.46, w, th); }
    ctx.globalAlpha = 1;
    return w;
  }
  function clipRect(ctx, x, y, w, h) { ctx.beginPath(); ctx.rect(x, y, Math.max(0, w), Math.max(0, h)); ctx.clip(); }
  /** Readable text colour for a background. */
  function on(color) {
    var m = /^#?([0-9a-f]{6})$/i.exec(String(color || ''));
    if (!m) { return '#FFFFFF'; }
    var n = parseInt(m[1], 16), l = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
    return l > 0.62 ? '#111111' : '#FFFFFF';
  }
  function shadow(ctx, blur, alpha) { ctx.shadowColor = 'rgba(0,0,0,' + (alpha === undefined ? 0.45 : alpha) + ')'; ctx.shadowBlur = blur; ctx.shadowOffsetY = blur / 4; }
  function noShadow(ctx) { ctx.shadowColor = 'rgba(0,0,0,0)'; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0; }

  // generic icons, drawn around (cx, cy) in a box of size s
  var ICON = {
    bell: function (c, s) {
      c.beginPath(); c.moveTo(-0.36 * s, 0.22 * s); c.quadraticCurveTo(-0.26 * s, 0.1 * s, -0.26 * s, -0.08 * s);
      c.bezierCurveTo(-0.26 * s, -0.5 * s, 0.26 * s, -0.5 * s, 0.26 * s, -0.08 * s); c.quadraticCurveTo(0.26 * s, 0.1 * s, 0.36 * s, 0.22 * s); c.closePath(); c.fill();
      c.beginPath(); c.arc(0, 0.33 * s, 0.09 * s, 0, TAU); c.fill();
    },
    thumb: function (c, s) {
      rr(c, -0.42 * s, -0.04 * s, 0.2 * s, 0.44 * s, 0.04 * s); c.fill();
      c.beginPath(); c.moveTo(-0.16 * s, 0.38 * s); c.lineTo(-0.16 * s, -0.02 * s); c.lineTo(0.02 * s, -0.42 * s);
      c.quadraticCurveTo(0.18 * s, -0.42 * s, 0.14 * s, -0.2 * s); c.lineTo(0.1 * s, -0.06 * s); c.lineTo(0.36 * s, -0.06 * s);
      c.quadraticCurveTo(0.46 * s, -0.04 * s, 0.42 * s, 0.08 * s); c.lineTo(0.32 * s, 0.34 * s); c.quadraticCurveTo(0.3 * s, 0.4 * s, 0.22 * s, 0.4 * s); c.closePath(); c.fill();
    },
    heart: function (c, s) {
      c.beginPath(); c.moveTo(0, 0.36 * s); c.bezierCurveTo(-0.6 * s, -0.02 * s, -0.4 * s, -0.46 * s, 0, -0.16 * s);
      c.bezierCurveTo(0.4 * s, -0.46 * s, 0.6 * s, -0.02 * s, 0, 0.36 * s); c.closePath(); c.fill();
    },
    plus: function (c, s) { rr(c, -0.07 * s, -0.36 * s, 0.14 * s, 0.72 * s, 0.05 * s); c.fill(); rr(c, -0.36 * s, -0.07 * s, 0.72 * s, 0.14 * s, 0.05 * s); c.fill(); },
    check: function (c, s) { c.lineWidth = 0.13 * s; c.lineCap = 'round'; c.lineJoin = 'round'; c.beginPath(); c.moveTo(-0.3 * s, 0.02 * s); c.lineTo(-0.08 * s, 0.24 * s); c.lineTo(0.32 * s, -0.22 * s); c.strokeStyle = c.fillStyle; c.stroke(); },
    play: function (c, s) { c.beginPath(); c.moveTo(-0.22 * s, -0.32 * s); c.lineTo(0.36 * s, 0); c.lineTo(-0.22 * s, 0.32 * s); c.closePath(); c.fill(); },
    cursor: function (c, s) {
      c.beginPath(); c.moveTo(-0.2 * s, -0.4 * s); c.lineTo(-0.2 * s, 0.3 * s); c.lineTo(-0.02 * s, 0.14 * s); c.lineTo(0.1 * s, 0.42 * s);
      c.lineTo(0.2 * s, 0.38 * s); c.lineTo(0.08 * s, 0.1 * s); c.lineTo(0.32 * s, 0.1 * s); c.closePath();
      c.lineWidth = 0.07 * s; c.lineJoin = 'round'; c.strokeStyle = '#111111'; c.stroke(); c.fill();
    },
    comment: function (c, s) { rr(c, -0.4 * s, -0.34 * s, 0.8 * s, 0.56 * s, 0.14 * s); c.fill(); c.beginPath(); c.moveTo(-0.2 * s, 0.18 * s); c.lineTo(-0.26 * s, 0.42 * s); c.lineTo(0.04 * s, 0.2 * s); c.closePath(); c.fill(); },
    share: function (c, s) { c.beginPath(); c.moveTo(0.02 * s, -0.4 * s); c.lineTo(0.44 * s, -0.04 * s); c.lineTo(0.02 * s, 0.32 * s); c.lineTo(0.02 * s, 0.1 * s); c.quadraticCurveTo(-0.3 * s, 0.08 * s, -0.44 * s, 0.38 * s); c.quadraticCurveTo(-0.4 * s, -0.16 * s, 0.02 * s, -0.18 * s); c.closePath(); c.fill(); },
    save: function (c, s) { c.beginPath(); c.moveTo(-0.26 * s, -0.4 * s); c.lineTo(0.26 * s, -0.4 * s); c.lineTo(0.26 * s, 0.4 * s); c.lineTo(0, 0.18 * s); c.lineTo(-0.26 * s, 0.4 * s); c.closePath(); c.fill(); },
    link: function (c, s) {
      c.lineWidth = 0.12 * s; c.lineCap = 'round'; c.strokeStyle = c.fillStyle;
      c.save(); c.rotate(-Math.PI / 4); rr(c, -0.46 * s, -0.15 * s, 0.5 * s, 0.3 * s, 0.15 * s); c.stroke(); rr(c, -0.04 * s, -0.15 * s, 0.5 * s, 0.3 * s, 0.15 * s); c.stroke(); c.restore();
    },
    up: function (c, s) { c.beginPath(); c.moveTo(0, -0.42 * s); c.lineTo(0.36 * s, -0.02 * s); c.lineTo(0.12 * s, -0.02 * s); c.lineTo(0.12 * s, 0.42 * s); c.lineTo(-0.12 * s, 0.42 * s); c.lineTo(-0.12 * s, -0.02 * s); c.lineTo(-0.36 * s, -0.02 * s); c.closePath(); c.fill(); },
    send: function (c, s) { c.beginPath(); c.moveTo(-0.44 * s, -0.06 * s); c.lineTo(0.44 * s, -0.4 * s); c.lineTo(0.12 * s, 0.42 * s); c.lineTo(-0.04 * s, 0.1 * s); c.closePath(); c.fill(); },
    cart: function (c, s) { c.beginPath(); c.moveTo(-0.44 * s, -0.36 * s); c.lineTo(-0.28 * s, -0.36 * s); c.lineTo(-0.16 * s, 0.14 * s); c.lineTo(0.3 * s, 0.14 * s); c.lineTo(0.42 * s, -0.2 * s); c.lineTo(-0.22 * s, -0.2 * s); c.lineWidth = 0.1 * s; c.lineJoin = 'round'; c.lineCap = 'round'; c.strokeStyle = c.fillStyle; c.stroke(); c.beginPath(); c.arc(-0.1 * s, 0.34 * s, 0.08 * s, 0, TAU); c.fill(); c.beginPath(); c.arc(0.24 * s, 0.34 * s, 0.08 * s, 0, TAU); c.fill(); },
    down: function (c, s) { c.beginPath(); c.moveTo(0, 0.22 * s); c.lineTo(0.3 * s, -0.1 * s); c.lineTo(0.1 * s, -0.1 * s); c.lineTo(0.1 * s, -0.42 * s); c.lineTo(-0.1 * s, -0.42 * s); c.lineTo(-0.1 * s, -0.1 * s); c.lineTo(-0.3 * s, -0.1 * s); c.closePath(); c.fill(); rr(c, -0.38 * s, 0.3 * s, 0.76 * s, 0.12 * s, 0.05 * s); c.fill(); },
    pin: function (c, s) { c.beginPath(); c.moveTo(0, 0.44 * s); c.bezierCurveTo(-0.5 * s, -0.06 * s, -0.3 * s, -0.44 * s, 0, -0.44 * s); c.bezierCurveTo(0.3 * s, -0.44 * s, 0.5 * s, -0.06 * s, 0, 0.44 * s); c.closePath(); c.fill(); c.save(); c.globalCompositeOperation = 'destination-out'; c.beginPath(); c.arc(0, -0.14 * s, 0.12 * s, 0, TAU); c.fill(); c.restore(); },
    phone: function (c, s) { c.save(); c.rotate(-0.6); rr(c, -0.14 * s, -0.42 * s, 0.28 * s, 0.26 * s, 0.08 * s); c.fill(); rr(c, -0.14 * s, 0.16 * s, 0.28 * s, 0.26 * s, 0.08 * s); c.fill(); rr(c, -0.14 * s, -0.3 * s, 0.13 * s, 0.6 * s, 0.05 * s); c.fill(); c.restore(); },
    star: function (c, s) { c.beginPath(); for (var i = 0; i < 10; i++) { var r = i % 2 ? 0.19 * s : 0.44 * s, an = -Math.PI / 2 + i * Math.PI / 5; c.lineTo(Math.cos(an) * r, Math.sin(an) * r); } c.closePath(); c.fill(); },
    hash: function (c, s) { c.save(); c.transform(1, 0, -0.18, 1, 0, 0); rr(c, -0.2 * s, -0.4 * s, 0.1 * s, 0.8 * s, 0.04 * s); c.fill(); rr(c, 0.1 * s, -0.4 * s, 0.1 * s, 0.8 * s, 0.04 * s); c.fill(); c.restore(); rr(c, -0.4 * s, -0.2 * s, 0.8 * s, 0.1 * s, 0.04 * s); c.fill(); rr(c, -0.4 * s, 0.1 * s, 0.8 * s, 0.1 * s, 0.04 * s); c.fill(); },
    quote: function (c, s) { for (var q = -1; q <= 1; q += 2) { c.beginPath(); c.arc(q * 0.2 * s, 0.08 * s, 0.16 * s, 0, TAU); c.fill(); c.beginPath(); c.moveTo(q * 0.2 * s - 0.16 * s, 0.08 * s); c.quadraticCurveTo(q * 0.2 * s - 0.16 * s, -0.3 * s, q * 0.2 * s + 0.12 * s, -0.38 * s); c.lineTo(q * 0.2 * s + 0.12 * s, -0.26 * s); c.quadraticCurveTo(q * 0.2 * s - 0.02 * s, -0.2 * s, q * 0.2 * s, 0.08 * s); c.closePath(); c.fill(); } },
    user: function (c, s) { c.beginPath(); c.arc(0, -0.16 * s, 0.18 * s, 0, TAU); c.fill(); c.beginPath(); c.arc(0, 0.5 * s, 0.36 * s, Math.PI, TAU); c.closePath(); c.fill(); }
  };
  function icon(ctx, name, cx, cy, s, color, scale, alpha, rot) {
    if (!ICON[name]) { return; }
    ctx.save(); ctx.translate(cx, cy); if (rot) { ctx.rotate(rot); }
    var k = scale === undefined ? 1 : scale; ctx.scale(k, k);
    ctx.globalAlpha = alpha === undefined ? 1 : clamp(alpha, 0, 1); ctx.fillStyle = color; ICON[name](ctx, s); ctx.restore(); ctx.globalAlpha = 1;
  }
  /** The round badge of a social design: the user's own picture when there is one, otherwise a plain monogram. */
  function badge(ctx, P, cx, cy, r, colors, mono, k) {
    k = k === undefined ? 1 : k;
    if (k <= 0) { return; }
    ctx.save(); ctx.translate(cx, cy); ctx.scale(k, k);
    ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU);
    if (P.logo) { ctx.save(); ctx.clip(); try { ctx.drawImage(P.logo, -r, -r, r * 2, r * 2); } catch (e) {} ctx.restore(); ctx.restore(); return; }
    if (colors.length > 1) { var g = ctx.createLinearGradient(-r, r, r, -r); for (var i = 0; i < colors.length; i++) { g.addColorStop(i / (colors.length - 1), colors[i]); } ctx.fillStyle = g; }
    else { ctx.fillStyle = colors[0]; }
    ctx.fill();
    text(ctx, mono, 0, r * 0.04, P, r * (mono.length > 1 ? 0.78 : 1.05), 800, on(colors[colors.length > 1 ? 1 : 0]), 'center');
    ctx.restore();
  }

  // ---------------------------------------------------------------- timers
  function pad(n, w) { var s = String(Math.floor(n)); while (s.length < w) { s = '0' + s; } return s; }
  /** What the clock shows at time t. Counting down, a second is shown until it is over (10 → 9 … → 0). */
  function clock(P, t) {
    var tm = P.timer || {}, total = Math.max(0, Number(tm.total) || 0), fmt = tm.fmt || 'auto';
    var el = clamp(t, 0, total), v = tm.down ? total - el : el;
    if (fmt === 'auto') { fmt = total >= 3600 ? 'h:mm:ss' : (total >= 60 ? 'm:ss' : 's'); }
    if (fmt === 'ss.cc') { v = Math.max(0, v); var c = Math.floor(v * 100 + 1e-6); return pad(c / 100, 2) + '.' + pad(c % 100, 2); }
    var s = tm.down ? Math.ceil(v - 1e-6) : Math.floor(v + 1e-6);
    if (fmt === 's') { return String(s); }
    if (fmt === 'mm:ss') { return pad(s / 60, 2) + ':' + pad(s % 60, 2); }
    if (fmt === 'h:mm:ss') { return Math.floor(s / 3600) + ':' + pad((s % 3600) / 60, 2) + ':' + pad(s % 60, 2); }
    return Math.floor(s / 60) + ':' + pad(s % 60, 2);
  }
  /** How far the timer has run, 0…1. */
  function ran(P, t) { var total = Math.max(0.001, Number((P.timer || {}).total) || 0); return clamp(t / total, 0, 1); }
  /** Time since the shown second last changed (for ticks and pops). */
  function sinceTick(P, t) { var total = Number((P.timer || {}).total) || 0; return t >= total ? t - total : t - Math.floor(t); }
  /** Digits in fixed cells, so the clock does not shake as numbers change. Returns the total width. */
  function digits(ctx, str, cx, cy, size, P, color, weight, alpha, each) {
    setFont(ctx, P, size, weight || 700);
    var cw = 0, i, ch, sp = P.track ? P.track / 1000 * px(P, size) : 0;
    if ('letterSpacing' in ctx) { ctx.letterSpacing = '0px'; }
    for (i = 0; i < 10; i++) { cw = Math.max(cw, ctx.measureText(String(i)).width); }
    cw += sp;
    var sw = Math.max(cw * 0.42, ctx.measureText(':').width + sp), total = 0;
    for (i = 0; i < str.length; i++) { total += /\d/.test(str.charAt(i)) ? cw : sw; }
    var x = cx - total / 2;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (i = 0; i < str.length; i++) {
      ch = str.charAt(i);
      var w = /\d/.test(ch) ? cw : sw;
      if (each) { each(ch, x + w / 2, w, i); }
      else { ctx.globalAlpha = alpha === undefined ? 1 : clamp(alpha, 0, 1); ctx.fillStyle = color; put(ctx, P, ch, x + w / 2, cy, size); }
      x += w;
    }
    ctx.globalAlpha = 1;
    return total;
  }

  var TIMER = {
    plain: function (ctx, t, P) {
      var a = st(t, P, 0, 0.35);
      ctx.save(); shadow(ctx, 18, 0.5 * a);
      digits(ctx, clock(P, t), 320, 110, 150, P, P.color, 800, a);
      ctx.restore();
    },
    line: function (ctx, t, P) {
      var a = st(t, P, 0, 0.35), w = 440, x = 100, p = ran(P, t);
      text(ctx, P.t1, 320, 34, P, 26, 600, P.color, 'center', 560, 0.75 * a);
      ctx.save(); shadow(ctx, 14, 0.4 * a); digits(ctx, clock(P, t), 320, 112, 122, P, P.color, 700, a); ctx.restore();
      box(ctx, x, 190, w, 6, 3, P.color, 0.25 * a);
      box(ctx, x, 190, w * ((P.timer || {}).down ? 1 - p : p), 6, 3, P.accent, a);
    },
    pill: function (ctx, t, P) {
      var a = st(t, P, 0, 0.4, E.back), blink = 0.35 + 0.65 * Math.abs(Math.cos(Math.PI * t));
      ctx.save(); ctx.translate(320, 110); ctx.scale(0.8 + 0.2 * a, 0.8 + 0.2 * a); ctx.translate(-320, -110);
      box(ctx, 90, 40, 460, 140, 70, P.bg, 0.92 * a);
      ctx.beginPath(); ctx.arc(150, 110, 13, 0, TAU); fill(ctx, P.accent, a * blink);
      digits(ctx, clock(P, t), 345, 113, 96, P, on(P.bg), 700, a);
      ctx.restore();
    },
    cards: function (ctx, t, P) {
      var a = st(t, P, 0, 0.4), now = clock(P, t), before = clock(P, Math.max(0, t - 0.22)), k = E.out3(seg(sinceTick(P, t), 0, 0.22));
      digits(ctx, now, 320, 110, 118, P, P.color, 800, a, function (ch, x, w, i) {
        if (!/\d/.test(ch)) { text(ctx, ch, x, 104, P, 100, 800, P.color, 'center', 0, a); return; }
        box(ctx, x - w / 2 + 4, 34, w - 8, 152, 16, P.bg, 0.94 * a);
        var changed = before.length === now.length && before.charAt(i) !== ch && k < 1;
        ctx.save(); clipRect(ctx, x - w / 2 + 4, 34, w - 8, 152);
        if (changed) { text(ctx, before.charAt(i), x, 112 - 150 * k, P, 118, 800, on(P.bg), 'center', 0, a); }
        text(ctx, ch, x, 112 + (changed ? 150 * (1 - k) : 0), P, 118, 800, on(P.bg), 'center', 0, a);
        ctx.restore();
        box(ctx, x - w / 2 + 4, 109, w - 8, 2, 0, '#000000', 0.28 * a);
      });
    },
    ring: function (ctx, t, P) {
      var a = st(t, P, 0, 0.45), p = ran(P, t), left = (P.timer || {}).down ? 1 - p : p, r = 150;
      ctx.lineCap = 'round'; ctx.lineWidth = 16;
      ctx.beginPath(); ctx.arc(190, 190, r, 0, TAU); ctx.globalAlpha = 0.9 * a; ctx.fillStyle = P.bg; ctx.fill();
      ctx.globalAlpha = 0.22 * a; ctx.strokeStyle = on(P.bg); ctx.stroke();
      ctx.beginPath(); ctx.arc(190, 190, r, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(left, 0.0001, 1)); ctx.globalAlpha = a; ctx.strokeStyle = P.accent; ctx.stroke(); ctx.globalAlpha = 1;
      digits(ctx, clock(P, t), 190, 186, clock(P, t).length > 4 ? 72 : 96, P, on(P.bg), 800, a);
      text(ctx, P.t1, 190, 254, P, 22, 600, on(P.bg), 'center', 200, 0.7 * a);
    },
    bar: function (ctx, t, P) {
      var a = st(t, P, 0, 0.4), p = ran(P, t), q = (P.timer || {}).down ? 1 - p : p;
      box(ctx, 20, 20, 600, 180, 22, P.bg, 0.9 * a);
      text(ctx, P.t1, 52, 62, P, 26, 600, on(P.bg), 'left', 300, 0.72 * a);
      ctx.font = fnt(P, 78, 800);
      digits(ctx, clock(P, t), 588 - digits(ctx, clock(P, t), 0, 0, 78, P, '#000', 800, 0, function () {}) / 2, 76, 78, P, on(P.bg), 800, a);
      box(ctx, 52, 140, 536, 26, 13, on(P.bg), 0.16 * a);
      box(ctx, 52, 140, Math.max(26, 536 * q), 26, 13, P.accent, a);
    },
    neon: function (ctx, t, P) {
      var a = st(t, P, 0, 0.5), fl = 0.86 + 0.14 * Math.sin(t * 37) * Math.sin(t * 11.3), s = clock(P, t);
      ctx.save(); ctx.shadowColor = P.accent; ctx.shadowBlur = 34; ctx.lineJoin = 'round';
      digits(ctx, s, 320, 110, 140, P, P.accent, 800, a, function (ch, x) {
        ctx.font = fnt(P, 140, 800); ctx.globalAlpha = a * fl; ctx.lineWidth = 5; ctx.strokeStyle = P.accent; ctx.strokeText(ch, x, 110);
        ctx.shadowBlur = 8; ctx.lineWidth = 1.6; ctx.strokeStyle = '#FFFFFF'; ctx.globalAlpha = 0.9 * a * fl; ctx.strokeText(ch, x, 110); ctx.shadowBlur = 34;
      });
      ctx.restore(); ctx.globalAlpha = 1;
    },
    rec: function (ctx, t, P) {
      var a = st(t, P, 0, 0.3), tm = P.timer || {}, total = Number(tm.total) || 0, el = clamp(t, 0, total), v = tm.down ? total - el : el, fps = Math.round(P.fps || 30);
      var f = Math.floor((v - Math.floor(v)) * fps + 1e-6), s = Math.floor(v), tc = pad(s / 3600, 2) + ':' + pad((s % 3600) / 60, 2) + ':' + pad(s % 60, 2) + ':' + pad(f, 2);
      box(ctx, 20, 60, 600, 100, 12, '#000000', 0.55 * a);
      ctx.beginPath(); ctx.arc(64, 110, 13, 0, TAU); fill(ctx, '#FF2D2D', a * (Math.floor(t * 2) % 2 ? 0.25 : 1));
      text(ctx, P.t1 || 'REC', 92, 112, P, 34, 700, '#FFFFFF', 'left', 110, a);
      var save = P.font; P.font = 'Menlo, "SF Mono", "Courier New", monospace';
      digits(ctx, tc, 410, 112, 54, P, '#FFFFFF', 600, a); P.font = save;
    },
    big: function (ctx, t, P) {
      var a = st(t, P, 0, 0.3), tk = sinceTick(P, t), pop = 1 + 0.32 * (1 - E.out5(seg(tk, 0, 0.45))), tm = P.timer || {}, total = Number(tm.total) || 0;
      var left = tm.down ? total - Math.min(t, total) : Infinity, hot = left <= 3.0001, col = hot ? P.accent : P.color, wave = seg(tk, 0, 0.7);
      ctx.beginPath(); ctx.arc(210, 210, 110 + 90 * E.out3(wave), 0, TAU); ctx.lineWidth = 8 * (1 - wave); ctx.globalAlpha = 0.55 * (1 - wave) * a; ctx.strokeStyle = col; if (ctx.lineWidth > 0.2) { ctx.stroke(); } ctx.globalAlpha = 1;
      ctx.save(); ctx.translate(210, 214); ctx.scale(pop, pop); shadow(ctx, 22, 0.5 * a);
      var s = clock(P, t); digits(ctx, s, 0, 0, s.length > 3 ? 120 : (s.length > 2 ? 170 : 240), P, col, 900, a); ctx.restore();
    },
    score: function (ctx, t, P) {
      var a = st(t, P, 0, 0.45), b = st(t, P, 0.12, 0.45), lw = Math.max(150, Math.min(300, width(ctx, P.t1, P, 34, 800) + 56));
      ctx.save(); ctx.transform(1, 0, -0.18, 1, 30, 0);
      ctx.save(); clipRect(ctx, 20, 50, (lw + 300) * a, 120);
      box(ctx, 20, 50, lw, 120, 6, P.accent, 1); text(ctx, P.t1, 20 + lw / 2, 112, P, 34, 800, on(P.accent), 'center', lw - 30, b);
      box(ctx, 20 + lw, 50, 290, 120, 6, P.bg, 0.96); ctx.restore();
      digits(ctx, clock(P, t), 20 + lw + 145, 113, 84, P, on(P.bg), 800, b);
      ctx.restore();
    },
    badge: function (ctx, t, P) {
      var a = st(t, P, 0, 0.5, E.back), k = 0.7 + 0.3 * a;
      ctx.save(); ctx.translate(190, 190); ctx.scale(k, k);
      ctx.beginPath(); ctx.arc(0, 0, 150, 0, TAU); fill(ctx, P.accent, a);
      ctx.save(); ctx.rotate(t * 0.5); ctx.setLineDash([14, 14]); ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(0, 0, 172, 0, TAU); ctx.globalAlpha = 0.9 * a; ctx.strokeStyle = P.accent; ctx.stroke(); ctx.restore(); ctx.globalAlpha = 1;
      text(ctx, P.t1, 0, -62, P, 24, 700, on(P.accent), 'center', 200, 0.85 * a);
      var s = clock(P, t); digits(ctx, s, 0, 6, s.length > 4 ? 74 : 100, P, on(P.accent), 900, a);
      text(ctx, P.t2, 0, 74, P, 22, 600, on(P.accent), 'center', 180, 0.8 * a);
      ctx.restore();
    },
    corner: function (ctx, t, P) {
      var a = st(t, P, 0, 0.4), b = st(t, P, 0.1, 0.4);
      box(ctx, 30, 36, 8, 148 * a, 4, P.accent, 1);
      ctx.save(); clipRect(ctx, 44, 0, 600, 220);
      text(ctx, P.t1, 62 - 40 * (1 - b), 64, P, 28, 600, P.color, 'left', 520, 0.8 * b);
      ctx.font = fnt(P, 104, 800); var w = digits(ctx, clock(P, t), 0, 0, 104, P, '#000', 800, 0, function () {});
      ctx.save(); shadow(ctx, 14, 0.4 * b); digits(ctx, clock(P, t), 62 + w / 2 - 60 * (1 - b), 134, 104, P, P.color, 800, b); ctx.restore();
      ctx.restore();
    }
  };

  // ---------------------------------------------------------------- lower thirds (name + line under it)
  // canvas 1000 × 220; V = the variant's options
  var LT = {
    line: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.4), b = st(t, P, 0.12, 0.5), c = st(t, P, 0.22, 0.5), r = V.side === 'r', th = V.thick ? 14 : 6, x0 = r ? 1000 - 40 - th : 40;
      box(ctx, x0, 110 - 75 * a, th, 150 * a, th / 2, P.accent, 1);
      if (V.two) { box(ctx, x0 + (r ? -th - 8 : th + 8), 110 - 75 * a * 0.6, th, 150 * a * 0.6, th / 2, P.color, 0.9); }
      var tx = r ? x0 - 26 - (V.two ? th + 8 : 0) : x0 + th + 26 + (V.two ? th + 8 : 0), dir = r ? 1 : -1;
      ctx.save(); if (r) { clipRect(ctx, 0, 0, tx + 6, 220); } else { clipRect(ctx, tx - 6, 0, 1000, 220); }
      shadow(ctx, 12, 0.45);
      text(ctx, P.t1, tx + dir * 420 * (1 - b), 84, P, 62, 800, P.color, r ? 'right' : 'left', 840, b);
      text(ctx, P.t2, tx + dir * 420 * (1 - c), 148, P, 34, 500, P.color, r ? 'right' : 'left', 840, 0.85 * c);
      ctx.restore();
    },
    under: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.5), b = st(t, P, 0.1, 0.5, E.out5), c = st(t, P, 0.25, 0.5), ctr = V.mode === 'center', x = ctr ? 500 : 50, al = ctr ? 'center' : 'left';
      var w = Math.min(880, width(ctx, P.t1, P, 64, 800)), lw = V.mode === 'short' ? 110 : w;
      ctx.save(); clipRect(ctx, 0, 30, 1000, 86); shadow(ctx, 12, 0.45); text(ctx, P.t1, x, 78 + 80 * (1 - a), P, 64, 800, P.color, al, 880); ctx.restore();
      box(ctx, ctr ? 500 - lw * b / 2 : 50, 122, lw * b, V.mode === 'short' ? 8 : 5, 3, P.accent, 1);
      ctx.save(); shadow(ctx, 10, 0.4); text(ctx, P.t2, x, 162 - 14 * (1 - c), P, 34, 500, P.color, al, 880, 0.9 * c); ctx.restore();
    },
    box: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.5, E.out5), b = st(t, P, 0.18, 0.5, E.out5), c = st(t, P, 0.3, 0.45), w1 = Math.min(900, width(ctx, P.t1, P, 56, 800)) + 64, w2 = Math.min(840, width(ctx, P.t2, P, 30, 600)) + 48;
      ctx.save(); if (V.skew) { ctx.transform(1, 0, -0.16, 1, 22, 0); }
      var top = V.style === 'duo' ? P.accent : P.bg, tc = on(top);
      if (V.style === 'outline') { ctx.save(); clipRect(ctx, 36, 30, (w1 + 10) * a, 110); rr(ctx, 40, 34, w1, 96, 8); ctx.lineWidth = 5; ctx.strokeStyle = P.accent; ctx.stroke(); ctx.restore(); tc = P.color; }
      else { box(ctx, 40, 34, w1 * a, 96, V.round ? 48 : 8, top, V.style === 'glass' ? 0.5 : 0.96); if (V.style === 'glass') { box(ctx, 40, 34, 8, 96 * a, 4, P.accent, 1); } }
      ctx.save(); clipRect(ctx, 40, 34, w1 * a, 96); text(ctx, P.t1, 72, 84, P, 56, 800, tc, 'left', 900, c); ctx.restore();
      var bottom = V.style === 'duo' ? P.bg : (V.style === 'solid' ? P.accent : P.bg);
      if (P.t2) {
        if (V.style === 'outline') { ctx.save(); shadow(ctx, 8, 0.4); text(ctx, P.t2, 46, 166, P, 30, 600, P.color, 'left', 840, c); ctx.restore(); }
        else { box(ctx, 40, 138, w2 * b, 54, V.round ? 27 : 6, bottom, V.style === 'glass' ? 0.5 : 0.96); ctx.save(); clipRect(ctx, 40, 138, w2 * b, 54); text(ctx, P.t2, 64, 166, P, 30, 600, on(bottom), 'left', 840, c); ctx.restore(); }
      }
      ctx.restore();
    },
    tag: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.45, E.back), b = st(t, P, 0.15, 0.5), c = st(t, P, 0.26, 0.5), ch = String(P.t1 || '•').replace(/^[@#\s]+/, '').charAt(0).toUpperCase() || '•';
      ctx.save(); ctx.translate(100, 110); ctx.scale(a, a);
      if (V.shape === 'circle') { ctx.beginPath(); ctx.arc(0, 0, 64, 0, TAU); fill(ctx, P.accent, 1); }
      else if (V.shape === 'diamond') { ctx.rotate(Math.PI / 4); box(ctx, -50, -50, 100, 100, 12, P.accent, 1); ctx.rotate(-Math.PI / 4); }
      else { box(ctx, -60, -60, 120, 120, 18, P.accent, 1); }
      if (P.logo) { ctx.save(); ctx.beginPath(); ctx.arc(0, 0, 54, 0, TAU); ctx.clip(); try { ctx.drawImage(P.logo, -54, -54, 108, 108); } catch (e) {} ctx.restore(); }
      else { text(ctx, ch, 0, 4, P, 74, 900, on(P.accent), 'center'); }
      ctx.restore();
      ctx.save(); clipRect(ctx, 176, 0, 824, 220); shadow(ctx, 12, 0.45);
      text(ctx, P.t1, 196 - 300 * (1 - b), 86, P, 58, 800, P.color, 'left', 770, b);
      text(ctx, P.t2, 196 - 300 * (1 - c), 146, P, 32, 500, P.color, 'left', 770, 0.85 * c);
      ctx.restore();
    },
    bracket: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.55, E.out5), b = st(t, P, 0.2, 0.5), w = Math.min(860, Math.max(width(ctx, P.t1, P, 58, 800), width(ctx, P.t2, P, 30, 500))) + 90, x = 40, L = 34;
      ctx.lineWidth = 6; ctx.strokeStyle = P.accent; ctx.lineCap = 'square'; ctx.globalAlpha = a;
      var gap = (1 - a) * w / 2, l = x + gap, r = x + w - gap;
      ctx.beginPath();
      if (V.mode === 'sides') { ctx.moveTo(l + L, 40); ctx.lineTo(l, 40); ctx.lineTo(l, 180); ctx.lineTo(l + L, 180); ctx.moveTo(r - L, 40); ctx.lineTo(r, 40); ctx.lineTo(r, 180); ctx.lineTo(r - L, 180); }
      else { ctx.moveTo(l, 40 + L); ctx.lineTo(l, 40); ctx.lineTo(l + L, 40); ctx.moveTo(r - L, 180); ctx.lineTo(r, 180); ctx.lineTo(r, 180 - L); }
      ctx.stroke(); ctx.globalAlpha = 1;
      ctx.save(); shadow(ctx, 12, 0.45);
      text(ctx, P.t1, x + 45, 90, P, 58, 800, P.color, 'left', 860, b);
      text(ctx, P.t2, x + 45, 146, P, 30, 500, P.color, 'left', 860, 0.85 * b);
      ctx.restore();
    },
    strip: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.55, E.out5), b = st(t, P, 0.2, 0.5), c = st(t, P, 0.3, 0.5);
      if (V.mode === 'news') {
        var lw = Math.min(360, width(ctx, P.t2, P, 30, 800) + 50);
        box(ctx, 0, 60, 1000 * a, 100, 0, P.bg, 0.95); box(ctx, 0, 60, lw * b, 100, 0, P.accent, 1);
        ctx.save(); clipRect(ctx, 0, 60, lw * b, 100); text(ctx, P.t2, lw / 2, 112, P, 30, 800, on(P.accent), 'center', lw - 30); ctx.restore();
        ctx.save(); clipRect(ctx, lw, 60, 1000 - lw, 100); text(ctx, P.t1, lw + 30 + 60 * (1 - c), 112, P, 46, 700, on(P.bg), 'left', 960 - lw, c); ctx.restore();
        return;
      }
      if (V.mode === 'fade') { var g = ctx.createLinearGradient(0, 0, 1000, 0); g.addColorStop(0, P.bg); g.addColorStop(0.75, P.bg); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.globalAlpha = 0.92 * a; ctx.fillStyle = g; ctx.fillRect(0, 34, 1000, 152); ctx.globalAlpha = 1; }
      else { box(ctx, 0, 34, 1000 * a, 152, 0, P.bg, 0.94); }
      box(ctx, 0, 34, 12, 152 * a, 0, P.accent, 1);
      ctx.save(); clipRect(ctx, 12, 34, 988, 152);
      text(ctx, P.t1, 44 - 80 * (1 - b), 92, P, 56, 800, on(P.bg), 'left', 900, b);
      text(ctx, P.t2, 44 - 80 * (1 - c), 148, P, 30, 500, on(P.bg), 'left', 900, 0.8 * c);
      ctx.restore();
    },
    pill: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.55, E.out5), b = st(t, P, 0.25, 0.45), bgc = V.tone === 'light' ? '#FFFFFF' : (V.tone === 'accent' ? P.accent : P.bg), fc = on(bgc);
      var w = Math.min(900, Math.max(width(ctx, P.t1, P, 46, 800), width(ctx, P.t2, P, 26, 500)) + 170), dot = V.tone === 'accent' ? fc : P.accent;
      box(ctx, 40, 44, 132 + (w - 132) * a, 132, 66, bgc, 0.96 * Math.min(1, a * 3));
      ctx.beginPath(); ctx.arc(106, 110, 20 + 5 * Math.sin(t * 4), 0, TAU); fill(ctx, dot, 0.28 * Math.min(1, a * 3));
      ctx.beginPath(); ctx.arc(106, 110, 14, 0, TAU); fill(ctx, dot, Math.min(1, a * 3));
      ctx.save(); clipRect(ctx, 150, 44, (w - 150) * a, 132);
      text(ctx, P.t1, 160, P.t2 ? 92 : 112, P, 46, 800, fc, 'left', 730, b);
      text(ctx, P.t2, 160, 140, P, 26, 500, fc, 'left', 730, 0.75 * b);
      ctx.restore();
    },
    stack: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.6, E.out5), b = st(t, P, 0.18, 0.5), c = st(t, P, 0.3, 0.5);
      ctx.save(); shadow(ctx, 16, 0.5);
      if (V.mode === 'wipe') { ctx.save(); clipRect(ctx, 0, 0, 1000 * a, 220); text(ctx, P.t1, 44, 84, P, 82, 900, P.color, 'left', 910); ctx.restore(); }
      else if (V.mode === 'split') {
        ctx.save(); clipRect(ctx, 0, 0, 1000, 86); text(ctx, P.t1, 44, 84 + 60 * (1 - a), P, 82, 900, P.color, 'left', 910, a); ctx.restore();
        ctx.save(); clipRect(ctx, 0, 86, 1000, 134); text(ctx, P.t1, 44, 84 - 60 * (1 - a), P, 82, 900, P.color, 'left', 910, a); ctx.restore();
      } else { ctx.save(); clipRect(ctx, 0, 30, 1000, 104); text(ctx, P.t1, 44, 84 + 110 * (1 - a), P, 82, 900, P.color, 'left', 910); ctx.restore(); }
      ctx.restore();
      box(ctx, 46, 142, 70 * b, 6, 3, P.accent, 1);
      ctx.save(); shadow(ctx, 10, 0.45); text(ctx, P.t2, 46 + 86 * b, 146, P, 32, 600, P.color, 'left', 820, c); ctx.restore();
    },
    tape: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.45, E.back), b = st(t, P, 0.14, 0.45, E.back), w1 = Math.min(880, width(ctx, P.t1, P, 54, 900)) + 56, w2 = Math.min(800, width(ctx, P.t2, P, 28, 700)) + 40, ang = (V.angle || -3) * Math.PI / 180;
      ctx.save(); ctx.translate(60 + w1 / 2, 86); ctx.rotate(ang); ctx.scale(a, a); shadow(ctx, 10, 0.35); box(ctx, -w1 / 2, -44, w1, 88, 4, P.accent, 1); noShadow(ctx);
      text(ctx, P.t1, 0, 3, P, 54, 900, on(P.accent), 'center', 880); ctx.restore();
      if (P.t2) { ctx.save(); ctx.translate(90 + w2 / 2, 164); ctx.rotate(-ang * 0.7); ctx.scale(b, b); shadow(ctx, 8, 0.35); box(ctx, -w2 / 2, -26, w2, 52, 4, P.bg, 1); noShadow(ctx); text(ctx, P.t2, 0, 2, P, 28, 700, on(P.bg), 'center', 800); ctx.restore(); }
    },
    corner: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.5, E.out5), b = st(t, P, 0.18, 0.5), c = st(t, P, 0.28, 0.5), up = V.up;
      ctx.lineWidth = 8; ctx.strokeStyle = P.accent; ctx.lineCap = 'square'; ctx.beginPath();
      if (up) { ctx.moveTo(40, 40 + 130 * a); ctx.lineTo(40, 40); ctx.lineTo(40 + 220 * a, 40); }
      else { ctx.moveTo(40, 180 - 130 * a); ctx.lineTo(40, 180); ctx.lineTo(40 + 220 * a, 180); }
      if (a > 0.01) { ctx.stroke(); }
      ctx.save(); shadow(ctx, 12, 0.45);
      text(ctx, P.t1, 72, up ? 96 : 76, P, 58, 800, P.color, 'left', 880, b);
      text(ctx, P.t2, 72 + 24 * (1 - c), up ? 152 : 134, P, 30, 500, P.color, 'left', 880, 0.85 * c);
      ctx.restore();
    },
    slash: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.5, E.out5), b = st(t, P, 0.1, 0.5, E.out5), c = st(t, P, 0.28, 0.5), w = Math.min(880, Math.max(width(ctx, P.t1, P, 56, 800), width(ctx, P.t2, P, 28, 600))) + 110;
      function para(x, y, ww, h, col, al) { if (ww <= 0) { return; } ctx.beginPath(); ctx.moveTo(x + 34, y); ctx.lineTo(x + ww + 34, y); ctx.lineTo(x + ww, y + h); ctx.lineTo(x, y + h); ctx.closePath(); fill(ctx, col, al); }
      para(30, 40, (w + 26) * b, 140, P.accent, V.dark ? 1 : 0.95); para(30, 40, w * a, 140, V.dark ? P.bg : '#FFFFFF', 0.97);
      var fc = on(V.dark ? P.bg : '#FFFFFF');
      ctx.save(); ctx.beginPath(); ctx.moveTo(64, 40); ctx.lineTo(30 + w * a + 34, 40); ctx.lineTo(30 + w * a, 180); ctx.lineTo(30, 180); ctx.closePath(); ctx.clip();
      text(ctx, P.t1, 92, 92, P, 56, 800, fc, 'left', 880, c); text(ctx, P.t2, 78, 146, P, 28, 600, fc, 'left', 880, 0.8 * c);
      ctx.restore();
    }
  };

  // ---------------------------------------------------------------- social: handles, subscribe / follow / like, calls to action
  var NET = {
    yt: { name: 'YouTube', mono: 'YT', c: ['#FF0000'] }, ig: { name: 'Instagram', mono: 'IG', c: ['#F9CE34', '#EE2A7B', '#6228D7'] },
    tt: { name: 'TikTok', mono: 'TT', c: ['#111111'], hi: '#FE2C55' }, fb: { name: 'Facebook', mono: 'FB', c: ['#1877F2'] },
    x: { name: 'X', mono: 'X', c: ['#000000'] }, tg: { name: 'Telegram', mono: 'TG', c: ['#26A5E4'] },
    th: { name: 'Threads', mono: 'TH', c: ['#101010'] }, li: { name: 'LinkedIn', mono: 'LI', c: ['#0A66C2'] },
    tw: { name: 'Twitch', mono: 'TW', c: ['#9146FF'] }, wa: { name: 'WhatsApp', mono: 'WA', c: ['#25D366'] }
  };
  function netColor(N) { return N.hi || N.c[Math.min(1, N.c.length - 1)]; }
  /** A pointer that arrives, presses at t0 and leaves. Returns how hard it presses (0…1) at time t. */
  function pointer(ctx, t, x, y, t0) {
    var come = E.out3(seg(t, t0 - 0.55, t0 - 0.05)), go = seg(t, t0 + 0.35, t0 + 0.8), press = seg(t, t0 - 0.05, t0 + 0.05) * (1 - seg(t, t0 + 0.05, t0 + 0.22));
    if (t > t0 - 0.55 && go < 1) { icon(ctx, 'cursor', x + 130 * (1 - come) + 60 * go, y + 110 * (1 - come) + 90 * go, 54, '#FFFFFF', 1 - 0.12 * press, 1 - go); }
    return press;
  }
  var SOC = {
    // canvas 1000 × 220
    handle: function (ctx, t, P, V) {
      var N = NET[V.net], a = st(t, P, 0, 0.5, E.back), b = st(t, P, 0.16, 0.55, E.out5), c = st(t, P, 0.34, 0.45), dark = V.tone !== 'light', bgc = dark ? '#111111' : '#FFFFFF', fc = on(bgc);
      if (V.card) {
        var w = Math.min(860, Math.max(width(ctx, P.t1, P, 44, 800), width(ctx, P.t2, P, 26, 500)) + 210);
        box(ctx, 40, 30, w * b, 160, 28, bgc, 0.97);
        box(ctx, 40, 30, 12, 160 * Math.min(1, b * 1.5), 6, netColor(N), 1);
        badge(ctx, P, 128, 110, 50, N.c, N.mono, a);
        ctx.save(); clipRect(ctx, 190, 30, Math.max(0, w * b - 160), 160);
        text(ctx, P.t2, 200, 80, P, 26, 600, fc, 'left', 640, 0.65 * c); text(ctx, P.t1, 200, 126, P, 44, 800, fc, 'left', 640, c);
        ctx.restore(); return;
      }
      var pw = Math.min(900, width(ctx, P.t1, P, 46, 800) + 190);
      box(ctx, 40, 54, 112 + (pw - 112) * b, 112, 56, bgc, 0.97 * Math.min(1, a * 2));
      badge(ctx, P, 96, 110, 44, N.c, N.mono, a);
      ctx.save(); clipRect(ctx, 150, 54, Math.max(0, (pw - 150) * b), 112);
      text(ctx, P.t1, 160, P.t2 ? 96 : 112, P, 46, 800, fc, 'left', 720, c); text(ctx, P.t2, 160, 138, P, 22, 600, fc, 'left', 720, 0.6 * c);
      ctx.restore();
    },
    sub: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.5, E.back), col = V.net === 'yt' ? '#FF0000' : P.accent, t0 = 1.5, done = t > t0, press = 0, ch = V.channel, bx = ch ? 600 : 300, bw = 360, by = 62, bh = 96;
      if (ch) {
        var b = st(t, P, 0.1, 0.5, E.out5);
        box(ctx, 20, 30, 960 * b, 160, 32, '#FFFFFF', 0.97);
        ctx.save(); clipRect(ctx, 20, 30, 960 * b, 160);
        badge(ctx, P, 108, 110, 54, [col], String(P.t1 || 'A').replace(/^[@\s]+/, '').charAt(0).toUpperCase(), a);
        text(ctx, P.t1, 186, 90, P, 40, 800, '#111111', 'left', 390); text(ctx, P.t2, 186, 136, P, 26, 500, '#555555', 'left', 390);
        ctx.restore();
        if (b < 0.9) { return; }
      }
      ctx.save(); ctx.translate(bx + bw / 2, by + bh / 2);
      // the button itself is drawn after the pointer's pressure is known
      var pr = seg(t, t0 - 0.05, t0 + 0.05) * (1 - seg(t, t0 + 0.05, t0 + 0.22)), k = a * (1 - 0.07 * pr) * (done ? 1 + 0.05 * (1 - E.out3(seg(t, t0, t0 + 0.4))) : 1);
      ctx.scale(k, k);
      box(ctx, -bw / 2, -bh / 2, bw, bh, ch ? 48 : 14, done ? '#E9E9E9' : col, 1);
      var label = done ? (P.t4 || 'გამოწერილია') : (P.t3 || 'გამოწერა'), fc = done ? '#333333' : '#FFFFFF';
      if (done) { ctx.save(); ctx.translate(-bw / 2 + 52, 0); ctx.rotate(0.35 * Math.sin((t - t0) * 22) * (1 - seg(t, t0, t0 + 0.9))); icon(ctx, 'bell', 0, 0, 46, '#333333'); ctx.restore(); }
      text(ctx, label, done ? 28 : 0, 3, P, 36, 800, fc, 'center', bw - (done ? 120 : 50));
      ctx.restore();
      press = pointer(ctx, t, bx + bw / 2 + 60, by + bh / 2 + 34, t0);
    },
    follow: function (ctx, t, P, V) {
      var N = NET[V.net], a = st(t, P, 0, 0.5, E.back), b = st(t, P, 0.12, 0.55, E.out5), t0 = 1.5, done = t > t0, col = netColor(N);
      box(ctx, 20, 30, 960 * b, 160, 80, V.net === 'tt' || V.net === 'x' ? '#111111' : '#FFFFFF', 0.97);
      var fc = on(V.net === 'tt' || V.net === 'x' ? '#111111' : '#FFFFFF');
      ctx.save(); clipRect(ctx, 20, 30, 960 * b, 160);
      badge(ctx, P, 104, 110, 58, N.c, N.mono, a);
      text(ctx, P.t1, 186, 92, P, 40, 800, fc, 'left', 400); text(ctx, P.t2, 186, 138, P, 26, 500, fc, 'left', 400, 0.6);
      var pr = seg(t, t0 - 0.05, t0 + 0.05) * (1 - seg(t, t0 + 0.05, t0 + 0.22)), k = 1 - 0.07 * pr;
      ctx.save(); ctx.translate(780, 110); ctx.scale(k, k);
      if (done) { rr(ctx, -150, -42, 300, 84, 42); ctx.lineWidth = 4; ctx.strokeStyle = fc; ctx.globalAlpha = 0.5; ctx.stroke(); ctx.globalAlpha = 1; icon(ctx, 'check', -100, 0, 40, fc); text(ctx, P.t4 || 'გამოწერილია', 18, 3, P, 28, 700, fc, 'center', 190); }
      else { box(ctx, -150, -42, 300, 84, 42, col, 1); icon(ctx, 'plus', -104, 0, 34, on(col)); text(ctx, P.t3 || 'გამოწერა', 18, 3, P, 30, 800, on(col), 'center', 190); }
      ctx.restore(); ctx.restore();
      if (b > 0.9) { pointer(ctx, t, 820, 140, t0); }
    },
    like: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.5, E.back), t0 = 1.1, k = E.back(seg(t, t0, t0 + 0.45)), ic = V.icon || 'thumb', col = V.icon === 'heart' ? '#FF2D55' : (V.icon === 'star' ? '#FFC400' : P.accent), i, burst = seg(t, t0, t0 + 0.6);
      ctx.save(); ctx.translate(150, 110); ctx.scale(a, a);
      ctx.beginPath(); ctx.arc(0, 0, 84, 0, TAU); fill(ctx, '#FFFFFF', 0.97);
      icon(ctx, ic, 0, 0, 96, '#C9C9C9', 1, 1 - seg(t, t0, t0 + 0.1));
      if (t > t0) { icon(ctx, ic, 0, 0, 96, col, 0.5 + 0.5 * k, 1, V.icon === 'heart' ? 0 : -0.25 * (1 - k)); }
      if (burst > 0 && burst < 1) { for (i = 0; i < 8; i++) { var an = i / 8 * TAU, r = 96 + 46 * E.out3(burst); ctx.beginPath(); ctx.arc(Math.cos(an) * r, Math.sin(an) * r, 7 * (1 - burst), 0, TAU); fill(ctx, col, 1 - burst); } }
      ctx.restore();
      var b = st(t, P, 0.2, 0.5);
      ctx.save(); shadow(ctx, 12, 0.45);
      if (V.count) {
        var from = parseInt(String(P.t2).replace(/\D/g, ''), 10) || 0, n = from + (t > t0 ? 1 : 0);
        text(ctx, P.t1, 262, 82, P, 40, 700, P.color, 'left', 700, b);
        ctx.save(); clipRect(ctx, 250, 108, 740, 78); if (t > t0 && k < 1) { text(ctx, String(from), 262, 146 - 70 * k, P, 58, 900, P.color, 'left', 0, b); } text(ctx, String(n), 262, 146 + (t > t0 ? 70 * (1 - Math.min(1, k)) : 0), P, 58, 900, t > t0 ? col : P.color, 'left', 0, b); ctx.restore();
      } else { text(ctx, P.t1, 262 - 30 * (1 - b), P.t2 ? 90 : 112, P, 54, 800, P.color, 'left', 700, b); text(ctx, P.t2, 262, 146, P, 30, 500, P.color, 'left', 700, 0.85 * b); }
      ctx.restore();
    },
    combo: function (ctx, t, P, V) {
      var list = V.set === 'social' ? ['heart', 'comment', 'share'] : (V.set === 'save' ? ['heart', 'save', 'send'] : ['thumb', 'plus', 'bell']), labels = [P.t1, P.t2, P.t3], i;
      for (i = 0; i < 3; i++) {
        var a = st(t, P, 0.12 * i, 0.5, E.back), t0 = 1.0 + 0.45 * i, k = E.back(seg(t, t0, t0 + 0.4)), onNow = t > t0, cx = 170 + 330 * i, col = i === 1 && V.set !== 'social' ? '#FF0000' : P.accent;
        ctx.save(); ctx.translate(cx, 92); ctx.scale(a * (onNow ? 0.85 + 0.15 * k : 1), a * (onNow ? 0.85 + 0.15 * k : 1));
        ctx.beginPath(); ctx.arc(0, 0, 70, 0, TAU); fill(ctx, onNow ? col : '#FFFFFF', 0.97);
        icon(ctx, list[i], 0, 0, 78, onNow ? on(col) : '#8A8A8A', 1, 1, list[i] === 'bell' && onNow ? 0.3 * Math.sin((t - t0) * 20) * (1 - seg(t, t0, t0 + 0.8)) : 0);
        ctx.restore();
        ctx.save(); shadow(ctx, 10, 0.5); text(ctx, labels[i], cx, 192, P, 28, 700, P.color, 'center', 300, a); ctx.restore();
      }
    },
    cta: function (ctx, t, P, V) {
      var a = st(t, P, 0, 0.5, E.back), b = st(t, P, 0.15, 0.55, E.out5), c = st(t, P, 0.32, 0.45), w = Math.min(900, Math.max(width(ctx, P.t1, P, 44, 800), width(ctx, P.t2, P, 26, 500)) + 200);
      var nud = Math.sin(Math.max(0, t - 1) * 5) * 8 * seg(t, 1, 1.2) * (1 - seg(t, P.dur - 0.9, P.dur - 0.5)), dark = V.tone === 'dark', bgc = dark ? P.bg : '#FFFFFF', fc = on(bgc);
      box(ctx, 40, 44, 132 + (w - 132) * b, 132, 30, bgc, 0.97 * Math.min(1, a * 2));
      ctx.save(); ctx.translate(106, 110); ctx.scale(a, a); box(ctx, -46, -46, 92, 92, 22, P.accent, 1);
      icon(ctx, V.icon, V.icon === 'share' ? nud * 0.5 : 0, V.icon === 'link' || V.icon === 'save' ? nud * 0.4 : 0, 64, on(P.accent), 1, 1, V.icon === 'bell' ? nud * 0.03 : 0); ctx.restore();
      ctx.save(); clipRect(ctx, 166, 44, Math.max(0, (w - 166) * b), 132);
      text(ctx, P.t1, 180, P.t2 ? 92 : 112, P, 44, 800, fc, 'left', 700, c); text(ctx, P.t2, 180, 140, P, 26, 500, fc, 'left', 700, 0.65 * c);
      ctx.restore();
    }
  };

  // ---------------------------------------------------------------- more timers
  var SEG = { '0': 'abcdef', '1': 'bc', '2': 'abged', '3': 'abgcd', '4': 'fgbc', '5': 'afgcd', '6': 'afgedc', '7': 'abc', '8': 'abcdefg', '9': 'abcdfg' };
  function seg7(ctx, ch, x, y, w, h, col, a) {
    var t = w * 0.17, v = h / 2 - t * 1.3, m = { a: [x + t, y, w - 2 * t, t], g: [x + t, y + h / 2 - t / 2, w - 2 * t, t], d: [x + t, y + h - t, w - 2 * t, t],
      f: [x, y + t * 0.8, t, v], b: [x + w - t, y + t * 0.8, t, v], e: [x, y + h / 2 + t * 0.5, t, v], c: [x + w - t, y + h / 2 + t * 0.5, t, v] }, k;
    for (k in m) { if (m.hasOwnProperty(k)) { rr(ctx, m[k][0], m[k][1], m[k][2], m[k][3], t / 2); fill(ctx, col, (SEG[ch] || '').indexOf(k) >= 0 ? a : a * 0.1); } }
  }
  TIMER.led = function (ctx, t, P) {
    var a = st(t, P, 0, 0.4), s = clock(P, t), n = s.length, cw = Math.min(92, 520 / Math.max(3, n)), x = 320 - (n * cw) / 2, i;
    box(ctx, 30, 26, 580, 168, 18, '#0A0A0A', 0.94 * a);
    ctx.save(); ctx.shadowColor = P.accent; ctx.shadowBlur = 16;
    for (i = 0; i < n; i++) {
      var ch = s.charAt(i);
      if (/\d/.test(ch)) { seg7(ctx, ch, x + cw * 0.14, 52, cw * 0.72, 116, P.accent, a); }
      else { var blink = Math.floor(t * 2) % 2 ? 0.35 : 1; ctx.beginPath(); ctx.arc(x + cw / 2, 88, 7, 0, TAU); fill(ctx, P.accent, a * blink); ctx.beginPath(); ctx.arc(x + cw / 2, 134, 7, 0, TAU); fill(ctx, P.accent, a * blink); }
      x += cw;
    }
    ctx.restore();
  };
  TIMER.dots = function (ctx, t, P) {
    var a = st(t, P, 0, 0.4), p = ran(P, t), q = (P.timer || {}).down ? 1 - p : p, n = 12, i;
    ctx.save(); shadow(ctx, 14, 0.45 * a); digits(ctx, clock(P, t), 320, 86, 116, P, P.color, 800, a); ctx.restore();
    for (i = 0; i < n; i++) { var onD = (i + 0.5) / n <= q + 1e-6; ctx.beginPath(); ctx.arc(320 - (n - 1) * 19 + i * 38, 178, onD ? 11 : 8, 0, TAU); fill(ctx, onD ? P.accent : P.color, (onD ? 1 : 0.3) * a); }
  };
  TIMER.gauge = function (ctx, t, P) {
    var a = st(t, P, 0, 0.45), p = ran(P, t), q = (P.timer || {}).down ? 1 - p : p;
    ctx.lineCap = 'round'; ctx.lineWidth = 22;
    ctx.beginPath(); ctx.arc(210, 230, 170, Math.PI, TAU); ctx.globalAlpha = 0.28 * a; ctx.strokeStyle = P.color; ctx.stroke();
    ctx.beginPath(); ctx.arc(210, 230, 170, Math.PI, Math.PI + Math.PI * clamp(q, 0.0001, 1)); ctx.globalAlpha = a; ctx.strokeStyle = P.accent; ctx.stroke(); ctx.globalAlpha = 1;
    ctx.save(); shadow(ctx, 12, 0.45 * a); var s = clock(P, t); digits(ctx, s, 210, 196, s.length > 4 ? 70 : 92, P, P.color, 800, a); ctx.restore();
    text(ctx, P.t1, 210, 258, P, 24, 600, P.color, 'center', 260, 0.75 * a);
  };
  TIMER.urgent = function (ctx, t, P) {
    var a = st(t, P, 0, 0.35), tm = P.timer || {}, total = Number(tm.total) || 0, left = tm.down ? total - Math.min(t, total) : total - Math.min(t, total), hot = left <= 5.0001 && left > 0;
    var sh = hot ? Math.sin(t * 60) * 5 * (1 - seg(sinceTick(P, t), 0, 0.3)) : 0, pulse = hot ? 1 + 0.08 * (1 - E.out3(seg(sinceTick(P, t), 0, 0.4))) : 1;
    if (hot) { box(ctx, 60, 30, 520, 160, 26, P.accent, 0.18 * a * (0.5 + 0.5 * Math.abs(Math.cos(Math.PI * t * 2)))); }
    ctx.save(); ctx.translate(320 + sh, 110); ctx.scale(pulse, pulse); shadow(ctx, 16, 0.5 * a);
    digits(ctx, clock(P, t), 0, 0, 140, P, hot || left <= 0 ? P.accent : P.color, 900, a); ctx.restore();
  };
  TIMER.split = function (ctx, t, P) {
    var a = st(t, P, 0, 0.4), b = st(t, P, 0.1, 0.4), tm = P.timer || {}, total = Number(tm.total) || 0, el = clamp(t, 0, total), v = tm.down ? Math.ceil(total - el - 1e-6) : Math.floor(el + 1e-6);
    var parts = [[pad(v / 60, 2), P.t1 || 'წთ'], [pad(v % 60, 2), P.t2 || 'წმ']], i;
    for (i = 0; i < 2; i++) {
      var x = 70 + i * 270, al = i ? b : a;
      box(ctx, x, 20, 230, 170, 22, i ? P.bg : P.accent, 0.96 * al);
      digits(ctx, parts[i][0], x + 115, 96, 104, P, on(i ? P.bg : P.accent), 800, al);
      text(ctx, parts[i][1], x + 115, 216, P, 24, 600, P.color, 'center', 220, 0.8 * al);
    }
    text(ctx, ':', 320, 96, P, 90, 800, P.color, 'center', 0, a * (Math.floor(t * 2) % 2 ? 0.3 : 1));
  };
  TIMER.analog = function (ctx, t, P) {
    var a = st(t, P, 0, 0.45), p = ran(P, t), i;
    ctx.beginPath(); ctx.arc(190, 200, 160, 0, TAU); fill(ctx, P.bg, 0.94 * a);
    box(ctx, 172, 14, 36, 34, 8, P.accent, a);
    for (i = 0; i < 12; i++) { var an = i / 12 * TAU; ctx.beginPath(); ctx.moveTo(190 + Math.sin(an) * 138, 200 - Math.cos(an) * 138); ctx.lineTo(190 + Math.sin(an) * 152, 200 - Math.cos(an) * 152); ctx.lineWidth = i % 3 ? 3 : 6; ctx.globalAlpha = (i % 3 ? 0.4 : 0.9) * a; ctx.strokeStyle = on(P.bg); ctx.stroke(); }
    ctx.globalAlpha = 1;
    ctx.save(); ctx.translate(190, 200); ctx.rotate(p * TAU); box(ctx, -4, -128, 8, 148, 4, P.accent, a); ctx.restore();
    ctx.beginPath(); ctx.arc(190, 200, 12, 0, TAU); fill(ctx, P.accent, a);
    var s = clock(P, t); digits(ctx, s, 190, 276, s.length > 4 ? 40 : 50, P, on(P.bg), 800, a);
  };
  TIMER.tagcard = function (ctx, t, P) {
    var a = st(t, P, 0, 0.45, E.out5), b = st(t, P, 0.14, 0.4);
    box(ctx, 110, 16, 420, 208, 20, P.bg, 0.95 * a);
    ctx.save(); rr(ctx, 110, 16, 420, 208, 20); ctx.clip(); ctx.fillStyle = P.accent; ctx.globalAlpha = a; ctx.fillRect(110, 16, 420, 62); ctx.globalAlpha = 1; ctx.restore();
    text(ctx, P.t1, 320, 49, P, 30, 800, on(P.accent), 'center', 380, b);
    digits(ctx, clock(P, t), 320, 152, 104, P, on(P.bg), 800, b);
  };
  TIMER.topbar = function (ctx, t, P) {
    var a = st(t, P, 0, 0.4), p = ran(P, t), q = (P.timer || {}).down ? 1 - p : p;
    box(ctx, 20, 70, 960, 18, 9, P.color, 0.25 * a); box(ctx, 20, 70, Math.max(18, 960 * q), 18, 9, P.accent, a);
    ctx.save(); shadow(ctx, 10, 0.5 * a);
    text(ctx, P.t1, 22, 34, P, 28, 700, P.color, 'left', 600, 0.9 * a);
    ctx.font = fnt(P, 40, 800); var w = digits(ctx, clock(P, t), 0, 0, 40, P, '#000', 800, 0, function () {});
    digits(ctx, clock(P, t), 980 - w / 2, 34, 40, P, P.color, 800, a); ctx.restore();
  };
  TIMER.pie = function (ctx, t, P) {
    var a = st(t, P, 0, 0.45, E.back), p = ran(P, t), q = (P.timer || {}).down ? 1 - p : p, k = 0.75 + 0.25 * a;
    ctx.save(); ctx.translate(190, 190); ctx.scale(k, k);
    ctx.beginPath(); ctx.arc(0, 0, 160, 0, TAU); fill(ctx, P.bg, 0.94 * a);
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, 146, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(q, 0.0001, 1)); ctx.closePath(); fill(ctx, P.accent, 0.9 * a);
    ctx.beginPath(); ctx.arc(0, 0, 96, 0, TAU); fill(ctx, P.bg, a);
    var s = clock(P, t); digits(ctx, s, 0, 4, s.length > 4 ? 50 : 72, P, on(P.bg), 800, a);
    ctx.restore();
  };

  // ---------------------------------------------------------------- more lower thirds and social layouts
  LT.rules = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.55, E.out5), b = st(t, P, 0.18, 0.5), c = st(t, P, 0.3, 0.5), w = Math.min(880, Math.max(width(ctx, P.t1, P, 56, 800), width(ctx, P.t2, P, 28, 500))) + 20, ctr = V.center, x = ctr ? 500 - w / 2 : 44;
    box(ctx, ctr ? 500 - w * a / 2 : x, 36, w * a, 4, 2, P.accent, 1); box(ctx, ctr ? 500 - w * a / 2 : x + w * (1 - a), 184, w * a, 4, 2, P.accent, 1);
    ctx.save(); shadow(ctx, 12, 0.45);
    text(ctx, P.t1, ctr ? 500 : x + 10, 90, P, 56, 800, P.color, ctr ? 'center' : 'left', 880, b);
    text(ctx, P.t2, ctr ? 500 : x + 10, 146 + 10 * (1 - c), P, 28, 500, P.color, ctr ? 'center' : 'left', 880, 0.85 * c);
    ctx.restore();
  };
  LT.live = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.45, E.back), b = st(t, P, 0.16, 0.55, E.out5), c = st(t, P, 0.3, 0.45), lw = Math.min(260, width(ctx, P.t3 || 'LIVE', P, 30, 900) + 76), w = Math.min(660, width(ctx, P.t1, P, 44, 800) + 60);
    var col = V.brand ? P.accent : '#E5202B';
    ctx.save(); ctx.translate(40 + lw / 2, 84); ctx.scale(a, a); box(ctx, -lw / 2, -38, lw, 76, 10, col, 1);
    ctx.beginPath(); ctx.arc(-lw / 2 + 32, 0, 10, 0, TAU); fill(ctx, '#FFFFFF', 0.4 + 0.6 * Math.abs(Math.cos(Math.PI * t)));
    text(ctx, P.t3 || 'LIVE', 14, 2, P, 30, 900, '#FFFFFF', 'center', lw - 70); ctx.restore();
    box(ctx, 40 + lw + 10, 46, w * b, 76, 10, P.bg, 0.95);
    ctx.save(); clipRect(ctx, 40 + lw + 10, 46, w * b, 76); text(ctx, P.t1, 40 + lw + 38, 86, P, 44, 800, on(P.bg), 'left', 640, c); ctx.restore();
    ctx.save(); shadow(ctx, 10, 0.45); text(ctx, P.t2, 44, 158, P, 28, 500, P.color, 'left', 900, 0.9 * c); ctx.restore();
  };
  SOC.tile = function (ctx, t, P, V) {
    var N = NET[V.net], a = st(t, P, 0, 0.45, E.back), b = st(t, P, 0.16, 0.55, E.out5), c = st(t, P, 0.3, 0.45), col = netColor(N), w = Math.min(760, width(ctx, P.t1, P, 58, 800));
    ctx.save(); ctx.translate(110, 110); ctx.scale(a, a);
    if (N.c.length > 1) { var g = ctx.createLinearGradient(-70, 70, 70, -70); for (var i = 0; i < N.c.length; i++) { g.addColorStop(i / (N.c.length - 1), N.c[i]); } rr(ctx, -70, -70, 140, 140, 30); ctx.fillStyle = g; ctx.fill(); }
    else { box(ctx, -70, -70, 140, 140, 30, N.c[0], 1); }
    if (P.logo) { ctx.save(); rr(ctx, -56, -56, 112, 112, 22); ctx.clip(); try { ctx.drawImage(P.logo, -56, -56, 112, 112); } catch (e) {} ctx.restore(); }
    else { text(ctx, N.mono, 0, 4, P, N.mono.length > 1 ? 58 : 80, 900, on(N.c[Math.min(1, N.c.length - 1)]), 'center'); }
    ctx.restore();
    ctx.save(); shadow(ctx, 12, 0.5); clipRect(ctx, 196, 0, 804, 220);
    text(ctx, P.t2, 214, 62, P, 26, 600, P.color, 'left', 760, 0.8 * c);
    text(ctx, P.t1, 214 - 60 * (1 - b), 116, P, 58, 800, P.color, 'left', 760, b); ctx.restore();
    box(ctx, 214, 160, w * b, 8, 4, col === '#111111' || col === '#000000' || col === '#101010' ? P.accent : col, 1);
  };
  SOC.multi = function (ctx, t, P, V) {
    var nets = V.nets, i, n = nets.length;
    for (i = 0; i < n; i++) {
      var N = NET[nets[i]], a = st(t, P, 0.1 * i, 0.45, E.back), b = st(t, P, 0.1 * i + 0.14, 0.5), x = 20 + i * (960 / n), w = 960 / n - 16;
      box(ctx, x, 60, w * Math.min(1, a * 1.2), 100, 50, '#111111', 0.95 * Math.min(1, a * 2));
      badge(ctx, P.logo && i === 0 ? P : { logo: null, font: P.font, fs: P.fs, ts: P.ts }, x + 50, 110, 38, N.c, N.mono, a);
      ctx.save(); clipRect(ctx, x + 92, 60, Math.max(0, w - 104), 100); text(ctx, P.t1, x + 100, 112, P, 32, 800, '#FFFFFF', 'left', w - 124, b); ctx.restore();
    }
  };
  /** Draws a design through a whole-piece entrance (pop, drop…): the piece is painted finished, then moved as one. */
  var SCRATCH = null;
  function entered(ctx, d, fn, t, P, V) {
    var m = ctx.getTransform ? ctx.getTransform() : null;
    if (!m || typeof document === 'undefined') { fn(ctx, t, P, V); return; }
    if (!SCRATCH) { SCRATCH = document.createElement('canvas'); }
    if (SCRATCH.width !== ctx.canvas.width || SCRATCH.height !== ctx.canvas.height) { SCRATCH.width = ctx.canvas.width; SCRATCH.height = ctx.canvas.height; }
    var sx = SCRATCH.getContext('2d'), Q = Object.create(P), kind = V.enter;
    Q.noIn = true; Q.noOut = true;
    sx.setTransform(1, 0, 0, 1, 0, 0); sx.clearRect(0, 0, SCRATCH.width, SCRATCH.height); sx.setTransform(m.a, m.b, m.c, m.d, m.e, m.f);
    fn(sx, t, Q, V);
    var lin = st(t, P, 0, 0.55, E.lin), a = E.out3(lin), cx = d.w / 2, cy = d.h / 2, s1 = 1, s2 = 1, dx = 0, dy = 0, al = Math.min(1, lin * 2.5), rot = 0;
    if (kind === 'pop') { s1 = s2 = 0.5 + 0.5 * E.back(lin); }
    else if (kind === 'drop') { dy = -(1 - E.bounce(lin)) * d.h * 1.1; al = Math.min(1, lin * 6); }
    else if (kind === 'right') { dx = (1 - E.out5(lin)) * d.w * 0.5; }
    else if (kind === 'rise') { dy = (1 - a) * d.h * 0.45; }
    else if (kind === 'zoom') { s1 = s2 = 1.6 - 0.6 * E.out5(lin); }
    else if (kind === 'unfold') { s2 = Math.max(0.001, E.out5(lin)); al = Math.min(1, lin * 8); }
    else if (kind === 'swing') { rot = (1 - E.back(lin)) * -0.5; cx = 0; cy = d.h; }
    ctx.save(); ctx.globalAlpha = clamp(al, 0, 1);
    ctx.translate(cx + dx, cy + dy); ctx.rotate(rot); ctx.scale(s1, s2); ctx.translate(-cx, -cy);
    ctx.scale(1 / m.a, 1 / m.d); ctx.drawImage(SCRATCH, 0, 0);
    ctx.restore();
  }

  // ---------------------------------------------------------------- numbers that count up
  function num(str) {
    var m = /^([^\d]*)([\d\s.,]*\d)(.*)$/.exec(String(str || ''));
    if (!m) { return null; }
    var raw = m[2].replace(/\s/g, ''), dec = 0, dm = /\.(\d{1,3})$/.exec(raw) || /,(\d{1,2})$/.exec(raw);
    if (dm) { dec = dm[1].length; raw = raw.substring(0, raw.length - dec - 1).replace(/[.,]/g, '') + '.' + dm[1]; } else { raw = raw.replace(/[.,]/g, ''); }
    return { pre: m[1], v: parseFloat(raw) || 0, dec: dec, post: m[3], sep: /\d\s\d/.test(m[2]) ? ' ' : (/\d,\d{3}/.test(m[2]) ? ',' : '') };
  }
  function shown(n, k) { var p = (n.v * k).toFixed(n.dec).split('.'); if (n.sep) { p[0] = p[0].replace(/\B(?=(\d{3})+(?!\d))/g, n.sep); } return n.pre + p.join('.') + n.post; }
  /** The text with its number counting up from zero between t0 and t1. */
  function counted(P, t, str, t0, t1) { var n = /\d:\d/.test(String(str)) ? null : num(str); return n ? shown(n, P.noIn ? 1 : E.out3(seg(t, t0, t1))) : String(str || ''); }
  function pair(str) { var p = String(str || '').split('|'); return [p[0].replace(/^\s+|\s+$/g, ''), (p[1] || '').replace(/^\s+|\s+$/g, '')]; }

  var X = {};
  // 700 × 240: a big number, its unit and a caption
  X.stat = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5, E.out5), b = st(t, P, 0.12, 0.5), c = st(t, P, 0.3, 0.5), val = counted(P, t, P.t1, 0.1, 1.4), w = Math.min(430, width(ctx, val, P, 112, 900));
    var col = P.color, ucol = P.accent, cap = P.color;
    if (V.style === 'card') { box(ctx, 20, 16, 660 * a, 208, 22, P.bg, 0.95); box(ctx, 20, 16, 660 * a, 10, 5, P.accent, 1); col = cap = on(P.bg); }
    else if (V.style === 'split') { box(ctx, 20, 24, (w + 64) * a, 150, 16, P.accent, 1); col = on(P.accent); ucol = P.color; }
    else if (V.style === 'line') { box(ctx, 24, 30, 8, 180 * a, 4, P.accent, 1); }
    ctx.save(); if (!V.style || V.style === 'line') { shadow(ctx, 14, 0.5); } clipRect(ctx, 0, 0, 700, 240);
    var x0 = V.style === 'line' ? 58 : 50;
    text(ctx, val, x0, 100, P, 112, 900, col, 'left', 430, b);
    ctx.restore(); ctx.save(); if (V.style !== 'card') { shadow(ctx, 12, 0.5); }
    text(ctx, P.t2, x0 + w + (V.style === 'split' ? 40 : 18), 120, P, 46, 800, ucol, 'left', 620 - w - x0, b);
    text(ctx, P.t3, x0 + 2, 196 + 10 * (1 - c), P, 30, 600, cap, 'left', 620, 0.82 * c);
    ctx.restore();
  };
  // 420 × 420: a dial whose needle sweeps to the value
  X.dial = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5, E.back), n = num(P.t1) || { v: 0, dec: 0, pre: '', post: '', sep: '' }, max = V.max || Math.max(10, Math.pow(10, Math.floor(Math.log(Math.max(1, n.v)) / Math.LN10)) * Math.ceil(n.v / Math.pow(10, Math.floor(Math.log(Math.max(1, n.v)) / Math.LN10)) * 1.15));
    var k = P.noIn ? 1 : E.out5(seg(t, 0.35, 2.0)), over = P.noIn ? 0 : Math.sin(seg(t, 2.0, 2.5) * Math.PI) * 0.012, fr = clamp(n.v * k / max + over, 0, 1), A0 = Math.PI * 0.75, SW = Math.PI * 1.5, i;
    ctx.save(); ctx.translate(210, 210); ctx.scale(0.7 + 0.3 * a, 0.7 + 0.3 * a);
    ctx.beginPath(); ctx.arc(0, 0, 196, 0, TAU); fill(ctx, P.bg, 0.95 * a);
    ctx.lineCap = 'butt'; ctx.lineWidth = 16;
    ctx.beginPath(); ctx.arc(0, 0, 166, A0, A0 + SW); ctx.globalAlpha = 0.2 * a; ctx.strokeStyle = on(P.bg); ctx.stroke();
    if (V.red) { ctx.beginPath(); ctx.arc(0, 0, 166, A0 + SW * 0.82, A0 + SW); ctx.globalAlpha = 0.9 * a; ctx.strokeStyle = '#E5202B'; ctx.stroke(); }
    ctx.beginPath(); ctx.arc(0, 0, 166, A0, A0 + SW * Math.max(0.001, fr)); ctx.globalAlpha = a; ctx.strokeStyle = P.accent; ctx.stroke(); ctx.globalAlpha = 1;
    for (i = 0; i <= 10; i++) {
      var an = A0 + SW * i / 10, c1 = Math.cos(an), s1 = Math.sin(an);
      ctx.beginPath(); ctx.moveTo(c1 * 140, s1 * 140); ctx.lineTo(c1 * 152, s1 * 152); ctx.lineWidth = 4; ctx.globalAlpha = 0.8 * a; ctx.strokeStyle = on(P.bg); ctx.stroke(); ctx.globalAlpha = 1;
      if (i % 2 === 0) { text(ctx, String(Math.round(max * i / 10 / (V.div || 1))), c1 * 116, s1 * 116, P, 20, 600, on(P.bg), 'center', 0, 0.75 * a); }
    }
    ctx.save(); ctx.rotate(A0 + SW * fr); ctx.beginPath(); ctx.moveTo(-18, -6); ctx.lineTo(150, -2); ctx.lineTo(150, 2); ctx.lineTo(-18, 6); ctx.closePath(); fill(ctx, V.red ? '#E5202B' : P.accent, a); ctx.restore();
    ctx.beginPath(); ctx.arc(0, 0, 16, 0, TAU); fill(ctx, on(P.bg), a);
    text(ctx, shown(n, k), 0, 86, P, 56, 900, on(P.bg), 'center', 190, a); text(ctx, P.t2, 0, 132, P, 22, 600, on(P.bg), 'center', 170, 0.7 * a);
    ctx.restore();
  };
  // 760 × 220: a number plate
  X.plate = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5, E.back), bgc = V.tone === 'dark' ? '#111111' : (V.tone === 'yellow' ? '#FFD400' : '#FFFFFF'), fc = on(bgc);
    ctx.save(); ctx.translate(380, 110); ctx.scale(0.6 + 0.4 * a, 0.6 + 0.4 * a); ctx.translate(-380, -110);
    ctx.save(); shadow(ctx, 18, 0.5 * a); box(ctx, 20, 24, 720, 172, 20, bgc, a); ctx.restore();
    rr(ctx, 30, 34, 700, 152, 14); ctx.lineWidth = 5; ctx.globalAlpha = a; ctx.strokeStyle = fc; ctx.stroke(); ctx.globalAlpha = 1;
    if (!V.plain) { ctx.save(); rr(ctx, 30, 34, 700, 152, 14); ctx.clip(); ctx.globalAlpha = a; ctx.fillStyle = V.strip || '#1B3FA6'; ctx.fillRect(30, 34, 84, 152); ctx.globalAlpha = 1; ctx.restore(); text(ctx, P.t2, 72, 150, P, 28, 800, '#FFFFFF', 'center', 70, a); }
    text(ctx, P.t1, V.plain ? 380 : 420, 114, P, 96, 900, fc, 'center', V.plain ? 660 : 580, a);
    ctx.restore();
  };
  // 760 × 330: a card with a title and three "name | value" rows
  X.specs = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.55, E.out5), rows = [P.t2, P.t3, P.t4], i;
    box(ctx, 20, 16, 720, 298 * a, 22, P.bg, 0.95);
    ctx.save(); clipRect(ctx, 20, 16, 720, 298 * a);
    box(ctx, 20, 16, 720, 78, 0, P.accent, 1); text(ctx, P.t1, 52, 57, P, 40, 800, on(P.accent), 'left', 660, st(t, P, 0.15, 0.4));
    for (i = 0; i < 3; i++) {
      var r = pair(rows[i]), b = st(t, P, 0.3 + 0.12 * i, 0.45), y = 132 + i * 66;
      text(ctx, r[0], 52 - 30 * (1 - b), y, P, 28, 500, on(P.bg), 'left', 320, 0.7 * b); text(ctx, r[1], 708 + 30 * (1 - b), y, P, 32, 800, on(P.bg), 'right', 340, b);
      if (i < 2) { box(ctx, 52, y + 32, 656 * b, 2, 1, on(P.bg), 0.14); }
    }
    ctx.restore();
  };
  // 1000 × 260: one against another
  X.versus = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5, E.out5), b = st(t, P, 0.35, 0.4, E.back), sh = Math.sin(t * 50) * 6 * (1 - seg(t, 0.55, 0.95)) * seg(t, 0.5, 0.56);
    ctx.save(); ctx.transform(1, 0, -0.14, 1, 20, 0);
    box(ctx, 20 - 480 * (1 - a), 50, 440, 160, 10, P.accent, 1); box(ctx, 540 + 480 * (1 - a), 50, 440, 160, 10, P.bg, 0.96);
    ctx.restore();
    text(ctx, P.t1, 230 - 480 * (1 - a), 118, P, 50, 900, on(P.accent), 'center', 380); text(ctx, P.t3, 230 - 480 * (1 - a), 172, P, 24, 600, on(P.accent), 'center', 380, 0.8);
    text(ctx, P.t2, 770 + 480 * (1 - a), 118, P, 50, 900, on(P.bg), 'center', 380); text(ctx, P.t4, 770 + 480 * (1 - a), 172, P, 24, 600, on(P.bg), 'center', 380, 0.8);
    ctx.save(); ctx.translate(500 + sh, 130); ctx.scale(b, b); ctx.beginPath(); ctx.arc(0, 0, 70, 0, TAU); fill(ctx, '#FFFFFF', 1); text(ctx, 'VS', 0, 4, P, 60, 900, '#111111', 'center'); ctx.restore();
  };
  // 640 × 240: a battery filling up
  X.battery = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5), n = num(P.t1) || { v: 0, dec: 0, pre: '', post: '', sep: '' }, k = P.noIn ? 1 : E.out3(seg(t, 0.3, 1.8)), fr = clamp(n.v * k / 100, 0, 1), col = V.green ? '#2ECC71' : P.accent;
    rr(ctx, 30, 40, 300, 150, 26); ctx.lineWidth = 10; ctx.globalAlpha = a; ctx.strokeStyle = P.color; ctx.stroke(); ctx.globalAlpha = 1;
    box(ctx, 338, 86, 20, 58, 8, P.color, a); box(ctx, 48, 58, Math.max(10, 264 * fr), 114, 14, col, a);
    ctx.save(); shadow(ctx, 12, 0.5); text(ctx, shown(n, k), 390, 96, P, 84, 900, P.color, 'left', 230, a); text(ctx, P.t2, 392, 166, P, 28, 600, P.color, 'left', 230, 0.8 * a); ctx.restore();
  };
  // 1000 × 200: a chequered band
  X.flag = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.55, E.out5), b = st(t, P, 0.25, 0.45, E.back), i, j, s = 28, w = Math.min(760, width(ctx, P.t1, P, 56, 900) + 90);
    ctx.save(); clipRect(ctx, 0, 0, 1000 * a, 200);
    for (j = 0; j < 2; j++) { for (i = 0; i < 36; i++) { ctx.fillStyle = (i + j) % 2 ? '#FFFFFF' : '#111111'; ctx.fillRect(i * s - ((t * 40) % (2 * s)), 16 + j * s, s, s); ctx.fillRect(i * s + ((t * 40) % (2 * s)) - 2 * s, 128 + j * s, s, s); } }
    ctx.restore();
    ctx.save(); ctx.translate(500, 100); ctx.scale(b, b); ctx.transform(1, 0, -0.16, 1, 0, 0); box(ctx, -w / 2, -42, w, 84, 8, P.accent, 1); ctx.restore();
    text(ctx, P.t1, 500, 103, P, 56, 900, on(P.accent), 'center', 700, b);
  };
  // 380 × 380: a round badge with one big word
  X.medal = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.55, E.back), k = 0.5 + 0.5 * a, i;
    ctx.save(); ctx.translate(190, 190); ctx.scale(k, k);
    if (V.burst) { ctx.save(); ctx.rotate(t * 0.35); ctx.beginPath(); for (i = 0; i < 32; i++) { var r = i % 2 ? 150 : 176, an = i / 32 * TAU; ctx.lineTo(Math.cos(an) * r, Math.sin(an) * r); } ctx.closePath(); fill(ctx, P.accent, a); ctx.restore(); }
    else { ctx.beginPath(); ctx.arc(0, 0, 168, 0, TAU); fill(ctx, P.accent, a); ctx.beginPath(); ctx.arc(0, 0, 146, 0, TAU); ctx.lineWidth = 5; ctx.globalAlpha = 0.55 * a; ctx.strokeStyle = on(P.accent); ctx.stroke(); ctx.globalAlpha = 1; }
    ctx.rotate(V.tilt ? -0.14 : 0);
    text(ctx, P.t2, 0, -74, P, 28, 700, on(P.accent), 'center', 220, 0.9 * a); text(ctx, P.t1, 0, 4, P, String(P.t1).length > 3 ? 82 : 128, 900, on(P.accent), 'center', 250, a); text(ctx, P.t3, 0, 82, P, 26, 600, on(P.accent), 'center', 210, 0.9 * a);
    ctx.restore();
  };
  // 380 × 380: a ring that fills to a share
  X.pct = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5, E.back), n = num(P.t1) || { v: 0, dec: 0, pre: '', post: '', sep: '' }, k = P.noIn ? 1 : E.out3(seg(t, 0.3, 1.7)), fr = clamp(n.v * k / 100, 0, 1);
    ctx.save(); ctx.translate(190, 190); ctx.scale(0.7 + 0.3 * a, 0.7 + 0.3 * a);
    if (!V.open) { ctx.beginPath(); ctx.arc(0, 0, 170, 0, TAU); fill(ctx, P.bg, 0.94 * a); }
    var fc = V.open ? P.color : on(P.bg);
    ctx.lineCap = 'round'; ctx.lineWidth = 24; ctx.beginPath(); ctx.arc(0, 0, 136, 0, TAU); ctx.globalAlpha = 0.2 * a; ctx.strokeStyle = fc; ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0, 136, -Math.PI / 2, -Math.PI / 2 + TAU * Math.max(0.001, fr)); ctx.globalAlpha = a; ctx.strokeStyle = P.accent; ctx.stroke(); ctx.globalAlpha = 1;
    ctx.save(); if (V.open) { shadow(ctx, 12, 0.5); } text(ctx, shown(n, k), 0, -4, P, 78, 900, fc, 'center', 220, a); text(ctx, P.t2, 0, 58, P, 24, 600, fc, 'center', 200, 0.75 * a); ctx.restore();
    ctx.restore();
  };
  // 900 × 300: two bars growing, "name | value" each
  X.bars = function (ctx, t, P, V) {
    var rows = [pair(P.t1), pair(P.t2)], v = [(num(rows[0][1]) || { v: 0 }).v, (num(rows[1][1]) || { v: 0 }).v], max = Math.max(1, v[0], v[1]), i;
    for (i = 0; i < 2; i++) {
      var a = st(t, P, 0.15 * i, 0.5), g = P.noIn ? 1 : E.out5(seg(t, 0.25 + 0.15 * i, 1.5 + 0.15 * i)), y = 40 + i * 130, w = 620 * v[i] / max * g;
      ctx.save(); shadow(ctx, 10, 0.5); text(ctx, rows[i][0], 30, y + 18, P, 30, 700, P.color, 'left', 600, a); ctx.restore();
      box(ctx, 30, y + 46, 620, 44, 22, P.color, 0.18 * a); box(ctx, 30, y + 46, Math.max(44, w), 44, 22, i ? P.color : P.accent, a);
      ctx.save(); shadow(ctx, 10, 0.5); text(ctx, counted(P, t, rows[i][1], 0.25 + 0.15 * i, 1.5 + 0.15 * i), 30 + Math.max(44, w) + 20, y + 70, P, 40, 900, P.color, 'left', 220, a); ctx.restore();
    }
  };
  // 700 × 200: five stars filling to a rating
  X.stars = function (ctx, t, P, V) {
    var n = num(P.t1) || { v: 5, dec: 0, pre: '', post: '', sep: '' }, i, b = st(t, P, 0.5, 0.5);
    for (i = 0; i < 5; i++) {
      var a = st(t, P, 0.1 * i, 0.4, E.back), f = clamp(n.v - i, 0, 1) * (P.noIn ? 1 : seg(t, 0.4 + 0.15 * i, 0.7 + 0.15 * i)), cx = 70 + i * 96;
      icon(ctx, 'star', cx, 80, 92, '#FFFFFF', a, 0.3);
      if (f > 0) { ctx.save(); clipRect(ctx, cx - 46, 30, 92 * f, 100); icon(ctx, 'star', cx, 80, 92, V.brand ? P.accent : '#FFC400', a, 1); ctx.restore(); }
    }
    ctx.save(); shadow(ctx, 12, 0.5); text(ctx, counted(P, t, P.t1, 0.4, 1.3), 540, 82, P, 84, 900, P.color, 'left', 150, b); text(ctx, P.t2, 28, 166, P, 28, 600, P.color, 'left', 640, 0.85 * b); ctx.restore();
  };
  // 800 × 180: step dots, "2/5"
  X.steps = function (ctx, t, P, V) {
    var m = /(\d+)\s*\/\s*(\d+)/.exec(String(P.t1 || '')) || [0, 1, 5], cur = Number(m[1]), tot = Math.max(2, Math.min(10, Number(m[2]))), i, gap = Math.min(110, 700 / tot), x0 = 400 - gap * (tot - 1) / 2;
    box(ctx, x0, 66, gap * (tot - 1) * st(t, P, 0, 0.6), 8, 4, P.color, 0.3);
    box(ctx, x0, 66, gap * Math.max(0, cur - 1) * st(t, P, 0.3, 0.8), 8, 4, P.accent, 1);
    for (i = 0; i < tot; i++) {
      var a = st(t, P, 0.07 * i, 0.4, E.back), done = i < cur, now = i === cur - 1;
      ctx.save(); ctx.translate(x0 + gap * i, 70); ctx.scale(a * (now ? 1.25 + 0.06 * Math.sin(t * 5) : 1), a * (now ? 1.25 + 0.06 * Math.sin(t * 5) : 1));
      ctx.beginPath(); ctx.arc(0, 0, 26, 0, TAU); fill(ctx, done ? P.accent : P.bg, 1); text(ctx, String(i + 1), 0, 2, P, 26, 800, on(done ? P.accent : P.bg), 'center'); ctx.restore();
    }
    ctx.save(); shadow(ctx, 10, 0.5); text(ctx, P.t2, 400, 146, P, 30, 700, P.color, 'center', 760, st(t, P, 0.4, 0.5)); ctx.restore();
  };
  // 760 × 240: an old price struck out, the new one arriving
  X.price = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.45), s = P.noIn ? 1 : E.out3(seg(t, 0.7, 1.0)), b = st(t, P, 1.0, 0.45, E.back), w = Math.min(330, width(ctx, P.t1, P, 60, 700));
    ctx.save(); shadow(ctx, 12, 0.5); text(ctx, P.t3, 40, 46, P, 28, 600, P.color, 'left', 680, 0.85 * a);
    text(ctx, P.t1, 40, 140, P, 60, 700, P.color, 'left', 330, 0.6 * a); ctx.restore();
    box(ctx, 34, 136, (w + 12) * s, 7, 3, '#E5202B', a);
    ctx.save(); ctx.translate(560, 138); ctx.scale(b, b); ctx.rotate(-0.05); box(ctx, -170, -62, 340, 124, 18, P.accent, 1); text(ctx, P.t2, 0, 4, P, 76, 900, on(P.accent), 'center', 300); ctx.restore();
  };
  // ---------------------------------------------------------------- titles and stickers
  X.ribbon = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.55, E.out5), b = st(t, P, 0.2, 0.45), w = Math.min(740, width(ctx, P.t1, P, 54, 900) + 110) * a, x = 450 - w / 2, dk = mix(P.accent, '#000000', 0.38);
    function tail(sx, dir) { ctx.beginPath(); ctx.moveTo(sx, 74); ctx.lineTo(sx + dir * 70, 74); ctx.lineTo(sx + dir * 46, 114); ctx.lineTo(sx + dir * 70, 154); ctx.lineTo(sx, 154); ctx.closePath(); fill(ctx, dk, a); }
    if (a > 0.3) { tail(x + 8, -1); tail(x + w - 8, 1); }
    box(ctx, x, 50, w, 100, 6, P.accent, 1);
    ctx.save(); clipRect(ctx, x, 50, w, 100); text(ctx, P.t1, 450, 102, P, 54, 900, on(P.accent), 'center', 640, b); ctx.restore();
    ctx.save(); shadow(ctx, 10, 0.5); text(ctx, P.t2, 450, 182, P, 26, 600, P.color, 'center', 800, 0.9 * b); ctx.restore();
  };
  X.chapter = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.6, E.out5), b = st(t, P, 0.2, 0.5), c = st(t, P, 0.35, 0.5), w = width(ctx, P.t1, P, 170, 900);
    ctx.save(); setFont(ctx, P, 170, 900); ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.lineWidth = 5; ctx.lineJoin = 'round'; ctx.globalAlpha = a; ctx.strokeStyle = P.accent;
    if (V.solid) { ctx.fillStyle = P.accent; ctx.fillText(say(P, P.t1), 30, 130 + 30 * (1 - a)); } else { ctx.strokeText(say(P, P.t1), 30, 130 + 30 * (1 - a)); }
    ctx.restore(); ctx.globalAlpha = 1;
    box(ctx, 60 + w, 56, 5, 148 * b, 2, P.color, 0.8);
    ctx.save(); shadow(ctx, 12, 0.5); text(ctx, P.t3, 90 + w, 84, P, 26, 600, P.accent, 'left', 760 - w, c); text(ctx, P.t2, 90 + w - 30 * (1 - c), 146, P, 56, 800, P.color, 'left', 760 - w, c); ctx.restore();
  };
  X.warn = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5, E.out5), b = st(t, P, 0.2, 0.4), i, col = V.brand ? P.accent : '#FFD400';
    function stripes(y, dir) { ctx.save(); clipRect(ctx, 0, y, 1000 * a, 26); ctx.fillStyle = col; ctx.fillRect(0, y, 1000, 26); ctx.fillStyle = '#111111'; for (i = -2; i < 40; i++) { var x = i * 52 + dir * ((t * 50) % 52); ctx.beginPath(); ctx.moveTo(x, y + 26); ctx.lineTo(x + 26, y + 26); ctx.lineTo(x + 52, y); ctx.lineTo(x + 26, y); ctx.closePath(); ctx.fill(); } ctx.restore(); }
    box(ctx, 0, 26, 1000 * a, 108, 0, '#111111', 0.96); stripes(0, 1); stripes(134, -1);
    icon(ctx, 'bell', 64, 80, 54, col, b); text(ctx, P.t1, 120, 68, P, 42, 900, '#FFFFFF', 'left', 840, b); text(ctx, P.t2, 120, 110, P, 22, 500, '#FFFFFF', 'left', 840, 0.75 * b);
  };
  X.stamp = function (ctx, t, P, V) {
    var k = P.noIn ? 1 : seg(t, 0, 0.28), o = P.noOut ? 0 : seg(t, P.dur - 0.35, P.dur - 0.05), s = 2.6 - 1.6 * E.out3(k), al = Math.min(1, k * 2) * (1 - o), col = V.red ? '#E5202B' : P.accent, w = Math.min(430, width(ctx, P.t1, P, 62, 900) + 70);
    ctx.save(); ctx.translate(260, 150); ctx.rotate(-0.16); ctx.scale(s, s); ctx.globalAlpha = al;
    rr(ctx, -w / 2, -76, w, 152, 16); ctx.lineWidth = 9; ctx.strokeStyle = col; ctx.stroke(); rr(ctx, -w / 2 + 14, -62, w - 28, 124, 8); ctx.lineWidth = 3; ctx.stroke(); ctx.globalAlpha = 1;
    text(ctx, P.t1, 0, -6, P, 62, 900, col, 'center', w - 60, al); text(ctx, P.t2, 0, 40, P, 20, 700, col, 'center', w - 60, al);
    ctx.restore();
  };
  X.bigtitle = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.7, E.out5), b = st(t, P, 0.25, 0.6), c = st(t, P, 0.45, 0.5);
    box(ctx, 500 - 440 * a, 36, 880 * a, 4, 2, P.accent, 1); box(ctx, 500 - 440 * a, 262, 880 * a, 4, 2, P.accent, 1);
    ctx.save(); shadow(ctx, 18, 0.55); clipRect(ctx, 0, 44, 1000, 214);
    if ('letterSpacing' in ctx) { /* the spread is drawn by size instead, so every engine shows the same */ }
    text(ctx, P.t1, 500, 128 + 60 * (1 - b), P, 96 * (V.wide ? 0.92 + 0.08 * seg(t, 0, P.dur) : 1), 900, P.color, 'center', 900, b);
    text(ctx, P.t2, 500, 216, P, 32, 500, P.color, 'center', 860, 0.85 * c);
    ctx.restore();
  };
  X.datecard = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5, E.back), b = st(t, P, 0.2, 0.5), c = st(t, P, 0.32, 0.5);
    ctx.save(); ctx.translate(110, 110); ctx.scale(a, a); ctx.save(); shadow(ctx, 14, 0.45); box(ctx, -86, -92, 172, 184, 18, '#FFFFFF', 1); ctx.restore();
    ctx.save(); rr(ctx, -86, -92, 172, 184, 18); ctx.clip(); ctx.fillStyle = P.accent; ctx.fillRect(-86, -92, 172, 54); ctx.restore();
    text(ctx, P.t2, 0, -64, P, 26, 800, on(P.accent), 'center', 150); text(ctx, P.t1, 0, 30, P, 100, 900, '#111111', 'center', 150); ctx.restore();
    ctx.save(); shadow(ctx, 12, 0.5); clipRect(ctx, 210, 0, 600, 220); text(ctx, P.t3, 228 - 40 * (1 - b), 86, P, 50, 800, P.color, 'left', 520, b); text(ctx, P.t4, 228 - 40 * (1 - c), 142, P, 28, 500, P.color, 'left', 520, 0.85 * c); ctx.restore();
  };
  // ---------------------------------------------------------------- pointers
  X.callout = function (ctx, t, P, V) {
    var d = V.dir || 'tr', fx = d.charAt(1) === 'r' ? 1 : -1, fy = d.charAt(0) === 't' ? -1 : 1, a = P.noIn ? 1 : E.out3(seg(t, 0, 0.3)), l1 = P.noIn ? 1 : E.out3(seg(t, 0.2, 0.55)), l2 = P.noIn ? 1 : E.out3(seg(t, 0.5, 0.8)), b = st(t, P, 0.7, 0.4), o = P.noOut ? 1 : 1 - seg(t, P.dur - 0.45, P.dur - 0.05);
    var x0 = fx > 0 ? 60 : 740, y0 = fy < 0 ? 340 : 60, x1 = x0 + fx * 150, y1 = y0 + fy * 150, w = Math.min(430, Math.max(width(ctx, P.t1, P, 36, 800), width(ctx, P.t2, P, 22, 500)) + 50), x2 = x1 + fx * 60;
    ctx.globalAlpha = o; ctx.beginPath(); ctx.arc(x0, y0, 26 + 10 * Math.sin(t * 4), 0, TAU); fill(ctx, P.accent, 0.3 * a * o); ctx.beginPath(); ctx.arc(x0, y0, 14 * a, 0, TAU); fill(ctx, P.accent, o);
    ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = P.color; ctx.globalAlpha = o; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + (x1 - x0) * l1, y0 + (y1 - y0) * l1); if (l2 > 0) { ctx.lineTo(x1 + (x2 - x1) * l2, y1); } if (l1 > 0) { ctx.stroke(); } ctx.globalAlpha = 1;
    var bx = fx > 0 ? x2 + 8 : x2 - 8 - w;
    box(ctx, bx, y1 - 52, w, 104, 14, P.bg, 0.95 * b); box(ctx, fx > 0 ? bx : bx + w - 8, y1 - 52, 8, 104, 4, P.accent, b);
    text(ctx, P.t1, bx + 28, P.t2 ? y1 - 14 : y1 + 2, P, 36, 800, on(P.bg), 'left', w - 46, b); text(ctx, P.t2, bx + 28, y1 + 26, P, 22, 500, on(P.bg), 'left', w - 46, 0.7 * b);
  };
  X.arrow = function (ctx, t, P, V) {
    var k = P.noIn ? 1 : E.io3(seg(t, 0.1, 0.9)), o = P.noOut ? 1 : 1 - seg(t, P.dur - 0.45, P.dur - 0.05), b = st(t, P, 0, 0.4), f = V.flip ? -1 : 1, wob = Math.sin(t * 5) * 6 * seg(t, 0.9, 1.1);
    ctx.save(); ctx.translate(300, 0); ctx.scale(f, 1); ctx.translate(-300, 0);
    var p0 = [110, 110], p1 = [380, 60], p2 = [470 + wob, 300 + wob], n = 40, i, last = p0, pt = p0;
    ctx.lineWidth = 12; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = P.accent; ctx.globalAlpha = o; ctx.beginPath(); ctx.moveTo(p0[0], p0[1]);
    for (i = 1; i <= Math.round(n * k); i++) { var u = i / n; last = pt; pt = [(1 - u) * (1 - u) * p0[0] + 2 * u * (1 - u) * p1[0] + u * u * p2[0], (1 - u) * (1 - u) * p0[1] + 2 * u * (1 - u) * p1[1] + u * u * p2[1]]; ctx.lineTo(pt[0], pt[1]); }
    if (k > 0.02) { ctx.stroke(); var an = Math.atan2(pt[1] - last[1], pt[0] - last[0]); ctx.translate(pt[0], pt[1]); ctx.rotate(an); ctx.beginPath(); ctx.moveTo(26, 0); ctx.lineTo(-18, -24); ctx.lineTo(-18, 24); ctx.closePath(); ctx.fillStyle = P.accent; ctx.fill(); }
    ctx.restore(); ctx.globalAlpha = 1;
    ctx.save(); shadow(ctx, 12, 0.55); text(ctx, P.t1, V.flip ? 590 : 10, 56, P, 44, 900, P.color, V.flip ? 'right' : 'left', 400, b); ctx.restore();
  };
  X.ringmark = function (ctx, t, P, V) {
    var k = P.noIn ? 1 : E.io3(seg(t, 0, 0.7)), o = P.noOut ? 1 : 1 - seg(t, P.dur - 0.45, P.dur - 0.05), b = st(t, P, 0.5, 0.4), i;
    ctx.lineCap = 'round'; ctx.strokeStyle = P.accent; ctx.globalAlpha = o;
    if (V.focus) { var g = 60 * (1 - k); ctx.lineWidth = 9; for (i = 0; i < 4; i++) { var sx = i % 2 ? 1 : -1, sy = i < 2 ? -1 : 1, cx = 250 + sx * (150 + g), cy = 220 + sy * (150 + g); ctx.beginPath(); ctx.moveTo(cx - sx * 54, cy); ctx.lineTo(cx, cy); ctx.lineTo(cx, cy - sy * 54); ctx.stroke(); } }
    else { ctx.lineWidth = 11; ctx.save(); ctx.translate(250, 220); ctx.rotate(-0.5); ctx.scale(1, 0.86); ctx.beginPath(); ctx.arc(0, 0, 170, 0.2, 0.2 + TAU * 1.06 * Math.max(0.001, k)); ctx.stroke(); ctx.restore(); }
    ctx.globalAlpha = 1;
    ctx.save(); shadow(ctx, 12, 0.55); text(ctx, P.t1, 250, 440, P, 38, 800, P.color, 'center', 480, b); ctx.restore();
  };
  X.bubble = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.45, E.back), b = st(t, P, 0.2, 0.4), w = Math.min(720, Math.max(width(ctx, P.t1, P, 44, 800), width(ctx, P.t2, P, 26, 500)) + 90), r = V.side === 'r', bgc = V.accent ? P.accent : '#FFFFFF', x = r ? 780 - w : 20;
    ctx.save(); ctx.translate(r ? 780 : 20, 250); ctx.scale(a, a); ctx.translate(-(r ? 780 : 20), -250);
    ctx.save(); shadow(ctx, 14, 0.45); box(ctx, x, 30, w, 160, 36, bgc, 1); ctx.restore();
    ctx.beginPath(); ctx.moveTo(r ? 700 : 100, 186); ctx.lineTo(r ? 740 : 60, 250); ctx.lineTo(r ? 640 : 160, 186); ctx.closePath(); fill(ctx, bgc, 1);
    text(ctx, P.t1, x + 44, P.t2 ? 92 : 112, P, 44, 800, on(bgc), 'left', w - 80, b); text(ctx, P.t2, x + 44, 142, P, 26, 500, on(bgc), 'left', w - 80, 0.7 * b);
    ctx.restore();
  };
  X.tip = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.4, E.back), w = Math.min(640, width(ctx, P.t1, P, 36, 800) + 70), up = V.up, bob = Math.sin(t * 3.4) * 5;
    ctx.save(); ctx.translate(350, (up ? 30 : 190) + bob); ctx.scale(a, a); ctx.translate(-350, -(up ? 30 : 190));
    ctx.save(); shadow(ctx, 12, 0.45); box(ctx, 350 - w / 2, up ? 56 : 44, w, 90, 16, P.accent, 1); ctx.restore();
    ctx.beginPath(); if (up) { ctx.moveTo(322, 58); ctx.lineTo(350, 22); ctx.lineTo(378, 58); } else { ctx.moveTo(322, 132); ctx.lineTo(350, 168); ctx.lineTo(378, 132); } ctx.closePath(); fill(ctx, P.accent, 1);
    text(ctx, P.t1, 350, up ? 103 : 91, P, 36, 800, on(P.accent), 'center', 600);
    ctx.restore();
  };
  // ---------------------------------------------------------------- a few more lower thirds and timers
  LT.ticker = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5, E.out5), lw = Math.min(300, width(ctx, P.t2, P, 28, 800) + 48), s = say(P, P.t1) + '   •   ', w = Math.max(60, width(ctx, s, P, 34, 600)), x = lw + 20 - ((t * 150) % w), i;
    box(ctx, 0, 70, 1000 * a, 80, 0, P.bg, 0.95);
    ctx.save(); clipRect(ctx, lw, 70, (1000 - lw) * a, 80); for (i = 0; i < Math.ceil(1100 / w) + 1; i++) { text(ctx, s, x + i * w, 112, P, 34, 600, on(P.bg), 'left'); } ctx.restore();
    box(ctx, 0, 70, lw * a, 80, 0, P.accent, 1); ctx.save(); clipRect(ctx, 0, 70, lw * a, 80); text(ctx, P.t2, lw / 2, 112, P, 28, 800, on(P.accent), 'center', lw - 24); ctx.restore();
  };
  LT.credit = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.7, E.out5), b = st(t, P, 0.25, 0.6), al = V.left ? 'left' : 'center', x = V.left ? 50 : 500;
    ctx.save(); shadow(ctx, 14, 0.55);
    text(ctx, P.t2, x, 62 - 12 * (1 - a), P, 26, 600, P.accent, al, 880, a);
    text(ctx, P.t1, x, 126 + 14 * (1 - b), P, 70, 800, P.color, al, 900, b);
    ctx.restore(); box(ctx, V.left ? 50 : 500 - 40 * a, 180, 80 * a, 4, 2, P.color, 0.8);
  };
  LT.duo = function (ctx, t, P, V) {
    var i, names = [[P.t1, P.t2], [P.t3, P.t4]];
    for (i = 0; i < 2; i++) {
      var a = st(t, P, 0.12 * i, 0.45), b = st(t, P, 0.12 * i + 0.14, 0.5), r = i === 1, x = r ? 960 : 40;
      box(ctx, r ? x - 8 : x, 110 - 70 * a, 8, 140 * a, 4, P.accent, 1);
      ctx.save(); shadow(ctx, 12, 0.5); if (r) { clipRect(ctx, 500, 0, 446, 220); } else { clipRect(ctx, 54, 0, 446, 220); }
      text(ctx, names[i][0], r ? x - 26 + 200 * (1 - b) : x + 26 - 200 * (1 - b), 88, P, 46, 800, P.color, r ? 'right' : 'left', 420, b);
      text(ctx, names[i][1], r ? x - 26 + 200 * (1 - b) : x + 26 - 200 * (1 - b), 140, P, 26, 500, P.color, r ? 'right' : 'left', 420, 0.85 * b); ctx.restore();
    }
  };
  TIMER.frame = function (ctx, t, P) {
    var a = st(t, P, 0, 0.45, E.out5), p = ran(P, t), q = (P.timer || {}).down ? 1 - p : p, per = 2 * (560 + 160), d = per * q;
    rr(ctx, 40, 30, 560, 160, 24); ctx.lineWidth = 8; ctx.globalAlpha = 0.25 * a; ctx.strokeStyle = P.color; ctx.stroke();
    ctx.setLineDash([Math.max(0.001, d), per]); ctx.globalAlpha = a; ctx.strokeStyle = P.accent; ctx.lineCap = 'round'; ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
    ctx.save(); shadow(ctx, 12, 0.5 * a); digits(ctx, clock(P, t), 320, 112, 104, P, P.color, 800, a); ctx.restore();
  };
  TIMER.fill = function (ctx, t, P) {
    var a = st(t, P, 0, 0.45), p = ran(P, t), q = (P.timer || {}).down ? 1 - p : p;
    box(ctx, 40, 30, 560, 160, 26, P.bg, 0.92 * a);
    ctx.save(); rr(ctx, 40, 30, 560, 160, 26); ctx.clip(); ctx.globalAlpha = 0.9 * a; ctx.fillStyle = P.accent; ctx.fillRect(40, 30, 560 * q, 160); ctx.restore(); ctx.globalAlpha = 1;
    digits(ctx, clock(P, t), 320, 112, 104, P, '#FFFFFF', 900, a);
  };
  TIMER.label = function (ctx, t, P) {
    var a = st(t, P, 0, 0.45, E.out5), b = st(t, P, 0.15, 0.4), lw = Math.min(330, width(ctx, P.t1, P, 34, 800) + 50);
    box(ctx, 20, 60, (lw + 250) * a, 100, 50, P.bg, 0.95); box(ctx, 20, 60, lw * a, 100, 50, P.accent, 1);
    ctx.save(); clipRect(ctx, 20, 60, (lw + 250) * a, 100); text(ctx, P.t1, 20 + lw / 2, 112, P, 34, 800, on(P.accent), 'center', lw - 36, b);
    digits(ctx, clock(P, t), 20 + lw + 118, 113, 64, P, on(P.bg), 800, b); ctx.restore();
  };

  // ---------------------------------------------------------------- racing and drift pieces
  // 760 × 260: five start lights come on one by one, then all go out
  X.lights = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.4), i, step = 0.7, goT = 0.6 + 5 * step + 0.7, go = !P.noIn && t > goT, all = P.noIn;
    box(ctx, 30, 24, 700, 150, 28, '#101010', 0.96 * a);
    for (i = 0; i < 5; i++) {
      var onL = all || (!go && t > 0.6 + i * step), cx = 110 + i * 135;
      ctx.save(); if (onL) { ctx.shadowColor = '#FF2D2D'; ctx.shadowBlur = 30; }
      ctx.beginPath(); ctx.arc(cx, 99, 46, 0, TAU); fill(ctx, onL ? '#F0262B' : '#34100F', a); ctx.restore();
    }
    ctx.save(); shadow(ctx, 12, 0.5); text(ctx, go ? (P.t2 || 'GO!') : P.t1, 380, 220, P, 38, 900, go ? '#2ECC71' : P.color, 'center', 700, a); ctx.restore();
  };
  // 520 × 360: a standings tower, "name | gap" per row
  X.tower = function (ctx, t, P, V) {
    var rows = [P.t1, P.t2, P.t3, P.t4], i;
    for (i = 0; i < 4; i++) {
      var r = pair(rows[i]);
      if (!r[0]) { continue; }
      var a = st(t, P, 0.12 * i, 0.45, E.out5), y = 16 + i * 84, lead = i === 0;
      ctx.save(); clipRect(ctx, 20, y, 480 * a, 72);
      box(ctx, 20, y, 480, 72, 10, P.bg, 0.95); box(ctx, 20, y, 72, 72, 10, lead ? P.accent : '#FFFFFF', 1);
      text(ctx, String(i + 1), 56, y + 38, P, 38, 900, on(lead ? P.accent : '#FFFFFF'), 'center');
      text(ctx, r[0], 112, y + 38, P, 30, 700, on(P.bg), 'left', 236); text(ctx, r[1], 484, y + 38, P, 24, 600, on(P.bg), 'right', 130, 0.75);
      ctx.restore();
    }
  };
  // 640 × 200: three sector boxes
  X.sectors = function (ctx, t, P, V) {
    var cols = V.cols || ['#B14AED', '#2ECC71', '#FFD400'], tx = [P.t1, P.t2, P.t3], i;
    for (i = 0; i < 3; i++) {
      var a = st(t, P, 0.25 * i, 0.4, E.back), x = 20 + i * 204;
      ctx.save(); ctx.translate(x + 96, 100); ctx.scale(a, a);
      box(ctx, -96, -70, 192, 140, 16, '#101010', 0.95); box(ctx, -96, -70, 192, 44, 0, cols[i], 1);
      text(ctx, 'S' + (i + 1), 0, -47, P, 26, 900, on(cols[i]), 'center'); text(ctx, counted(P, t, tx[i], 0.25 * i + 0.1, 0.25 * i + 0.9), 0, 26, P, 44, 800, '#FFFFFF', 'center', 170);
      ctx.restore();
    }
  };
  // 380 × 380: the gear, under a row of shift lights
  X.gear = function (ctx, t, P, V) {
    var a = st(t, P, 0, 0.5, E.back), rev = P.noIn ? 0.8 : (0.35 + 0.65 * ((t * 0.9) % 1)), i, n = 11;
    ctx.save(); ctx.translate(190, 190); ctx.scale(0.7 + 0.3 * a, 0.7 + 0.3 * a);
    ctx.beginPath(); ctx.arc(0, 0, 172, 0, TAU); fill(ctx, P.bg, 0.95 * a);
    for (i = 0; i < n; i++) { var an = Math.PI * 1.15 + i / (n - 1) * Math.PI * 0.7, lit = i / (n - 1) <= rev, col = i > 8 ? '#F0262B' : (i > 5 ? '#FFD400' : '#2ECC71'); ctx.beginPath(); ctx.arc(Math.cos(an) * 136, Math.sin(an) * 136, 11, 0, TAU); fill(ctx, lit ? col : on(P.bg), (lit ? 1 : 0.16) * a); }
    text(ctx, P.t1, 0, 16, P, 190, 900, on(P.bg), 'center', 220, a); text(ctx, P.t2, 0, 116, P, 24, 600, on(P.bg), 'center', 220, 0.7 * a);
    ctx.restore();
  };
  // 760 × 250: three judges' scores and a caption
  X.scores = function (ctx, t, P, V) {
    var v = [P.t1, P.t2, P.t3], i;
    for (i = 0; i < 3; i++) {
      var a = st(t, P, 0.15 * i, 0.45, E.back), x = 30 + i * 238;
      ctx.save(); ctx.translate(x + 112, 96); ctx.scale(a, a); box(ctx, -112, -76, 224, 152, 18, i === 1 ? P.accent : P.bg, 0.96);
      text(ctx, counted(P, t, v[i], 0.2 + 0.15 * i, 1.2 + 0.15 * i), 0, 6, P, 86, 900, on(i === 1 ? P.accent : P.bg), 'center', 200); ctx.restore();
    }
    ctx.save(); shadow(ctx, 10, 0.5); text(ctx, P.t4, 380, 216, P, 30, 700, P.color, 'center', 720, st(t, P, 0.5, 0.5)); ctx.restore();
  };
  /** A themed decoration under a design: chequers, racing stripes, tyre tread, drift smoke, speed lines. */
  function trim(ctx, d, t, P, kind) {
    var a = st(t, P, 0, 0.6, E.out5), i, w = d.w, h = d.h;
    if (a <= 0) { return; }
    if (kind === 'check') {
      ctx.save(); clipRect(ctx, 0, h - 22, w * a, 22);
      for (i = 0; i < Math.ceil(w / 11); i++) { ctx.fillStyle = i % 2 ? '#FFFFFF' : '#111111'; ctx.fillRect(i * 11, h - 22, 11, 11); ctx.fillStyle = i % 2 ? '#111111' : '#FFFFFF'; ctx.fillRect(i * 11, h - 11, 11, 11); }
      ctx.restore();
    } else if (kind === 'stripes') {
      ctx.save(); ctx.globalAlpha = a; ctx.transform(1, 0, -0.3, 1, h * 0.3, 0);
      ctx.fillStyle = P.accent; ctx.fillRect(w - 150 + 240 * (1 - a), 0, 34, h); ctx.fillStyle = '#FFFFFF'; ctx.fillRect(w - 104 + 240 * (1 - a), 0, 14, h);
      ctx.restore();
    } else if (kind === 'tyre') {
      ctx.save(); clipRect(ctx, 0, h - 26, w * a, 26); ctx.globalAlpha = 0.6; ctx.fillStyle = '#0A0A0A';
      for (i = 0; i < w / 18 + 1; i++) { ctx.beginPath(); ctx.moveTo(i * 18, h - 26); ctx.lineTo(i * 18 + 9, h - 13); ctx.lineTo(i * 18, h); ctx.lineTo(i * 18 + 7, h); ctx.lineTo(i * 18 + 16, h - 13); ctx.lineTo(i * 18 + 7, h - 26); ctx.closePath(); ctx.fill(); }
      ctx.restore();
    } else if (kind === 'smoke') {
      for (i = 0; i < 9; i++) { var ph = (t * 0.35 + i / 9) % 1; ctx.beginPath(); ctx.arc(w * 0.08 + i * w * 0.1 + Math.sin(i * 7 + t) * 14, h * 0.92 - ph * h * 0.5, 24 + ph * 44, 0, TAU); fill(ctx, '#FFFFFF', 0.17 * (1 - ph) * a); }
    } else if (kind === 'speed') {
      ctx.save();
      for (i = 0; i < 8; i++) { var p2 = (t * 1.6 + i * 0.37) % 1, len = 90 + (i * 37 % 120); ctx.globalAlpha = 0.35 * a * (1 - Math.abs(p2 - 0.5) * 2); ctx.fillStyle = i % 3 ? '#FFFFFF' : P.accent; ctx.fillRect(w - p2 * (w + len), 10 + (i * 53 % Math.max(20, h - 20)), len, 4); }
      ctx.restore(); ctx.globalAlpha = 1;
    }
  }

  // ---------------------------------------------------------------- competitions: 2 to 6 people and their points
  // P.players = [{ n: name, s: points }], P.pick = the one the design is about (who scores, who is out, whose turn)
  var PLAYERS = [{ n: 'გოგა', s: '12', a: '1' }, { n: 'ნიკა', s: '9' }, { n: 'დათო', s: '7', a: '2' }, { n: 'ლუკა', s: '4' }, { n: 'სანდრო', s: '3' }, { n: 'ანი', s: '2' }];
  function pts(p) { var v = parseFloat(String(p.s).replace(',', '.')); return isNaN(v) ? 0 : v; }
  function order(P) { var a = [], i; for (i = 0; i < P.players.length; i++) { a.push(i); } a.sort(function (x, y) { return pts(P.players[y]) - pts(P.players[x]) || x - y; }); return a; }
  function ini(name) { return String(name || '•').replace(/^[@#\s]+/, '').charAt(0).toUpperCase() || '•'; }
  var C = {};
  function hasPhoto(p) { return !!(p && p.img && (p.img.naturalWidth || p.img.width)); }
  /** A player's picture in a circle: their photo when they have one (p.img, cropped to fill, a little above the middle — where a face is), else the first letter of the name. */
  function face(ctx, P, p, cx, cy, r, bg, fg, alpha, ring) {
    alpha = alpha === undefined ? 1 : clamp(alpha, 0, 1);
    if (hasPhoto(p)) {
      var iw = p.img.naturalWidth || p.img.width, ih = p.img.naturalHeight || p.img.height, k = Math.max(2 * r / iw, 2 * r / ih), w = iw * k, h = ih * k;
      ctx.save(); ctx.globalAlpha = alpha; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.save(); ctx.clip();
      try { ctx.drawImage(p.img, cx - w / 2, cy - r - (h - 2 * r) * 0.3, w, h); } catch (e) {}
      ctx.restore(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.lineWidth = Math.max(3, r * 0.1); ctx.strokeStyle = ring || bg; ctx.stroke(); ctx.restore();
      return true;
    }
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); fill(ctx, bg, alpha); text(ctx, ini(p.n), cx, cy + 2, P, r * 1.1, 900, fg, 'center', 0, alpha);
    return false;
  }
  /** One player's card at x…x+w: initial, name, points. hi = lit up, dim = greyed. */
  function pcard(ctx, P, p, x, y, w, h, a, o) {
    o = o || {};
    var pc = p.c || P.accent, bgc = o.hi ? pc : P.bg, fc = on(bgc), r = P.photos ? Math.min(44, w * 0.27) : Math.min(34, w * 0.2);
    ctx.save(); ctx.translate(x + w / 2, y + h / 2); ctx.scale(a * (o.scale || 1), a * (o.scale || 1)); ctx.translate(-w / 2, -h / 2); ctx.globalAlpha = 1;
    box(ctx, 0, 0, w, h, 18, bgc, o.dim ? 0.5 : 0.96);
    face(ctx, P, p, w / 2, 14 + r, r, o.hi ? on(pc) : pc, o.hi ? pc : on(pc), o.dim ? 0.45 : 1);
    text(ctx, p.n, w / 2, (P.photos ? 30 : 34) + r * 2, P, 28, 700, fc, 'center', w - 16, o.dim ? 0.5 : 1);
    text(ctx, o.score !== undefined ? o.score : p.s, w / 2, h - 44, P, 64, 900, fc, 'center', w - 16, o.dim ? 0.5 : 1);
    ctx.restore();
  }
  function slots(n, w, gap) { var cw = (w - gap * (n - 1)) / n, out = [], i; for (i = 0; i < n; i++) { out.push([20 + i * (cw + gap), cw]); } return out; }
  // 1000 × 280: everyone side by side
  C.cards = function (ctx, t, P, V) {
    var n = P.players.length, sl = slots(n, 960, 14), lead = order(P)[0], i;
    for (i = 0; i < n; i++) { pcard(ctx, P, P.players[i], sl[i][0], 30, sl[i][1], 230, st(t, P, 0.08 * i, 0.45, E.back), { hi: V.lead && i === lead, score: counted(P, t, P.players[i].s, 0.3 + 0.08 * i, 1.2 + 0.08 * i) }); }
    if (P.t1) { ctx.save(); shadow(ctx, 10, 0.5); text(ctx, P.t1, 500, 14, P, 22, 700, P.color, 'center', 900, st(t, P, 0.2, 0.4)); ctx.restore(); }
  };
  // 1000 × 280: one of them is out
  C.out = function (ctx, t, P, V) {
    var n = P.players.length, sl = slots(n, 960, 14), k = P.pick, t0 = 1.1, i, gone = P.noIn || t > t0, sl2 = P.noIn ? 1 : E.out5(seg(t, t0, t0 + 0.25));
    for (i = 0; i < n; i++) { pcard(ctx, P, P.players[i], sl[i][0], 30, sl[i][1], 230, st(t, P, 0.08 * i, 0.45, E.back), { dim: i === k && gone }); }
    if (gone) {
      var cx = sl[k][0] + sl[k][1] / 2, a = st(t, P, 0, 0.1);
      ctx.save(); ctx.translate(cx, 145); ctx.rotate(-0.2); ctx.scale(2 - sl2, 2 - sl2); ctx.globalAlpha = a;
      var w = Math.min(sl[k][1] + 30, width(ctx, P.t1 || 'გამოეთიშა', P, 30, 900) + 44); rr(ctx, -w / 2, -30, w, 60, 10); ctx.lineWidth = 6; ctx.strokeStyle = '#E5202B'; ctx.stroke(); ctx.globalAlpha = 1;
      text(ctx, P.t1 || 'გამოეთიშა', 0, 2, P, 30, 900, '#E5202B', 'center', w - 24, a); ctx.restore();
    }
  };
  // 1000 × 300: whose turn it is
  C.turn = function (ctx, t, P, V) {
    var n = P.players.length, sl = slots(n, 960, 14), k = P.pick, i, pulse = 1 + 0.035 * Math.sin(t * 5);
    for (i = 0; i < n; i++) { pcard(ctx, P, P.players[i], sl[i][0], 64, sl[i][1], 226, st(t, P, 0.08 * i, 0.45, E.back), { hi: i === k, scale: i === k ? pulse : 0.94, dim: false }); }
    var b = st(t, P, 0.4, 0.4, E.back), cx = sl[k][0] + sl[k][1] / 2, w = Math.min(420, width(ctx, P.t1, P, 26, 800) + 40);
    ctx.save(); ctx.translate(clamp(cx, w / 2 + 10, 990 - w / 2), 30); ctx.scale(b, b); box(ctx, -w / 2, -22, w, 44, 22, '#FFFFFF', 1); text(ctx, P.t1, 0, 2, P, 26, 800, '#111111', 'center', w - 24); ctx.restore();
  };
  // 560 × 540: the table, best first
  C.board = function (ctx, t, P, V) {
    var ord = V.keep ? null : order(P), n = P.players.length, lead = order(P)[0], i, a0 = st(t, P, 0, 0.45, E.out5);
    box(ctx, 20, 10, 520 * a0, 58, 12, P.accent, 1); ctx.save(); clipRect(ctx, 20, 10, 520 * a0, 58); text(ctx, P.t1, 44, 41, P, 28, 800, on(P.accent), 'left', 470); ctx.restore();
    for (i = 0; i < n; i++) {
      var pi = ord ? ord[i] : i, p = P.players[pi], a = st(t, P, 0.1 + 0.09 * i, 0.45, E.out5), y = 78 + i * 76, top = pi === lead;
      ctx.save(); clipRect(ctx, 20, y, 520 * a, 68);
      var rc = P.multi ? p.c : (top ? P.accent : '#FFFFFF');
      box(ctx, 20, y, 520, 68, 10, P.bg, 0.95); box(ctx, 20, y, 68, 68, 10, rc, 1);
      text(ctx, String(i + 1), 54, y + 36, P, 34, 900, on(rc), 'center');
      var ph = hasPhoto(p); if (ph) { face(ctx, P, p, 126, y + 34, 25, P.multi ? p.c : '#FFFFFF', '#111111', 1); }
      text(ctx, p.n, ph ? 164 : 108, y + 36, P, 30, 700, on(P.bg), 'left', ph ? 236 : 290); text(ctx, counted(P, t, p.s, 0.3 + 0.09 * i, 1.3 + 0.09 * i), 522, y + 36, P, 36, 900, top && !P.multi ? P.accent : on(P.bg), 'right', 120);
      ctx.restore();
    }
  };
  // 900 × 520: bars racing to the best score (or to the goal in the second field)
  C.race = function (ctx, t, P, V) {
    var n = P.players.length, goal = (num(P.t2) || { v: 0 }).v, mx = 1, i, lead = order(P)[0];
    for (i = 0; i < n; i++) { mx = Math.max(mx, pts(P.players[i])); }
    mx = Math.max(mx, goal);
    ctx.save(); shadow(ctx, 10, 0.5); text(ctx, P.t1, 30, 30, P, 28, 800, P.color, 'left', 840, st(t, P, 0, 0.4)); ctx.restore();
    for (i = 0; i < n; i++) {
      var p = P.players[i], a = st(t, P, 0.08 * i, 0.45), g = P.noIn ? 1 : E.out5(seg(t, 0.3 + 0.08 * i, 1.6 + 0.08 * i)), y = 66 + i * 74, w = 560 * pts(p) / mx * g;
      ctx.save(); shadow(ctx, 8, 0.5); text(ctx, p.n, 196, y + 30, P, 28, 700, P.color, 'right', 170, a); ctx.restore();
      box(ctx, 214, y + 6, 560, 48, 24, P.color, 0.16 * a); box(ctx, 214, y + 6, Math.max(48, w), 48, 24, P.multi ? p.c : (i === lead ? P.accent : P.color), a);
      ctx.save(); shadow(ctx, 8, 0.5); text(ctx, counted(P, t, p.s, 0.3 + 0.08 * i, 1.6 + 0.08 * i), 214 + Math.max(48, w) + 16, y + 32, P, 36, 900, P.color, 'left', 110, a); ctx.restore();
    }
  };
  // 900 × 470: the podium (best three; a duel shows two)
  C.podium = function (ctx, t, P, V) {
    var ord = order(P).slice(0, 3), n = ord.length, place = n === 2 ? [0, 1] : [1, 0, 2], hs = [230, 170, 120], i;
    for (i = 0; i < n; i++) {
      var rank = place[i], p = P.players[ord[rank]], g = P.noIn ? 1 : E.out5(seg(t, 0.15 * (2 - rank), 0.15 * (2 - rank) + 0.7)), o = P.noOut ? 1 : 1 - E.in3(seg(t, P.dur - 0.5, P.dur - 0.05)), h = hs[rank] * g * o, x = 450 + (i - (n - 1) / 2) * 262 - 120, b = st(t, P, 0.5 + 0.15 * (2 - rank), 0.4, E.back);
      var sc = P.multi ? p.c : (rank === 0 ? P.accent : P.bg);
      box(ctx, x, 440 - h, 240, h, 12, sc, 0.96);
      if (h > 70) { text(ctx, String(rank + 1), x + 120, 440 - h / 2, P, 78, 900, on(sc), 'center', 0, 0.9 * b); }
      ctx.save(); ctx.translate(x + 120, 440 - hs[rank] - 62); ctx.scale(b, b); shadow(ctx, 10, 0.5);
      text(ctx, p.n, 0, 0, P, 34, 800, P.color, 'center', 250); text(ctx, p.s, 0, 38, P, 28, 700, P.multi ? P.color : P.accent, 'center', 250);
      if (hasPhoto(p)) { face(ctx, P, p, 0, -70, 44, P.multi ? p.c : (rank === 0 ? P.accent : '#FFFFFF'), '#111111', 1); }
      ctx.restore();
    }
  };
  // 1000 × 280: the winner of the round
  C.winner = function (ctx, t, P, V) {
    var p = P.players[V.pick ? P.pick : order(P)[0]], a = st(t, P, 0, 0.5, E.out5), b = st(t, P, 0.2, 0.5, E.back), i, burst = P.noIn ? 1 : seg(t, 0.3, 1.5), w = Math.min(820, width(ctx, p.n, P, 96, 900) + 120), ph = hasPhoto(p);
    if (ph) { w = Math.min(900, w + 130); }
    if (burst > 0 && burst < 1) { for (i = 0; i < 26; i++) { var an = i * 2.4, r = 60 + 420 * E.out3(burst) * (0.5 + (i * 37 % 50) / 100); ctx.save(); ctx.translate(500 + Math.cos(an) * r, 150 + Math.sin(an) * r * 0.45 + 120 * burst * burst); ctx.rotate(an + t * 6); box(ctx, -7, -4, 14, 8, 2, i % 3 ? (p.c || P.accent) : (i % 2 ? '#FFFFFF' : '#FFD400'), 1 - burst); ctx.restore(); } }
    ctx.save(); shadow(ctx, 10, 0.5); text(ctx, P.t1, 500, 40, P, 28, 700, P.color, 'center', 900, a); ctx.restore();
    ctx.save(); ctx.translate(500, 150); ctx.scale(b, b); box(ctx, -w / 2, -72, w, 144, 20, p.c || P.accent, 1); text(ctx, p.n, ph ? 62 : 0, 6, P, 96, 900, on(p.c || P.accent), 'center', w - (ph ? 200 : 70)); if (ph) { face(ctx, P, p, -w / 2 + 80, 0, 58, on(p.c || P.accent), '#111111', 1); } ctx.restore();
    ctx.save(); shadow(ctx, 10, 0.5); text(ctx, counted(P, t, p.s, 0.4, 1.3) + (P.t2 ? ' ' + P.t2 : ''), 500, 254, P, 34, 800, P.color, 'center', 900, st(t, P, 0.4, 0.4)); ctx.restore();
  };
  // 1000 × 240: everyone against everyone
  C.versus = function (ctx, t, P, V) {
    var n = P.players.length, sl = slots(n, 960, 54), i;
    for (i = 0; i < n; i++) {
      var p = P.players[i], a = st(t, P, 0.08 * i, 0.45, E.out5), x = sl[i][0], w = sl[i][1], dy = (i % 2 ? 1 : -1) * 240 * (1 - a), col = P.multi ? p.c : (i % 2 ? P.bg : P.accent);
      ctx.save(); ctx.transform(1, 0, -0.14, 1, 17, 0); box(ctx, x, 50 + dy, w, 140, 10, col, 0.97); ctx.restore();
      text(ctx, p.n, x + w / 2, 112 + dy, P, 44, 900, on(col), 'center', w - 30); if (V.score) { text(ctx, p.s, x + w / 2, 162 + dy, P, 26, 700, on(col), 'center', w - 30, 0.85); }
    }
    for (i = 0; i < n - 1; i++) { var b = st(t, P, 0.4 + 0.08 * i, 0.35, E.back), cx = sl[i][0] + sl[i][1] + 27; ctx.save(); ctx.translate(cx, 120); ctx.scale(b, b); ctx.beginPath(); ctx.arc(0, 0, 34, 0, TAU); fill(ctx, '#FFFFFF', 1); text(ctx, 'VS', 0, 2, P, 30, 900, '#111111', 'center'); ctx.restore(); }
  };
  // 1000 × 120: a thin strip for the top of the picture
  C.strip = function (ctx, t, P, V) {
    var n = P.players.length, a = st(t, P, 0, 0.5, E.out5), lw = P.t1 ? Math.min(240, width(ctx, P.t1, P, 26, 800) + 44) : 0, cw = (980 - lw) / n, lead = order(P)[0], i;
    box(ctx, 10, 26, 980 * a, 68, 12, P.bg, 0.95);
    ctx.save(); rr(ctx, 10, 26, 980 * a, 68, 12); ctx.clip();
    if (lw) { ctx.fillStyle = P.accent; ctx.fillRect(10, 26, lw, 68); text(ctx, P.t1, 10 + lw / 2, 62, P, 26, 800, on(P.accent), 'center', lw - 20); }
    for (i = 0; i < n; i++) {
      var p = P.players[i], x = 10 + lw + i * cw, b = st(t, P, 0.15 + 0.07 * i, 0.4);
      if (i) { box(ctx, x, 40, 2, 40, 1, on(P.bg), 0.2); }
      var sc2 = i === lead && !P.multi ? P.accent : on(P.bg);
      if (cw < 175) { if (P.multi) { box(ctx, x + 12, 36, 6, 48, 3, p.c, b); } text(ctx, p.n, x + (P.multi ? 26 : 16), 46, P, 20, 600, on(P.bg), 'left', cw - 34, b * 0.85); text(ctx, counted(P, t, p.s, 0.3, 1.1), x + (P.multi ? 26 : 16), 75, P, 30, 900, sc2, 'left', cw - 34, b); continue; }
      if (P.multi) { box(ctx, x + 14, 52, 8, 20, 4, p.c, b); }
      text(ctx, p.n, x + (P.multi ? 30 : 18), 62, P, 26, 600, on(P.bg), 'left', cw - (P.multi ? 108 : 96), b); text(ctx, counted(P, t, p.s, 0.3, 1.1), x + cw - 18, 62, P, 32, 900, sc2, 'right', 80, b);
    }
    ctx.restore();
  };
  // 900 × 520: points as dots, first to the goal wins (goal = second field)
  C.tally = function (ctx, t, P, V) {
    var n = P.players.length, goal = clamp(Math.round((num(P.t2) || { v: 5 }).v), 1, 12), i, j;
    ctx.save(); shadow(ctx, 10, 0.5); text(ctx, P.t1, 30, 30, P, 28, 800, P.color, 'left', 840, st(t, P, 0, 0.4)); ctx.restore();
    for (i = 0; i < n; i++) {
      var p = P.players[i], a = st(t, P, 0.08 * i, 0.45), y = 66 + i * 74, gap = Math.min(54, 600 / goal);
      ctx.save(); shadow(ctx, 8, 0.5); text(ctx, p.n, 196, y + 30, P, 28, 700, P.color, 'right', 170, a); ctx.restore();
      for (j = 0; j < goal; j++) { var onD = j < pts(p), b = onD ? st(t, P, 0.3 + 0.08 * i + 0.06 * j, 0.3, E.back) : a; ctx.beginPath(); ctx.arc(240 + j * gap, y + 30, onD ? 17 * b : 13, 0, TAU); fill(ctx, onD ? (p.c || P.accent) : P.color, onD ? 1 : 0.25 * a); }
    }
  };

  // ---------------------------------------------------------------- score styles: everyone's points, and points going to any of them
  // Each player has p.a — how many points they get now (0 = none, minus = a penalty) — and p.c, their own colour.
  var RED = '#E5202B';
  var SC = {};
  function row(n, gap, maxW) { var cw = Math.min(maxW || 230, (960 - gap * (n - 1)) / n), x0 = 500 - (cw * n + gap * (n - 1)) / 2, out = [], i; for (i = 0; i < n; i++) { out.push([x0 + i * (cw + gap), cw]); } return out; }
  /** Where player i is at time t: the number shown, how far the points have landed (k), the "+2" label. Those who get points light up one after another. */
  function gain(P, t, i, together) {
    var p = P.players[i], a = p.a || 0, k = 0, j;
    if (!together) { for (j = 0; j < i; j++) { if (P.players[j].a) { k++; } } }
    var t0 = 1.1 + 0.16 * k, h = !a ? 0 : (P.noIn ? 1 : seg(t, t0, t0 + 0.6)), from = pts(p), dec = /\./.test(String(from) + String(a)) ? 1 : 0;
    return { p: p, c: p.c || P.accent, a: a, t0: t0, hit: h > 0, k: h, e: E.out3(h), from: from, to: from + a, dec: dec, now: from + a * E.out3(h),
      val: a ? (from + a * E.out3(h)).toFixed(dec) : (P.adds ? String(p.s) : counted(P, t, p.s, 0.3 + 0.08 * i, 1.2 + 0.08 * i)),
      pop: h > 0 && h < 1 ? 1 + 0.1 * Math.sin(Math.PI * h) : 1, fly: !a || P.noIn ? 1 : seg(t, t0, t0 + 1),
      chip: !a ? 0 : (P.noIn ? 1 : E.back(seg(t, t0, t0 + 0.4))),
      lab: (a > 0 ? '+' : '−') + String(Math.abs(a)), lc: a < 0 ? RED : null, inn: st(t, P, 0.07 * i, 0.45, E.back), o: st(t, P, 0, 0.01) };
  }
  function each(P, t, gap, maxW, fn) { var n = P.players.length, sl = row(n, gap, maxW), i; for (i = 0; i < n; i++) { fn(gain(P, t, i), sl[i][0], sl[i][1], i); } }
  function at(ctx, cx, cy, s, fn) { if (s <= 0.002) { return; } ctx.save(); ctx.translate(cx, cy); ctx.scale(s, s); fn(); ctx.restore(); }
  /** "+2" that rises and fades. */
  function flyLab(ctx, P, g, cx, y, size) { if (!g.a || g.fly <= 0 || g.fly >= 1) { return; } ctx.save(); shadow(ctx, 10, 0.5); text(ctx, g.lab, cx, y - 38 * E.out3(g.fly), P, size || 44, 900, g.lc || g.c, 'center', 0, (1 - g.fly * g.fly) * g.o); ctx.restore(); }
  /** "+2" in a round badge that pops up and stays. */
  function chip(ctx, P, g, cx, cy, r, col) {
    if (!g.a || g.chip * g.o <= 0.002) { return; }
    var c = g.lc || col || '#FFFFFF';
    at(ctx, cx, cy, g.chip * g.o, function () { ctx.save(); shadow(ctx, 8, 0.4); ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); fill(ctx, c, 1); ctx.restore(); ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.lineWidth = 3; ctx.strokeStyle = on(c); ctx.globalAlpha = 0.25; ctx.stroke(); ctx.globalAlpha = 1; text(ctx, g.lab, 0, 1, P, r * 0.95, 900, on(c), 'center', r * 1.6); });
  }
  function poly(ctx, r, n, rot, r2) { ctx.beginPath(); var m = r2 ? n * 2 : n, i; for (i = 0; i < m; i++) { var an = rot + i * TAU / m, rd = r2 && i % 2 ? r2 : r; if (i) { ctx.lineTo(Math.cos(an) * rd, Math.sin(an) * rd); } else { ctx.moveTo(Math.cos(an) * rd, Math.sin(an) * rd); } } ctx.closePath(); }
  function most(P) { var m = 1, i; for (i = 0; i < P.players.length; i++) { m = Math.max(m, pts(P.players[i]), pts(P.players[i]) + (P.players[i].a || 0)); } return m; }
  function lit(c) { return on(c) === '#FFFFFF' ? mix(c, '#FFFFFF', 0.22) : c; }
  // 1000 × 300 — cards
  SC.card = function (ctx, t, P, V) { each(P, t, 14, 230, function (g, x, w) {
    var bgc = g.hit ? g.c : P.bg, fc = on(bgc), ph = !!P.photos, r = ph ? Math.min(40, w * 0.25) : Math.min(34, w * 0.2);
    at(ctx, x + w / 2, 180, g.inn * g.pop, function () {
      box(ctx, -w / 2, -103, w, 206, 18, bgc, 0.96);
      face(ctx, P, g.p, 0, -91 + r, r, g.hit ? fc : g.c, g.hit ? g.c : on(g.c), 1);
      text(ctx, g.p.n, 0, (ph ? -77 : -73) + r * 2, P, ph ? 24 : 27, 700, fc, 'center', w - 16); text(ctx, g.val, 0, ph ? 64 : 60, P, ph ? 58 : 62, 900, fc, 'center', w - 16);
    });
    flyLab(ctx, P, g, x + w / 2, 68, 44);
  }); };
  // circles with a ring
  SC.orb = function (ctx, t, P, V) { each(P, t, 18, 190, function (g, x, w) {
    var r = Math.min(74, w / 2 - 6), cx = x + w / 2, cy = 132;
    if (g.hit && g.k < 1) { ctx.beginPath(); ctx.arc(cx, cy, r + 34 * g.e, 0, TAU); ctx.lineWidth = 6; ctx.strokeStyle = g.c; ctx.globalAlpha = (1 - g.k) * g.o; ctx.stroke(); ctx.globalAlpha = 1; }
    at(ctx, cx, cy, g.inn * g.pop, function () { ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); fill(ctx, P.bg, 0.96); ctx.lineWidth = 9; ctx.strokeStyle = g.c; ctx.stroke(); text(ctx, g.val, 0, 3, P, r * 0.95, 900, on(P.bg), 'center', r * 1.6); });
    ctx.save(); shadow(ctx, 8, 0.5); text(ctx, g.p.n, cx, cy + r + 36, P, 30, 700, P.color, 'center', w + 10, g.inn); ctx.restore();
    chip(ctx, P, g, cx + r * 0.74, cy - r * 0.74, 27, g.c);
  }); };
  // slanted colour plates
  SC.slant = function (ctx, t, P, V) { each(P, t, 10, 240, function (g, x, w) {
    var a = Math.min(1, g.inn), dy = (1 - a) * -40;
    ctx.save(); ctx.transform(1, 0, -0.16, 1, 28, 0);
    box(ctx, x, 80 + dy, w, 190, 8, g.c, 0.97 * a); box(ctx, x, 80 + dy, w, 54, 8, '#000000', 0.3 * a);
    if (g.hit && g.k < 1) { box(ctx, x, 80, w, 190, 8, '#FFFFFF', 0.7 * (1 - g.k) * g.o); }
    ctx.restore();
    text(ctx, g.p.n, x + w / 2 + 3, 108 + dy, P, 26, 800, '#FFFFFF', 'center', w - 44, a);
    at(ctx, x + w / 2 - 10, 204 + dy, g.pop, function () { text(ctx, g.val, 0, 0, P, 88, 900, on(g.c), 'center', w - 44, a); });
    flyLab(ctx, P, g, x + w / 2, 68, 44);
  }); };
  // neon outlines
  SC.neon = function (ctx, t, P, V) { each(P, t, 18, 220, function (g, x, w) {
    var a = Math.min(1, g.inn), c = lit(g.c);
    ctx.save(); rr(ctx, x, 76, w, 200, 16); fill(ctx, '#000000', 0.62 * a); ctx.shadowColor = c; ctx.shadowBlur = 18 + (g.hit ? 36 * (1 - g.k) : 0); ctx.lineWidth = 5; ctx.strokeStyle = c; ctx.globalAlpha = a; rr(ctx, x, 76, w, 200, 16); ctx.stroke(); ctx.stroke();
    at(ctx, x + w / 2, 198, g.pop, function () { text(ctx, g.val, 0, 0, P, 92, 900, c, 'center', w - 30, a); }); ctx.restore();
    text(ctx, g.p.n, x + w / 2, 112, P, 26, 700, '#FFFFFF', 'center', w - 24, a);
    flyLab(ctx, P, g, x + w / 2, 68, 44);
  }); };
  // a flip board: the old number folds away, the new one unfolds
  SC.flip = function (ctx, t, P, V) { each(P, t, 14, 210, function (g, x, w) {
    var a = Math.min(1, g.inn), cx = x + w / 2, mid = g.a && g.k < 1, sy = !mid ? 1 : (g.k < 0.5 ? 1 - g.k * 2 : g.k * 2 - 1), s = !g.a ? g.val : (g.k < 0.5 ? g.from.toFixed(g.dec) : g.to.toFixed(g.dec));
    box(ctx, x, 70, w, 46, 10, g.c, a); text(ctx, g.p.n, cx, 94, P, 24, 800, on(g.c), 'center', w - 16, a);
    box(ctx, x, 122, w, 156, 12, '#141414', 0.97 * a);
    at(ctx, cx, 200, 1, function () { ctx.scale(1, Math.max(0.02, sy)); text(ctx, s, 0, 4, P, 104, 900, '#FFFFFF', 'center', w - 24, a); });
    box(ctx, x, 198, w, 4, 0, '#000000', 0.8 * a); box(ctx, x - 4, 190, 8, 20, 3, '#3A3A3A', a); box(ctx, x + w - 4, 190, 8, 20, 3, '#3A3A3A', a);
    flyLab(ctx, P, g, cx, 68, 44);
  }); };
  // a LED scoreboard
  SC.led = function (ctx, t, P, V) { each(P, t, 12, 220, function (g, x, w) {
    var a = Math.min(1, g.inn), s = String(g.val).replace(/[^0-9]/g, '') || '0', n = Math.max(2, s.length), dw = Math.min(54, (w - 36) / n - 8), dh = dw * 1.8, x0 = x + w / 2 - (n * (dw + 8) - 8) / 2, i, blink = g.hit && g.k < 1 && Math.floor(g.k * 8) % 2 ? 0.35 : 1;
    while (s.length < n) { s = ' ' + s; }
    box(ctx, x, 70, w, 208, 12, '#0A0A0A', 0.96 * a); box(ctx, x, 70, w, 44, 12, g.c, a); text(ctx, g.p.n, x + w / 2, 93, P, 24, 800, on(g.c), 'center', w - 16, a);
    for (i = 0; i < n; i++) { seg7(ctx, s.charAt(i), x0 + i * (dw + 8), 198 - dh / 2, dw, dh, lit(g.c), a * blink); }
    flyLab(ctx, P, g, x + w / 2, 68, 44);
  }); };
  // no plates: big numbers over a colour line
  SC.mini = function (ctx, t, P, V) { each(P, t, 20, 220, function (g, x, w) {
    var a = Math.min(1, g.inn), cx = x + w / 2, c = Math.min(1, g.chip);
    ctx.save(); shadow(ctx, 12, 0.55);
    at(ctx, cx, 150, g.pop, function () { text(ctx, g.val, 0, 0, P, 110, 900, P.color, 'center', w - 10, a); });
    text(ctx, g.p.n, cx, 250, P, 28, 700, P.color, 'center', w, a);
    if (g.a && c > 0) { text(ctx, g.lab, cx, 72 + 16 * (1 - c), P, 40, 900, g.lc || lit(g.c), 'center', 0, c * g.o); }
    ctx.restore();
    box(ctx, cx - w * 0.3 * a, 212, w * 0.6 * a, 7, 3.5, g.c, 1);
  }); };
  // one bar cut into everyone's colour
  SC.block = function (ctx, t, P, V) {
    var n = P.players.length, a0 = st(t, P, 0, 0.5, E.out5), cw = 960 / n, i;
    function one(g, x, c, b) {
      var fc = on(c);
      ctx.fillStyle = c; ctx.fillRect(x, 84, cw + 1, 190);
      if (g.hit && g.k < 1) { ctx.globalAlpha = 0.6 * (1 - g.k); ctx.fillStyle = '#FFFFFF'; ctx.fillRect(x, 84, cw + 1, 190); ctx.globalAlpha = 1; }
      text(ctx, g.p.n, x + 18, 116, P, 26, 700, fc, 'left', cw - (g.a ? 96 : 30), b);
      at(ctx, x + 18, 212, g.pop, function () { text(ctx, g.val, 0, 0, P, 92, 900, fc, 'left', cw - 30, b); });
      if (g.a && g.chip > 0) { text(ctx, g.lab, x + cw - 16, 116, P, 32, 900, fc, 'right', 0, Math.min(1, g.chip)); }
    }
    ctx.save(); rr(ctx, 20, 84, 960 * a0, 190, 18); ctx.clip();
    for (i = 0; i < n; i++) { var g = gain(P, t, i); one(g, 20 + i * cw, P.multi ? g.c : mix(g.c, '#000000', 0.55 * i / n), st(t, P, 0.15 + 0.07 * i, 0.4)); }
    ctx.restore();
  };
  // tickets
  SC.ticket = function (ctx, t, P, V) { each(P, t, 16, 210, function (g, x, w) {
    at(ctx, x + w / 2, 178, g.inn * g.pop, function () {
      box(ctx, -w / 2, -100, w, 200, 14, '#F4F1EA', 1);
      ctx.save(); rr(ctx, -w / 2, -100, w, 200, 14); ctx.clip(); ctx.fillStyle = g.c; ctx.fillRect(-w / 2, -100, w, 56); ctx.restore();
      text(ctx, g.p.n, 0, -71, P, 25, 800, on(g.c), 'center', w - 20);
      ctx.setLineDash([7, 7]); ctx.beginPath(); ctx.moveTo(-w / 2 + 14, -34); ctx.lineTo(w / 2 - 14, -34); ctx.lineWidth = 2; ctx.strokeStyle = '#111111'; ctx.globalAlpha = 0.35; ctx.stroke(); ctx.globalAlpha = 1; ctx.setLineDash([]);
      text(ctx, g.val, 0, P.t1 ? 22 : 34, P, 88, 900, '#111111', 'center', w - 24); text(ctx, P.t1, 0, 78, P, 18, 700, '#111111', 'center', w - 20, 0.55);
    });
    chip(ctx, P, g, x + w - 8, 80, 27, g.c);
  }); };
  // hexagons
  SC.hex = function (ctx, t, P, V) { each(P, t, 12, 190, function (g, x, w) {
    var r = Math.min(88, w / 2 - 4), cx = x + w / 2, cy = 152;
    at(ctx, cx, cy, g.inn * g.pop, function () {
      poly(ctx, r, 6, -Math.PI / 2); fill(ctx, P.bg, 0.96); ctx.lineWidth = 8; ctx.lineJoin = 'round'; ctx.strokeStyle = g.c; ctx.stroke();
      text(ctx, g.val, 0, -6, P, r * 0.8, 900, on(P.bg), 'center', r * 1.4);
      var nw = Math.min(w + 6, Math.max(90, width(ctx, g.p.n, P, 24, 800) + 30)); box(ctx, -nw / 2, r * 0.6, nw, 40, 20, g.c, 1); text(ctx, g.p.n, 0, r * 0.6 + 21, P, 24, 800, on(g.c), 'center', nw - 18);
    });
    chip(ctx, P, g, cx + r * 0.8, cy - r * 0.72, 26, '#FFFFFF');
  }); };
  // shields
  SC.shield = function (ctx, t, P, V) { each(P, t, 14, 180, function (g, x, w) {
    function path(sw, sh) { ctx.beginPath(); ctx.moveTo(-sw / 2, -sh / 2); ctx.lineTo(sw / 2, -sh / 2); ctx.lineTo(sw / 2, sh * 0.08); ctx.quadraticCurveTo(sw / 2, sh * 0.36, 0, sh / 2); ctx.quadraticCurveTo(-sw / 2, sh * 0.36, -sw / 2, sh * 0.08); ctx.closePath(); }
    var fc = on(g.c);
    at(ctx, x + w / 2, 176, g.inn * g.pop, function () {
      ctx.save(); shadow(ctx, 14, 0.4); path(w, 208); fill(ctx, g.c, 1); ctx.restore();
      path(w - 18, 190); ctx.lineWidth = 3; ctx.strokeStyle = fc; ctx.globalAlpha = 0.4; ctx.stroke(); ctx.globalAlpha = 1;
      text(ctx, g.p.n, 0, -66, P, 24, 800, fc, 'center', w - 34); text(ctx, g.val, 0, 0, P, 84, 900, fc, 'center', w - 40);
    });
    chip(ctx, P, g, x + w - 6, 82, 26, '#FFFFFF');
  }); };
  // comic panels with a burst
  SC.comic = function (ctx, t, P, V) { each(P, t, 24, 210, function (g, x, w) {
    var cx = x + w / 2;
    at(ctx, cx, 188, g.inn, function () {
      rr(ctx, -w / 2 + 9, -86, w, 180, 6); fill(ctx, '#000000', 1); rr(ctx, -w / 2, -95, w, 180, 6); fill(ctx, '#FFFFFF', 1);
      ctx.fillStyle = g.c; ctx.fillRect(-w / 2 + 3, -92, w - 6, 52); ctx.fillStyle = '#000000'; ctx.fillRect(-w / 2 + 3, -41, w - 6, 5);
      rr(ctx, -w / 2, -95, w, 180, 6); ctx.lineWidth = 6; ctx.strokeStyle = '#000000'; ctx.stroke();
      text(ctx, g.p.n, 0, -65, P, 26, 900, on(g.c), 'center', w - 22);
      ctx.save(); ctx.scale(g.pop, g.pop); text(ctx, g.val, 0, 28 / g.pop, P, 92, 900, '#111111', 'center', w - 30); ctx.restore();
    });
    if (g.a && g.chip * g.o > 0.002) { at(ctx, x + w - 14, 66, g.chip * g.o, function () { ctx.rotate(-0.14 + 0.05 * Math.sin(t * 4)); poly(ctx, 52, 12, 0, 38); fill(ctx, g.lc || '#FFD400', 1); ctx.lineJoin = 'round'; ctx.lineWidth = 5; ctx.strokeStyle = '#000000'; ctx.stroke(); text(ctx, g.lab, 0, 2, P, 34, 900, g.lc ? '#FFFFFF' : '#111111', 'center', 60); }); }
  }); };
  // coins drop into the card
  SC.coin = function (ctx, t, P, V) { each(P, t, 14, 220, function (g, x, w) {
    var cx = x + w / 2, n = g.a > 0 ? Math.min(6, Math.ceil(g.a)) : 0, j;
    at(ctx, cx, 180, g.inn * g.pop, function () {
      box(ctx, -w / 2, -100, w, 200, 18, P.bg, 0.96); ctx.save(); rr(ctx, -w / 2, -100, w, 200, 18); ctx.clip(); ctx.fillStyle = g.c; ctx.fillRect(-w / 2, 88, w, 12); ctx.restore();
      text(ctx, g.p.n, 0, -66, P, 26, 700, on(P.bg), 'center', w - 20); text(ctx, g.val, 0, 14, P, 92, 900, on(P.bg), 'center', w - 24);
    });
    for (j = 0; j < n && !P.noIn; j++) {
      var f = seg(t, g.t0 - 0.25 + j * 0.1, g.t0 + 0.3 + j * 0.1);
      if (f > 0 && f < 1) { var px0 = cx + ((j * 53) % 60 - 30), py = 10 + 170 * E.in3(f); ctx.beginPath(); ctx.ellipse(px0, py, 17 * Math.abs(Math.cos(f * 7 + j)) + 3, 17, 0, 0, TAU); fill(ctx, '#FFC83D', g.o); ctx.lineWidth = 3; ctx.strokeStyle = '#B8860B'; ctx.globalAlpha = g.o; ctx.stroke(); ctx.globalAlpha = 1; }
    }
    if (g.a > 0) { chip(ctx, P, g, x + w - 8, 82, 27, '#FFC83D'); } else { flyLab(ctx, P, g, cx, 68, 44); }
  }); };
  // colour tiles; stars fly out when points land
  SC.star = function (ctx, t, P, V) { each(P, t, 20, 180, function (g, x, w) {
    var cx = x + w / 2, sz = Math.min(150, w), j;
    at(ctx, cx, 150, g.inn * g.pop, function () { box(ctx, -sz / 2, -sz / 2, sz, sz, 30, g.c, 1); text(ctx, g.val, 0, 4, P, sz * 0.56, 900, on(g.c), 'center', sz - 24); });
    ctx.save(); shadow(ctx, 8, 0.5); text(ctx, g.p.n, cx, 150 + sz / 2 + 34, P, 30, 700, P.color, 'center', w + 14, g.inn); ctx.restore();
    if (g.hit && g.fly < 1) { for (j = 0; j < 7; j++) { var an = -Math.PI / 2 + (j - 3) * 0.62, rd = 50 + 90 * E.out3(g.fly); at(ctx, cx + Math.cos(an) * rd, 150 + Math.sin(an) * rd, (1 - g.fly) * g.o, function () { ctx.rotate(g.fly * 3 + j); poly(ctx, 17, 5, -Math.PI / 2, 7.5); fill(ctx, j % 2 ? '#FFFFFF' : (g.lc || '#FFD400'), 1); }); } }
    chip(ctx, P, g, cx + sz / 2 - 6, 150 - sz / 2 + 6, 26, '#FFFFFF');
  }); };
  // paper notes; the new number gets circled
  SC.paper = function (ctx, t, P, V) { each(P, t, 20, 200, function (g, x, w, i) {
    at(ctx, x + w / 2, 182, g.inn, function () {
      ctx.rotate((i % 2 ? 1 : -1) * 0.045);
      ctx.save(); shadow(ctx, 14, 0.4); rr(ctx, -w / 2, -95, w, 190, 4); fill(ctx, '#F7F2E4', 1); ctx.restore(); box(ctx, -38, -108, 76, 26, 3, g.c, 0.88);
      text(ctx, g.p.n, 0, -52, P, 26, 800, '#222222', 'center', w - 20); text(ctx, g.val, 0, 26, P, 86, 900, '#111111', 'center', w - 40);
      if (g.a && g.k > 0) { ctx.beginPath(); ctx.ellipse(0, 26, Math.min(w / 2 - 8, 76), 54, -0.1, -1.2, -1.2 + TAU * 1.04 * g.e); ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.strokeStyle = g.lc || (on(g.c) === '#111111' ? RED : g.c); ctx.stroke(); ctx.lineCap = 'butt'; }
    });
    chip(ctx, P, g, x + w - 4, 84, 26, g.c);
  }); };
  // glass
  SC.glass = function (ctx, t, P, V) { each(P, t, 14, 220, function (g, x, w) {
    var a = Math.min(1, g.inn), cx = x + w / 2;
    rr(ctx, x, 78, w, 200, 22); fill(ctx, '#FFFFFF', 0.17 * a); if (g.hit && g.k < 1) { fill(ctx, g.c, 0.5 * (1 - g.k) * g.o); }
    ctx.lineWidth = 2; ctx.strokeStyle = '#FFFFFF'; ctx.globalAlpha = 0.55 * a; ctx.stroke(); ctx.globalAlpha = 1;
    var ph = hasPhoto(g.p); if (ph) { face(ctx, P, g.p, x + 34, 113, 19, g.c, on(g.c), a); } else { ctx.beginPath(); ctx.arc(x + 26, 112, 8, 0, TAU); fill(ctx, g.c, a); }
    ctx.save(); shadow(ctx, 8, 0.45); text(ctx, g.p.n, x + (ph ? 62 : 44), 113, P, 24, 700, '#FFFFFF', 'left', w - (ph ? 76 : 60), a);
    at(ctx, cx, 196, g.pop, function () { text(ctx, g.val, 0, 0, P, 92, 900, '#FFFFFF', 'center', w - 30, a); }); ctx.restore();
    box(ctx, x + 22, 258, (w - 44) * a, 6, 3, g.c, 1);
    flyLab(ctx, P, g, cx, 68, 44);
  }); };
  // 1000 × 330 — columns that grow
  SC.cols = function (ctx, t, P, V) { var mx = most(P); each(P, t, 26, 150, function (g, x, w, i) {
    var grow = (P.noIn ? 1 : E.out5(seg(t, 0.1 + 0.07 * i, 0.9 + 0.07 * i))) * g.o, hOld = (24 + 130 * Math.max(0, g.from) / mx) * grow, hNow = (24 + 130 * Math.max(0, g.now) / mx) * grow, cx = x + w / 2, a = Math.min(1, g.inn);
    box(ctx, x, 268 - hNow, w, hNow, 10, g.c, 1);
    if (g.a > 0 && hNow > hOld + 1) { box(ctx, x, 268 - hNow, w, hNow - hOld, 10, '#FFFFFF', 0.5 * (1 - (P.noIn ? 1 : seg(t, g.t0 + 0.6, g.t0 + 1.3)))); }
    ctx.save(); shadow(ctx, 8, 0.5); at(ctx, cx, 268 - hNow - 34, g.pop, function () { text(ctx, g.val, 0, 0, P, 54, 900, P.color, 'center', w + 20, a); }); text(ctx, g.p.n, cx, 298, P, 26, 700, P.color, 'center', w + 22, a); ctx.restore();
    flyLab(ctx, P, g, cx, 268 - hNow - 72, 40);
  }); };
  // rings that fill up
  SC.ring = function (ctx, t, P, V) { var mx = most(P); each(P, t, 18, 190, function (g, x, w) {
    var r = Math.min(74, w / 2 - 10), cx = x + w / 2, cy = 136, a = Math.min(1, g.inn), fr = clamp(g.now / mx, 0, 1) * (P.noIn ? 1 : E.out5(seg(t, 0.2, 1)));
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); fill(ctx, P.bg, 0.92 * a); ctx.lineWidth = 13; ctx.strokeStyle = on(P.bg); ctx.globalAlpha = 0.16 * a; ctx.stroke();
    if (fr > 0.001) { ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + TAU * fr); ctx.lineCap = 'round'; ctx.strokeStyle = g.c; ctx.globalAlpha = a; ctx.stroke(); ctx.lineCap = 'butt'; }
    ctx.globalAlpha = 1;
    at(ctx, cx, cy + 3, g.pop, function () { text(ctx, g.val, 0, 0, P, r * 0.86, 900, on(P.bg), 'center', r * 1.4, a); });
    ctx.save(); shadow(ctx, 8, 0.5); text(ctx, g.p.n, cx, cy + r + 40, P, 30, 700, P.color, 'center', w + 10, a); ctx.restore();
    chip(ctx, P, g, cx + r * 0.8, cy - r * 0.8, 26, g.c);
  }); };
  // an arcade cabinet
  SC.arcade = function (ctx, t, P, V) { each(P, t, 14, 220, function (g, x, w, i) {
    var a = Math.min(1, g.inn), c = lit(g.c), s = String(g.val), blink = g.hit && g.k < 1 && Math.floor(g.k * 8) % 2 ? 0.25 : 1;
    while (s.replace(/[^0-9]/g, '').length < 3 && s.charAt(0) !== '-') { s = '0' + s; }
    ctx.globalAlpha = a; ctx.fillStyle = '#000000'; ctx.fillRect(x + 6, 82, w - 12, 192);
    ctx.fillStyle = c; ctx.fillRect(x + 6, 76, w - 12, 6); ctx.fillRect(x + 6, 274, w - 12, 6); ctx.fillRect(x, 82, 6, 192); ctx.fillRect(x + w - 6, 82, 6, 192); ctx.globalAlpha = 1;
    text(ctx, 'P' + (i + 1), x + w / 2, 108, P, 24, 900, c, 'center', 0, a); text(ctx, g.p.n, x + w / 2, 140, P, 22, 700, '#FFFFFF', 'center', w - 26, a);
    text(ctx, s, x + w / 2, 216, P, 72, 900, '#FFFFFF', 'center', w - 30, a * blink);
    flyLab(ctx, P, g, x + w / 2, 68, 44);
  }); };
  // one at a time, big: "ნიკა +2"
  SC.shout = function (ctx, t, P, V) {
    var L = [], i; for (i = 0; i < P.players.length; i++) { if (P.players[i].a) { L.push(i); } }
    if (!L.length) { L = [order(P)[0]]; }
    var sl = Math.max(0.8, (P.dur - 0.1) / L.length), j = P.noIn ? 0 : clamp(Math.floor(t / sl), 0, L.length - 1), lt = P.noIn ? sl / 2 : t - j * sl, last = j === L.length - 1;
    var g = gain(P, 99, L[j]), a = (P.noIn ? 1 : E.back(seg(lt, 0, 0.35))) * (last && P.noOut ? 1 : 1 - E.in3(seg(lt, sl - 0.32, sl - 0.03))), fc = on(g.c);
    var lab = g.a ? g.lab : String(g.p.s), wn = width(ctx, g.p.n, P, 66, 800), wl = width(ctx, lab, P, 120, 900), ph = hasPhoto(g.p) ? 140 : 0, w = Math.min(940, wn + wl + 130 + ph), k = Math.min(1, (w - 130 - ph) / (wn + wl)), tot = P.noIn ? 1 : seg(lt, 0.3, 0.9);
    at(ctx, 500, 140, a, function () {
      box(ctx, -w / 2, -84, w, 168, 26, g.lc || g.c, 1); if (g.lc) { fc = '#FFFFFF'; }
      if (ph) { face(ctx, P, g.p, -w / 2 + 92, 0, 62, fc, '#111111', 1); }
      text(ctx, g.p.n, -w / 2 + 50 + ph, 4, P, 66 * k, 800, fc, 'left'); text(ctx, lab, w / 2 - 46, 6, P, 120 * k, 900, fc, 'right');
    });
    if (g.a) { ctx.save(); shadow(ctx, 10, 0.5); text(ctx, (P.t1 ? P.t1 + ' ' : '') + (g.from + g.a * E.out3(tot)).toFixed(g.dec), 500, 262, P, 36, 800, P.color, 'center', 900, Math.min(1, a)); ctx.restore(); }
  };
  // 760 × 540 — rows; the "+2" slides out on the right
  SC.rows = function (ctx, t, P, V) {
    var n = P.players.length, y0 = 270 - (n * 78 - 10) / 2, i;
    function one(g, y, a) {
      var x = 30 - 40 * (1 - a);
      box(ctx, x, y, 560, 68, 34, P.bg, 0.96 * a); face(ctx, P, g.p, x + 34, y + 34, 28, g.c, on(g.c), a);
      text(ctx, g.p.n, x + 78, y + 36, P, 30, 700, on(P.bg), 'left', 320, a); at(ctx, x + 532, y + 36, g.pop, function () { text(ctx, g.val, 0, 0, P, 40, 900, on(P.bg), 'right', 120, a); });
      if (g.a && g.chip > 0) { var s = Math.min(1, g.chip) * g.o, c = g.lc || g.c, cw = Math.max(76, width(ctx, g.lab, P, 30, 900) + 36), cx = x + 574 - 50 * (1 - s); box(ctx, cx, y + 10, cw, 48, 24, c, s); text(ctx, g.lab, cx + cw / 2, y + 35, P, 30, 900, on(c), 'center', 0, s); }
    }
    for (i = 0; i < n; i++) { one(gain(P, t, i), y0 + i * 78, st(t, P, 0.07 * i, 0.45, E.out5)); }
  };
  // 900 × 520 — bars that get longer
  SC.bars = function (ctx, t, P, V) {
    var n = P.players.length, mx = most(P), y0 = 280 - n * 37, i;
    function one(g, y, a, grow) {
      var wOld = Math.max(48, 520 * Math.max(0, g.from) / mx * grow), w = Math.max(48, 520 * Math.max(0, g.now) / mx * grow);
      ctx.save(); shadow(ctx, 8, 0.5); text(ctx, g.p.n, 196, y + 30, P, 28, 700, P.color, 'right', 170, a); ctx.restore();
      box(ctx, 214, y + 6, 520, 48, 24, P.color, 0.16 * a); box(ctx, 214, y + 6, w, 48, 24, g.c, a);
      if (g.a > 0 && w > wOld + 1) { ctx.save(); rr(ctx, 214, y + 6, w, 48, 24); ctx.clip(); ctx.fillStyle = '#FFFFFF'; ctx.globalAlpha = 0.5 * (1 - (P.noIn ? 1 : seg(t, g.t0 + 0.6, g.t0 + 1.3))) * a; ctx.fillRect(214 + wOld, y + 6, w - wOld, 48); ctx.restore(); }
      ctx.save(); shadow(ctx, 8, 0.5); var vw = text(ctx, g.val, 214 + w + 16, y + 32, P, 36, 900, P.color, 'left', 110, a);
      if (g.a && g.chip > 0) { text(ctx, g.lab, 214 + w + 30 + vw, y + 32, P, 30, 900, g.lc || lit(g.c), 'left', 0, Math.min(1, g.chip) * g.o); }
      ctx.restore();
    }
    for (i = 0; i < n; i++) { one(gain(P, t, i), y0 + i * 74, st(t, P, 0.08 * i, 0.45), P.noIn ? 1 : E.out5(seg(t, 0.2 + 0.08 * i, 1 + 0.08 * i))); }
  };
  // 560 × 540 — the table; places change after the points land
  SC.rank = function (ctx, t, P, V) {
    var n = P.players.length, before = order(P), after = [], i, a0 = st(t, P, 0, 0.45, E.out5), mv = !P.adds ? 0 : (P.noIn ? 1 : E.io3(seg(t, 1.9, 2.6)));
    for (i = 0; i < n; i++) { after.push(i); }
    after.sort(function (x, y) { return (pts(P.players[y]) + P.players[y].a) - (pts(P.players[x]) + P.players[x].a) || x - y; });
    function one(g, pb, pa, a) {
      var y = 78 + (pb + (pa - pb) * mv) * 76, moving = pa !== pb && mv > 0 && mv < 1;
      ctx.save(); if (moving) { shadow(ctx, 18, 0.6); } box(ctx, 98, y, 442 * a, 68, 10, moving ? mix(P.bg, '#FFFFFF', 0.12) : P.bg, 0.96 * Math.min(1, a * 2)); ctx.restore();
      ctx.save(); clipRect(ctx, 98, y, 442 * a, 68);
      var ph = hasPhoto(g.p); if (ph) { face(ctx, P, g.p, 142, y + 34, 25, g.c, on(g.c), 1); }
      box(ctx, 98, y, 10, 68, 0, g.c, 1); text(ctx, g.p.n, ph ? 178 : 126, y + 36, P, 30, 700, on(P.bg), 'left', (g.a ? 220 : 290) - (ph ? 52 : 0));
      at(ctx, 522, y + 36, g.pop, function () { text(ctx, g.val, 0, 0, P, 36, 900, on(P.bg), 'right', 100); });
      if (g.a && g.chip > 0) { text(ctx, g.lab, 420, y + 36, P, 28, 900, g.lc || lit(g.c), 'right', 0, Math.min(1, g.chip)); }
      if (pa !== pb && mv > 0.5) { var up = pa < pb, tx = 356, ty = y + 34; ctx.beginPath(); ctx.moveTo(tx - 9, ty + (up ? 6 : -6)); ctx.lineTo(tx + 9, ty + (up ? 6 : -6)); ctx.lineTo(tx, ty + (up ? -8 : 8)); ctx.closePath(); fill(ctx, up ? '#2ECC71' : RED, (mv - 0.5) * 2); }
      ctx.restore();
    }
    box(ctx, 20, 10, 520 * a0, 58, 12, P.accent, 1); ctx.save(); clipRect(ctx, 20, 10, 520 * a0, 58); text(ctx, P.t1, 44, 41, P, 28, 800, on(P.accent), 'left', 470); ctx.restore();
    for (i = 0; i < n; i++) { var b = st(t, P, 0.1 + 0.09 * i, 0.4, E.back); at(ctx, 54, 78 + i * 76 + 34, b, function () { box(ctx, -34, -34, 68, 68, 10, i ? '#FFFFFF' : P.accent, 1); text(ctx, String(i + 1), 0, 2, P, 34, 900, on(i ? '#FFFFFF' : P.accent), 'center'); }); }
    for (i = 0; i < n; i++) { var pi = before[n - 1 - i], pb = n - 1 - i; one(gain(P, t, pi, true), pb, after.indexOf(pi), st(t, P, 0.1 + 0.09 * pb, 0.45, E.out5)); }
    for (i = 0; i < n; i++) { if (after.indexOf(before[i]) < i && mv > 0 && mv < 1) { one(gain(P, t, before[i], true), i, after.indexOf(before[i]), 1); } }
  };
  // 1000 × 160 — a thin strip for the top of the picture
  SC.strip = function (ctx, t, P, V) {
    var n = P.players.length, a = st(t, P, 0, 0.5, E.out5), lw = P.t1 ? Math.min(240, width(ctx, P.t1, P, 26, 800) + 44) : 0, cw = (980 - lw) / n, i;
    function one(g, x, b) {
      if (g.hit && g.k < 1) { ctx.fillStyle = g.c; ctx.globalAlpha = 0.55 * (1 - g.k); ctx.fillRect(x, 70, cw, 68); ctx.globalAlpha = 1; }
      if (cw < 175) { box(ctx, x + 12, 80, 6, 48, 3, g.c, b); text(ctx, g.p.n, x + 26, 90, P, 20, 600, on(P.bg), 'left', cw - 34, b * 0.85); at(ctx, x + 26, 119, g.pop, function () { text(ctx, g.val, 0, 0, P, 30, 900, on(P.bg), 'left', cw - 34, b); }); return; }
      box(ctx, x + 14, 96, 8, 20, 4, g.c, b); text(ctx, g.p.n, x + 30, 106, P, 26, 600, on(P.bg), 'left', cw - 108, b);
      at(ctx, x + cw - 18, 106, g.pop, function () { text(ctx, g.val, 0, 0, P, 32, 900, on(P.bg), 'right', 80, b); });
    }
    box(ctx, 10, 70, 980 * a, 68, 12, P.bg, 0.95);
    ctx.save(); rr(ctx, 10, 70, 980 * a, 68, 12); ctx.clip();
    if (lw) { ctx.fillStyle = P.accent; ctx.fillRect(10, 70, lw, 68); text(ctx, P.t1, 10 + lw / 2, 106, P, 26, 800, on(P.accent), 'center', lw - 20); }
    for (i = 0; i < n; i++) { if (i) { box(ctx, 10 + lw + i * cw, 84, 2, 40, 1, on(P.bg), 0.2); } one(gain(P, t, i), 10 + lw + i * cw, st(t, P, 0.15 + 0.07 * i, 0.4)); }
    ctx.restore();
    for (i = 0; i < n; i++) { flyLab(ctx, P, gain(P, t, i), 10 + lw + (cw < 175 ? i * cw + 44 : (i + 1) * cw - 40), 68, 42); }
  };

  // ---------------------------------------------------------------- the library
  var CATS = [
    { id: 'timer', name: 'წამზომები', hint: 'უკუთვლა ან წინ თვლა — დრო, ფონტი და ფერი შენია' },
    { id: 'lt', name: 'ქვედა ტიტრი', hint: 'სახელი და თანამდებობა, თემა, ადგილი, ციტატა' },
    { id: 'net', name: 'სოც. ქსელები', hint: 'შენი @სახელი სხვადასხვა პლატფორმისთვის' },
    { id: 'cta', name: 'ღილაკები', hint: 'გამოწერის, ლაიქის, კომენტარის და ბმულის მოწოდებები' },
    { id: 'vs', name: 'შეჯიბრი', hint: '2-დან 6 მონაწილემდე, თითოს თავისი ფერი: ქულები, ქულის დამატება ერთს ან რამდენიმეს, ცხრილი, პოდიუმი, გამარჯვებული' },
    { id: 'auto', name: 'ავტო', hint: 'ცხენის ძალა, 0–100, სპიდომეტრი, ნომერი, მახასიათებლები, შედარება' },
    { id: 'num', name: 'ციფრები', hint: 'მთვლელები, პროცენტი, შედარება, შეფასება, ფასი' },
    { id: 'stk', name: 'სათაურები', hint: 'სტიკერები, ბანერები, თავის სათაურები, გაფრთხილება' },
    { id: 'co', name: 'მინიშნებები', hint: 'ისრები, ხაზით მინიშნება, შემოხაზვა, ბუშტი' }
  ];
  var DESIGNS = [];
  function add(cat, id, name, w, h, fn, V, defs) {
    var d = { id: id, cat: cat, name: name, w: w, h: h, V: V || {}, defs: defs || {} };
    d.draw = function (ctx, t, P) {
      SK = d.V.skin || '';
      try { if (d.V.trim) { trim(ctx, d, t, P, d.V.trim); } if (d.V.enter) { entered(ctx, d, fn, t, P, d.V); } else { fn(ctx, t, P, d.V); } } finally { SK = ''; }
    };
    DESIGNS.push(d);
    return d;
  }
  function ext(V, more) { var o = {}, k; for (k in V) { if (V.hasOwnProperty(k)) { o[k] = V[k]; } } for (k in more) { if (more.hasOwnProperty(k)) { o[k] = more[k]; } } return o; }
  var SKIN = { grad: 'გრადიენტი', soft: 'ჩრდილით', hard: 'რეტრო ჩრდილი', glow: 'ნათება' };
  var ENTER = { pop: 'ამოხტომა', drop: 'ჩამოვარდნა', right: 'მარჯვნიდან', rise: 'ამოცურება', zoom: 'დაჯდომა', unfold: 'გაშლა', swing: 'გადმოქანება' };
  /** The same design in another skin or with another entrance, listed right after it. */
  function also(base, list) {
    for (var i = 0; i < list.length; i++) {
      var k = list[i], isSkin = !!SKIN[k];
      add(base.cat, base.id + '-' + k, base.name + ' · ' + (isSkin ? SKIN[k] : ENTER[k]), base.w, base.h, base.fn, ext(base.V, isSkin ? { skin: k } : { enter: k }), base.defs);
    }
  }
  function tm(id, name, w, h, fam, defs, more) {
    var f = { timer: true }, k; for (k in defs || {}) { if (defs.hasOwnProperty(k)) { f[k] = defs[k]; } }
    var d = add('timer', 't-' + id, name, w, h, TIMER[fam], null, f); d.fn = TIMER[fam];
    if (more) { also(d, more); }
  }
  tm('plain', 'სუფთა ციფრები', 640, 220, 'plain', null, ['pop', 'drop']);
  tm('line', 'ხაზით და წარწერით', 640, 220, 'line', { t1: 'დარჩა' }, ['rise']);
  tm('corner', 'კუთხის მინიმალი', 640, 220, 'corner', { t1: 'დაწყებამდე' });
  tm('dots', 'წერტილების რიგი', 640, 220, 'dots', null, ['pop']);
  tm('topbar', 'ზედა ზოლი (ეთერის სტილი)', 1000, 120, 'topbar', { t1: 'შესვენება' });
  tm('pill', 'კაფსულა წერტილით', 640, 220, 'pill', null, ['grad', 'glow', 'hard', 'drop']);
  tm('cards', 'ბარათები (ციფრი ცვივა)', 640, 220, 'cards', null, ['grad', 'soft', 'hard']);
  tm('split', 'წუთი და წამი ცალ-ცალკე', 640, 240, 'split', { t1: 'წთ', t2: 'წმ', fmt: 'mm:ss' }, ['grad', 'hard', 'pop']);
  tm('tagcard', 'ბარათი სათაურით', 640, 240, 'tagcard', { t1: 'შესვენება' }, ['soft', 'hard', 'unfold']);
  tm('bar', 'პროგრეს-ზოლი', 640, 220, 'bar', { t1: 'დრო' }, ['grad', 'soft', 'right']);
  tm('score', 'ტაბლო', 700, 220, 'score', { t1: 'რაუნდი 1' }, ['grad', 'hard']);
  tm('ring', 'რგოლი', 380, 380, 'ring', { t1: 'წამი' }, ['pop', 'zoom']);
  tm('pie', 'ნამცხვარი (ივსება)', 380, 380, 'pie', null, ['drop']);
  tm('gauge', 'ნახევარრკალი', 420, 300, 'gauge', { t1: 'დარჩა' }, ['rise']);
  tm('analog', 'ისრიანი წამზომი', 380, 400, 'analog', null, ['pop']);
  tm('badge', 'მრგვალი ბეჯი', 380, 380, 'badge', { t1: 'გამოწვევა', t2: 'წამი', fmt: 's' }, ['grad', 'swing']);
  tm('big', 'დიდი უკუთვლა (3-2-1)', 420, 420, 'big', { total: 5, fmt: 's' });
  tm('urgent', 'განგაში (ბოლო 5 წამი)', 640, 220, 'urgent', { total: 10, fmt: 's' });
  tm('neon', 'ნეონი', 640, 220, 'neon', null, ['zoom']);
  tm('led', 'ელექტრონული ტაბლო (LED)', 640, 220, 'led', { fmt: 'mm:ss' }, ['unfold']);
  tm('rec', 'კამერის REC', 640, 220, 'rec', { t1: 'REC' });
  tm('frame', 'ჩარჩო, რომელიც ივსება', 640, 220, 'frame', null, ['pop', 'zoom']);
  tm('fill', 'ფერით ივსება', 640, 220, 'fill', null, ['soft', 'hard', 'drop']);
  tm('label', 'წარწერა + დრო', 700, 220, 'label', { t1: 'შესვენება' }, ['grad', 'soft', 'right']);
  tm('lap', 'წრის დრო (მეასედებით)', 700, 220, 'label', { t1: 'წრე 1', fmt: 'ss.cc', down: false }, ['grad']);
  tm('quiz', 'ვიქტორინა: 10 წამი', 380, 380, 'pie', { total: 10, fmt: 's' }, ['pop']);
  tm('start', 'სტარტამდე', 640, 220, 'line', { t1: 'სტარტამდე', total: 10, fmt: 's' });
  tm('workout', 'ვარჯიში: მიდგომა', 640, 240, 'tagcard', { t1: 'მიდგომა 1', total: 45 }, ['grad']);
  tm('cook', 'სამზარეულოს ტაიმერი', 380, 380, 'ring', { t1: 'წუთი', total: 180 });
  tm('offer', 'შეთავაზება მთავრდება', 640, 240, 'split', { t1: 'წუთი', t2: 'წამი', fmt: 'mm:ss', total: 600 });

  var NAME = { t1: 'გოგა მელია', t2: 'რეჟისორი' };
  function lt(id, name, fam, V, defs, more) {
    var fn = LT[fam] || SOC[fam], d = add('lt', 'lt-' + id, name, 1000, 220, fn, V, defs || NAME); d.fn = fn;
    if (more) { also(d, more); }
  }
  lt('line', 'ხაზი მარცხნივ', 'line', {}, null, ['rise']);
  lt('line-thick', 'სქელი ხაზი', 'line', { thick: true });
  lt('line-two', 'ორმაგი ხაზი', 'line', { two: true });
  lt('line-r', 'ხაზი მარჯვნივ', 'line', { side: 'r' });
  lt('under', 'ხაზგასმა', 'under', { mode: 'full' });
  lt('under-short', 'მოკლე ხაზგასმა', 'under', { mode: 'short' });
  lt('under-center', 'ცენტრში, ხაზგასმით', 'under', { mode: 'center' }, null, ['zoom']);
  lt('rules', 'ორ ხაზს შორის', 'rules', {});
  lt('rules-center', 'ორ ხაზს შორის, ცენტრში', 'rules', { center: true });
  lt('box', 'ორი ყუთი', 'box', { style: 'solid' }, null, ['grad', 'hard', 'drop']);
  lt('box-duo', 'ფერადი ყუთი + მუქი', 'box', { style: 'duo' }, null, ['grad', 'soft', 'glow']);
  lt('box-outline', 'კონტურის ყუთი', 'box', { style: 'outline' });
  lt('box-glass', 'გამჭვირვალე ყუთი', 'box', { style: 'glass' });
  lt('box-skew', 'დახრილი ყუთები', 'box', { style: 'solid', skew: true }, null, ['right']);
  lt('box-duo-skew', 'დახრილი, ფერადი', 'box', { style: 'duo', skew: true }, null, ['grad']);
  lt('box-round', 'მომრგვალებული ყუთები', 'box', { style: 'duo', round: true }, null, ['grad', 'pop']);
  lt('tag', 'კვადრატი ინიციალით', 'tag', { shape: 'sq' }, null, ['grad']);
  lt('tag-circle', 'წრე ინიციალით', 'tag', { shape: 'circle' });
  lt('tag-diamond', 'რომბი ინიციალით', 'tag', { shape: 'diamond' });
  lt('bracket', 'კუთხის ფრჩხილები', 'bracket', { mode: 'corners' });
  lt('bracket-sides', 'გვერდითი ფრჩხილები', 'bracket', { mode: 'sides' });
  lt('strip', 'მთლიანი ზოლი', 'strip', { mode: 'full' }, null, ['grad']);
  lt('strip-fade', 'ქრებადი ზოლი', 'strip', { mode: 'fade' });
  lt('strip-news', 'ახალი ამბების ზოლი', 'strip', { mode: 'news' }, { t1: 'ახალი მოდელი უკვე საქართველოშია', t2: 'ახალი ამბები' }, ['grad']);
  lt('live', 'პირდაპირი ეთერი', 'live', {}, { t1: 'გოგა მელია', t2: 'თბილისი, საქართველო', t3: 'LIVE' });
  lt('live-brand', 'ბეჯი + სახელი (შენი ფერი)', 'live', { brand: true }, { t1: 'გოგა მელია', t2: 'სპეციალური სტუმარი', t3: 'ახალი' });
  lt('pill', 'მუქი კაფსულა', 'pill', { tone: 'dark' }, null, ['soft', 'drop']);
  lt('pill-light', 'თეთრი კაფსულა', 'pill', { tone: 'light' }, null, ['hard']);
  lt('pill-accent', 'ფერადი კაფსულა', 'pill', { tone: 'accent' }, null, ['grad', 'glow']);
  lt('stack', 'დიდი სახელი — ამოსვლა', 'stack', { mode: 'rise' });
  lt('stack-wipe', 'დიდი სახელი — გახსნა', 'stack', { mode: 'wipe' });
  lt('stack-split', 'დიდი სახელი — გაყოფა', 'stack', { mode: 'split' });
  lt('tape', 'სკოჩი', 'tape', { angle: -3 }, null, ['hard']);
  lt('tape-up', 'სკოჩი, აწეული', 'tape', { angle: 3 });
  lt('corner', 'კუთხე ქვემოდან', 'corner', {});
  lt('corner-up', 'კუთხე ზემოდან', 'corner', { up: true });
  lt('slash', 'დახრილი ფირფიტა', 'slash', {}, null, ['right']);
  lt('slash-dark', 'დახრილი, მუქი', 'slash', { dark: true }, null, ['grad']);
  lt('place', 'ადგილი და თარიღი', 'line', { thick: true }, { t1: 'თბილისი', t2: '17 ნოემბერი, 2026' });
  lt('pin', 'ლოკაცია (ნიშნულით)', 'cta', { icon: 'pin' }, { t1: 'ბათუმი, საქართველო', t2: 'გადაღების ადგილი' }, ['soft']);
  lt('topic', 'თემა (ცენტრში)', 'under', { mode: 'center' }, { t1: 'ნაწილი 1', t2: 'როგორ დაიწყო ყველაფერი' });
  lt('quote', 'ციტატა', 'cta', { icon: 'quote', tone: 'dark' }, { t1: 'მთავარია დაიწყო', t2: '— გოგა მელია' });
  lt('hash', 'ჰეშთეგი', 'cta', { icon: 'hash' }, { t1: '#meliavision', t2: 'გამოიყენე ჩვენი ჰეშთეგი' }, ['pop']);
  lt('star', 'შეფასება / ფაქტი', 'cta', { icon: 'star', tone: 'dark' }, { t1: 'იცოდი?', t2: 'საინტერესო ფაქტი' });
  lt('phone', 'ტელეფონის ნომერი', 'cta', { icon: 'phone' }, { t1: '+995 555 00 00 00', t2: 'დაგვირეკე' });
  lt('price', 'ფასი / შეთავაზება', 'cta', { icon: 'cart', tone: 'dark' }, { t1: '199 ₾-დან', t2: 'შეუკვეთე ახლავე' }, ['grad']);
  lt('ticker', 'მორბენალი სტრიქონი', 'ticker', {}, { t1: 'ახალი ვიდეო ყოველ პარასკევს · გამოიწერე არხი · ჩართე შეტყობინებები', t2: 'სიახლე', dur: 8 }, ['grad']);
  lt('ticker-sport', 'მორბენალი სტრიქონი — შედეგები', 'ticker', {}, { t1: 'ფინალი: დინამო 2:1 ტორპედო · შემდეგი ტური შაბათს', t2: 'სპორტი', dur: 8 });
  lt('credit', 'ტიტრი: როლი და სახელი', 'credit', {}, { t1: 'გოგა მელია', t2: 'რეჟისორი' }, ['zoom']);
  lt('credit-left', 'ტიტრი მარცხნივ', 'credit', { left: true }, { t1: 'ანი', t2: 'მონტაჟი' });
  lt('duo', 'ორი სტუმარი', 'duo', {}, { t1: 'გოგა მელია', t2: 'წამყვანი', t3: 'დავით ნუცუბიძე', t4: 'სტუმარი' }, ['rise']);
  lt('guest', 'სტუმარი (ბეჯით)', 'live', { brand: true }, { t1: 'დავით ნუცუბიძე', t2: 'ბლოგერი', t3: 'სტუმარი' });
  lt('song', 'სიმღერა / მუსიკა', 'cta', { icon: 'play', tone: 'dark' }, { t1: 'სიმღერის სახელი', t2: 'შემსრულებელი' });
  lt('source', 'წყარო', 'under', { mode: 'short' }, { t1: 'წყარო: Reuters', t2: '17 ნოემბერი, 2026' });

  var k, HANDLE = { t1: '@meliavision' }, d0;
  NET.dc = { name: 'Discord', mono: 'DC', c: ['#5865F2'] }; NET.pn = { name: 'Pinterest', mono: 'PN', c: ['#E60023'] };
  NET.sc = { name: 'Snapchat', mono: 'SC', c: ['#FFFC00'] }; NET.sp = { name: 'Spotify', mono: 'SP', c: ['#1DB954'] };
  NET.rd = { name: 'Reddit', mono: 'RD', c: ['#FF4500'] }; NET.be = { name: 'Behance', mono: 'BE', c: ['#1769FF'] }; NET.gh = { name: 'GitHub', mono: 'GH', c: ['#181717'] };
  NET.vm = { name: 'Vimeo', mono: 'VM', c: ['#1AB7EA'] }; NET.pt = { name: 'Patreon', mono: 'PT', c: ['#FF424D'] }; NET.kk = { name: 'Kick', mono: 'KK', c: ['#53FC18'] };
  NET.web = { name: 'ვებგვერდი', mono: 'www', c: ['#2B2B2B'] }; NET.mail = { name: 'ელფოსტა', mono: '@', c: ['#4A4A4A'] };
  for (k in NET) { if (NET.hasOwnProperty(k)) { d0 = add('net', 'net-' + k, NET[k].name + ' — კაფსულა', 1000, 220, SOC.handle, { net: k }, { t1: HANDLE.t1, t2: NET[k].name }); } }
  for (k in NET) { if (NET.hasOwnProperty(k)) { add('net', 'net-' + k + '-tile', NET[k].name + ' — დიდი ფილა', 1000, 220, SOC.tile, { net: k }, { t1: HANDLE.t1, t2: NET[k].name }); } }
  for (k in NET) { if (NET.hasOwnProperty(k)) { add('net', 'net-' + k + '-card', NET[k].name + ' — ბარათი', 1000, 220, SOC.handle, { net: k, card: true, tone: 'light' }, { t1: HANDLE.t1, t2: 'გამოგვყევი ' + NET[k].name + '-ზე' }); } }
  var LIGHT = ['yt', 'ig', 'tt', 'fb', 'tg'];
  for (k = 0; k < LIGHT.length; k++) { add('net', 'net-' + LIGHT[k] + '-light', NET[LIGHT[k]].name + ' — თეთრი კაფსულა', 1000, 220, SOC.handle, { net: LIGHT[k], tone: 'light' }, { t1: HANDLE.t1, t2: NET[LIGHT[k]].name }); }
  add('net', 'net-multi-3', 'სამი ქსელი ერთად (YT · IG · TT)', 1000, 220, SOC.multi, { nets: ['yt', 'ig', 'tt'] }, HANDLE);
  add('net', 'net-multi-fb', 'სამი ქსელი ერთად (FB · IG · TG)', 1000, 220, SOC.multi, { nets: ['fb', 'ig', 'tg'] }, HANDLE);
  add('net', 'net-multi-2', 'ორი ქსელი ერთად (IG · TT)', 1000, 220, SOC.multi, { nets: ['ig', 'tt'] }, HANDLE);

  function cta(id, name, fam, V, defs, more) { var d = add('cta', id, name, 1000, fam === 'combo' ? 240 : 220, SOC[fam], V, defs); d.fn = SOC[fam]; if (more) { also(d, more); } }
  var SUB = { t1: 'Melia Vision', t2: '12.4K გამომწერი', t3: 'გამოწერა', t4: 'გამოწერილია', dur: 4 };
  cta('sub-yt', 'გამოწერის ღილაკი (წითელი)', 'sub', { net: 'yt' }, SUB, ['pop', 'drop']);
  cta('sub-brand', 'გამოწერის ღილაკი (შენი ფერი)', 'sub', {}, SUB, ['grad', 'glow']);
  cta('sub-channel', 'არხი + გამოწერა', 'sub', { net: 'yt', channel: true }, SUB, ['soft', 'rise']);
  cta('sub-channel-brand', 'არხი + გამოწერა (შენი ფერი)', 'sub', { channel: true }, SUB, ['hard']);
  var FOL = { t1: '@meliavision', t2: 'Melia Vision', t3: 'გამოწერა', t4: 'გამოწერილია', dur: 4 }, FN = ['ig', 'tt', 'fb', 'x', 'th', 'li', 'tw', 'pn', 'sc', 'sp', 'rd', 'be', 'gh', 'vm', 'pt', 'kk'];
  for (k = 0; k < FN.length; k++) { cta('fol-' + FN[k], NET[FN[k]].name + ' — Follow', 'follow', { net: FN[k] }, FOL); }
  cta('fol-tg', 'Telegram — შემოგვიერთდი', 'follow', { net: 'tg' }, { t1: '@meliavision', t2: 'Telegram არხი', t3: 'შემოსვლა', t4: 'შემოერთდი', dur: 4 });
  cta('fol-dc', 'Discord — შემოგვიერთდი', 'follow', { net: 'dc' }, { t1: 'Melia Vision', t2: 'Discord სერვერი', t3: 'შემოსვლა', t4: 'შემოერთდი', dur: 4 });
  cta('fol-wa', 'WhatsApp — მოგვწერე', 'follow', { net: 'wa' }, { t1: '+995 555 00 00 00', t2: 'WhatsApp', t3: 'მიწერა', t4: 'გაიგზავნა', dur: 4 });
  cta('like', 'ლაიქი', 'like', { icon: 'thumb' }, { t1: 'მოგეწონა?', t2: 'დაგვილაიქე', dur: 4 }, ['pop']);
  cta('like-heart', 'გული', 'like', { icon: 'heart' }, { t1: 'ორჯერ დააჭირე', t2: 'თუ მოგეწონა', dur: 4 });
  cta('like-star', 'ვარსკვლავი (შეაფასე)', 'like', { icon: 'star' }, { t1: 'შეგვაფასე', t2: '5 ვარსკვლავით', dur: 4 });
  cta('like-count', 'ლაიქი მთვლელით', 'like', { icon: 'thumb', count: true }, { t1: 'ლაიქები', t2: '1249', dur: 4 });
  cta('like-heart-count', 'გული მთვლელით', 'like', { icon: 'heart', count: true }, { t1: 'მოწონებები', t2: '9999', dur: 4 });
  cta('combo', 'ლაიქი · გამოწერა · ზარი', 'combo', {}, { t1: 'ლაიქი', t2: 'გამოწერა', t3: 'ზარი', dur: 4.5 }, ['rise']);
  cta('combo-social', 'გული · კომენტარი · გაზიარება', 'combo', { set: 'social' }, { t1: 'მოიწონე', t2: 'დაწერე', t3: 'გააზიარე', dur: 4.5 });
  cta('combo-save', 'გული · შენახვა · გაგზავნა', 'combo', { set: 'save' }, { t1: 'მოიწონე', t2: 'შეინახე', t3: 'გაუგზავნე', dur: 4.5 });
  cta('cta-link', 'ბმული აღწერაში', 'cta', { icon: 'link' }, { t1: 'ბმული აღწერაშია', t2: 'იხილე ვიდეოს ქვემოთ', dur: 4 }, ['soft']);
  cta('cta-bio', 'ბმული ბიოში', 'cta', { icon: 'link', tone: 'dark' }, { t1: 'ბმული ბიოშია', t2: 'გადადი პროფილზე', dur: 4 });
  cta('cta-comment', 'დაწერე კომენტარი', 'cta', { icon: 'comment' }, { t1: 'შენ რას ფიქრობ?', t2: 'დაგვიწერე კომენტარებში', dur: 4 }, ['pop']);
  cta('cta-share', 'გააზიარე', 'cta', { icon: 'share' }, { t1: 'გაუზიარე მეგობარს', t2: 'ვისაც გამოადგება', dur: 4 });
  cta('cta-save', 'შეინახე', 'cta', { icon: 'save', tone: 'dark' }, { t1: 'შეინახე', t2: 'რომ არ დაგეკარგოს', dur: 4 });
  cta('cta-bell', 'ჩართე ზარი', 'cta', { icon: 'bell', tone: 'dark' }, { t1: 'ჩართე შეტყობინებები', t2: 'ახალი ვიდეო ყოველ კვირას', dur: 4 }, ['glow']);
  cta('cta-next', 'შემდეგი ვიდეო', 'cta', { icon: 'play' }, { t1: 'უყურე შემდეგ ვიდეოს', t2: 'ბმული ეკრანზეა', dur: 4 });
  cta('cta-full', 'სრული ვიდეო არხზე', 'cta', { icon: 'play', tone: 'dark' }, { t1: 'სრული ვიდეო არხზეა', t2: 'ბმული აღწერაში', dur: 4 });
  cta('cta-swipe', 'აწიე ზემოთ', 'cta', { icon: 'up' }, { t1: 'აწიე ზემოთ', t2: 'მეტის სანახავად', dur: 4 });
  cta('cta-dm', 'მოგვწერე პირადში', 'cta', { icon: 'send' }, { t1: 'მოგვწერე პირადში', t2: 'გიპასუხებთ მალე', dur: 4 }, ['grad']);
  cta('cta-shop', 'შეიძინე', 'cta', { icon: 'cart' }, { t1: 'შეიძინე ახლავე', t2: 'ბმული აღწერაშია', dur: 4 });
  cta('cta-download', 'ჩამოტვირთე', 'cta', { icon: 'down', tone: 'dark' }, { t1: 'ჩამოტვირთე უფასოდ', t2: 'ბმული აღწერაშია', dur: 4 });
  cta('cta-call', 'დაგვირეკე', 'cta', { icon: 'phone' }, { t1: 'დაგვირეკე', t2: '+995 555 00 00 00', dur: 4 });
  cta('cta-visit', 'გვესტუმრე', 'cta', { icon: 'pin', tone: 'dark' }, { t1: 'გვესტუმრე', t2: 'თბილისი, ჭავჭავაძის 1', dur: 4 });
  cta('cta-follow', 'გამოგვყევი', 'cta', { icon: 'user' }, { t1: 'გამოგვყევი', t2: 'ახალი ვიდეოები ყოველდღე', dur: 4 }, ['hard']);

  function xx(cat, id, name, w, h, fam, V, defs, more) { var d = add(cat, id, name, w, h, X[fam] || LT[fam] || SOC[fam], V, defs); d.fn = X[fam] || LT[fam] || SOC[fam]; if (more) { also(d, more); } }
  var L3 = { t1: 'რიცხვი', t2: 'ერთეული', t3: 'წარწერა' }, LR = { t1: 'სათაური', t2: 'სტრიქონი 1 (სახელი | მნიშვნელობა)', t3: 'სტრიქონი 2', t4: 'სტრიქონი 3' };
  function S(t1, t2, t3) { return { t1: t1, t2: t2, t3: t3, labels: L3, dur: 5 }; }
  // --- cars
  xx('auto', 'a-hp', 'ცხენის ძალა', 700, 240, 'stat', {}, S('510', 'ცხ.ძ.', 'სიმძლავრე'), ['pop']);
  xx('auto', 'a-0100', '0–100 კმ/სთ', 700, 240, 'stat', { style: 'line' }, S('3.2', 'წმ', '0–100 კმ/სთ'));
  xx('auto', 'a-top', 'მაქსიმალური სიჩქარე', 700, 240, 'stat', {}, S('280', 'კმ/სთ', 'მაქსიმალური სიჩქარე'), ['right']);
  xx('auto', 'a-torque', 'ბრუნვის მომენტი', 700, 240, 'stat', { style: 'card' }, S('650', 'ნმ', 'ბრუნვის მომენტი'), ['grad']);
  xx('auto', 'a-weight', 'წონა', 700, 240, 'stat', { style: 'card' }, S('1 850', 'კგ', 'წონა'), ['soft']);
  xx('auto', 'a-price', 'ფასი', 700, 240, 'stat', { style: 'split' }, S('45 000', '$', 'ფასი საქართველოში'), ['grad', 'hard']);
  xx('auto', 'a-fuel', 'საწვავის ხარჯი', 700, 240, 'stat', { style: 'split' }, S('8.4', 'ლ/100კმ', 'საშუალო ხარჯი'));
  xx('auto', 'a-range', 'ელექტრო მარაგი', 700, 240, 'stat', { style: 'line' }, S('480', 'კმ', 'ერთი დატენვით'));
  xx('auto', 'a-engine', 'ძრავა', 700, 240, 'stat', { style: 'split' }, S('4.0', 'V8 ბი-ტურბო', 'ძრავა'), ['glow']);
  xx('auto', 'a-mileage', 'გარბენი', 700, 240, 'stat', { style: 'card' }, S('86 000', 'კმ', 'გარბენი'));
  xx('auto', 'a-speedo', 'სპიდომეტრი', 420, 420, 'dial', {}, { t1: '280', t2: 'კმ/სთ', labels: { t1: 'სიჩქარე', t2: 'ერთეული' }, dur: 5 }, ['pop']);
  xx('auto', 'a-speedo-300', 'სპიდომეტრი (300-მდე)', 420, 420, 'dial', { max: 300 }, { t1: '250', t2: 'კმ/სთ', labels: { t1: 'სიჩქარე', t2: 'ერთეული' }, dur: 5 }, ['soft']);
  xx('auto', 'a-tacho', 'ტაქომეტრი (წითელი ზონით)', 420, 420, 'dial', { red: true, max: 8000, div: 1000 }, { t1: '7200', t2: 'ბრ/წთ ×1000', labels: { t1: 'ბრუნი', t2: 'ერთეული' }, dur: 5 }, ['zoom']);
  xx('auto', 'a-boost', 'ტურბოს წნევა', 420, 420, 'dial', { max: 2, red: true }, { t1: '1.4', t2: 'ბარი', labels: { t1: 'წნევა', t2: 'ერთეული' }, dur: 5 });
  xx('auto', 'a-plate', 'ნომერი (თეთრი)', 760, 220, 'plate', {}, { t1: 'AA-001-AA', t2: 'GE', labels: { t1: 'ნომერი', t2: 'ქვეყანა' } }, ['drop']);
  xx('auto', 'a-plate-dark', 'ნომერი (შავი)', 760, 220, 'plate', { tone: 'dark', strip: '#FD4A00' }, { t1: 'MELIA-01', t2: 'GE', labels: { t1: 'ნომერი', t2: 'ქვეყანა' } });
  xx('auto', 'a-plate-yellow', 'ნომერი (ყვითელი)', 760, 220, 'plate', { tone: 'yellow', plain: true }, { t1: 'TURBO S', labels: { t1: 'წარწერა' } });
  xx('auto', 'a-plate-model', 'მოდელის ფირფიტა', 760, 220, 'plate', { plain: true }, { t1: '911 GT3 RS', labels: { t1: 'მოდელი' } }, ['zoom']);
  xx('auto', 'a-specs', 'მახასიათებლების ბარათი', 760, 330, 'specs', {}, { t1: 'Porsche Taycan Turbo S', t2: 'ძრავა | 2 ელექტრომოტორი', t3: 'სიმძლავრე | 761 ცხ.ძ.', t4: '0–100 | 2.8 წმ', labels: LR, dur: 6 }, ['grad', 'soft', 'unfold']);
  xx('auto', 'a-specs-used', 'განცხადების ბარათი', 760, 330, 'specs', {}, { t1: 'Subaru Crosstrek 2015', t2: 'გარბენი | 86 000 კმ', t3: 'ძრავა | 2.0 ბენზინი', t4: 'ფასი | 9 500 $', labels: LR, dur: 6 });
  xx('auto', 'a-versus', 'შედარება (VS)', 1000, 260, 'versus', {}, { t1: 'BMW M3', t2: 'Mercedes C63', t3: '510 ცხ.ძ.', t4: '476 ცხ.ძ.', labels: { t1: 'მარცხენა', t2: 'მარჯვენა', t3: 'მარცხენას ქვეშ', t4: 'მარჯვენას ქვეშ' }, dur: 5 }, ['grad']);
  xx('auto', 'a-versus-drag', 'დრაგი: ვინ მოიგებს?', 1000, 260, 'versus', {}, { t1: 'პროფესიონალი', t2: 'დამწყები', t3: 'ჟიგული', t4: 'პორშე', dur: 5 });
  xx('auto', 'a-battery', 'ბატარეა (ელექტრომობილი)', 640, 240, 'battery', { green: true }, { t1: '80%', t2: 'მარაგი 420 კმ', labels: { t1: 'დატენვა %', t2: 'წარწერა' }, dur: 5 });
  xx('auto', 'a-battery-brand', 'ბატარეა (შენი ფერი)', 640, 240, 'battery', {}, { t1: '100%', t2: 'დატენილია', labels: { t1: 'დატენვა %', t2: 'წარწერა' }, dur: 5 });
  xx('auto', 'a-flag-start', 'სტარტი (ფინიშის დროშა)', 1000, 200, 'flag', {}, { t1: 'სტარტი' });
  xx('auto', 'a-flag-finish', 'ფინიში', 1000, 200, 'flag', {}, { t1: 'ფინიში' });
  xx('auto', 'a-p1', 'ადგილი: P1', 380, 380, 'medal', {}, { t1: 'P1', t2: 'ადგილი', t3: '1:42.318', labels: { t1: 'ადგილი', t2: 'ზედა', t3: 'ქვედა' } }, ['drop']);
  xx('auto', 'a-lap', 'საუკეთესო წრე', 380, 380, 'medal', { burst: true }, { t1: '1:42', t2: 'საუკეთესო წრე', t3: 'ნიურბურგრინგი', labels: { t1: 'დრო', t2: 'ზედა', t3: 'ქვედა' } });
  xx('auto', 'a-model', 'მოდელი და წელი', 1000, 220, 'box', { style: 'duo' }, { t1: 'Porsche 911 Turbo S', t2: '2024 · 650 ცხ.ძ.' }, ['grad']);
  xx('auto', 'a-model-line', 'მოდელი (ხაზით)', 1000, 220, 'line', { thick: true }, { t1: 'Mercedes-AMG G 63', t2: '4.0 V8 · 585 ცხ.ძ.' });
  xx('auto', 'a-model-slash', 'მოდელი (სპორტული)', 1000, 220, 'slash', { dark: true }, { t1: 'BMW M5 Competition', t2: '0–100: 3.3 წმ' }, ['right']);
  xx('auto', 'a-model-big', 'მოდელი (დიდი სახელი)', 1000, 220, 'stack', { mode: 'wipe' }, { t1: 'BYD Shark 6', t2: 'პიკაპი · ჰიბრიდი' });
  xx('auto', 'a-owner', 'მფლობელი / მრბოლელი', 1000, 220, 'tag', { shape: 'sq' }, { t1: 'გოგა მელია', t2: 'მრბოლელი · გუნდი Melia' });
  xx('auto', 'a-service', 'სერვისი / დეტეილინგი', 1000, 220, 'cta', { icon: 'star', tone: 'dark' }, { t1: 'კერამიკული დაფარვა', t2: 'Racing Line Detailing' });
  xx('auto', 'a-location', 'ტრასა / ადგილი', 1000, 220, 'cta', { icon: 'pin' }, { t1: 'რუსთავის ავტოდრომი', t2: 'წრის სიგრძე 4.1 კმ' });
  xx('auto', 'a-news', 'ავტო სიახლე (ზოლი)', 1000, 220, 'strip', { mode: 'news' }, { t1: 'ახალი მოდელი უკვე საქართველოშია', t2: 'ავტო სიახლე' });
  xx('auto', 'a-ticker', 'ავტო სიახლეები — მორბენალი', 1000, 220, 'ticker', {}, { t1: 'ელექტრომობილების გაყიდვები 30%-ით გაიზარდა · ახალი G-Class უკვე თბილისშია', t2: 'ავტო', dur: 8 });
  xx('auto', 'a-bars', 'ორი მანქანის შედარება (ზოლებით)', 900, 300, 'bars', {}, { t1: 'Taycan Turbo S | 761 ცხ.ძ.', t2: 'Model S Plaid | 1020 ცხ.ძ.', labels: { t1: 'პირველი (სახელი | მნიშვნელობა)', t2: 'მეორე' }, dur: 5 });
  xx('auto', 'a-rating', 'ჩვენი შეფასება', 700, 200, 'stars', { brand: true }, { t1: '4.5', t2: 'ჩვენი შეფასება', labels: { t1: 'შეფასება (0–5)', t2: 'წარწერა' }, dur: 4 });
  // --- numbers
  xx('num', 'n-views', 'ნახვების მთვლელი', 700, 240, 'stat', {}, S('1 000 000', 'ნახვა', 'გმადლობთ!'), ['pop']);
  xx('num', 'n-subs', 'გამომწერების მთვლელი', 700, 240, 'stat', { style: 'card' }, S('50 000', 'გამომწერი', 'ერთად გავიზარდეთ'), ['grad', 'soft']);
  xx('num', 'n-money', 'თანხა', 700, 240, 'stat', { style: 'split' }, S('1 250', '₾', 'ბიუჯეტი'), ['hard']);
  xx('num', 'n-fact', 'ფაქტი ციფრებში', 700, 240, 'stat', { style: 'line' }, S('73', '%', 'ადამიანების ასე ფიქრობს'), ['rise']);
  xx('num', 'n-years', 'წლები / გამოცდილება', 700, 240, 'stat', {}, S('12', 'წელი', 'გამოცდილება'));
  xx('num', 'n-distance', 'მანძილი', 700, 240, 'stat', { style: 'card' }, S('2 400', 'კმ', 'გავლილი გზა'));
  xx('num', 'n-pct', 'პროცენტის რგოლი', 380, 380, 'pct', {}, { t1: '87%', t2: 'დასრულებულია', labels: { t1: 'პროცენტი', t2: 'წარწერა' }, dur: 5 }, ['pop', 'drop']);
  xx('num', 'n-pct-open', 'პროცენტის რგოლი (ფონის გარეშე)', 380, 380, 'pct', { open: true }, { t1: '64%', t2: 'მომხრე', labels: { t1: 'პროცენტი', t2: 'წარწერა' }, dur: 5 });
  xx('num', 'n-bars', 'ორი ზოლის შედარება', 900, 300, 'bars', {}, { t1: 'გასული წელი | 1 200', t2: 'წელს | 3 400', labels: { t1: 'პირველი (სახელი | მნიშვნელობა)', t2: 'მეორე' }, dur: 5 }, ['rise']);
  xx('num', 'n-poll', 'გამოკითხვის შედეგი', 900, 300, 'bars', {}, { t1: 'კი | 68%', t2: 'არა | 32%', labels: { t1: 'პირველი (სახელი | მნიშვნელობა)', t2: 'მეორე' }, dur: 5 });
  xx('num', 'n-stars', 'ვარსკვლავებით შეფასება', 700, 200, 'stars', {}, { t1: '4.8', t2: 'მომხმარებლების შეფასება', labels: { t1: 'შეფასება (0–5)', t2: 'წარწერა' }, dur: 4 });
  xx('num', 'n-stars-brand', 'შეფასება (შენი ფერი)', 700, 200, 'stars', { brand: true }, { t1: '5', t2: 'გირჩევთ!', labels: { t1: 'შეფასება (0–5)', t2: 'წარწერა' }, dur: 4 });
  xx('num', 'n-steps', 'ნაბიჯები (2 / 5)', 800, 180, 'steps', {}, { t1: '2/5', t2: 'ნაბიჯი 2: მომზადება', labels: { t1: 'რომელი / სულ', t2: 'წარწერა' } });
  xx('num', 'n-steps-3', 'ნაბიჯები (1 / 3)', 800, 180, 'steps', {}, { t1: '1/3', t2: 'ნაწილი პირველი', labels: { t1: 'რომელი / სულ', t2: 'წარწერა' } });
  xx('num', 'n-price', 'ძველი ფასი → ახალი', 760, 240, 'price', {}, { t1: '299 ₾', t2: '199 ₾', t3: 'მხოლოდ ამ კვირაში', labels: { t1: 'ძველი ფასი', t2: 'ახალი ფასი', t3: 'წარწერა' } }, ['soft']);
  xx('num', 'n-rank', 'ადგილი სიაში (#1)', 380, 380, 'medal', {}, { t1: '#1', t2: 'ტოპ 5', t3: 'ადგილი', labels: { t1: 'ნომერი', t2: 'ზედა', t3: 'ქვედა' } }, ['swing']);
  xx('num', 'n-rank-burst', 'ნომერი (ვარსკვლავა)', 380, 380, 'medal', { burst: true }, { t1: '5', t2: 'ტოპ', t3: 'მიზეზი', labels: { t1: 'ნომერი', t2: 'ზედა', t3: 'ქვედა' } });
  xx('num', 'n-gauge', 'მაჩვენებელი ისრით', 420, 420, 'dial', { max: 100 }, { t1: '72', t2: 'ქულა 100-დან', labels: { t1: 'მნიშვნელობა', t2: 'წარწერა' }, dur: 5 });
  xx('num', 'n-battery', 'ენერგია / დატვირთვა', 640, 240, 'battery', {}, { t1: '35%', t2: 'დარჩენილი ენერგია', labels: { t1: 'პროცენტი', t2: 'წარწერა' }, dur: 5 });
  // --- titles and stickers
  var LS = { t1: 'მთავარი', t2: 'ზედა', t3: 'ქვედა' };
  xx('stk', 's-sale', 'ფასდაკლების სტიკერი', 380, 380, 'medal', { burst: true, tilt: true }, { t1: '-50%', t2: 'ფასდაკლება', t3: 'მხოლოდ დღეს', labels: LS }, ['drop']);
  xx('stk', 's-new', 'სტიკერი „ახალი“', 380, 380, 'medal', { burst: true }, { t1: 'ახალი', t2: '', t3: '', labels: LS }, ['swing']);
  xx('stk', 's-round', 'მრგვალი ბეჯი', 380, 380, 'medal', { tilt: true }, { t1: 'TOP', t2: 'რედაქციის', t3: 'არჩევანი', labels: LS });
  xx('stk', 's-free', 'უფასოდ', 380, 380, 'medal', {}, { t1: '0 ₾', t2: 'სრულიად', t3: 'უფასოდ', labels: LS }, ['zoom']);
  xx('stk', 's-ribbon', 'ლენტი', 900, 220, 'ribbon', {}, { t1: 'ახალი ვიდეო', t2: 'ყოველ პარასკევს' }, ['drop', 'grad']);
  xx('stk', 's-ribbon-win', 'ლენტი — გამარჯვებული', 900, 220, 'ribbon', {}, { t1: 'გამარჯვებული', t2: 'გილოცავთ!' });
  xx('stk', 's-chapter', 'თავის ნომერი (კონტური)', 900, 260, 'chapter', {}, { t1: '01', t2: 'დასაწყისი', t3: 'ნაწილი', labels: { t1: 'ნომერი', t2: 'სათაური', t3: 'ზედა წარწერა' } }, ['rise']);
  xx('stk', 's-chapter-solid', 'თავის ნომერი (სავსე)', 900, 260, 'chapter', { solid: true }, { t1: '02', t2: 'როგორ მუშაობს', t3: 'ნაწილი', labels: { t1: 'ნომერი', t2: 'სათაური', t3: 'ზედა წარწერა' } });
  xx('stk', 's-top', 'ტოპ სიის პუნქტი', 900, 260, 'chapter', { solid: true }, { t1: '#5', t2: 'ყველაზე სწრაფი სედანი', t3: 'ტოპ 5', labels: { t1: 'ნომერი', t2: 'სათაური', t3: 'ზედა წარწერა' } }, ['right']);
  xx('stk', 's-warn', 'გაფრთხილების ზოლი', 1000, 160, 'warn', {}, { t1: 'ყურადღება', t2: 'არ გაიმეოროთ სახლში' });
  xx('stk', 's-warn-brand', 'ყურადღების ზოლი (შენი ფერი)', 1000, 160, 'warn', { brand: true }, { t1: 'სპონსორის დრო', t2: 'ვიდეოს მხარდამჭერი' });
  xx('stk', 's-stamp', 'ბეჭედი', 520, 300, 'stamp', {}, { t1: 'შემოწმებულია', t2: 'MELIA VISION' });
  xx('stk', 's-stamp-red', 'ბეჭედი (წითელი)', 520, 300, 'stamp', { red: true }, { t1: 'უარყოფილია', t2: 'მითი' });
  xx('stk', 's-stamp-fact', 'ბეჭედი — ფაქტი', 520, 300, 'stamp', {}, { t1: 'ფაქტია', t2: 'დადასტურებული' });
  xx('stk', 's-title', 'დიდი სათაური ხაზებს შორის', 1000, 300, 'bigtitle', {}, { t1: 'ისტორია', t2: 'როგორ შეიქმნა ლეგენდა' }, ['zoom']);
  xx('stk', 's-title-wide', 'დიდი სათაური, ნელი მოახლოება', 1000, 300, 'bigtitle', { wide: true }, { t1: 'ფინალი', t2: 'ბოლო ეპიზოდი', dur: 6 });
  xx('stk', 's-date', 'თარიღის ბარათი', 820, 220, 'datecard', {}, { t1: '17', t2: 'ნოემ', t3: 'პრემიერა', t4: 'საღამოს 8 საათზე', labels: { t1: 'რიცხვი', t2: 'თვე', t3: 'სათაური', t4: 'ქვედა ხაზი' } }, ['rise']);
  xx('stk', 's-soon', 'მალე', 1000, 220, 'pill', { tone: 'accent' }, { t1: 'მალე', t2: 'ახალი სეზონი' }, ['pop']);
  xx('stk', 's-live', 'პირდაპირი ეთერი იწყება', 1000, 220, 'live', {}, { t1: 'ვიწყებთ 5 წუთში', t2: 'დარჩით ჩვენთან', t3: 'LIVE' });
  xx('stk', 's-flag', 'დროშის ბანერი', 1000, 200, 'flag', {}, { t1: 'გამოწვევა' });
  xx('stk', 's-tape', 'სკოჩის სათაური', 1000, 220, 'tape', { angle: -4 }, { t1: 'ექსპერიმენტი', t2: 'ნაწილი 3' }, ['hard']);
  xx('stk', 's-topic', 'თემა ორ ხაზს შორის', 1000, 220, 'rules', { center: true }, { t1: 'დღის თემა', t2: 'რა შეიცვალა ერთ წელიწადში' });
  // --- pointers
  var LC = { t1: 'წარწერა', t2: 'ქვედა ხაზი' };
  xx('co', 'c-line-tr', 'მინიშნება ხაზით ↗', 800, 400, 'callout', { dir: 'tr' }, { t1: 'ახალი ფარი', t2: 'LED მატრიცა', labels: LC });
  xx('co', 'c-line-tl', 'მინიშნება ხაზით ↖', 800, 400, 'callout', { dir: 'tl' }, { t1: 'კარბონის სახურავი', t2: '', labels: LC });
  xx('co', 'c-line-br', 'მინიშნება ხაზით ↘', 800, 400, 'callout', { dir: 'br' }, { t1: 'შეხედე აქ', t2: 'დეტალი', labels: LC });
  xx('co', 'c-line-bl', 'მინიშნება ხაზით ↙', 800, 400, 'callout', { dir: 'bl' }, { t1: '21 დიუმი', t2: 'დისკები', labels: LC });
  xx('co', 'c-arrow', 'მოხრილი ისარი →', 600, 400, 'arrow', {}, { t1: 'აი ეს!', labels: { t1: 'წარწერა' }, dur: 4 });
  xx('co', 'c-arrow-flip', 'მოხრილი ისარი ←', 600, 400, 'arrow', { flip: true }, { t1: 'შეხედე', labels: { t1: 'წარწერა' }, dur: 4 });
  xx('co', 'c-ring', 'შემოხაზვა', 500, 480, 'ringmark', {}, { t1: 'აქ არის', labels: { t1: 'წარწერა' }, dur: 4 });
  xx('co', 'c-focus', 'ფოკუსის ჩარჩო', 500, 480, 'ringmark', { focus: true }, { t1: 'დეტალი', labels: { t1: 'წარწერა' }, dur: 4 });
  xx('co', 'c-bubble', 'ბუშტი (მარცხნიდან)', 800, 270, 'bubble', {}, { t1: 'ეს რა არის?!', t2: '', labels: LC }, ['soft']);
  xx('co', 'c-bubble-r', 'ბუშტი (მარჯვნიდან)', 800, 270, 'bubble', { side: 'r' }, { t1: 'მართლა?', t2: 'არ მჯერა', labels: LC });
  xx('co', 'c-bubble-accent', 'ბუშტი (შენი ფერი)', 800, 270, 'bubble', { accent: true }, { t1: 'რჩევა', t2: 'ჯერ გააცივე ძრავა', labels: LC });
  xx('co', 'c-tip', 'პატარა ფირნიში ↓', 700, 200, 'tip', {}, { t1: 'დააჭირე აქ', labels: { t1: 'წარწერა' }, dur: 4 });
  xx('co', 'c-tip-up', 'პატარა ფირნიში ↑', 700, 200, 'tip', { up: true }, { t1: 'ეს ღილაკი', labels: { t1: 'წარწერა' }, dur: 4 });
  xx('co', 'c-pin', 'ადგილის ნიშნული', 1000, 220, 'cta', { icon: 'pin' }, { t1: 'აქ ვართ', t2: 'ბათუმი' }, ['drop']);
  // --- a few more buttons
  cta('cta-rate', 'შეგვაფასე', 'cta', { icon: 'star' }, { t1: 'შეგვაფასე', t2: 'შენი აზრი მნიშვნელოვანია', dur: 4 });
  cta('cta-qa', 'დასვი კითხვა', 'cta', { icon: 'comment', tone: 'dark' }, { t1: 'დასვი კითხვა', t2: 'ვუპასუხებთ შემდეგ ვიდეოში', dur: 4 });
  cta('cta-tag', 'მონიშნე მეგობარი', 'cta', { icon: 'hash' }, { t1: 'მონიშნე მეგობარი', t2: 'ვისაც ეს ეხება', dur: 4 });
  cta('cta-giveaway', 'გათამაშება', 'cta', { icon: 'star', tone: 'dark' }, { t1: 'გათამაშება', t2: 'პირობები აღწერაში', dur: 4 }, ['glow', 'pop']);
  cta('cta-part2', 'მეორე ნაწილი', 'cta', { icon: 'play' }, { t1: 'მეორე ნაწილი მალე', t2: 'გამოიწერე, რომ არ გამოტოვო', dur: 4 });
  cta('cta-test', 'სატესტო სვლა', 'cta', { icon: 'phone', tone: 'dark' }, { t1: 'ჩაეწერე სატესტო სვლაზე', t2: '+995 555 00 00 00', dur: 4 });
  cta('sub-yt-big', 'გამოწერა + ლაიქი ერთად', 'combo', {}, { t1: 'მოიწონე', t2: 'გამოიწერე', t3: 'ჩართე ზარი', dur: 4.5 }, ['pop']);

  // ---------------------------------------------------------------- the big themed sets
  // Each set is a list of texts run through a list of looks; `tag` says what it is about (auto · drift · race).
  var FAM = function (n) { return X[n] || LT[n] || SOC[n] || TIMER[n]; };
  function tagOf(s) { s = String(s); return /დრიფტ|ტანდემ|ბერნაუთ|drift/i.test(s) ? 'drift' : (/რბოლ|წრე|წრის|კვალიფ|მრბოლელ|ავტოდრომ|პიტ|სტარტ|ფინიშ|სექტორ|პოდიუმ|პოლ-|დრაგ|402|ტრეკ|P1|P2|P3|რალი|ჯეტკან/i.test(s) ? 'race' : 'auto'); }
  function many(cat, pre, auto, texts, looks, labels, from) {
    for (var i = 0; i < texts.length; i++) {
      var L = looks[(i + (from || 0)) % looks.length], T = texts[i], defs = ext(T, {}), V = ext(L.V || {}, {});
      if (labels || L.labels) { defs.labels = L.labels || labels; }
      if (L.defs) { defs = ext(defs, L.defs); }
      var base = defs.name || (L.fam === 'stat' && T.t3 ? T.t3 + ' — ' + T.t1 + (T.t2 ? ' ' + T.t2 : '') : defs.t1);
      delete defs.name;
      var d = add(cat, pre + (i + 1), base + (L.n ? ' · ' + L.n : ''), L.w, L.h, FAM(L.fam), V, defs);
      d.fn = FAM(L.fam);
      d.tag = auto ? tagOf(base + ' ' + (T.t2 || '') + ' ' + (T.t3 || '')) : '';
    }
  }
  function K(fam, w, h, n, V, defs) { return { fam: fam, w: w, h: h, n: n, V: V, defs: defs }; }
  function T2(a, b, c, d) { var o = { t1: a, t2: b || '' }; if (c !== undefined) { o.t3 = c; } if (d !== undefined) { o.t4 = d; } return o; }
  function rows(list) { var o = []; for (var i = 0; i < list.length; i++) { o.push(T2.apply(null, list[i])); } return o; }
  var i3;
  // mark what was built above
  for (i3 = 0; i3 < DESIGNS.length; i3++) { if (DESIGNS[i3].cat === 'auto') { DESIGNS[i3].tag = tagOf(DESIGNS[i3].name + ' ' + (DESIGNS[i3].defs.t1 || '')); } else if (/^(t-lap|a-)/.test(DESIGNS[i3].id)) { DESIGNS[i3].tag = 'race'; } }

  // --- timers
  function TT(label, total, fmt, up) { return { t1: label, timer: true, total: total, fmt: fmt, down: up ? false : undefined }; }
  var TL = [K('label', 700, 220, 'წარწერით'), K('line', 640, 220, 'ხაზით'), K('tagcard', 640, 240, 'ბარათი'), K('corner', 640, 220, 'მინიმალი'), K('topbar', 1000, 120, 'ზედა ზოლი'), K('score', 700, 220, 'ტაბლო'),
    K('bar', 640, 220, 'პროგრესი'), K('gauge', 420, 300, 'რკალი'), K('ring', 380, 380, 'რგოლი'), K('badge', 380, 380, 'ბეჯი')];
  var TLA = [K('label', 700, 220, 'დროშით', { trim: 'check' }), K('score', 700, 220, 'ტაბლო', { skin: 'grad' }), K('tagcard', 640, 240, 'ბარათი', { trim: 'tyre' }), K('line', 640, 220, 'სიჩქარის ხაზებით', { trim: 'speed' }), K('topbar', 1000, 120, 'ზედა ზოლი'),
    K('corner', 640, 220, 'ზოლებით', { trim: 'stripes' }), K('bar', 640, 220, 'პროგრესი', { skin: 'hard' }), K('gauge', 420, 300, 'რკალი'), K('label', 700, 220, 'კვამლით', { trim: 'smoke' }), K('badge', 380, 380, 'ბეჯი', { enter: 'pop' })];
  var TA = [TT('წრის დრო', 90, 'ss.cc', 1), TT('პიტ-სტოპი', 10, 'ss.cc', 1), TT('დრიფტის გასვლა', 60, 's', 1), TT('კვალიფიკაცია', 600, 'm:ss'), TT('სტარტამდე', 10, 's'), TT('402 მეტრი', 15, 'ss.cc', 1), TT('0–100 კმ/სთ', 6, 'ss.cc', 1),
    TT('სექტორი 1', 30, 'ss.cc', 1), TT('საბურავების გათბობა', 120, 'm:ss'), TT('რბოლის ბოლომდე', 300, 'm:ss'), TT('შემდეგი გასვლა', 90, 'm:ss'), TT('ბერნაუთი', 15, 's'), TT('ტესტ-დრაივი', 900, 'm:ss'), TT('ძრავის გათბობა', 180, 'm:ss'),
    TT('ტანდემის ბრძოლა', 45, 's', 1), TT('თავისუფალი ვარჯიში', 1200, 'm:ss'), TT('საწვავის ჩასხმა', 12, 'ss.cc', 1), TT('საბურავების შეცვლა', 8, 'ss.cc', 1), TT('დრაგის სტარტი', 5, 's'), TT('ჯეტკანა', 75, 'ss.cc', 1),
    TT('ავტომრეცხავი', 600, 'm:ss'), TT('დატენვის ბოლომდე', 1800, 'm:ss')];
  many('timer', 't-a', true, TA, TLA); many('timer', 't-b', true, TA, TLA, null, 5);
  var TG2 = [TT('შესვენება', 300, 'm:ss'), TT('ვარჯიში', 45, 's'), TT('დასვენება', 20, 's'), TT('მომზადება', 600, 'm:ss'), TT('ვიქტორინა', 10, 's'), TT('პასუხის დრო', 15, 's'), TT('რაუნდი', 60, 's'), TT('პრეზენტაცია', 300, 'm:ss'),
    TT('მედიტაცია', 180, 'm:ss'), TT('გამოცდა', 1800, 'm:ss'), TT('პომოდორო', 1500, 'mm:ss'), TT('სტრიმი იწყება', 300, 'm:ss'), TT('აქცია მთავრდება', 3600, 'h:mm:ss'), TT('ახალ წლამდე', 10, 's'), TT('ჩელენჯი', 30, 's'),
    TT('გაყიდვის დაწყებამდე', 120, 'm:ss'), TT('შემდეგი სტუმარი', 60, 's'), TT('ცხობის დრო', 900, 'm:ss'), TT('თამაშის რაუნდი', 90, 'm:ss'), TT('დარჩა', 30, 's')];
  many('timer', 't-g', false, TG2, TL); many('timer', 't-h', false, TG2, TL, null, 3); many('timer', 't-i', false, TG2, TL, null, 7);

  // --- lower thirds
  var LL = [K('line', 1000, 220, 'ხაზი', { thick: true }), K('box', 1000, 220, 'ყუთები', { style: 'duo' }), K('slash', 1000, 220, 'დახრილი', { dark: true }), K('stack', 1000, 220, 'დიდი სახელი', { mode: 'wipe' }), K('strip', 1000, 220, 'ზოლი', { mode: 'full' }),
    K('tag', 1000, 220, 'ინიციალი', { shape: 'sq' }), K('pill', 1000, 220, 'კაფსულა', { tone: 'dark' }), K('corner', 1000, 220, 'კუთხე', {}), K('rules', 1000, 220, 'ორი ხაზი', {}), K('under', 1000, 220, 'ხაზგასმა', { mode: 'short' }), K('credit', 1000, 220, 'ტიტრი', { left: true }), K('box', 1000, 220, 'დახრილი ყუთები', { style: 'solid', skew: true })];
  var LLA = [K('slash', 1000, 220, 'სპორტული', { dark: true, trim: 'check' }), K('box', 1000, 220, 'დახრილი', { style: 'duo', skew: true, trim: 'speed' }), K('line', 1000, 220, 'ზოლებით', { thick: true, trim: 'stripes' }), K('stack', 1000, 220, 'დიდი სახელი', { mode: 'wipe', trim: 'tyre' }),
    K('strip', 1000, 220, 'ზოლი', { mode: 'full', skin: 'grad' }), K('tag', 1000, 220, 'ნომრით', { shape: 'sq', trim: 'check' }), K('box', 1000, 220, 'კვამლით', { style: 'duo', trim: 'smoke' }), K('pill', 1000, 220, 'კაფსულა', { tone: 'accent', trim: 'speed' }),
    K('corner', 1000, 220, 'კუთხე', { trim: 'tyre' }), K('tape', 1000, 220, 'სკოჩი', { angle: -3, skin: 'hard' })];
  var LA = rows([['Porsche 911 GT3 RS', '4.0 ატმოსფერული · 525 ცხ.ძ.'], ['BMW M3 Competition', '2024 · 510 ცხ.ძ.'], ['Nissan Silvia S15', 'დრიფტ-ქარი · 450 ცხ.ძ.'], ['Toyota Supra A90', 'Stage 2 · 520 ცხ.ძ.'], ['Mercedes-AMG GT', 'V8 ბი-ტურბო'],
    ['Subaru WRX STI', 'სრული ამძრავი · რალი'], ['გოგა მელია', 'მრბოლელი · #27'], ['ნიკა', 'დრიფტ-პილოტი'], ['დათო', 'მთავარი მექანიკოსი'], ['რუსთავის ავტოდრომი', 'წრე 4.1 კმ'], ['დრიფტის ჩემპიონატი', 'ეტაპი 3 · ფინალი'],
    ['კვალიფიკაცია', 'საუკეთესო წრე 1:42.318'], ['ტანდემის ბრძოლა', 'ტოპ 16'], ['ძრავა', '2JZ-GTE · 800 ცხ.ძ.'], ['საბურავები', '265/35 R18 · ნახევრად სლიკი'], ['გუნდი Melia Racing', 'პიტ-ლეინი'], ['ტესტ-დრაივი', 'პირველი შთაბეჭდილება'],
    ['მიმოხილვა', 'ღირს თუ არა ყიდვა?'], ['ტიუნინგი', 'Stage 1 → Stage 3'], ['მფლობელის ისტორია', '5 წელი ერთ მანქანაზე'], ['დრაგ-რბოლა', '402 მეტრი · 10.8 წმ'], ['ტრეკ-დეი', 'ღია გასვლები ყველასთვის']]);
  many('lt', 'lt-a', true, LA, LLA); many('lt', 'lt-b', true, LA, LLA, null, 4);
  var LG = rows([['ნინო', 'ექიმი'], ['გიორგი', 'შეფ-მზარეული'], ['ანა', 'ფოტოგრაფი'], ['ლუკა', 'მუსიკოსი'], ['სანდრო', 'მწვრთნელი'], ['მარიამი', 'იურისტი'], ['ლევანი', 'პროგრამისტი'], ['ელენე', 'დიზაინერი'], ['ირაკლი', 'ჟურნალისტი'],
    ['თამარი', 'მასწავლებელი'], ['ზურა', 'არქიტექტორი'], ['სალომე', 'ბლოგერი'], ['ნიკოლოზი', 'პროდიუსერი'], ['ქეთი', 'მეწარმე'], ['სპეციალური სტუმარი', 'დღევანდელი ეპიზოდი'], ['ექსპერტის აზრი', 'რას ამბობს მეცნიერება'],
    ['კომპანიის დირექტორი', 'ინტერვიუ'], ['კამერის მიღმა', 'გადაღების დღე'], ['პოდკასტი', 'ეპიზოდი 12'], ['კითხვა-პასუხი', 'თქვენი კითხვები']]);
  many('lt', 'lt-g', false, LG, LL); many('lt', 'lt-h', false, LG, LL, null, 4); many('lt', 'lt-i', false, LG, LL, null, 8);

  // --- social
  var HA = rows([['@melia.racing', 'ავტოსპორტი'], ['@driftgeorgia', 'დრიფტი საქართველოში'], ['@racinglinedetailing', 'დეტეილინგი'], ['@gezmotors', 'ავტოსერვისი'], ['@auto.news.ge', 'ავტო სიახლეები'], ['@trackday.ge', 'ტრეკ-დეი'],
    ['@garage27', 'გარაჟი'], ['@jdm.georgia', 'JDM კულტურა'], ['@carspotting.tbilisi', 'ქარსპოტინგი'], ['@rally.ge', 'რალი']]);
  function NL(net, fam, n, V) { return K(fam, 1000, 220, NET[net].name + ' · ' + n, ext({ net: net }, V || {})); }
  var NA = [NL('yt', 'tile', 'დროშით', { trim: 'check' }), NL('ig', 'handle', 'სიჩქარით', { trim: 'speed' }), NL('tt', 'handle', 'ბარათი', { card: true, tone: 'light', trim: 'tyre' }), NL('fb', 'tile', 'ზოლებით', { trim: 'stripes' }),
    NL('tg', 'handle', 'კვამლით', { trim: 'smoke' }), NL('yt', 'handle', 'ბარათი', { card: true, tone: 'light', trim: 'check' }), NL('ig', 'tile', 'ზოლებით', { trim: 'stripes' }), NL('tt', 'tile', 'სიჩქარით', { trim: 'speed' })];
  many('net', 'net-a', true, HA, NA); many('net', 'net-b', true, HA, NA, null, 1); many('net', 'net-c', true, HA, NA, null, 3); many('net', 'net-d', true, HA, NA, null, 5);
  for (i3 = 0; i3 < DESIGNS.length; i3++) { if (/^net-[abcd]\d/.test(DESIGNS[i3].id)) { DESIGNS[i3].name = DESIGNS[i3].defs.t1 + ' — ' + DESIGNS[i3].name.split(' · ').slice(1).join(' · '); } }
  var NK = []; for (k in NET) { if (NET.hasOwnProperty(k)) { NK.push(k); } }
  for (i3 = 0; i3 < NK.length; i3++) {
    var nk = NK[i3];
    add('net', 'net-' + nk + '-pop', NET[nk].name + ' — კაფსულა · ამოხტომა', 1000, 220, SOC.handle, { net: nk, enter: 'pop' }, { t1: HANDLE.t1, t2: NET[nk].name });
    add('net', 'net-' + nk + '-soft', NET[nk].name + ' — ბარათი · ჩრდილით', 1000, 220, SOC.handle, { net: nk, card: true, tone: 'light', skin: 'soft' }, { t1: HANDLE.t1, t2: NET[nk].name });
    if (LIGHT.indexOf(nk) < 0) { add('net', 'net-' + nk + '-light', NET[nk].name + ' — თეთრი კაფსულა', 1000, 220, SOC.handle, { net: nk, tone: 'light' }, { t1: HANDLE.t1, t2: NET[nk].name }); }
  }

  // --- buttons
  function CL(icon, n, V) { return K('cta', 1000, 220, n, ext({ icon: icon }, V || {}), { dur: 4 }); }
  var CA = [[CL('phone', 'დროშით', { trim: 'check' }), T2('ჩაეწერე ტესტ-დრაივზე', 'ბმული აღწერაშია')], [CL('play', 'სიჩქარით', { tone: 'dark', trim: 'speed' }), T2('ნახე სრული მიმოხილვა', 'არხზეა')], [CL('comment', '', {}), T2('რომელს აირჩევდი?', 'დაწერე კომენტარში')],
    [CL('comment', 'მუქი', { tone: 'dark' }), T2('V8 თუ ელექტრო?', 'შენი აზრი დაწერე')], [CL('share', 'კვამლით', { trim: 'smoke' }), T2('გაუზიარე დრიფტერ მეგობარს', 'ვინც გვერდულად დადის')], [CL('cart', 'დროშით', { tone: 'dark', trim: 'check' }), T2('ბილეთები რბოლაზე', 'ბმული აღწერაშია')],
    [CL('link', 'ზოლებით', { trim: 'stripes' }), T2('დარეგისტრირდი ტრეკ-დეიზე', 'ადგილები შეზღუდულია')], [CL('save', '', { tone: 'dark' }), T2('შეინახე, სანამ იყიდი', 'გამოგადგება')], [CL('bell', 'სიჩქარით', { tone: 'dark', trim: 'speed' }), T2('ჩართე ზარი', 'ახალი ტესტები ყოველ კვირას')],
    [CL('send', '', {}), T2('მოგვწერე ფასზე', 'გიპასუხებთ მალე')], [CL('pin', 'საბურავის კვალით', { trim: 'tyre' }), T2('გვესტუმრე სერვისში', 'ყოველდღე 10–19')], [CL('phone', 'მუქი', { tone: 'dark' }), T2('დაგვირეკე დეტეილინგზე', '+995 555 00 00 00')],
    [CL('star', '', {}), T2('შეაფასე ეს მანქანა', '1-დან 10-მდე')], [CL('play', 'დროშით', { trim: 'check' }), T2('უყურე დრაგ-რბოლას', 'ვინ მოიგო?')], [CL('down', '', { tone: 'dark' }), T2('ჩამოტვირთე ფასების სია', 'ბმული აღწერაშია')],
    [CL('up', '', {}), T2('აწიე ზემოთ', 'ინტერიერის სანახავად')], [CL('hash', 'კვამლით', { tone: 'dark', trim: 'smoke' }), T2('#დრიფტი', 'გამოიყენე ჩვენი ჰეშთეგი')], [CL('user', 'ზოლებით', { trim: 'stripes' }), T2('გამოგვყევი', 'ავტო კონტენტი ყოველდღე')],
    [CL('cart', '', {}), T2('შეუკვეთე ნაწილები', 'მიწოდება მთელ საქართველოში')], [CL('quote', '', { tone: 'dark' }), T2('მოგვიყევი შენი მანქანის ამბავი', 'კომენტარებში')]];
  for (i3 = 0; i3 < CA.length; i3++) { many('cta', 'cta-a' + i3 + '-', true, [CA[i3][1]], [CA[i3][0]]); many('cta', 'cta-b' + i3 + '-', true, [CA[i3][1]], [ext(CA[i3][0], { n: (CA[i3][0].n ? CA[i3][0].n + ', ' : '') + 'ამოხტომა', V: ext(CA[i3][0].V, { enter: i3 % 2 ? 'pop' : 'right' }) })]); }
  cta('sub-auto', 'გამოიწერე ავტო არხი', 'sub', { net: 'yt', channel: true, trim: 'check' }, { t1: 'Melia Auto', t2: 'ტესტები · დრიფტი · რბოლა', t3: 'გამოწერა', t4: 'გამოწერილია', dur: 4 });
  cta('like-auto', 'დაალაიქე, თუ ხმა მოგეწონა', 'like', { icon: 'thumb', trim: 'speed' }, { t1: 'მოგეწონა გამონაბოლქვის ხმა?', t2: 'დაალაიქე', dur: 4 });
  cta('combo-auto', 'ლაიქი · გამოწერა · ზარი (დროშით)', 'combo', { trim: 'check' }, { t1: 'ლაიქი', t2: 'გამოწერა', t3: 'ზარი', dur: 4.5 });
  for (i3 = 0; i3 < DESIGNS.length; i3++) { if (/^(sub|like|combo)-auto$/.test(DESIGNS[i3].id)) { DESIGNS[i3].tag = 'auto'; } }
  var CG = [[CL('link', '', {}), T2('დაჯავშნე ონლაინ', 'ბმული აღწერაშია')], [CL('play', '', { tone: 'dark' }), T2('მოუსმინე პოდკასტს', 'ყველა პლატფორმაზე')], [CL('cart', '', {}), T2('ნახე მენიუ', 'შეუკვეთე ადგილზე მიტანით')], [CL('down', '', { tone: 'dark' }), T2('ჩამოტვირთე აპლიკაცია', 'უფასოა')],
    [CL('user', '', {}), T2('გახდი არხის წევრი', 'ექსკლუზიური ვიდეოები')], [CL('send', '', { tone: 'dark' }), T2('გამოიწერე სიახლეები', 'კვირაში ერთხელ')], [CL('star', '', {}), T2('დაგვიტოვე შეფასება', 'გვეხმარება ზრდაში')], [CL('pin', '', { tone: 'dark' }), T2('გვეწვიე ფილიალში', 'ყოველდღე 10–20')],
    [CL('comment', '', {}), T2('რას იტყვი?', 'ველოდებით კომენტარს')], [CL('share', '', { tone: 'dark' }), T2('გააზიარე სთორიში', 'და მოგვნიშნე')], [CL('save', '', {}), T2('შეინახე რეცეპტი', 'მოგვიანებით გამოგადგება')], [CL('bell', '', {}), T2('არ გამოტოვო', 'პრემიერა პარასკევს')],
    [CL('phone', '', {}), T2('დაგვიკავშირდი', 'უფასო კონსულტაცია')], [CL('up', '', { tone: 'dark' }), T2('აწიე ზემოთ', 'ფასდაკლების სანახავად')], [CL('hash', '', {}), T2('#ჩელენჯი', 'შემოგვიერთდი')], [CL('quote', '', {}), T2('გვითხარი შენი ისტორია', 'საუკეთესოს წავიკითხავთ')],
    [CL('link', '', { tone: 'dark' }), T2('დარეგისტრირდი', 'ადგილები შეზღუდულია')], [CL('play', '', {}), T2('უყურე თავიდან', 'პირველი სერია არხზეა')], [CL('cart', '', { tone: 'dark' }), T2('დაამატე კალათაში', 'უფასო მიწოდება')], [CL('star', '', { tone: 'dark' }), T2('მიიღე საჩუქარი', 'პირობები აღწერაში')]];
  var ENT = ['', 'pop', 'rise'], SKN = ['', 'soft', 'grad'];
  for (i3 = 0; i3 < CG.length; i3++) { for (k = 0; k < 3; k++) { many('cta', 'cta-g' + i3 + '-' + k + '-', false, [CG[i3][1]], [ext(CG[i3][0], { n: [k ? ENTER[ENT[k]] : '', SKN[(i3 + k) % 3] ? SKIN[SKN[(i3 + k) % 3]] : ''].filter(function (x) { return x; }).join(', '), V: ext(CG[i3][0].V, ext(k ? { enter: ENT[k] } : {}, SKN[(i3 + k) % 3] ? { skin: SKN[(i3 + k) % 3] } : {})) })]); } }

  // --- numbers
  var SL = [K('stat', 700, 240, '', {}), K('stat', 700, 240, 'ხაზით', { style: 'line' }), K('stat', 700, 240, 'ბარათი', { style: 'card' }), K('stat', 700, 240, 'ფერადი ყუთი', { style: 'split' })];
  var SLA = [K('stat', 700, 240, 'დროშით', { trim: 'check' }), K('stat', 700, 240, 'სიჩქარით', { style: 'line', trim: 'speed' }), K('stat', 700, 240, 'ბარათი', { style: 'card', skin: 'grad' }), K('stat', 700, 240, 'ზოლებით', { style: 'split', trim: 'stripes' }), K('stat', 700, 240, 'საბურავის კვალით', { style: 'card', trim: 'tyre' })];
  var SA = rows([['510', 'ცხ.ძ.', 'სიმძლავრე'], ['3.2', 'წმ', '0–100 კმ/სთ'], ['320', 'კმ/სთ', 'მაქსიმალური სიჩქარე'], ['650', 'ნმ', 'ბრუნვის მომენტი'], ['1 850', 'კგ', 'წონა'], ['4.0', 'ლ', 'ძრავის მოცულობა'], ['8', 'ცილინდრი', 'V8'], ['1.6', 'ბარი', 'ტურბოს წნევა'],
    ['1:42.3', '', 'წრის დრო'], ['94', 'ქულა', 'დრიფტის შეფასება'], ['62', '°', 'დრიფტის კუთხე'], ['10.8', 'წმ', '402 მეტრი'], ['21', 'დიუმი', 'დისკები'], ['480', 'კმ', 'ელექტრო მარაგი'], ['105', 'კვტ·სთ', 'ბატარეა'], ['18', 'წთ', 'დატენვა 10–80%'],
    ['9 000', 'ბრ/წთ', 'წითელი ზონა'], ['2.3', 'წმ', 'პიტ-სტოპი'], ['86 000', 'კმ', 'გარბენი'], ['45 000', '$', 'ფასი'], ['8.4', 'ლ/100კმ', 'ხარჯი'], ['1.2', 'G', 'გვერდითი გადატვირთვა'], ['380', 'მმ', 'სამუხრუჭე დისკი'], ['27', '', 'სასტარტო ნომერი']]);
  many('num', 'n-a', true, SA, SLA, L3);
  var NX = [[K('pct', 380, 380, ''), { t1: '80%', t2: 'ბატარეა' }], [K('pct', 380, 380, 'ღია', { open: true }), { t1: '35%', t2: 'საწვავი' }], [K('pct', 380, 380, ''), { t1: '60%', t2: 'საბურავის რესურსი' }], [K('pct', 380, 380, 'ღია', { open: true }), { t1: '45%', t2: 'მუხრუჭების რესურსი' }],
    [K('bars', 900, 300, ''), { t1: 'სტოკი | 340 ცხ.ძ.', t2: 'Stage 2 | 480 ცხ.ძ.' }], [K('bars', 900, 300, ''), { t1: 'M3 | 3.5 წმ', t2: 'C63 | 3.4 წმ' }], [K('bars', 900, 300, ''), { t1: 'ბენზინი | 12 ₾/100კმ', t2: 'ელექტრო | 4 ₾/100კმ' }], [K('bars', 900, 300, ''), { t1: 'პირველი გასვლა | 82 ქულა', t2: 'მეორე გასვლა | 94 ქულა' }],
    [K('stars', 700, 200, '', { brand: true }), { t1: '4.5', t2: 'დინამიკა' }], [K('stars', 700, 200, ''), { t1: '4', t2: 'კომფორტი' }], [K('stars', 700, 200, '', { brand: true }), { t1: '5', t2: 'დიზაინი' }], [K('stars', 700, 200, ''), { t1: '3.5', t2: 'ფასი და ხარისხი' }],
    [K('steps', 800, 180, ''), { t1: '3/10', t2: 'წრე 3 / 10' }], [K('steps', 800, 180, ''), { t1: '2/6', t2: 'ეტაპი 2 / 6' }], [K('price', 760, 240, ''), { t1: '52 000 $', t2: '45 000 $', t3: 'ფასი დაკლებულია' }], [K('dial', 420, 420, '', { max: 100 }), { t1: '88', t2: 'ჩვენი ქულა' }]];
  for (i3 = 0; i3 < NX.length; i3++) { many('num', 'n-x' + i3 + '-', true, [ext(NX[i3][1], { name: NX[i3][1].t2 && !/\|/.test(NX[i3][1].t1) ? NX[i3][1].t2 : NX[i3][1].t1.split('|')[0] + (NX[i3][1].t2 ? 'vs ' + NX[i3][1].t2.split('|')[0] : '') })], [NX[i3][0]]); }
  var SG = rows([['125 000', 'გამომწერი', 'მადლობა!'], ['2.4', 'მლნ', 'ნახვა'], ['98', '%', 'კმაყოფილი მომხმარებელი'], ['1 500', '+', 'შესრულებული შეკვეთა'], ['24', 'ქალაქი', 'მთელ საქართველოში'], ['350', 'პროექტი', '5 წელიწადში'], ['12', 'წელი', 'ბაზარზე'],
    ['47', '%', 'ზრდა წელიწადში'], ['520', 'კკალ', 'ერთ ულუფაში'], ['10 000', 'ნაბიჯი', 'დღეში'], ['42', 'კმ', 'მარათონი'], ['30', 'დღე', 'ჩელენჯი'], ['8', 'საათი', 'ძილი'], ['1 000 000', '', 'ჩამოტვირთვა'], ['4.9', '', 'საშუალო შეფასება'],
    ['3 200', 'შეფასება', 'მომხმარებლებისგან'], ['15', 'ადამიანი', 'ჩვენი გუნდი'], ['7', 'ქვეყანა', 'სადაც ვმუშაობთ'], ['250', '₾', 'დაზოგე თვეში'], ['36.6', '°C', 'ტემპერატურა']]);
  many('num', 'n-g', false, SG, SL, L3); many('num', 'n-h', false, SG, SL, L3, 1); many('num', 'n-i', false, SG, SL, L3, 2);

  // --- titles and stickers
  var LS2 = { t1: 'მთავარი', t2: 'ზედა', t3: 'ქვედა' };
  function SX(arr, looks, auto, pre) { for (var q = 0; q < arr.length; q++) { many('stk', pre + q + '-', auto, [arr[q]], [looks[q % looks.length]]); } }
  var KA = [K('medal', 380, 380, 'სტიკერი', { burst: true, tilt: true }, { labels: LS2 }), K('ribbon', 900, 220, 'ლენტი', {}), K('flag', 1000, 200, 'დროშა', {}), K('stamp', 520, 300, 'ბეჭედი', {}), K('bigtitle', 1000, 300, 'დიდი სათაური', { trim: 'check' }),
    K('tape', 1000, 220, 'სკოჩი', { angle: -4, skin: 'hard' }), K('warn', 1000, 160, 'ზოლი', {}), K('chapter', 900, 260, 'ნომრით', { solid: true }, { labels: { t1: 'ნომერი', t2: 'სათაური', t3: 'ზედა წარწერა' } })];
  var QA = [T2('V8', 'ნამდვილი', 'ხმა'), T2('ახალი მოდელი', 'უკვე საქართველოშია'), T2('სტარტი'), T2('ტექდათვალიერება', 'გავლილია'), T2('დრიფტის ღამე', 'რუსთავის ავტოდრომი'), T2('ტესტ-დრაივი', 'ნაწილი 1'), T2('არ გაიმეოროთ გზაზე', 'გადაღებულია დახურულ ტრასაზე'), T2('01', 'რაუნდი პირველი', 'რბოლა'),
    T2('ტურბო', 'ორმაგი', 'წნევა'), T2('პოლ-პოზიცია', 'კვალიფიკაციის გამარჯვებული'), T2('ფინიში'), T2('იყიდება', 'დარეკე ახლავე'), T2('რბოლის დღე', 'ეტაპი 3'), T2('დრაგი', '402 მეტრი'), T2('სახიფათო მონაკვეთი', 'შეანელე'), T2('#27', 'გოგა მელია', 'მრბოლელი'),
    T2('Stage 2', 'ტიუნინგი', '+140 ცხ.ძ.'), T2('გამარჯვებული', 'ტანდემის ფინალი'), T2('კვალიფიკაცია'), T2('გაყიდულია', 'გილოცავთ მფლობელს'), T2('მსოფლიო პრემიერა', 'პირველი ჩვენება'), T2('ბერნაუთი', 'საბურავების ბოლო დღე'), T2('პიტ-ლეინი', 'სიჩქარის ლიმიტი 60'), T2('02', 'ტანდემი', 'დრიფტი'),
    T2('JDM', 'იაპონური', 'ლეგენდა'), T2('ტრეკ-დეი', 'ღია გასვლები'), T2('ბოლო წრე'), T2('ექსკლუზივი', 'მხოლოდ ჩვენთან'), T2('ელექტრო ერა', 'მომავალი აქაა'), T2('რალი', 'ხრეშიანი ეტაპი'), T2('ყინულიანი გზა', 'ფრთხილად'), T2('03', 'ფინალური რბოლა', 'რბოლა'),
    T2('AWD', 'სრული', 'ამძრავი'), T2('პოდიუმი', 'პირველი სამეული'), T2('გამოწვევა'), T2('შემოწმებული გარბენი', 'ნამდვილია'), T2('გარაჟის ამბები', 'ახალი პროექტი'), T2('დრიფტის სკოლა', 'გაკვეთილი 1'), T2('სატესტო მანქანა', 'არ არის გასაყიდი'), T2('04', 'დაჯილდოება', 'რბოლა')];
  SX(QA, KA, true, 's-a');
  var KG = [K('medal', 380, 380, 'სტიკერი', { burst: true }, { labels: LS2 }), K('ribbon', 900, 220, 'ლენტი', {}), K('stamp', 520, 300, 'ბეჭედი', {}), K('bigtitle', 1000, 300, 'დიდი სათაური', {}), K('tape', 1000, 220, 'სკოჩი', { angle: 3 }), K('warn', 1000, 160, 'ზოლი', { brand: true }),
    K('chapter', 900, 260, 'ნომრით', {}, { labels: { t1: 'ნომერი', t2: 'სათაური', t3: 'ზედა წარწერა' } }), K('medal', 380, 380, 'მრგვალი ბეჯი', { tilt: true }, { labels: LS2 }), K('rules', 1000, 220, 'ორი ხაზი', { center: true }), K('pill', 1000, 220, 'კაფსულა', { tone: 'accent' })];
  var QG = [T2('-30%', 'ფასდაკლება', 'კვირის ბოლომდე'), T2('ახალი სეზონი', 'მალე ეთერში'), T2('დადასტურებულია', 'ნამდვილი ამბავი'), T2('დასაწყისი', 'როგორ დაიწყო ყველაფერი'), T2('რეცეპტი', '15 წუთში'), T2('რეკლამა', 'ვიდეოს მხარდამჭერი'), T2('01', 'მომზადება', 'ნაბიჯი'), T2('1+1', 'აქცია', 'მხოლოდ დღეს'),
    T2('დღის რჩევა', 'მარტივი ხრიკი'), T2('სპოილერი', 'ფრთხილად'), T2('ჰიტი', 'ყველაზე', 'გაყიდვადი'), T2('გილოცავთ', 'დაბადების დღეს'), T2('მითი', 'სიმართლე არ არის'), T2('ფინალი', 'ბოლო ეპიზოდი'), T2('ექსპერიმენტი', 'რა მოხდება?'), T2('ყურადღება', 'მნიშვნელოვანი ინფორმაცია'),
    T2('02', 'მთავარი ნაწილი', 'ნაბიჯი'), T2('უფასო', 'მიწოდება', 'მთელ ქალაქში'), T2('კითხვა-პასუხი', 'თქვენი კითხვები'), T2('ტოპ 10', 'წლის საუკეთესო'), T2('ახალი', 'კოლექცია', '2026'), T2('მადლობა', 'ყურებისთვის'), T2('სანდოა', 'შემოწმებული წყარო'), T2('მოგზაურობა', 'დღე პირველი'),
    T2('ვარჯიში', 'სახლში'), T2('სპონსორი', 'მადლობა მხარდაჭერისთვის'), T2('03', 'შედეგი', 'ნაბიჯი'), T2('VIP', 'მხოლოდ', 'წევრებისთვის'), T2('მოკლედ', 'მთავარი 60 წამში'), T2('პრემიერა', 'დღეს საღამოს'), T2('ლიმიტირებული', 'რაოდენობა', 'იჩქარე'), T2('გამარჯობა', 'კეთილი იყოს მობრძანება'),
    T2('ფაქტია', 'მეცნიერულად დამტკიცებული'), T2('ისტორია', 'ნაწილი მეორე'), T2('მიმოხილვა', 'ღირს თუ არა?'), T2('ცოცხალი ეთერი', 'იწყება მალე'), T2('04', 'დასკვნა', 'ნაბიჯი'), T2('BIO', 'ბუნებრივი', 'პროდუქტი'), T2('შეჯამება', 'რა ვისწავლეთ'), T2('დასასრული', 'შეხვედრამდე')];
  SX(QG, KG, false, 's-g'); SX(QG.slice(0, 20), KG.slice(3).concat(KG.slice(0, 3)), false, 's-h');

  // --- pointers
  var DIRS = [['tr', '↗'], ['tl', '↖'], ['br', '↘'], ['bl', '↙']];
  function CO2(list, auto, pre) { for (var q = 0; q < list.length; q++) { var dr = DIRS[q % 4], d2 = add('co', pre + q, list[q][0] + ' ' + dr[1], 800, 400, X.callout, { dir: dr[0] }, { t1: list[q][0], t2: list[q][1] || '', labels: LC }); d2.fn = X.callout; d2.tag = auto ? tagOf(list[q][0]) : ''; } }
  var PA = [['ტურბო', 'ორმაგი'], ['კარბონის სპოილერი', '+120 კგ მიჭერა'], ['კერამიკული მუხრუჭები', '410 მმ'], ['21″ დისკები', 'ჭედური'], ['LED მატრიცული ფარები'], ['ჰაერის შემშვები', 'მუხრუჭების გაგრილება'], ['ტიტანის გამონაბოლქვი', '−8 კგ'], ['დიფუზორი'],
    ['სპორტული სავარძლები', 'კარბონის კარკასი'], ['ციფრული პანელი', '12.3 დიუმი'], ['დრიფტის ხელის მუხრუჭი', 'ჰიდრავლიკური'], ['ლოკირებული დიფერენციალი'], ['კოილოვერები', 'რეგულირებადი'], ['როლ-კეიჯი', 'უსაფრთხოების კარკასი'], ['ნახევრად სლიკი', '265/35 R18'], ['ინტერკულერი'],
    ['უკანა ამძრავი'], ['პანორამული სახურავი'], ['დამტენი პორტი', '270 კვტ'], ['აქტიური ფრთა', 'ჰაერის მუხრუჭი'], ['ბზარი აქ', 'შეკეთება საჭიროა'], ['ორიგინალი საღებავი', '110 მიკრონი'], ['საბურავის ცვეთა', 'გარე მხარე'], ['სასტარტო ნომერი', '#27']];
  CO2(PA, true, 'c-a');
  var PB = [['უყურე უკანა ღერძს!'], ['აი აქ დაკარგა მოჭიდება'], ['იდეალური ტრაექტორია'], ['კვამლი!'], ['გასწრების ადგილი'], ['აპექსი'], ['დაგვიანებული დამუხრუჭება'], ['კედელთან 10 სმ']];
  for (i3 = 0; i3 < PB.length; i3++) { var fa = [X.arrow, X.arrow, X.ringmark, X.bubble][i3 % 4], da = add('co', 'c-b' + i3, PB[i3][0], i3 % 4 === 3 ? 800 : (i3 % 4 === 2 ? 500 : 600), i3 % 4 === 3 ? 270 : (i3 % 4 === 2 ? 480 : 400), fa, i3 % 4 === 1 ? { flip: true } : (i3 % 4 === 3 ? { accent: true } : {}), { t1: PB[i3][0], t2: '', labels: LC, dur: 4 }); da.fn = fa; da.tag = tagOf(PB[i3][0] + ' დრიფტ'); }
  for (i3 = 0; i3 < 8; i3++) { var db = add('co', 'c-t' + i3, PA[i3][0] + ' — ფირნიში', 700, 200, X.tip, i3 % 2 ? { up: true } : {}, { t1: PA[i3][0], labels: { t1: 'წარწერა' }, dur: 4 }); db.fn = X.tip; db.tag = 'auto'; }
  var PG = [['ახალი ფუნქცია', 'ვერსია 2.0'], ['დააჭირე აქ'], ['მთავარი ინგრედიენტი', '200 გრ'], ['შეცდომა აქ იყო'], ['ყველაზე მნიშვნელოვანი'], ['ფასი', '49 ₾-დან'], ['ხელნაკეთი', '100% ბამბა'], ['აქ ვცხოვრობთ'], ['მენიუ', 'პარამეტრები'], ['საიდუმლო ღილაკი'],
    ['პირველი ნაბიჯი'], ['შედეგი', '30 დღეში'], ['ორიგინალი'], ['ასლი'], ['კამერა', '48 მგპ'], ['ბატარეა', '2 დღე'], ['ჩვენი ოფისი'], ['შეხვედრის ადგილი'], ['ფასდაკლება', '−20%'], ['ახალი კოლექცია'], ['ექსპერტის რჩევა'], ['ნახე განსხვავება'], ['მანამდე'], ['შემდეგ'],
    ['გემრიელი ნაწილი'], ['ყურადღება მიაქციე'], ['სწორი პასუხი'], ['მცდარი პასუხი'], ['ლოგო აქ'], ['ტექსტი აქ'], ['დაწყება'], ['დასასრული'], ['ჩემი ფავორიტი'], ['ბესტსელერი'], ['ლიმიტირებული'], ['მხოლოდ დღეს']];
  CO2(PG, false, 'c-g');
  var PH = ['ეს რა არის?!', 'მართლა?', 'ვაუ!', 'შეხედე!', 'აი ეს!', 'არ მჯერა', 'სცადე შენც', 'ზუსტად ასე', 'დაიმახსოვრე', 'ჩაინიშნე', 'აქ დააჭირე', 'ეს მნიშვნელოვანია', 'საიდუმლო', 'რჩევა', 'ყურადღება', 'გაგრძელება იქნება', 'შეცდომა', 'სწორია', 'ახალი!', 'უფასოდ', 'მალე', 'ნახე ბოლომდე', 'დააკვირდი', 'აი პასუხი'];
  for (i3 = 0; i3 < PH.length; i3++) {
    var kind = i3 % 6, ff = [X.bubble, X.arrow, X.tip, X.bubble, X.ringmark, X.arrow][kind], vv = [{}, {}, {}, { side: 'r', accent: true }, kind === 4 && i3 % 12 > 5 ? { focus: true } : {}, { flip: true }][kind], sz = [[800, 270], [600, 400], [700, 200], [800, 270], [500, 480], [600, 400]][kind];
    var dc = add('co', 'c-h' + i3, PH[i3] + ' — ' + ['ბუშტი', 'ისარი', 'ფირნიში', 'ბუშტი მარჯვნიდან', 'შემოხაზვა', 'ისარი მარცხნივ'][kind], sz[0], sz[1], ff, vv, { t1: PH[i3], t2: '', labels: LC, dur: 4 }); dc.fn = ff;
  }

  // --- cars: the wide set
  many('auto', 'a-s', true, SA, [K('stat', 700, 240, '', {}), K('stat', 700, 240, 'ბარათი', { style: 'card', trim: 'check' }), K('stat', 700, 240, 'ფერადი ყუთი', { style: 'split', trim: 'speed' }), K('stat', 700, 240, 'ხაზით', { style: 'line', trim: 'tyre' })], L3, 1);
  var LD = { t1: 'მნიშვნელობა', t2: 'ერთეული' };
  many('auto', 'a-d', true, [T2('320', 'კმ/სთ'), T2('200', 'მილი/სთ'), T2('8600', 'ბრ/წთ ×1000'), T2('62', 'გრადუსი · დრიფტის კუთხე'), T2('110', '°C · ზეთი'), T2('95', '°C · საბურავი'), T2('1.8', 'ბარი · ტურბო'), T2('75', '% · გაზის პედალი')],
    [K('dial', 420, 420, 'სპიდომეტრი', { max: 340 }), K('dial', 420, 420, 'სპიდომეტრი', { max: 220 }), K('dial', 420, 420, 'ტაქომეტრი', { red: true, max: 9000, div: 1000 }), K('dial', 420, 420, 'კუთხის მზომი', { max: 90 }), K('dial', 420, 420, 'ტემპერატურა', { max: 150, red: true }), K('dial', 420, 420, 'ტემპერატურა', { max: 120 }), K('dial', 420, 420, 'წნევა', { max: 2.5, red: true }), K('dial', 420, 420, 'პროცენტი', { max: 100 })], LD);
  for (i3 = 0; i3 < DESIGNS.length; i3++) { if (/^a-d\d/.test(DESIGNS[i3].id)) { DESIGNS[i3].name = DESIGNS[i3].defs.t2.replace(/^.*· /, '') + ' — ' + DESIGNS[i3].name.split(' · ').pop() + ' (' + DESIGNS[i3].defs.t1 + ')'; DESIGNS[i3].defs.dur = 5; } }
  var LT4 = { t1: '1-ლი (სახელი | სხვაობა)', t2: 'მე-2', t3: 'მე-3', t4: 'მე-4' };
  xx('auto', 'a-lights', 'სასტარტო შუქნიშანი', 760, 260, 'lights', {}, { t1: 'მოემზადე', t2: 'წავიდა!', labels: { t1: 'ლოდინისას', t2: 'სტარტზე' }, dur: 6.5 });
  xx('auto', 'a-lights-drag', 'დრაგის სტარტი (შუქები)', 760, 260, 'lights', { trim: 'check' }, { t1: 'დრაგის სტარტი', t2: 'GO!', labels: { t1: 'ლოდინისას', t2: 'სტარტზე' }, dur: 6.5 });
  xx('auto', 'a-tower', 'რბოლის ცხრილი (ტოპ 4)', 520, 360, 'tower', {}, { t1: 'მელია | ლიდერი', t2: 'ნიკა | +0.312', t3: 'დათო | +1.840', t4: 'ლუკა | +4.2', labels: LT4, dur: 6 }, ['soft', 'right']);
  xx('auto', 'a-tower-drift', 'დრიფტის შედეგები', 520, 360, 'tower', {}, { t1: 'ნიკა | 94 ქულა', t2: 'გოგა | 91 ქულა', t3: 'დათო | 88 ქულა', t4: 'სანდრო | 85 ქულა', labels: LT4, dur: 6 }, ['grad']);
  xx('auto', 'a-tower-quali', 'კვალიფიკაციის შედეგები', 520, 360, 'tower', {}, { t1: 'მელია | 1:42.318', t2: 'ნიკა | 1:42.630', t3: 'დათო | 1:43.011', t4: '', labels: LT4, dur: 6 });
  xx('auto', 'a-sectors', 'სექტორების დრო', 640, 200, 'sectors', {}, { t1: '28.412', t2: '35.006', t3: '38.900', labels: { t1: 'სექტორი 1', t2: 'სექტორი 2', t3: 'სექტორი 3' }, dur: 5 }, ['pop']);
  xx('auto', 'a-sectors-brand', 'სექტორები (ერთ ფერში)', 640, 200, 'sectors', { cols: ['#2ECC71', '#2ECC71', '#B14AED'] }, { t1: '27.9', t2: '34.8', t3: '38.1', labels: { t1: 'სექტორი 1', t2: 'სექტორი 2', t3: 'სექტორი 3' }, dur: 5 });
  many('auto', 'a-g', true, [T2('4', 'გადაცემა'), T2('N', 'ნეიტრალი'), T2('R', 'უკუსვლა'), T2('6', 'ბოლო გადაცემა'), T2('2', 'დრიფტის გადაცემა'), T2('D', 'ავტომატი')], [K('gear', 380, 380, 'გადაცემა'), K('gear', 380, 380, 'გადაცემა', { skin: 'soft' }), K('gear', 380, 380, 'გადაცემა', { enter: 'pop' })], { t1: 'გადაცემა', t2: 'წარწერა' });
  var LJ = { t1: 'მსაჯი 1', t2: 'მსაჯი 2', t3: 'მსაჯი 3', t4: 'წარწერა' };
  xx('auto', 'a-scores', 'მსაჯების ქულები (დრიფტი)', 760, 250, 'scores', {}, { t1: '92', t2: '95', t3: '90', t4: 'დრიფტის გასვლა · საშუალო 92.3', labels: LJ, dur: 5 }, ['grad', 'pop']);
  xx('auto', 'a-scores-tandem', 'ტანდემის ქულები', 760, 250, 'scores', { trim: 'smoke' }, { t1: '6', t2: '4', t3: '7', t4: 'ტანდემის ბრძოლა · ლიდერის უპირატესობა', labels: LJ, dur: 5 });
  xx('auto', 'a-scores-test', 'ჩვენი შეფასება სამ ნაწილად', 760, 250, 'scores', {}, { t1: '9', t2: '8', t3: '7', t4: 'დინამიკა · კომფორტი · ფასი', labels: LJ, dur: 5 });
  many('auto', 'a-m', true, [T2('P1', 'ადგილი', '1:42.318'), T2('P2', 'ადგილი', '+0.312'), T2('P3', 'ადგილი', '+1.840'), T2('#27', 'მრბოლელი', 'გოგა მელია'), T2('94', 'დრიფტის', 'ქულა'), T2('DNF', 'ვერ', 'დაასრულა'), T2('MVP', 'დღის', 'პილოტი'), T2('S', 'რბილი', 'საბურავი'), T2('M', 'საშუალო', 'საბურავი'), T2('H', 'მაგარი', 'საბურავი')],
    [K('medal', 380, 380, 'ბეჯი'), K('medal', 380, 380, 'ბეჯი', { enter: 'drop' }), K('medal', 380, 380, 'ბეჯი', { tilt: true }), K('medal', 380, 380, 'ვარსკვლავა', { burst: true })], LS2);
  many('auto', 'a-f', true, [T2('კვალიფიკაცია'), T2('ფინალი'), T2('პოლ-პოზიცია'), T2('ბოლო წრე'), T2('დრიფტის შოუ'), T2('რბოლა იწყება'), T2('გამარჯვება'), T2('ტრეკ-დეი')], [K('flag', 1000, 200, 'დროშა')], { t1: 'წარწერა' });
  many('auto', 'a-v', true, [T2('Nissan GT-R', 'Porsche 911', '570 ცხ.ძ.', '650 ცხ.ძ.'), T2('ატმოსფერული', 'ტურბო', 'ხმა', 'ძალა'), T2('უკანა ამძრავი', 'სრული ამძრავი', 'დრიფტი', 'მოჭიდება'), T2('ბენზინი', 'ელექტრო', '8.4 ლ', '18 კვტ·სთ'), T2('სტოკი', 'ტიუნინგი', '340 ცხ.ძ.', '480 ცხ.ძ.'), T2('მექანიკა', 'ავტომატი', '3 პედალი', '2 პედალი')],
    [K('versus', 1000, 260, 'VS'), K('versus', 1000, 260, 'VS', { skin: 'grad' }), K('versus', 1000, 260, 'VS', { trim: 'check' })], { t1: 'მარცხენა', t2: 'მარჯვენა', t3: 'მარცხენას ქვეშ', t4: 'მარჯვენას ქვეშ' });
  for (i3 = 0; i3 < DESIGNS.length; i3++) { if (/^a-v\d/.test(DESIGNS[i3].id)) { DESIGNS[i3].name = DESIGNS[i3].defs.t1 + ' vs ' + DESIGNS[i3].defs.t2; DESIGNS[i3].defs.dur = 5; } }
  many('auto', 'a-c', true, [T2('BMW M5 Competition', 'ძრავა | 4.4 V8 ბი-ტურბო', 'სიმძლავრე | 625 ცხ.ძ.', '0–100 | 3.3 წმ'), T2('Nissan Silvia S15 (დრიფტი)', 'ძრავა | SR20DET', 'სიმძლავრე | 450 ცხ.ძ.', 'კუთხე | 65°'), T2('Toyota GR Yaris', 'ძრავა | 1.6 ტურბო', 'ამძრავი | სრული', 'წონა | 1 280 კგ'),
    T2('ტრასის მონაცემები', 'სიგრძე | 4.1 კმ', 'მოსახვევი | 12', 'რეკორდი | 1:38.2'), T2('სერვისის ფასები', 'ზეთის შეცვლა | 120 ₾', 'დიაგნოსტიკა | 50 ₾', 'დეტეილინგი | 400 ₾-დან'), T2('ელექტრომობილი', 'ბატარეა | 105 კვტ·სთ', 'მარაგი | 480 კმ', 'დატენვა | 18 წთ')],
    [K('specs', 760, 330, 'ბარათი'), K('specs', 760, 330, 'ბარათი', { skin: 'grad' }), K('specs', 760, 330, 'ბარათი', { trim: 'check' })], LR);
  many('auto', 'a-pl', true, [T2('DR-1FT-27', 'GE'), T2('GT3 RS'), T2('JDM-001', 'GE'), T2('V8 BITURBO'), T2('TURBO', 'GE'), T2('2JZ-GTE')],
    [K('plate', 760, 220, 'ნომერი', {}), K('plate', 760, 220, 'ფირფიტა', { plain: true, tone: 'dark' }), K('plate', 760, 220, 'ნომერი', { tone: 'dark', strip: '#FD4A00' }), K('plate', 760, 220, 'ფირფიტა', { plain: true }), K('plate', 760, 220, 'ნომერი', { tone: 'yellow' }), K('plate', 760, 220, 'ფირფიტა', { plain: true, tone: 'yellow' })], { t1: 'წარწერა', t2: 'ქვეყანა' });

  many('auto', 'a-z', true, SA.slice(0, 12), [K('stat', 700, 240, 'ზოლებით', { style: 'card', trim: 'stripes' }), K('stat', 700, 240, 'ამოხტომა', { style: 'split', enter: 'pop' }), K('stat', 700, 240, 'კვამლით', { trim: 'smoke' })], L3);
  for (i3 = 0; i3 < DESIGNS.length; i3++) { if (DESIGNS[i3].cat === 'auto' && !DESIGNS[i3].tag) { DESIGNS[i3].tag = tagOf(DESIGNS[i3].name + ' ' + (DESIGNS[i3].defs.t1 || '') + ' ' + (DESIGNS[i3].defs.t4 || '')); } }

  // --- competitions
  function vs(id, name, w, h, fam, V, defs, more, tag) {
    var d = add('vs', 'v-' + id, name, w, h, C[fam], V, ext({ players: true, dur: 6 }, defs || {})); d.fn = C[fam]; if (tag) { d.tag = tag; }
    if (more) { var from = DESIGNS.length; also(d, more); for (var q = from; q < DESIGNS.length; q++) { DESIGNS[q].tag = tag || ''; } }
  }
  var LV1 = { t1: 'სათაური' }, LVG = { t1: 'სათაური', t2: 'მიზანი (ქულა)' };
  vs('cards', 'ქულები გვერდიგვერდ', 1000, 280, 'cards', {}, { t1: '' }, ['grad', 'soft', 'drop']);
  vs('cards-lead', 'ქულები — ლიდერი გამოყოფილია', 1000, 280, 'cards', { lead: true }, { t1: 'ქულები', labels: LV1 }, ['hard', 'rise']);
  // points going to one, two or all of them — the same thing in many styles
  function pl(id, name, w, h, fam, V, defs, more, tag) {
    var d = add('vs', 'v-' + id, name, w, h, SC[fam], V, ext({ players: true, adds: true, dur: 5 }, defs || {})); d.fn = SC[fam]; d.tag = tag || '';
    if (more) { var from = DESIGNS.length; also(d, more); for (var q = from; q < DESIGNS.length; q++) { DESIGNS[q].tag = tag || ''; } }
  }
  var PN = 'ქულა ემატება · ';
  pl('plus', PN + 'ბარათები', 1000, 300, 'card', {}, {}, ['grad', 'soft']);
  pl('p-orb', PN + 'წრეები', 1000, 300, 'orb', {}, {}, ['soft']);
  pl('p-slant', PN + 'დახრილი ფირფიტები', 1000, 300, 'slant', {}, {}, ['grad']);
  pl('p-neon', PN + 'ნეონი', 1000, 300, 'neon');
  pl('p-flip', PN + 'გადასაფურცლი ტაბლო', 1000, 300, 'flip');
  pl('p-led', PN + 'LED ტაბლო', 1000, 300, 'led');
  pl('p-mini', PN + 'მინიმალური', 1000, 300, 'mini');
  pl('p-block', PN + 'ფერადი ზოლი', 1000, 300, 'block');
  pl('p-ticket', PN + 'ბილეთები', 1000, 300, 'ticket', {}, { t1: 'ქულა', labels: { t1: 'წარწერა ქულის ქვეშ' } });
  pl('p-hex', PN + 'ექვსკუთხედები', 1000, 300, 'hex');
  pl('p-shield', PN + 'ფარები', 1000, 300, 'shield');
  pl('p-comic', PN + 'კომიქსი', 1000, 300, 'comic');
  pl('p-coin', PN + 'მონეტები', 1000, 300, 'coin');
  pl('p-star', PN + 'ვარსკვლავები', 1000, 300, 'star', {}, {}, ['grad']);
  pl('p-paper', PN + 'ფურცლები', 1000, 300, 'paper');
  pl('p-glass', PN + 'მინა', 1000, 300, 'glass');
  pl('p-cols', PN + 'სვეტები', 1000, 330, 'cols', {}, {}, ['grad']);
  pl('p-ring', PN + 'რგოლები', 1000, 300, 'ring');
  pl('p-arcade', PN + 'არკადა', 1000, 300, 'arcade');
  pl('p-shout', PN + 'დიდად, სათითაოდ', 1000, 300, 'shout', {}, { t1: 'სულ:', labels: { t1: 'წარწერა ჯამის წინ' } });
  pl('p-rows', PN + 'სტრიქონები', 760, 540, 'rows', {}, {}, ['grad']);
  pl('p-bars', PN + 'ზოლები', 900, 520, 'bars');
  pl('p-rank', PN + 'ცხრილი, ადგილები იცვლება', 560, 540, 'rank', {}, { t1: 'ქულები', labels: { t1: 'სათაური' }, dur: 6 });
  pl('p-strip', PN + 'ზედა ზოლი', 1000, 160, 'strip', {}, { t1: 'რაუნდი 2', labels: { t1: 'მარცხენა წარწერა' }, dur: 6 });
  vs('out', 'გამოეთიშა', 1000, 280, 'out', {}, { t1: 'გამოეთიშა', pick: true, labels: { t1: 'ბეჭედზე წარწერა' }, dur: 5 }, ['soft']);
  vs('out-lost', 'წააგო რაუნდი', 1000, 280, 'out', {}, { t1: 'წააგო', pick: true, labels: { t1: 'ბეჭედზე წარწერა' }, dur: 5 });
  vs('turn', 'ვისი ჯერია', 1000, 300, 'turn', {}, { t1: 'ახლა თამაშობს', pick: true, labels: { t1: 'წარწერა' }, dur: 5 }, ['grad']);
  vs('turn-next', 'შემდეგი მონაწილე', 1000, 300, 'turn', {}, { t1: 'შემდეგია', pick: true, labels: { t1: 'წარწერა' }, dur: 5 });
  vs('board', 'ქულების ცხრილი (დალაგებული)', 560, 540, 'board', {}, { t1: 'ქულები', labels: LV1 }, ['grad', 'soft', 'right']);
  vs('board-keep', 'ქულების ცხრილი (შენი რიგით)', 560, 540, 'board', { keep: true }, { t1: 'შედეგები', labels: LV1 }, ['hard']);
  vs('board-final', 'საბოლოო შედეგები', 560, 540, 'board', {}, { t1: 'საბოლოო შედეგები', labels: LV1 }, ['unfold']);
  vs('race', 'ზოლების შეჯიბრი', 900, 520, 'race', {}, { t1: 'ვინ ლიდერობს?', t2: '', labels: LVG }, ['rise']);
  vs('race-goal', 'ზოლები მიზნამდე', 900, 520, 'race', {}, { t1: 'პირველი 15 ქულამდე', t2: '15', labels: LVG });
  vs('tally', 'ქულები წერტილებით', 900, 520, 'tally', {}, { t1: 'პირველი 5 მოგებამდე', t2: '5', labels: LVG }, ['pop']);
  vs('podium', 'პოდიუმი', 900, 470, 'podium', {}, {}, ['grad', 'soft']);
  vs('winner', 'რაუნდის გამარჯვებული', 1000, 280, 'winner', {}, { t1: 'რაუნდის გამარჯვებული', t2: 'ქულა', labels: { t1: 'ზედა წარწერა', t2: 'ქულის შემდეგ' }, dur: 5 }, ['grad']);
  vs('winner-final', 'ჩემპიონი', 1000, 280, 'winner', {}, { t1: 'ჩემპიონი', t2: 'ქულით', labels: { t1: 'ზედა წარწერა', t2: 'ქულის შემდეგ' }, dur: 6 }, ['zoom']);
  vs('winner-pick', 'ამ რაუნდს იგებს… (შენ ირჩევ)', 1000, 280, 'winner', { pick: true }, { t1: 'ამ რაუნდს იგებს', t2: '', pick: true, labels: { t1: 'ზედა წარწერა', t2: 'ქულის შემდეგ' }, dur: 5 });
  vs('versus', 'ყველა ყველას წინააღმდეგ (VS)', 1000, 240, 'versus', {}, { dur: 5 }, ['grad', 'hard']);
  vs('versus-score', 'VS ქულებით', 1000, 240, 'versus', { score: true }, { dur: 5 });
  vs('strip', 'ზედა ზოლი ქულებით', 1000, 120, 'strip', {}, { t1: 'რაუნდი 2', labels: { t1: 'მარცხენა წარწერა' }, dur: 8 }, ['grad', 'soft']);
  vs('strip-plain', 'ზედა ზოლი (წარწერის გარეშე)', 1000, 120, 'strip', {}, { t1: '', labels: { t1: 'მარცხენა წარწერა' }, dur: 8 });
  // the same for races and drift
  vs('r-board', 'რბოლის შედეგები', 560, 540, 'board', { trim: 'check' }, { t1: 'რბოლის შედეგები', labels: LV1 }, null, 'race');
  vs('r-cards', 'მრბოლელების ქულები', 1000, 280, 'cards', { lead: true, trim: 'check' }, { t1: 'ჩემპიონატის ქულები', labels: LV1 }, null, 'race');
  vs('r-versus', 'სტარტზე არიან', 1000, 240, 'versus', { trim: 'check' }, { dur: 5 }, null, 'race');
  vs('r-podium', 'რბოლის პოდიუმი', 900, 470, 'podium', { trim: 'check' }, {}, null, 'race');
  pl('r-plus', 'რბოლა მოიგო (+ქულა) · ბარათები', 1000, 300, 'card', { trim: 'speed' }, {}, null, 'race');
  pl('r-p-slant', 'რბოლის ქულები ემატება · დახრილი', 1000, 300, 'slant', { trim: 'check' }, {}, null, 'race');
  pl('r-p-led', 'რბოლის ტაბლო · LED (+ქულა)', 1000, 300, 'led', { trim: 'check' }, {}, null, 'race');
  pl('r-p-rank', 'ჩემპიონატის ცხრილი · ადგილები იცვლება', 560, 540, 'rank', { trim: 'check' }, { t1: 'ჩემპიონატი', labels: { t1: 'სათაური' }, dur: 6 }, null, 'race');
  pl('d-p-bars', 'დრიფტის ქულები ემატება · ზოლები', 900, 520, 'bars', { trim: 'smoke' }, {}, null, 'drift');
  pl('d-p-neon', 'დრიფტის ქულები ემატება · ნეონი', 1000, 300, 'neon', { trim: 'smoke' }, {}, null, 'drift');
  pl('d-p-shout', 'მსაჯების ქულა · დიდად', 1000, 300, 'shout', { trim: 'smoke' }, { t1: 'სულ:', labels: { t1: 'წარწერა ჯამის წინ' } }, null, 'drift');
  vs('r-strip', 'რბოლის ზედა ზოლი', 1000, 120, 'strip', { trim: 'speed' }, { t1: 'წრე 3 / 10', labels: { t1: 'მარცხენა წარწერა' }, dur: 8 }, null, 'race');
  vs('r-race', 'ჩემპიონატის ცხრილი (ზოლებით)', 900, 520, 'race', { trim: 'check' }, { t1: 'ჩემპიონატი', t2: '', labels: LVG }, null, 'race');
  vs('r-winner', 'რბოლის გამარჯვებული', 1000, 280, 'winner', { trim: 'check' }, { t1: 'რბოლის გამარჯვებული', t2: 'ქულა', labels: { t1: 'ზედა წარწერა', t2: 'ქულის შემდეგ' }, dur: 5 }, null, 'race');
  vs('d-board', 'დრიფტის ქულები', 560, 540, 'board', { trim: 'smoke' }, { t1: 'დრიფტის ქულები', labels: LV1 }, null, 'drift');
  vs('d-cards', 'დრიფტერების ქულები', 1000, 280, 'cards', { lead: true, trim: 'smoke' }, { t1: 'მსაჯების შეფასება', labels: LV1 }, null, 'drift');
  vs('d-versus', 'ტანდემის წყვილები', 1000, 240, 'versus', { score: true, trim: 'smoke' }, { dur: 5 }, null, 'drift');
  vs('d-winner', 'დრიფტის გამარჯვებული', 1000, 280, 'winner', { trim: 'smoke' }, { t1: 'საუკეთესო გასვლა', t2: 'ქულა', labels: { t1: 'ზედა წარწერა', t2: 'ქულის შემდეგ' }, dur: 5 }, null, 'drift');
  vs('d-out', 'ტანდემიდან გავარდა', 1000, 280, 'out', { trim: 'smoke' }, { t1: 'გავარდა', pick: true, labels: { t1: 'ბეჭედზე წარწერა' }, dur: 5 }, null, 'drift');
  vs('a-tally', 'დრაგის სერია (5 მოგებამდე)', 900, 520, 'tally', { trim: 'tyre' }, { t1: 'დრაგის სერია', t2: '5', labels: LVG }, null, 'race');
  vs('a-turn', 'ტრასაზე გადის', 1000, 300, 'turn', { trim: 'speed' }, { t1: 'ტრასაზე გადის', pick: true, labels: { t1: 'წარწერა' }, dur: 5 }, null, 'race');

  function design(id) { for (var i = 0; i < DESIGNS.length; i++) { if (DESIGNS[i].id === id) { return DESIGNS[i]; } } return null; }
  function inCategory(cat) { var out = []; for (var i = 0; i < DESIGNS.length; i++) { if (DESIGNS[i].cat === cat) { out.push(DESIGNS[i]); } } return out; }
  function norm(s) { return String(s || '').toLowerCase().replace(/\s+/g, ' '); }
  var TAGS = [{ id: 'auto', name: 'ავტო' }, { id: 'drift', name: 'დრიფტი' }, { id: 'race', name: 'რბოლა' }];
  var TAGWORD = { auto: 'ავტო მანქანა car auto', drift: 'დრიფტი drift ავტო', race: 'რბოლა race racing ავტო' };
  /** tag '' = everything; 'auto' = anything about cars (drift and racing too); 'drift' / 'race' = only those. */
  function tagged(list, tag) { if (!tag) { return list; } var out = []; for (var i = 0; i < list.length; i++) { var g = list[i].tag || ''; if (tag === 'auto' ? !!g : g === tag) { out.push(list[i]); } } return out; }
  function search(q) { q = norm(q); var out = []; for (var i = 0; i < DESIGNS.length; i++) { var d = DESIGNS[i]; if (norm(d.name + ' ' + d.id + ' ' + (TAGWORD[d.tag] || '')).indexOf(q) >= 0) { out.push(d); } } return out; }

  /** Everything a design needs, from what the user set (U) over the design's own defaults. */
  function params(d, U) {
    U = U || {};
    var f = d.defs || {}, isT = !!f.timer, tm = U.timer || {};
    var total = isT ? Math.max(1, Math.min(6 * 3600, Number(tm.total) || f.total || 30)) : 0;
    var P = {
      t1: U.t1 !== undefined ? U.t1 : (f.t1 || ''), t2: U.t2 !== undefined ? U.t2 : (f.t2 || ''), t3: U.t3 !== undefined ? U.t3 : (f.t3 || ''), t4: U.t4 !== undefined ? U.t4 : (f.t4 || ''),
      font: U.font || '"Helvetica Neue", Helvetica, Arial, sans-serif', accent: U.accent || '#FD4A00', color: U.color || '#FFFFFF', bg: U.bg || '#111111',
      noIn: !!U.noIn, noOut: !!U.noOut, fps: U.fps || 30, logo: U.logo || null,
      fs: U.fs || null, ts: U.ts || 1, track: U.track || 0, geoCaps: !!U.geoCaps
    };
    if (f.players) { var all = U.players && U.players.length ? U.players : PLAYERS, pn = clamp(Math.round(U.pn || 4), 2, 6); P.players = [];
      for (var q = 0; q < pn; q++) {
        var u = all[q] || PLAYERS[q], uc = /^#[0-9a-f]{6}$/i.test(u.c || '') ? u.c : P.accent, ua = f.adds ? parseFloat(String(u.a === undefined || u.a === null ? '' : u.a).replace(',', '.').replace(/[−–]/, '-').replace(/^\+/, '')) : 0;
        if (isNaN(ua)) { ua = 0; }
        P.players.push({ n: u.n, s: u.s, c: uc, a: ua, ph: u.ph || '', img: u.img && typeof u.img === 'object' ? u.img : null });
        if (uc.toLowerCase() !== String(P.accent).toLowerCase()) { P.multi = true; }
        if (ua) { P.adds = true; }
        if (hasPhoto(P.players[q])) { P.photos = true; }
      }
      P.pick = clamp(Math.round(U.pick || 0), 0, pn - 1);
    }
    if (isT) { P.timer = { total: total, down: f.down === false ? false : tm.down !== false, fmt: tm.fmt || f.fmt || 'auto' }; P.dur = total + 1; }
    else { P.dur = Math.max(1.5, Math.min(600, Number(U.dur) || f.dur || 5)); }
    return P;
  }
  /** Paint one frame: the design at time t, scaled by k (canvas pixels per design unit). */
  function paint(ctx, d, t, P, k) {
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.scale(k, k);
    try { d.draw(ctx, t, P); } finally { ctx.restore(); }
  }
  function even(n) { n = Math.max(2, Math.ceil(n)); return n + (n % 2); }
  /** Size of the movie for a picture of seqW × seqH; `size` is the user's scale (1 = as designed for 1080p). */
  function output(d, seqW, seqH, size) {
    var k = Math.min(seqW, seqH) / 1080 * (size || 1), w = even(d.w * k), h = even(d.h * k);
    if (w > seqW) { k *= seqW / w; w = even(d.w * k); h = even(d.h * k); }
    return { w: w, h: h, k: w / d.w };
  }
  function fpsArg(fps) {
    var table = [[23.976, '24000/1001'], [29.97, '30000/1001'], [59.94, '60000/1001'], [47.952, '48000/1001'], [119.88, '120000/1001']];
    for (var i = 0; i < table.length; i++) { if (Math.abs(fps - table[i][0]) < 0.01) { return table[i][1]; } }
    return String(Math.round(fps * 1000) / 1000);
  }
  function mmss(sec) { sec = Math.max(0, Math.round(sec)); return Math.floor(sec / 60) + ':' + pad(sec % 60, 2); }
  /** "1:30", "90", "1:02:03" → seconds. */
  function parseTime(s) {
    var p = String(s || '').replace(/[^\d:.]/g, '').split(':'), v = 0;
    for (var i = 0; i < p.length; i++) { v = v * 60 + (parseFloat(p[i]) || 0); }
    return v;
  }

  root.QFXGfx = { PLAYERS: PLAYERS, TAGS: TAGS, tagged: tagged, CATS: CATS, DESIGNS: DESIGNS, NET: NET, design: design, inCategory: inCategory, search: search, params: params, paint: paint,
    output: output, fpsArg: fpsArg, clock: clock, mmss: mmss, parseTime: parseTime, st: st };
})(typeof window !== 'undefined' ? window : (typeof module !== 'undefined' ? module.exports : this));
