/*
 * Quick FX — downloading a video (or only its picture / only its sound) into the project.
 *
 * The work is done by three well-known open-source tools, fetched once into
 * ~/Library/Application Support/QuickFX/bin on first use:
 *   yt-dlp  — finds and downloads the streams
 *   deno    — the JavaScript runtime yt-dlp needs for YouTube
 *   ffmpeg  — joins picture + sound, and converts what Premiere cannot open
 *
 * YouTube serves H.264 (which Premiere opens directly) only up to 1080p. Above that the stream is
 * VP9/AV1, so those are converted to H.264 after the download — slower, same picture size.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  if (root) { root.QFXYt = api; }
})(this, function () {
  'use strict';

  var GH = 'https://github.com/';

  /** What to fetch on first use, for this Mac's processor. */
  function tools(arch) {
    var arm = String(arch || '').indexOf('arm') === 0;
    return [
      { name: 'yt-dlp', file: 'yt-dlp', check: ['--version'], url: GH + 'yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos' },
      { name: 'deno', file: 'deno', zip: true, check: ['--version'], url: GH + 'denoland/deno/releases/latest/download/deno-' + (arm ? 'aarch64' : 'x86_64') + '-apple-darwin.zip' },
      { name: 'ffmpeg', file: 'ffmpeg', check: ['-version'], url: GH + 'eugeneware/ffmpeg-static/releases/download/b6.1.1/ffmpeg-darwin-' + (arm ? 'arm64' : 'x64') }
    ];
  }

  function isUrl(text) {
    return /^https?:\/\/[^\s/]+\.[^\s/]+\/\S*$/i.test(String(text || '').replace(/^\s+|\s+$/g, ''));
  }
  function isYouTube(text) { return /^https?:\/\/([a-z0-9-]+\.)?(youtube\.com|youtu\.be|youtube-nocookie\.com)\//i.test(String(text || '')); }

  /** A file name that is safe on macOS and readable in the Project panel. */
  function safeName(title, id) {
    // no emoji (Premiere's scripting cannot address files whose names contain them) and no #hashtags (TikTok captions are full of both)
    var t = String(title || 'video').replace(/[\uD800-\uDFFF\uFE00-\uFE0F\u200D\u20E3]/g, '').replace(/(^|\s)#[^\s#]+/g, ' ')
      .replace(/[\/\\:*?"<>|\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').replace(/^[\s.]+|[\s.]+$/g, '');
    if (t.length > 80) { t = t.slice(0, 80).replace(/\s+$/, ''); }
    return (t || 'video') + (id ? ' [' + String(id).replace(/[^A-Za-z0-9_-]/g, '') + ']' : '');
  }

  function clock(sec) {
    sec = Math.max(0, Math.round(Number(sec) || 0));
    var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    return (h ? h + ':' + (m < 10 ? '0' : '') : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }

  /** "45" · "0:45" · "1:02:05" · "1.20" · "1m20s" → seconds (null when it is not a time) */
  function parseTime(text) {
    var t = String(text == null ? '' : text).replace(/^\s+|\s+$/g, '').toLowerCase();
    if (!t) { return null; }
    var m = /^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+(?:\.\d+)?)s?)?$/.exec(t);
    if (m && /[hms]/.test(t)) { return (Number(m[1]) || 0) * 3600 + (Number(m[2]) || 0) * 60 + (Number(m[3]) || 0); }
    var parts = t.split(/[:.,;\s]+/), sec = 0;
    if (parts.length > 3) { return null; }
    for (var i = 0; i < parts.length; i++) {
      if (!/^\d+$/.test(parts[i])) { return null; }
      if (i > 0 && parts.length > 1 && Number(parts[i]) > 59) { return null; }
      sec = sec * 60 + Number(parts[i]);
    }
    return sec;
  }

  /** The start time a link carries: …?t=45 · …&t=1m20s · …#t=90 */
  function timeFromUrl(url) {
    var m = /[?&#](?:t|start)=([0-9hms.]+)/i.exec(String(url || ''));
    var v = m ? parseTime(m[1]) : null;
    return v && v > 0 ? v : 0;
  }

  /** A section for file names: "0.45-1.20" */
  function sectionTag(sec) { return clock(sec.start).replace(/:/g, '.') + '-' + clock(sec.end).replace(/:/g, '.'); }
  function goodSection(sec) { return !!sec && Number(sec.end) > Number(sec.start) && Number(sec.start) >= 0; }

  function sizeOf(f) { return Number(f.filesize) || Number(f.filesize_approx) || 0; }

  function siteOf(j) {
    var key = String((j && (j.extractor_key || j.extractor)) || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    if (!key || /youtube/.test(key)) { return { site: 'youtube', name: 'YouTube' }; }
    if (/tiktok|douyin/.test(key)) { return { site: 'tiktok', name: 'TikTok' }; }
    var raw = String(j.extractor_key || j.extractor).replace(/[^A-Za-z0-9]/g, '').slice(0, 24);
    return { site: key.slice(0, 24), name: raw || 'Video' };
  }

  /**
   * Sites other than YouTube (TikTok first of all). Their files usually hold picture and sound together, so
   * each quality remembers the exact file to fetch (fid) instead of a YouTube-style rule.
   *  - copies that carry the app's watermark are left out, so what is offered is the clean original;
   *  - on TikTok the separate "audio" entry is the music track, not this video's own sound, so it is never
   *    paired with a picture and never used for "sound only";
   *  - yt-dlp lists formats worst → best, so the last one seen for a height is the best one.
   */
  function parseOther(j, where) {
    var formats = (j && j.formats) || [], byH = {}, hasAudio = false, marked = 0, i;
    for (i = 0; i < formats.length; i++) {
      var f = formats[i], v = f.vcodec && f.vcodec !== 'none', a = f.acodec && f.acodec !== 'none', note = String(f.format_note || '');
      if (/watermark/i.test(note)) { marked++; continue; }
      if (/UNPLAYABLE|storyboard/i.test(note) || Number(f.preference) <= -100) { continue; }
      if (a && (v || where.site !== 'tiktok')) { hasAudio = true; }
      if (!v || !f.height) { continue; }
      if (where.site === 'tiktok' && !a) { continue; }
      var h = stdHeight(f.height, f.width), vc = String(f.vcodec).toLowerCase();
      var codec = /^(h265|hev|hvc)/.test(vc) ? 'hevc' : (/^(avc|h264)/.test(vc) ? 'h264' : vc.split('.')[0]);
      byH[h] = {
        height: h, px: Number(f.height), fps: Math.round(Number(f.fps) || 0), fid: String(f.format_id), codec: codec, sound: !!a,
        // Premiere opens H.264 and HEVC in an .mp4 / .mov as they are; anything else is converted after the download
        direct: (codec === 'h264' || codec === 'hevc') && /^(mp4|mov|m4v)$/i.test(String(f.ext || '')), bytes: sizeOf(f)
      };
    }
    var list = [];
    for (var k in byH) { if (byH.hasOwnProperty(k)) { list.push(byH[k]); } }
    list.sort(function (x, y) { return y.height - x.height; });
    return {
      id: String(j.id || ''), title: String(j.title || j.fulltitle || j.description || (j.uploader ? '@' + j.uploader : '')).replace(/\s+/g, ' ').slice(0, 200), uploader: String(j.uploader || j.channel || j.creator || ''),
      duration: Number(j.duration) || 0, thumbnail: String(j.thumbnail || ''), live: !!j.is_live,
      qualities: list, hasAudio: hasAudio, audioBytes: 0, url: String(j.webpage_url || j.original_url || ''),
      site: where.site, siteName: where.name, clean: where.site === 'tiktok' && list.length > 0, watermarked: marked
    };
  }

  /** yt-dlp's -J output → what the panel shows. */
  function parseInfo(j) {
    var where = siteOf(j);
    if (where.site !== 'youtube') { return parseOther(j, where); }
    var formats = (j && j.formats) || [], byH = {}, audio = 0, hasAudio = false, i;
    for (i = 0; i < formats.length; i++) {
      var f = formats[i], v = f.vcodec && f.vcodec !== 'none', a = f.acodec && f.acodec !== 'none';
      if (a && !v) {
        hasAudio = true;
        if (f.ext === 'm4a' && sizeOf(f) > audio) { audio = sizeOf(f); }
      }
      if (a && v) { hasAudio = true; }
      if (!v || !f.height || /storyboard/i.test(String(f.format_note || ''))) { continue; }
      // 1080p is sometimes 1920×1012 etc.: name the quality by its nearest standard height
      var h = stdHeight(f.height, f.width);
      var e = byH[h] || (byH[h] = { height: h, px: 0, fps: 0, direct: false, bytes: 0, directBytes: 0 });
      if (Number(f.height) > e.px) { e.px = Number(f.height); }
      var avc = /^avc1/.test(String(f.vcodec));
      if (Number(f.fps) > e.fps) { e.fps = Math.round(Number(f.fps)); }
      if (avc) { e.direct = true; if (sizeOf(f) > e.directBytes) { e.directBytes = sizeOf(f); } }
      if (sizeOf(f) > e.bytes) { e.bytes = sizeOf(f); }
    }
    var list = [];
    for (var k in byH) {
      if (byH.hasOwnProperty(k)) {
        var q = byH[k];
        list.push({ height: q.height, px: q.px, fps: q.fps, direct: q.direct, bytes: (q.direct ? q.directBytes || q.bytes : q.bytes) });
      }
    }
    list.sort(function (x, y) { return y.height - x.height; });
    return {
      id: String(j.id || ''), title: String(j.title || j.fulltitle || ''), uploader: String(j.uploader || j.channel || ''),
      duration: Number(j.duration) || 0, thumbnail: String(j.thumbnail || ''), live: !!j.is_live,
      qualities: list, hasAudio: hasAudio, audioBytes: audio, url: String(j.webpage_url || j.original_url || ''),
      site: 'youtube', siteName: 'YouTube'
    };
  }

  function stdHeight(h, w) {
    var std = [144, 240, 360, 480, 720, 1080, 1440, 2160, 4320], best = std[0], i;
    // vertical videos: the short side decides ("1080p" vertical is 1080×1920)
    var side = (w && w < h) ? w : h;
    for (i = 0; i < std.length; i++) { if (Math.abs(std[i] - side) < Math.abs(best - side)) { best = std[i]; } }
    return best;
  }

  function label(q) { return (q.height >= 2160 ? '4K' : q.height + 'p') + (q.fps > 30 ? ' ' + q.fps : ''); }

  function bitrate(height, fps) {
    var mbps = height >= 2160 ? 45 : (height >= 1440 ? 24 : (height >= 1080 ? 12 : 8));
    if (fps > 30) { mbps = Math.round(mbps * 1.4); }
    return mbps + 'M';
  }

  /**
   * Arguments for one download.
   *   o: { url, mode: 'both'|'video'|'audio', height, px, fps, direct, dir, base, binDir, software, cookies }
   * height is the quality's name (1080), px the real pixel height to filter by (1920 for a vertical 1080p).
   * section: { start, end } in seconds — only that part of the video.
   * site / fid / sound: for sites other than YouTube — which file exactly, and whether it already carries sound.
   * The output name is fixed by us (base), so the finished file is found without parsing yt-dlp's text.
   */
  function buildArgs(o) {
    var Q = Number(o.height) || 1080, H = Number(o.px) || Q;
    var a = ['--no-playlist', '--newline', '--progress', '--no-mtime',
      '--progress-template', 'download:QFX|%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s',
      '--ffmpeg-location', o.binDir, '--js-runtimes', 'deno:' + o.binDir + '/deno',
      '-o', o.dir + '/' + o.base + '.%(ext)s'];
    var enc = o.software ? ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18'] : ['-c:v', 'h264_videotoolbox', '-b:v', bitrate(Q, o.fps)];
    if (o.site && o.site !== 'youtube') {
      // the exact file chosen in the panel; "+ba" only where the site keeps sound apart (never on TikTok: see parseOther)
      var pair = !!o.fid && !o.sound && o.site !== 'tiktok' && o.mode !== 'audio';
      var src = o.fid ? (pair ? o.fid + '+ba/' : '') + o.fid + '/b' : 'b';
      var tail = ['-pix_fmt', 'yuv420p'].concat(o.mode === 'video' ? ['-an'] : ['-c:a', 'aac', '-b:a', '256k']);
      if (goodSection(o.section)) { a.push('--download-sections', '*' + Number(o.section.start) + '-' + Number(o.section.end)); }
      if (o.mode === 'audio') {
        // this video's own sound, taken out of the video file
        a.push('-f', o.site === 'tiktok' ? (o.fid ? o.fid + '/b' : 'ba/b') : 'ba/' + src, '-x', '--audio-format', 'm4a');
      } else if (goodSection(o.section)) {
        a.push('--force-keyframes-at-cuts', '--downloader-args', 'ffmpeg_o:' + enc.concat(tail).join(' '), '-f', src);
        if (pair) { a.push('--merge-output-format', 'mp4'); }
      } else {
        a.push('-f', src);
        if (pair) { a.push('--merge-output-format', o.direct ? 'mp4' : 'mkv'); }
        if (o.direct) { a.push('--remux-video', 'mp4'); }
        else { a.push('--recode-video', 'mp4', '--postprocessor-args', 'VideoConvertor:' + enc.concat(tail).join(' ')); }
      }
    } else if (goodSection(o.section)) {
      // Only this part is fetched. Picture is re-encoded while it downloads, so the cut is exact
      // (not at the nearest keyframe) and the result is H.264 whatever the source was — 4K included.
      a.push('--download-sections', '*' + Number(o.section.start) + '-' + Number(o.section.end));
      if (o.mode === 'audio') {
        a.push('-f', 'ba[ext=m4a]/ba[acodec^=mp4a]');
      } else {
        a.push('--force-keyframes-at-cuts', '--downloader-args',
          'ffmpeg_o:' + enc.concat(['-pix_fmt', 'yuv420p'], o.mode === 'video' ? ['-an'] : ['-c:a', 'aac', '-b:a', '256k']).join(' '));
        if (o.mode === 'video' && o.direct) {
          a.push('-f', 'bv[height<=' + H + '][vcodec^=avc1]');
        } else {
          // (picture only, above 1080p: the sound stream is paired just to get an .mp4 out, and dropped by -an)
          a.push('-f', o.direct ? 'bv*[height<=' + H + '][vcodec^=avc1]+ba[ext=m4a]/b[height<=' + H + '][ext=mp4]'
            : 'bv*[height<=' + H + '][ext=webm]+ba/bv*[height<=' + H + ']+ba/bv[height<=' + H + '][ext=mp4]', '--merge-output-format', 'mp4');
        }
      }
    } else if (o.mode === 'audio') {
      a.push('-f', 'ba[ext=m4a]/ba[acodec^=mp4a]');
    } else if (o.mode === 'video') {
      if (o.direct) {
        a.push('-f', 'bv[height<=' + H + '][vcodec^=avc1]/bv*[height<=' + H + '][vcodec^=avc1]');
      } else {
        a.push('-f', 'bv[height<=' + H + '][ext=webm]/bv[height<=' + H + ']', '--recode-video', 'mp4',
          '--postprocessor-args', 'VideoConvertor:' + enc.concat(['-pix_fmt', 'yuv420p', '-an']).join(' '));
      }
    } else {
      if (o.direct) {
        a.push('-f', 'bv*[height<=' + H + '][vcodec^=avc1]+ba[ext=m4a]/b[height<=' + H + '][ext=mp4]', '--merge-output-format', 'mp4');
      } else {
        a.push('-f', 'bv*[height<=' + H + '][ext=webm]+ba/bv*[height<=' + H + ']+ba', '--merge-output-format', 'mkv', '--recode-video', 'mp4',
          '--postprocessor-args', 'VideoConvertor:' + enc.concat(['-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '256k']).join(' '));
      }
    }
    if (o.cookies) { a.push('--cookies-from-browser', String(o.cookies)); }
    a.push(o.url);
    return a;
  }

  function finalExt(mode) { return mode === 'audio' ? 'm4a' : 'mp4'; }

  /** "Title [id] 1080p" · "Title [id] 1080p video" · "Title [id]" (sound only) */
  function outBase(info, mode, q, section) {
    var b = safeName(info.title, info.id), tag = goodSection(section) ? ' ' + sectionTag(section) : '';
    if (mode === 'audio' || !q) { return b + tag; }
    return b + ' ' + label(q).replace(/\s+/g, '-') + (mode === 'video' ? ' video' : '') + tag;
  }

  /** One line of yt-dlp output → an event for the progress display (or null). */
  function parseLine(line) {
    line = String(line || '');
    if (line.indexOf('QFX|') === 0) {
      var p = line.split('|'), pct = parseFloat(String(p[1]).replace('%', ''));
      return { type: 'progress', pct: isNaN(pct) ? null : pct, speed: clean(p[2]), eta: clean(p[3]) };
    }
    if (/^\[download\] Destination:/.test(line)) { return { type: 'part' }; }
    var tm = /\btime=(\d+):(\d\d):(\d\d(?:\.\d+)?)/.exec(line);            // ffmpeg's own status line (section downloads)
    if (tm) {
      var sp = /\bspeed=\s*([\d.]+)x/.exec(line);
      return { type: 'time', sec: Number(tm[1]) * 3600 + Number(tm[2]) * 60 + Number(tm[3]), speed: sp ? Number(sp[1]) : 0 };
    }
    if (/^\[Merger\]/.test(line)) { return { type: 'phase', phase: 'merge' }; }
    if (/^\[VideoConvertor\]/.test(line)) { return { type: 'phase', phase: 'convert' }; }
    if (/^\[(FixupM4a|Fixup\w*|ExtractAudio)\]/.test(line)) { return { type: 'phase', phase: 'fix' }; }
    return null;
  }
  function clean(s) { s = String(s == null ? '' : s).replace(/^\s+|\s+$/g, ''); return (/^(N\/A|NA|Unknown.*)$/i.test(s)) ? '' : s; }

  /** Why it failed, from yt-dlp's error text. */
  function classify(text) {
    text = String(text || '');
    if (/Sign in to confirm|confirm you.re not a bot|age.restricted|Sign in to confirm your age/i.test(text)) { return 'ytLogin'; }
    if (/Private video|Video unavailable|This video is unavailable|has been removed|members-only|not available in your country/i.test(text)) { return 'ytUnavailable'; }
    if (/HTTP Error 429|Too Many Requests/i.test(text)) { return 'ytBusy'; }
    if (/Unsupported URL|is not a valid URL/i.test(text)) { return 'ytBadUrl'; }
    if (/Requested format is not available/i.test(text)) { return 'ytNoFormat'; }
    if (/getaddrinfo|Temporary failure in name resolution|Network is unreachable|timed out|Unable to download webpage|Connection (refused|reset)/i.test(text)) { return 'ytNetwork'; }
    if (/No space left on device/i.test(text)) { return 'ENOSPC'; }
    return 'ytFailed';
  }
  function lastError(text) {
    var lines = String(text || '').split(/\r?\n/), i;
    for (i = lines.length - 1; i >= 0; i--) { if (/^ERROR:/.test(lines[i])) { return lines[i].replace(/^ERROR:\s*/, '').slice(0, 300); } }
    for (i = lines.length - 1; i >= 0; i--) { if (lines[i].replace(/\s/g, '')) { return lines[i].slice(0, 300); } }
    return '';
  }

  // ------------------------------------------------------------------ engine (needs Node: the panel's cep_node)
  /**
   * n: { fs, path, os, child_process, https, http }   opts: { binDir, arch, tools?, unzip? }
   */
  function createEngine(n, opts) {
    var fs = n.fs, cp = n.child_process, binDir = opts.binDir;
    var list = opts.tools || tools(opts.arch);
    // two slots, so a link can be looked up while a download is running: 'dl' (one download at a time) and 'info'
    var procs = { dl: null, info: null }, cancelled = { dl: false, info: false };

    function p(name) { return binDir + '/' + name; }
    function exists(f) { try { return fs.statSync(f).size > 0; } catch (e) { return false; } }
    function mkdirp(dir) {
      if (!dir || dir === '/' || fs.existsSync(dir)) { return; }
      mkdirp(dir.slice(0, dir.lastIndexOf('/')));
      try { fs.mkdirSync(dir); } catch (e) { if (!fs.existsSync(dir)) { throw e; } }
    }
    function env() {
      var e = {}, src = (n.process && n.process.env) || {}, k;
      for (k in src) { if (Object.prototype.hasOwnProperty.call(src, k)) { e[k] = src[k]; } }
      e.PATH = binDir + ':' + (e.PATH || '/usr/bin:/bin:/usr/sbin:/sbin');
      return e;
    }

    function status() {
      var missing = [];
      for (var i = 0; i < list.length; i++) { if (!exists(p(list[i].file))) { missing.push(list[i].name); } }
      return { ready: !missing.length, missing: missing, binDir: binDir };
    }

    function fetchTo(url, dest, onPct, hops) {
      return new Promise(function (resolve, reject) {
        var lib = /^http:/i.test(url) ? n.http : n.https;
        var req = lib.get(url, { headers: { 'User-Agent': 'QuickFX' } }, function (res) {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            res.resume();
            if ((hops || 0) > 6) { reject(new Error('too many redirects')); return; }
            var next = res.headers.location;
            if (!/^https?:/i.test(next)) { next = url.replace(/^(https?:\/\/[^/]+).*$/, '$1') + next; }
            fetchTo(next, dest, onPct, (hops || 0) + 1).then(resolve, reject);
            return;
          }
          if (res.statusCode !== 200) { res.resume(); reject(new Error('HTTP ' + res.statusCode)); return; }
          var total = Number(res.headers['content-length']) || 0, got = 0, out = fs.createWriteStream(dest);
          res.on('data', function (chunk) { got += chunk.length; if (onPct && total) { onPct(got / total * 100); } });
          res.on('error', function (e) { try { out.destroy(); } catch (e2) {} reject(e); });
          out.on('error', reject);
          out.on('finish', function () { resolve(got); });
          res.pipe(out);
        });
        req.on('error', reject);
        if (req.setTimeout) { req.setTimeout(60000, function () { req.destroy(new Error('timed out')); }); }
      });
    }

    function run(cmd, args, onLine, slot) {
      return new Promise(function (resolve) {
        var out = '', err = '', child;
        try { child = cp.spawn(cmd, args, { env: env(), detached: !!slot }); } catch (e) { resolve({ code: -1, out: '', err: String(e && e.message || e) }); return; }
        if (slot) { procs[slot] = child; }
        function feed(buf, isErr) {
          var s = String(buf);
          if (isErr) { err += s; if (err.length > 200000) { err = err.slice(-100000); } }
          else { out += s; if (!onLine && out.length > 30000000) { out = out.slice(-30000000); } }
          if (onLine) { var ls = s.split(/[\r\n]+/); for (var i = 0; i < ls.length; i++) { if (ls[i]) { onLine(ls[i], isErr); } } }
        }
        child.stdout.on('data', function (b) { feed(b, false); });
        child.stderr.on('data', function (b) { feed(b, true); });
        child.on('error', function (e) { if (slot && procs[slot] === child) { procs[slot] = null; } resolve({ code: -1, out: out, err: err + String(e && e.message || e) }); });
        child.on('close', function (code, signal) { if (slot && procs[slot] === child) { procs[slot] = null; } resolve({ code: code, signal: signal, out: out, err: err }); });
      });
    }

    /** Does each tool actually start on this Mac? A file that is there but cannot run is removed, so the next install fetches it again. */
    function verify(onCheck) {
      var i = 0;
      function next() {
        if (i >= list.length) { return Promise.resolve(status()); }
        var t = list[i++];
        if (!t.check) { return next(); }
        if (onCheck) { onCheck(t.name); }
        return run(p(t.file), t.check).then(function (r) {
          if (r.code !== 0) {
            try { fs.unlinkSync(p(t.file)); } catch (e) {}
            var er = new Error(t.name + ' does not start on this computer: ' + (lastError(r.err) || 'exit ' + r.code));
            er.code = 'ytToolBroken';
            throw er;
          }
          return next();
        });
      }
      return next();
    }

    /** First use: fetch the three tools, then make sure they run. onStep(index, total, name, percent) — percent -1 while checking */
    function install(onStep) {
      mkdirp(binDir);
      var i = 0;
      function next() {
        if (i >= list.length) { return verify(function (name) { if (onStep) { onStep(list.length - 1, list.length, name, -1); } }); }
        var t = list[i], idx = i++;
        if (exists(p(t.file))) { return next(); }
        var tmp = p(t.file + (t.zip ? '.zip' : '') + '.part');
        if (onStep) { onStep(idx, list.length, t.name, 0); }
        return fetchTo(t.url, tmp, function (pct) { if (onStep) { onStep(idx, list.length, t.name, pct); } }).then(function () {
          if (!t.zip) { fs.renameSync(tmp, p(t.file)); return null; }
          var zip = p(t.file + '.zip');
          fs.renameSync(tmp, zip);
          var unzip = opts.unzip || ['/usr/bin/ditto', ['-xk', zip, binDir]];
          return run(unzip[0], unzip[1]).then(function (r) {
            try { fs.unlinkSync(zip); } catch (e) {}
            if (r.code !== 0 || !exists(p(t.file))) { throw new Error('unzip ' + t.name + ': ' + (r.err || r.code)); }
          });
        }).then(function () {
          fs.chmodSync(p(t.file), 493);                                   // 0755
          return run('/usr/bin/xattr', ['-d', 'com.apple.quarantine', p(t.file)]);   // harmless when not set
        }).then(next);
      }
      return next();
    }

    function ytdlp(args, onLine, slot) { return run(p('yt-dlp'), args, onLine, slot); }

    function update() {
      return ytdlp(['-U']).then(function (r) { return { updated: /Updated yt-dlp to/i.test(r.out + r.err), text: lastLine(r.out + '\n' + r.err) }; });
    }
    function lastLine(t) { var l = String(t).split(/\r?\n/).filter(function (x) { return x.replace(/\s/g, ''); }); return l.length ? l[l.length - 1].slice(0, 200) : ''; }

    function failure(r, slot) {
      var text = r.err + '\n' + r.out.slice(-4000);
      var e = new Error(lastError(r.err) || lastError(r.out) || 'yt-dlp exited with ' + r.code);
      e.code = ((slot && cancelled[slot]) || r.signal) ? 'ytCancelled' : classify(text);
      e.log = text.slice(-3000);
      return e;
    }

    /** Retry once after updating yt-dlp: YouTube changes often, and an old yt-dlp is the usual reason for a failure. */
    function withUpdate(attempt) {
      return attempt().catch(function (e) {
        if (e.code !== 'ytFailed' && e.code !== 'ytNoFormat') { throw e; }
        return update().then(function (u) {
          if (!u.updated) { throw e; }
          return attempt();
        });
      });
    }

    function info(url, cookies) {
      stop('info');                                                // a newer lookup replaces the one still running
      cancelled.info = false;
      return withUpdate(function () {
        return ytdlp(['-J', '--no-playlist', '--no-warnings', '--js-runtimes', 'deno:' + p('deno')].concat(cookies ? ['--cookies-from-browser', String(cookies)] : [], [url]), null, 'info').then(function (r) {
          if (r.code !== 0) { throw failure(r, 'info'); }
          var j;
          try { j = JSON.parse(r.out); } catch (e) { var er = new Error('bad JSON from yt-dlp'); er.code = 'ytFailed'; er.log = r.out.slice(0, 500); throw er; }
          return parseInfo(j);
        });
      });
    }

    /** o: { url, mode, height, fps, direct, dir, base }   onEvent: progress / part / phase events */
    function download(o, onEvent) {
      mkdirp(o.dir);
      cancelled.dl = false;
      var target = o.dir + '/' + o.base + '.' + finalExt(o.mode);
      if (exists(target)) { return Promise.resolve({ path: target, bytes: fs.statSync(target).size, existed: true }); }
      // "picture only" from a file that holds picture + sound (TikTok): fetched under a working name, then the sound is dropped
      var strip = o.mode === 'video' && !!o.site && o.site !== 'youtube' && !!o.sound && o.direct && !goodSection(o.section);
      var fetched = strip ? o.dir + '/' + o.base + '.src.mp4' : target;
      function attempt(software) {
        var args = buildArgs({ url: o.url, mode: o.mode, height: o.height, px: o.px, fps: o.fps, direct: o.direct, dir: o.dir, base: o.base + (strip ? '.src' : ''), binDir: binDir, software: software, cookies: o.cookies, section: o.section,
          site: o.site, fid: o.fid, sound: o.sound });
        return ytdlp(args, function (line) { var ev = parseLine(line); if (ev && onEvent) { onEvent(ev); } }, 'dl').then(function (r) {
          if (r.code !== 0) {
            var e = failure(r, 'dl');
            // no hardware encoder in this ffmpeg build → one more go with the software encoder
            if (!cancelled.dl && !software && o.mode !== 'audio' && (!o.direct || goodSection(o.section)) && /Postprocessing|videotoolbox|encoder|Conversion failed|ffmpeg exited/i.test(e.log)) { return attempt(true); }
            throw e;
          }
          if (!exists(fetched)) { var er = new Error('finished, but the file is not where it should be'); er.code = 'ytFailed'; er.log = r.out.slice(-1500); throw er; }
          if (!strip) { return null; }
          if (onEvent) { onEvent({ type: 'phase', phase: 'fix' }); }
          return run(p('ffmpeg'), ['-y', '-loglevel', 'error', '-i', fetched, '-map', '0:v:0', '-c', 'copy', '-an', '-movflags', '+faststart', target]).then(function (x) {
            try { fs.unlinkSync(fetched); } catch (e3) {}
            if (x.code !== 0 || !exists(target)) { var er3 = new Error('could not remove the sound: ' + (lastError(x.err) || 'ffmpeg exit ' + x.code)); er3.code = 'ytFailed'; er3.log = x.err.slice(-1500); throw er3; }
            return null;
          });
        }).then(function (r2) {
          if (r2 && r2.path) { return r2; }                              // (the software-encoder retry already produced the result)
          // yt-dlp can report success for a section it could not read (a few hundred bytes of container, no media)
          if (fs.statSync(target).size < 1024) { var er2 = new Error('the downloaded file is empty'); er2.code = 'ytFailed'; er2.log = ''; throw er2; }
          return { path: target, bytes: fs.statSync(target).size };
        });
      }
      return withUpdate(function () { return attempt(false); }).then(function (r) { sweep(o.dir, o.base, target); return r; }, function (e) {
        sweep(o.dir, o.base, null);
        throw e;
      });
    }

    function stop(slot) {
      var child = procs[slot];
      if (!child) { return; }
      cancelled[slot] = true;
      try { n.process.kill(-child.pid, 'SIGTERM'); } catch (e) { try { child.kill('SIGTERM'); } catch (e2) {} }
    }
    /** Stops the running download (a lookup of another link is left alone). */
    function cancel() { stop('dl'); }

    /** Half-finished pieces of one download (.part, .f299.mp4, .mkv …); the finished file is kept. */
    function sweep(dir, base, keep) {
      var names = [];
      try { names = fs.readdirSync(dir); } catch (e) { return; }
      for (var i = 0; i < names.length; i++) {
        if (names[i].indexOf(base + '.') !== 0 || dir + '/' + names[i] === keep) { continue; }
        try { fs.unlinkSync(dir + '/' + names[i]); } catch (e2) {}
      }
    }

    return { status: status, install: install, verify: verify, info: info, download: download, cancel: cancel, cancelInfo: function () { stop('info'); }, update: update, binDir: binDir, busy: function () { return !!procs.dl; } };
  }

  return {
    tools: tools, isUrl: isUrl, isYouTube: isYouTube, safeName: safeName, clock: clock, parseInfo: parseInfo, label: label,
    buildArgs: buildArgs, finalExt: finalExt, outBase: outBase, parseTime: parseTime, timeFromUrl: timeFromUrl, sectionTag: sectionTag, parseLine: parseLine, classify: classify, lastError: lastError, bitrate: bitrate,
    createEngine: createEngine
  };
});
