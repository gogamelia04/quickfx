/*
 * Quick FX — text animations: the library and the maths.
 *
 * An animation moves the WHOLE text clip (Premiere's scripting cannot reach single letters), using three
 * ordinary effects the host adds to the clip: Transform, Gaussian Blur and Crop. Because nothing is baked
 * into the text itself, font, size, colour and wording stay editable in Premiere.
 *
 * One animation = how the text gets from "hidden" (p = 0) to "at rest" (p = 1):
 *   f: { channel: [from, ease, t0, t1] }      declarative: start value, easing, optional slice of p
 *   fn(p, k, n)                               or a function for the odd ones (glitch, flicker, jelly…)
 * The same definition played backwards is the "out" animation. Loops are functions of time.
 *
 * Units: positions are in frame heights; x/y "from" numbers are in text-box heights (so a small caption
 * and a big title move proportionally); 'L' 'R' 'T' 'B' mean "from outside that edge of the frame".
 * The text box (where the text sits in the frame, 0..1) gives the anchor for scale/rotation and the
 * edges for masks.
 *
 * bake() samples every frame and thins the result, so what the panel previews is what Premiere gets.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  if (root) { root.QFXText = api; }
})(this, function () {
  'use strict';

  // ------------------------------------------------------------------ easing (0..1 → 0..1, may overshoot)
  function clamp(n, a, b) { return n < a ? a : (n > b ? b : n); }
  var EASE = {
    lin: function (q) { return q; },
    out2: function (q) { return 1 - (1 - q) * (1 - q); },
    out3: function (q) { return 1 - Math.pow(1 - q, 3); },
    out5: function (q) { return 1 - Math.pow(1 - q, 5); },
    in2: function (q) { return q * q; },
    in3: function (q) { return q * q * q; },
    io3: function (q) { return q < 0.5 ? 4 * q * q * q : 1 - Math.pow(-2 * q + 2, 3) / 2; },
    back: function (q, k) { var c = 1.70158 * (k || 1); return 1 + (c + 1) * Math.pow(q - 1, 3) + c * Math.pow(q - 1, 2); },
    backL: function (q, k) { var c = 3.2 * (k || 1); return 1 + (c + 1) * Math.pow(q - 1, 3) + c * Math.pow(q - 1, 2); },
    elastic: function (q, k) {
      if (q <= 0) { return 0; } if (q >= 1) { return 1; }
      return 1 + (k || 1) * Math.pow(2, -10 * q) * Math.sin((q * 10 - 0.75) * (2 * Math.PI) / 3);
    },
    bounce: function (q) {
      var n = 7.5625, d = 2.75;
      if (q < 1 / d) { return n * q * q; }
      if (q < 2 / d) { q -= 1.5 / d; return n * q * q + 0.75; }
      if (q < 2.5 / d) { q -= 2.25 / d; return n * q * q + 0.9375; }
      q -= 2.625 / d; return n * q * q + 0.984375;
    }
  };
  function ease(name, q, k) {
    var m = /^steps(\d+)$/.exec(name || '');
    if (m) { var n = Number(m[1]); return q >= 1 ? 1 : Math.floor(q * n) / n; }
    return (EASE[name] || EASE.out3)(q, k);
  }
  /** Played backwards, a bounce or a spring looks wrong (it would wobble before leaving): leave with a pull-back instead. */
  var OUT_EASE = { bounce: 'back', elastic: 'back' };

  /** Repeatable "random" 0..1 for a whole number. */
  function rnd(i, seed) { var x = Math.sin(i * 12.9898 + (seed || 0) * 78.233) * 43758.5453; return x - Math.floor(x); }

  // ------------------------------------------------------------------ the library
  var CATS = [
    { id: 'clean', name: 'სუფთა', hint: 'სუბტიტრები, წარწერები, ინფო' },
    { id: 'title', name: 'სათაურები', hint: 'მთავარი ტექსტი, ნიღბიანი გამოჩენა' },
    { id: 'lower', name: 'ქვედა ტიტრი', hint: 'სახელი და თანამდებობა, lower third' },
    { id: 'social', name: 'Reels / TikTok', hint: 'პოპი, ხტუნვა, დარტყმა' },
    { id: 'bounce', name: 'ხტუნვა / ზამბარა', hint: 'ელასტიური და მხიარული' },
    { id: 'zoom', name: 'ზუმი', hint: 'მოახლოება და დაშორება' },
    { id: 'blur', name: 'ბლური', hint: 'ბუნდოვნიდან ფოკუსში' },
    { id: 'cinema', name: 'Cinematic', hint: 'ფილმის და ტრეილერის სათაურები: ნელი, რბილი. „კომბო“ ერთად სვამს შემოსვლას, ნელ მოძრაობას მთელ კლიპზე და გასვლას' },
    { id: 'tech', name: 'გლიჩი / ტექ', hint: 'ციმციმი, ნაბიჯები, სკანირება' },
    { id: 'turn', name: 'ბრუნვა', hint: 'ტრიალი და გადაბრუნება' },
    { id: 'slide', name: 'სრიალი', hint: 'ოთხივე მხრიდან' }
  ];

  function jitter(p, k, n, amp, steps) {              // a shake that dies out as p → 1
    var i = Math.floor(p * steps), left = 1 - p;
    return { x: (rnd(i, 1) - 0.5) * 2 * amp * k * left, y: (rnd(i, 2) - 0.5) * 2 * amp * k * left };
  }

  var ANIMS = [
    // ---- clean
    { id: 'fade', c: 'clean', n: 'გაჩენა', d: 0.4, f: { o: [0, 'out2'] } },
    { id: 'fadeUp', c: 'clean', n: 'რბილი აწევა', d: 0.5, f: { y: [0.5, 'out3'], o: [0, 'out2'] } },
    { id: 'fadeDown', c: 'clean', n: 'რბილი ჩამოსვლა', d: 0.5, f: { y: [-0.5, 'out3'], o: [0, 'out2'] } },
    { id: 'fadeRight', c: 'clean', n: 'მარცხნიდან რბილად', d: 0.5, f: { x: [-0.8, 'out3'], o: [0, 'out2'] } },
    { id: 'fadeLeft', c: 'clean', n: 'მარჯვნიდან რბილად', d: 0.5, f: { x: [0.8, 'out3'], o: [0, 'out2'] } },
    { id: 'softPop', c: 'clean', n: 'რბილი პოპი', d: 0.4, f: { s: [0.85, 'out3'], o: [0, 'out2'] } },
    { id: 'blurIn', c: 'clean', n: 'ფოკუსში მოსვლა', d: 0.6, f: { b: [40, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'softZoomOut', c: 'clean', n: 'რბილი დაპატარავება', d: 0.6, f: { s: [1.15, 'out3'], b: [12, 'out3'], o: [0, 'out2'] } },
    { id: 'wipeR', c: 'clean', n: 'გადაწმენდა →', d: 0.6, box: 1, f: { cr: [1, 'io3'] } },
    { id: 'typeSteps', c: 'clean', n: 'ბეჭდვა (ნაბიჯებით)', d: 1.0, box: 1, mb: 0, f: { cr: [1, 'steps14'] } },

    // ---- title
    { id: 'maskUp', c: 'title', n: 'ხაზიდან ამოსვლა', d: 0.7, box: 1, f: { y: [1.15, 'out5'], cb: [0] } },
    { id: 'maskDown', c: 'title', n: 'ხაზიდან ჩამოსვლა', d: 0.7, box: 1, f: { y: [-1.15, 'out5'], ct: [0] } },
    { id: 'splitOpen', c: 'title', n: 'შუიდან გახსნა', d: 0.7, box: 1, f: { cl: [0.5, 'out5'], cr: [0.5, 'out5'] } },
    { id: 'openV', c: 'title', n: 'ვერტიკალური გახსნა', d: 0.6, box: 1, f: { ct: [0.5, 'out5'], cb: [0.5, 'out5'] } },
    { id: 'wipeL', c: 'title', n: 'გადაწმენდა ←', d: 0.6, box: 1, f: { cl: [1, 'io3'] } },
    { id: 'bigSettle', c: 'title', n: 'დიდიდან დაჯდომა', d: 0.8, f: { s: [1.6, 'out5'], b: [30, 'out5'], o: [0, 'out2', 0, 0.5] } },
    { id: 'stretchIn', c: 'title', n: 'გაჭიმვიდან შეკვრა', d: 0.8, f: { sx: [1.6, 'out5'], o: [0, 'out2', 0, 0.6] } },
    { id: 'riseBlur', c: 'title', n: 'აწევა ბუნდოვნიდან', d: 0.7, f: { y: [0.8, 'out5'], b: [30, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'dropIn', c: 'title', n: 'ზემოდან ჩამოვარდნა', d: 0.7, f: { y: ['T', 'back'] } },
    { id: 'maskSideR', c: 'title', n: 'კიდიდან გამოსრიალება →', d: 0.7, box: 1, f: { xw: [-1.05, 'out5'], cl: [0] } },
    { id: 'maskSideL', c: 'title', n: 'კიდიდან გამოსრიალება ←', d: 0.7, box: 1, f: { xw: [1.05, 'out5'], cr: [0] } },

    // ---- lower third
    { id: 'ltSlideR', c: 'lower', n: 'მარცხნიდან შემოსრიალება', d: 0.6, f: { x: ['L', 'out5'] } },
    { id: 'ltSlideL', c: 'lower', n: 'მარჯვნიდან შემოსრიალება', d: 0.6, f: { x: ['R', 'out5'] } },
    { id: 'ltRise', c: 'lower', n: 'ქვემოდან ნიღბით', d: 0.45, box: 1, f: { y: [1.15, 'out5'], cb: [0], o: [0, 'out2', 0, 0.4] } },
    { id: 'ltWipe', c: 'lower', n: 'გაშლა გადაწმენდით', d: 0.5, box: 1, f: { cr: [1, 'out5'], x: [-0.4, 'out5'] } },
    { id: 'ltFadeSlide', c: 'lower', n: 'სრიალი გაჩენით', d: 0.5, f: { x: [-1.6, 'out5'], o: [0, 'out2', 0, 0.7] } },
    { id: 'ltGrow', c: 'lower', n: 'მარცხნიდან გაშლა', d: 0.5, a: 'l', f: { sx: [0, 'out5'], o: [0, 'out2', 0, 0.3] } },
    { id: 'ltDrop', c: 'lower', n: 'მსუბუქი ჩამოჯდომა', d: 0.5, f: { y: [-0.9, 'back'], o: [0, 'out2', 0, 0.5] } },
    { id: 'ltUnder', c: 'lower', n: 'ზემოდან ნიღბით', d: 0.45, box: 1, f: { y: [-1.15, 'out5'], ct: [0], o: [0, 'out2', 0, 0.4] } },

    // ---- social
    { id: 'pop', c: 'social', n: 'პოპი', d: 0.45, f: { s: [0, 'back'], o: [0, 'out2', 0, 0.25] } },
    { id: 'popBig', c: 'social', n: 'დიდი პოპი', d: 0.5, f: { s: [0, 'backL'], o: [0, 'out2', 0, 0.2] } },
    { id: 'bounceIn', c: 'social', n: 'ხტუნვით გაჩენა', d: 0.8, f: { s: [0.3, 'bounce'], o: [0, 'out2', 0, 0.2] } },
    { id: 'elastic', c: 'social', n: 'ზამბარა', d: 0.9, f: { s: [0, 'elastic'], o: [0, 'out2', 0, 0.15] } },
    { id: 'punch', c: 'social', n: 'დარტყმა დიდიდან', d: 0.35, f: { s: [3, 'out5'], b: [24, 'out3'], o: [0, 'out2', 0, 0.3] } },
    { id: 'slam', c: 'social', n: 'ჩაჭედება', d: 0.4, mb: 0, fn: function (p, k, n) {
      var hit = 0.55, q = clamp(p / hit, 0, 1), j = p > hit ? jitter((p - hit) / (1 - hit), k, n, 0.06, 7) : { x: 0, y: 0 };
      return { s: 1 + 1.4 * k * (1 - EASE.in3(q)), o: clamp(p / 0.2, 0, 1), x: j.x, y: j.y };
    } },
    { id: 'dropBounce', c: 'social', n: 'ზემოდან ხტუნვით', d: 0.9, f: { y: [-3.2, 'bounce'], o: [0, 'out2', 0, 0.15] } },
    { id: 'jelly', c: 'social', n: 'ჟელე', d: 0.9, fn: function (p, k) {
      var w = Math.pow(2, -7 * p) * Math.cos(p * 16) * 0.45 * k * (1 - p), e = EASE.out5(clamp(p / 0.35, 0, 1));
      return { sx: e * (1 + w), sy: e * (1 - w), o: clamp(p / 0.15, 0, 1) };
    } },
    { id: 'spinPop', c: 'social', n: 'ტრიალით პოპი', d: 0.6, f: { s: [0, 'back'], r: [-180, 'out5'], o: [0, 'out2', 0, 0.25] } },
    { id: 'shakeIn', c: 'social', n: 'რხევით გაჩენა', d: 0.5, mb: 0, fn: function (p, k, n) {
      var j = jitter(p, k, n, 0.22, 12); return { x: j.x, y: j.y, o: clamp(p / 0.2, 0, 1) };
    } },
    { id: 'hopUp', c: 'social', n: 'ქვემოდან ხტომით', d: 0.55, f: { y: [2, 'back'], o: [0, 'out2', 0, 0.3] } },
    { id: 'whipR', c: 'social', n: 'სწრაფი შემოვარდნა →', d: 0.35, f: { x: ['L', 'out5'] } },
    { id: 'whipL', c: 'social', n: 'სწრაფი შემოვარდნა ←', d: 0.35, f: { x: ['R', 'out5'] } },
    { id: 'flashIn', c: 'social', n: 'ციმციმით გაჩენა', d: 0.5, mb: 0, fn: function (p) {
      var i = Math.floor(p * 9); return { o: p >= 1 ? 1 : ([0, 1, 0, 1, 0.2, 1, 0.5, 1, 1][i] || 0), s: 1 + 0.06 * (1 - p) };
    } },
    { id: 'wobble', c: 'social', n: 'ქანაობით', d: 0.9, f: { r: [-14, 'elastic'], s: [0.8, 'out5'], o: [0, 'out2', 0, 0.2] } },

    // ---- cinema
    // ready combinations: picking one as the entrance also sets the slow move across the whole clip and the exit
    { id: 'cineTrailer', c: 'cinema', n: 'ტრეილერის სათაური', d: 1.8, f: { s: [0.9, 'out3'], b: [30, 'out3'], o: [0, 'out2', 0, 0.5] }, 'with': { loop: 'pushIn', out: 'slowFade' } },
    { id: 'cineBlack', c: 'cinema', n: 'შავიდან, ნელი მოახლოებით', d: 2.6, f: { o: [0, 'io3'] }, 'with': { loop: 'pushIn', out: 'cineBlack' } },
    { id: 'cineFocus', c: 'cinema', n: 'ფოკუსში მოსვლა და გასვლა', d: 1.6, f: { b: [70, 'out3'], s: [1.06, 'out3'], o: [0, 'out2', 0, 0.45] }, 'with': { loop: 'pushIn', out: 'cineFocus' } },
    { id: 'cineWide', c: 'cinema', n: 'ფართო ეკრანი (გაშლილიდან)', d: 2.0, f: { sx: [1.45, 'out5'], b: [18, 'out3'], o: [0, 'out2', 0, 0.5] }, 'with': { loop: 'pullOut', out: 'slowFade' } },
    { id: 'cineBars', c: 'cinema', n: 'ზოლიდან გახსნა, მოახლოებით', d: 1.5, box: 1, f: { ct: [0.5, 'io3'], cb: [0.5, 'io3'], b: [12, 'out3'] }, 'with': { loop: 'pushIn', out: 'cineBars' } },
    { id: 'cineImpact', c: 'cinema', n: 'დრამატული დარტყმა', d: 0.55, f: { s: [1.7, 'out5'], b: [26, 'out5'], o: [0, 'out2', 0, 0.3] }, 'with': { loop: 'pushIn', out: 'slowFade' } },
    { id: 'cineFar', c: 'cinema', n: 'შორიდან მოსვლა', d: 2.4, f: { s: [0.6, 'out5'], b: [22, 'out3'], o: [0, 'out2', 0, 0.5] }, 'with': { loop: 'pushIn', out: 'cineFocus' } },
    { id: 'cineEpic', c: 'cinema', n: 'ეპიკური დაჯდომა, დაშორებით', d: 1.7, f: { s: [1.4, 'out5'], b: [44, 'out5'], o: [0, 'out2', 0, 0.4] }, 'with': { loop: 'pullOut', out: 'slowFade' } },
    { id: 'cineWipe', c: 'cinema', n: 'ნელი გადაწმენდა, მოახლოებით', d: 1.8, box: 1, f: { cr: [1, 'io3'] }, 'with': { loop: 'pushIn', out: 'slowFade' } },
    { id: 'cineChapter', c: 'cinema', n: 'თავის სათაური (შუიდან)', d: 1.6, box: 1, f: { cl: [0.5, 'io3'], cr: [0.5, 'io3'], b: [8, 'out3'] }, 'with': { loop: 'pullOut', out: 'cineChapter' } },
    { id: 'cineCredits', c: 'cinema', n: 'ფინალური ტიტრი (ნელი აწევა)', d: 1.8, f: { y: [0.35, 'out3'], o: [0, 'io3'] }, 'with': { loop: 'driftUp', out: 'slowFade' } },
    { id: 'cineAnamorph', c: 'cinema', n: 'ანამორფული (შეკუმშულიდან)', d: 1.9, f: { sx: [0.7, 'out5'], b: [16, 'out3'], o: [0, 'out2', 0, 0.5] }, 'with': { loop: 'pushIn', out: 'slowFade' } },
    { id: 'cineMist', c: 'cinema', n: 'ნისლიდან ამოსვლა', d: 2.0, f: { y: [0.25, 'out3'], b: [36, 'out3'], o: [0, 'out2', 0, 0.6] }, 'with': { loop: 'driftUp', out: 'cineFocus' } },
    { id: 'cineQuiet', c: 'cinema', n: 'ჩუმი გაჩენა (თითქმის უძრავი)', d: 2.2, f: { s: [0.97, 'io3'], o: [0, 'io3'] }, 'with': { loop: 'pushIn', out: 'cineQuiet' } },
    { id: 'slowFade', c: 'cinema', n: 'ნელი გაჩენა', d: 1.5, f: { o: [0, 'io3'] } },
    { id: 'slowZoom', c: 'cinema', n: 'ნელი მოახლოება', d: 2.0, f: { s: [0.92, 'out2'], o: [0, 'out2', 0, 0.6] } },
    { id: 'focusPull', c: 'cinema', n: 'ფოკუსის მოყვანა', d: 1.4, f: { b: [60, 'out3'], s: [1.05, 'out3'], o: [0, 'out2', 0, 0.5] } },
    { id: 'slowStretch', c: 'cinema', n: 'ნელი შეკვრა სიგანეში', d: 1.8, f: { sx: [1.25, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'slowRise', c: 'cinema', n: 'ნელი აწევა', d: 1.6, f: { y: [0.4, 'out3'], o: [0, 'out2', 0, 0.7] } },
    { id: 'letterOpen', c: 'cinema', n: 'ზოლიდან გახსნა', d: 1.2, box: 1, f: { ct: [0.5, 'io3'], cb: [0.5, 'io3'], b: [14, 'out3'] } },
    { id: 'fogDown', c: 'cinema', n: 'ნისლიდან ჩამოსვლა', d: 1.4, f: { y: [-0.3, 'out3'], b: [28, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'epic', c: 'cinema', n: 'ეპიკური დაჯდომა', d: 1.6, f: { s: [1.35, 'out5'], b: [40, 'out5'], o: [0, 'out2', 0, 0.4] } },

    // ---- tech
    { id: 'glitch', c: 'tech', n: 'გლიჩი', d: 0.5, mb: 0, fn: function (p, k) {
      if (p >= 1) { return {}; }
      var i = Math.floor(p * 11), r = rnd(i, 5), left = 1 - p;
      return { x: (rnd(i, 3) - 0.5) * 1.6 * k * left, sx: 1 + (r > 0.6 ? (r - 0.6) * 1.8 * k * left : 0), sy: r < 0.2 ? 0.7 : 1, o: rnd(i, 7) < 0.25 * left + 0.05 ? 0 : 1 };
    } },
    { id: 'flicker', c: 'tech', n: 'ნეონის ციმციმი', d: 0.7, mb: 0, fn: function (p) {
      if (p >= 1) { return {}; }
      var i = Math.floor(p * 16); return { o: i === 0 ? 0 : (rnd(i, 11) < 0.55 - p * 0.5 ? 0.08 : (rnd(i, 13) < 0.3 ? 0.6 : 1)) };
    } },
    { id: 'scan', c: 'tech', n: 'სკანირება ზემოდან', d: 0.6, box: 1, mb: 0, f: { cb: [1, 'steps12'] } },
    { id: 'stepsIn', c: 'tech', n: 'ციფრული ნაბიჯები', d: 0.4, mb: 0, f: { x: [-2.4, 'steps5'], o: [0, 'steps3', 0, 0.6] } },
    { id: 'zoomGlitch', c: 'tech', n: 'ზუმის ნახტომები', d: 0.4, mb: 0, fn: function (p) {
      var i = Math.floor(p * 6); return p >= 1 ? {} : { s: [1.5, 0.85, 1.25, 0.95, 1.08, 1][i] || 1, o: i === 1 ? 0.4 : 1 };
    } },
    { id: 'stutter', c: 'tech', n: 'წყვეტილი ჩამოსვლა', d: 0.5, mb: 0, f: { y: [-1.6, 'steps6'], o: [0, 'steps2', 0, 0.3] } },
    { id: 'blinkIn', c: 'tech', n: 'კურსორივით ციმციმი', d: 0.8, mb: 0, fn: function (p) { return { o: p >= 1 ? 1 : (Math.floor(p * 6) % 2) }; } },
    { id: 'tvOn', c: 'tech', n: 'ეკრანის ჩართვა', d: 0.45, fn: function (p) {
      var a = EASE.out5(clamp(p / 0.45, 0, 1)), b = EASE.out5(clamp((p - 0.3) / 0.7, 0, 1));
      return { sx: 0.05 + 0.95 * a + 0.25 * (1 - b) * a, sy: 0.03 + 0.97 * b, o: clamp(p / 0.1, 0, 1) };
    } },

    // ---- turn
    { id: 'rotIn', c: 'turn', n: 'ბრუნვით შემოსვლა ↻', d: 0.6, f: { r: [-90, 'out5'], s: [0.6, 'out5'], o: [0, 'out2', 0, 0.4] } },
    { id: 'rotInR', c: 'turn', n: 'ბრუნვით შემოსვლა ↺', d: 0.6, f: { r: [90, 'out5'], s: [0.6, 'out5'], o: [0, 'out2', 0, 0.4] } },
    { id: 'spinIn', c: 'turn', n: 'სრული ტრიალი', d: 0.8, f: { r: [-360, 'out5'], s: [0, 'out5'], o: [0, 'out2', 0, 0.2] } },
    { id: 'swing', c: 'turn', n: 'საქანელა', d: 1.0, a: 't', f: { r: [-28, 'elastic'], o: [0, 'out2', 0, 0.15] } },
    { id: 'hinge', c: 'turn', n: 'კარივით გაღება', d: 0.9, a: 'l', f: { r: [80, 'bounce'], o: [0, 'out2', 0, 0.15] } },
    { id: 'flipX', c: 'turn', n: 'გადაბრუნება ჰორიზონტალურად', d: 0.55, f: { sx: [0, 'back'], o: [0, 'out2', 0, 0.2] } },
    { id: 'flipY', c: 'turn', n: 'გადაბრუნება ვერტიკალურად', d: 0.55, f: { sy: [0, 'back'], o: [0, 'out2', 0, 0.2] } },
    { id: 'unfold', c: 'turn', n: 'ზემოდან გაშლა', d: 0.5, a: 't', f: { sy: [0, 'out5'], o: [0, 'out2', 0, 0.2] } },
    { id: 'tiltDrop', c: 'turn', n: 'დახრილი ჩამოვარდნა', d: 0.9, f: { y: [-1.8, 'bounce'], r: [-16, 'out5'], o: [0, 'out2', 0, 0.15] } },

    // ---- slide
    { id: 'slideR', c: 'slide', n: 'მარცხნიდან →', d: 0.6, f: { x: ['L', 'out5'] } },
    { id: 'slideL', c: 'slide', n: 'მარჯვნიდან ←', d: 0.6, f: { x: ['R', 'out5'] } },
    { id: 'slideD', c: 'slide', n: 'ზემოდან ↓', d: 0.6, f: { y: ['T', 'out5'] } },
    { id: 'slideU', c: 'slide', n: 'ქვემოდან ↑', d: 0.6, f: { y: ['B', 'out5'] } },
    { id: 'nudgeR', c: 'slide', n: 'მოკლე ბიძგი →', d: 0.5, f: { x: [-1.5, 'back'], o: [0, 'out2', 0, 0.4] } },
    { id: 'nudgeL', c: 'slide', n: 'მოკლე ბიძგი ←', d: 0.5, f: { x: [1.5, 'back'], o: [0, 'out2', 0, 0.4] } },
    { id: 'nudgeD', c: 'slide', n: 'მოკლე ბიძგი ↓', d: 0.5, f: { y: [-1.5, 'back'], o: [0, 'out2', 0, 0.4] } },
    { id: 'nudgeU', c: 'slide', n: 'მოკლე ბიძგი ↑', d: 0.5, f: { y: [1.5, 'back'], o: [0, 'out2', 0, 0.4] } },
    { id: 'diag', c: 'slide', n: 'დიაგონალზე ↘', d: 0.6, f: { x: [-2, 'out5'], y: [-2, 'out5'], o: [0, 'out2', 0, 0.5] } },

    // ================= more of everything (1.19) =================
    // ---- clean
    { id: 'fadeSlow', c: 'clean', n: 'გაჩენა ნელა', d: 0.9, f: { o: [0, 'io3'] } },
    { id: 'riseHigh', c: 'clean', n: 'მაღალი აწევა', d: 0.6, f: { y: [1.0, 'out5'], o: [0, 'out2', 0, 0.6] } },
    { id: 'dropHigh', c: 'clean', n: 'მაღალი ჩამოსვლა', d: 0.6, f: { y: [-1.0, 'out5'], o: [0, 'out2', 0, 0.6] } },
    { id: 'popRise', c: 'clean', n: 'პოპი აწევით', d: 0.45, f: { s: [0.9, 'out3'], y: [0.4, 'out3'], o: [0, 'out2'] } },
    { id: 'fadeStretch', c: 'clean', n: 'რბილი შეკვრა', d: 0.6, f: { sx: [1.15, 'out3'], o: [0, 'out2'] } },

    // ---- title
    { id: 'wipeDown', c: 'title', n: 'გადაწმენდა ↓', d: 0.6, box: 1, f: { cb: [1, 'io3'] } },
    { id: 'wipeUp', c: 'title', n: 'გადაწმენდა ↑', d: 0.6, box: 1, f: { ct: [1, 'io3'] } },
    { id: 'maskUpBack', c: 'title', n: 'ხაზიდან ამოხტომა', d: 0.7, box: 1, f: { y: [1.15, 'back'], cb: [0] } },
    { id: 'maskUpZoom', c: 'title', n: 'ხაზიდან ამოსვლა ზუმით', d: 0.8, box: 1, f: { y: [1.3, 'out5'], s: [1.15, 'out5'], cb: [0] } },
    { id: 'maskUpSlow', c: 'title', n: 'ნელი ამოსვლა ხაზიდან', d: 1.1, box: 1, f: { y: [1.15, 'io3'], cb: [0] } },
    { id: 'cornerTL', c: 'title', n: 'კუთხიდან გახსნა ↘', d: 0.7, box: 1, f: { cr: [1, 'out5'], cb: [1, 'out5'] } },
    { id: 'cornerBR', c: 'title', n: 'კუთხიდან გახსნა ↖', d: 0.7, box: 1, f: { cl: [1, 'out5'], ct: [1, 'out5'] } },
    { id: 'curtain', c: 'title', n: 'ფარდის გახსნა', d: 0.9, box: 1, f: { cl: [0.5, 'io3'], cr: [0.5, 'io3'], sx: [1.12, 'out3'] } },
    { id: 'bigDrop', c: 'title', n: 'დიდი ჩამოჯდომა', d: 0.8, f: { s: [1.3, 'out5'], y: [-1, 'out5'], b: [20, 'out3'], o: [0, 'out2', 0, 0.5] } },

    // ---- lower third
    { id: 'ltSlideUp', c: 'lower', n: 'ქვემოდან შემოსრიალება', d: 0.6, f: { y: ['B', 'out5'] } },
    { id: 'ltWipeL', c: 'lower', n: 'გაშლა გადაწმენდით ←', d: 0.5, box: 1, f: { cl: [1, 'out5'], x: [0.4, 'out5'] } },
    { id: 'ltGrowR', c: 'lower', n: 'მარჯვნიდან გაშლა', d: 0.5, a: 'r', f: { sx: [0, 'out5'], o: [0, 'out2', 0, 0.3] } },
    { id: 'ltBlurSlide', c: 'lower', n: 'სრიალი ბუნდოვნიდან', d: 0.55, f: { x: [-1.6, 'out5'], b: [24, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'ltElastic', c: 'lower', n: 'ზამბარით შემოსვლა', d: 0.9, f: { x: [-2.2, 'elastic'], o: [0, 'out2', 0, 0.15] } },
    { id: 'ltSplit', c: 'lower', n: 'ხაზიდან გაშლა', d: 0.4, box: 1, f: { ct: [0.5, 'out5'], cb: [0.5, 'out5'] } },

    // ---- social
    { id: 'popTilt', c: 'social', n: 'პოპი დახრით', d: 0.5, f: { s: [0, 'back'], r: [-14, 'back'], o: [0, 'out2', 0, 0.25] } },
    { id: 'popUp', c: 'social', n: 'პოპი ქვემოდან', d: 0.5, f: { s: [0, 'back'], y: [1.2, 'back'], o: [0, 'out2', 0, 0.25] } },
    { id: 'popDown', c: 'social', n: 'პოპი ზემოდან', d: 0.5, f: { s: [0, 'back'], y: [-1.2, 'back'], o: [0, 'out2', 0, 0.25] } },
    { id: 'stamp', c: 'social', n: 'ბეჭედი', d: 0.45, mb: 0, fn: function (p, k, n) {
      var hit = 0.5, q = clamp(p / hit, 0, 1), j = p > hit ? jitter((p - hit) / (1 - hit), k, n, 0.05, 6) : { x: 0, y: 0 };
      return { s: 1 + 1.6 * k * (1 - EASE.in3(q)), r: -8 * (1 - q), o: clamp(p / 0.15, 0, 1), x: j.x, y: j.y };
    } },
    { id: 'swooshR', c: 'social', n: 'შემოქროლება →', d: 0.45, f: { x: ['L', 'out5'], r: [-12, 'out5'] } },
    { id: 'swooshL', c: 'social', n: 'შემოქროლება ←', d: 0.45, f: { x: ['R', 'out5'], r: [12, 'out5'] } },
    { id: 'twirl', c: 'social', n: 'ორმაგი ტრიალი', d: 0.8, f: { r: [-720, 'out5'], s: [0, 'out5'], o: [0, 'out2', 0, 0.2] } },
    { id: 'squash', c: 'social', n: 'ჩამოვარდნა და გაბრტყელება', d: 0.9, a: 'b', fn: function (p, k) {
      var o = clamp(p / 0.1, 0, 1), q, w;
      if (p < 0.4) { q = p / 0.4; return { y: -3 * (1 - EASE.in2(q)), o: o }; }
      if (p < 0.55) { q = Math.sin((p - 0.4) / 0.15 * Math.PI); return { sy: 1 - 0.4 * k * q, sx: 1 + 0.3 * k * q, o: o }; }
      q = (p - 0.55) / 0.45; w = Math.pow(2, -8 * q) * Math.sin(q * 14) * 0.12 * k * (1 - q);
      return { sy: 1 + w, sx: 1 - w, o: o };
    } },
    { id: 'stretchPop', c: 'social', n: 'გაჭიმული პოპი', d: 0.8, fn: function (p, k) {
      return { sx: Math.max(0, 1 + 0.7 * (1 - EASE.elastic(p, k))), sy: 1 - 0.5 * (1 - EASE.out5(p)), o: clamp(p / 0.15, 0, 1) };
    } },
    { id: 'tada', c: 'social', n: 'ტა-და!', d: 1.0, fn: function (p, k) {
      var q = clamp((p - 0.3) / 0.7, 0, 1);
      return { s: Math.max(0, EASE.back(clamp(p / 0.35, 0, 1), k)), r: p > 0.3 ? 8 * k * Math.sin(q * Math.PI * 6) * (1 - q) : 0, o: clamp(p / 0.12, 0, 1) };
    } },
    { id: 'headShake', c: 'social', n: 'თავის ქნევა', d: 0.8, fn: function (p, k) { return { x: 0.9 * k * Math.sin(p * Math.PI * 6) * (1 - p), o: clamp(p / 0.2, 0, 1) }; } },
    { id: 'heartIn', c: 'social', n: 'გულისცემით', d: 0.9, fn: function (p, k) {
      var b = function (c) { var d = (p - c) / 0.08; return Math.exp(-d * d); };
      return { s: EASE.out5(clamp(p / 0.25, 0, 1)) * (1 + 0.22 * k * b(0.3) + 0.12 * k * b(0.55)), o: clamp(p / 0.12, 0, 1) };
    } },

    // ---- bounce / spring
    { id: 'bounceR', c: 'bounce', n: 'ხტუნვით მარცხნიდან', d: 0.9, f: { x: [-4, 'bounce'], o: [0, 'out2', 0, 0.15] } },
    { id: 'bounceL', c: 'bounce', n: 'ხტუნვით მარჯვნიდან', d: 0.9, f: { x: [4, 'bounce'], o: [0, 'out2', 0, 0.15] } },
    { id: 'bounceU', c: 'bounce', n: 'ხტუნვით ქვემოდან', d: 0.9, f: { y: [3, 'bounce'], o: [0, 'out2', 0, 0.15] } },
    { id: 'bounceDShort', c: 'bounce', n: 'მოკლე ჩამოხტომა', d: 0.7, f: { y: [-1.5, 'bounce'], o: [0, 'out2', 0, 0.2] } },
    { id: 'elasticR', c: 'bounce', n: 'ზამბარით მარცხნიდან', d: 1.0, f: { x: [-3, 'elastic'], o: [0, 'out2', 0, 0.12] } },
    { id: 'elasticL', c: 'bounce', n: 'ზამბარით მარჯვნიდან', d: 1.0, f: { x: [3, 'elastic'], o: [0, 'out2', 0, 0.12] } },
    { id: 'elasticU', c: 'bounce', n: 'ზამბარით ქვემოდან', d: 1.0, f: { y: [3, 'elastic'], o: [0, 'out2', 0, 0.12] } },
    { id: 'elasticD', c: 'bounce', n: 'ზამბარით ზემოდან', d: 1.0, f: { y: [-3, 'elastic'], o: [0, 'out2', 0, 0.12] } },
    { id: 'elasticX', c: 'bounce', n: 'ზამბარა სიგანეში', d: 0.9, f: { sx: [0, 'elastic'], o: [0, 'out2', 0, 0.12] } },
    { id: 'elasticY', c: 'bounce', n: 'ზამბარა სიმაღლეში', d: 0.9, f: { sy: [0, 'elastic'], o: [0, 'out2', 0, 0.12] } },
    { id: 'elasticRot', c: 'bounce', n: 'ზამბარა კუთხით', d: 1.0, f: { r: [40, 'elastic'], o: [0, 'out2', 0, 0.15] } },
    { id: 'springPop', c: 'bounce', n: 'მსუბუქი ზამბარა', d: 0.8, f: { s: [0.5, 'elastic'], o: [0, 'out2', 0, 0.15] } },
    { id: 'rubber', c: 'bounce', n: 'რეზინი', d: 0.9, fn: function (p, k) {
      var w = Math.sin(p * Math.PI * 5) * 0.28 * k * (1 - p) * (1 - p);
      return { sx: 1 + w, sy: 1 - w, o: clamp(p / 0.12, 0, 1) };
    } },
    { id: 'pendulum', c: 'bounce', n: 'ქანქარა', d: 1.2, a: 't', f: { r: [-45, 'elastic'], o: [0, 'out2', 0, 0.12] } },
    { id: 'growUp', c: 'bounce', n: 'მიწიდან ამოზრდა', d: 0.8, a: 'b', f: { sy: [0, 'bounce'], o: [0, 'out2', 0, 0.12] } },

    // ---- zoom
    { id: 'zoomIn', c: 'zoom', n: 'მოახლოება', d: 0.5, f: { s: [0.5, 'out5'], o: [0, 'out2', 0, 0.4] } },
    { id: 'zoomInFar', c: 'zoom', n: 'შორიდან მოახლოება', d: 0.6, f: { s: [0, 'out5'], o: [0, 'out2', 0, 0.2] } },
    { id: 'zoomOut', c: 'zoom', n: 'დაპატარავება', d: 0.5, f: { s: [1.6, 'out5'], o: [0, 'out2', 0, 0.4] } },
    { id: 'zoomOutFar', c: 'zoom', n: 'უზარმაზარიდან', d: 0.6, f: { s: [4, 'out5'], o: [0, 'out2', 0, 0.3] } },
    { id: 'zoomRot', c: 'zoom', n: 'მოახლოება ბრუნვით', d: 0.6, f: { s: [0.3, 'out5'], r: [-25, 'out5'], o: [0, 'out2', 0, 0.3] } },
    { id: 'zoomRotOut', c: 'zoom', n: 'დაპატარავება ბრუნვით', d: 0.6, f: { s: [1.8, 'out5'], r: [12, 'out5'], o: [0, 'out2', 0, 0.4] } },
    { id: 'zoomUp', c: 'zoom', n: 'მოახლოება ქვემოდან', d: 0.55, f: { s: [0.6, 'out5'], y: [1.2, 'out5'], o: [0, 'out2', 0, 0.4] } },
    { id: 'zoomDown', c: 'zoom', n: 'მოახლოება ზემოდან', d: 0.55, f: { s: [0.6, 'out5'], y: [-1.2, 'out5'], o: [0, 'out2', 0, 0.4] } },
    { id: 'zoomRight', c: 'zoom', n: 'მოახლოება მარცხნიდან', d: 0.55, f: { s: [0.6, 'out5'], x: [-2, 'out5'], o: [0, 'out2', 0, 0.4] } },
    { id: 'zoomLeft', c: 'zoom', n: 'მოახლოება მარჯვნიდან', d: 0.55, f: { s: [0.6, 'out5'], x: [2, 'out5'], o: [0, 'out2', 0, 0.4] } },
    { id: 'zoomSnap', c: 'zoom', n: 'მოკლე ზუმ-დარტყმა', d: 0.35, f: { s: [1.25, 'back'], o: [0, 'out2', 0, 0.3] } },
    { id: 'zoomFlash', c: 'zoom', n: 'ზუმი ციმციმით', d: 0.5, mb: 0, fn: function (p, k) {
      return { s: 1 + 0.4 * k * (1 - EASE.out5(p)), o: p >= 1 ? 1 : [0, 1, 0, 1, 0.3, 1, 1, 1][Math.floor(p * 8)] };
    } },

    // ---- blur
    { id: 'blurDown', c: 'blur', n: 'ბუნდოვნიდან ჩამოსვლა', d: 0.7, f: { y: [-0.7, 'out5'], b: [30, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'blurR', c: 'blur', n: 'ბუნდოვნიდან →', d: 0.7, f: { x: [-1.4, 'out5'], b: [36, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'blurL', c: 'blur', n: 'ბუნდოვნიდან ←', d: 0.7, f: { x: [1.4, 'out5'], b: [36, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'blurZoomIn', c: 'blur', n: 'ბუნდოვნიდან მოახლოება', d: 0.7, f: { s: [0.8, 'out5'], b: [34, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'blurZoomOut', c: 'blur', n: 'ბუნდოვნიდან დაპატარავება', d: 0.7, f: { s: [1.3, 'out5'], b: [40, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'blurStretch', c: 'blur', n: 'ბუნდოვანი გაჭიმვა', d: 0.7, f: { sx: [1.5, 'out5'], b: [30, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'blurHeavy', c: 'blur', n: 'ძლიერი ბუნდოვანება', d: 0.9, f: { b: [100, 'out3'], o: [0, 'out2', 0, 0.5] } },
    { id: 'blurSpin', c: 'blur', n: 'ბუნდოვანი მობრუნება', d: 0.7, f: { r: [20, 'out5'], s: [0.9, 'out5'], b: [30, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'blurFlicker', c: 'blur', n: 'ბუნდოვანი ციმციმი', d: 0.7, mb: 0, fn: function (p, k) {
      if (p >= 1) { return {}; }
      var i = Math.floor(p * 10);
      return { b: rnd(i, 51) * 60 * k * (1 - p), o: i === 0 ? 0 : (rnd(i, 52) < 0.3 * (1 - p) ? 0.3 : 1) };
    } },

    // ---- cinema
    { id: 'slowBlurR', c: 'cinema', n: 'ნელი სრიალი ნისლიდან', d: 1.6, f: { x: [-0.6, 'out3'], b: [20, 'out3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'slowDown', c: 'cinema', n: 'ნელი ჩამოსვლა', d: 1.6, f: { y: [-0.4, 'out3'], o: [0, 'out2', 0, 0.7] } },
    { id: 'slowWipe', c: 'cinema', n: 'ნელი გადაწმენდა', d: 1.6, box: 1, f: { cr: [1, 'io3'] } },
    { id: 'slowOpen', c: 'cinema', n: 'ნელი გახსნა შუიდან', d: 1.6, box: 1, f: { cl: [0.5, 'io3'], cr: [0.5, 'io3'] } },
    { id: 'tiltSettle', c: 'cinema', n: 'ნელი გასწორება', d: 1.8, f: { r: [4, 'out3'], s: [1.06, 'out3'], o: [0, 'out2', 0, 0.5] } },
    { id: 'breatheIn', c: 'cinema', n: 'ჩასუნთქვა', d: 2.2, f: { s: [1.05, 'io3'], o: [0, 'io3', 0, 0.7] } },

    // ---- tech
    { id: 'glitchHard', c: 'tech', n: 'ძლიერი გლიჩი', d: 0.6, mb: 0, fn: function (p, k) {
      if (p >= 1) { return {}; }
      var i = Math.floor(p * 15), r = rnd(i, 71), left = 1 - p;
      return { x: (rnd(i, 72) - 0.5) * 3 * k * left, y: (rnd(i, 73) - 0.5) * 0.8 * k * left, sx: 1 + (r > 0.5 ? (r - 0.5) * 3 * k * left : 0), sy: r < 0.25 ? 0.5 : 1, o: i === 0 ? 0 : (rnd(i, 74) < 0.3 * left ? 0 : 1) };
    } },
    { id: 'scanUp', c: 'tech', n: 'სკანირება ქვემოდან', d: 0.6, box: 1, mb: 0, f: { ct: [1, 'steps12'] } },
    { id: 'scanR', c: 'tech', n: 'სკანირება →', d: 0.5, box: 1, mb: 0, f: { cr: [1, 'steps10'] } },
    { id: 'strobe', c: 'tech', n: 'სტრობი', d: 0.5, mb: 0, fn: function (p) { return p >= 1 ? {} : { o: Math.floor(p * 10) % 2 }; } },
    { id: 'pixelZoom', c: 'tech', n: 'ნაბიჯებით მოახლოება', d: 0.45, mb: 0, f: { s: [0.3, 'steps6'], o: [0, 'steps2', 0, 0.3] } },
    { id: 'stepsUp', c: 'tech', n: 'ციფრული ნაბიჯები ↑', d: 0.4, mb: 0, f: { y: [2, 'steps5'], o: [0, 'steps3', 0, 0.6] } },
    { id: 'dataJitter', c: 'tech', n: 'მონაცემთა ხმაური', d: 0.6, mb: 0, fn: function (p, k) {
      if (p >= 1) { return {}; }
      var i = Math.floor(p * 14), left = 1 - p;
      return { y: (rnd(i, 61) - 0.5) * 1.2 * k * left, sx: Math.max(0.2, 1 + (rnd(i, 62) - 0.5) * 0.5 * k * left), o: i === 0 ? 0 : 1 };
    } },
    { id: 'hud', c: 'tech', n: 'HUD გახსნა', d: 0.4, box: 1, mb: 0, f: { ct: [0.5, 'steps6'], cb: [0.5, 'steps6'] } },
    { id: 'lineIn', c: 'tech', n: 'ზოლიდან ეკრანად', d: 0.6, fn: function (p) {
      return { sx: EASE.out5(clamp(p / 0.5, 0, 1)), sy: 0.04 + 0.96 * EASE.out5(clamp((p - 0.45) / 0.55, 0, 1)), o: clamp(p / 0.08, 0, 1) };
    } },

    // ---- turn
    { id: 'rotHalf', c: 'turn', n: 'ნახევარბრუნი', d: 0.7, f: { r: [-180, 'out5'], s: [0, 'out5'], o: [0, 'out2', 0, 0.2] } },
    { id: 'tiltIn', c: 'turn', n: 'დახრილი აწევა ↻', d: 0.6, f: { r: [8, 'out5'], y: [0.6, 'out5'], o: [0, 'out2', 0, 0.5] } },
    { id: 'tiltInR', c: 'turn', n: 'დახრილი აწევა ↺', d: 0.6, f: { r: [-8, 'out5'], y: [0.6, 'out5'], o: [0, 'out2', 0, 0.5] } },
    { id: 'rockIn', c: 'turn', n: 'ქანაობა ძირიდან', d: 1.0, a: 'b', f: { r: [22, 'elastic'], o: [0, 'out2', 0, 0.15] } },
    { id: 'flipXBounce', c: 'turn', n: 'გადაბრუნება ხტუნვით', d: 0.8, f: { sx: [0, 'bounce'], o: [0, 'out2', 0, 0.15] } },
    { id: 'flipYElastic', c: 'turn', n: 'გადაბრუნება ზამბარით', d: 0.9, f: { sy: [0, 'elastic'], o: [0, 'out2', 0, 0.15] } },
    { id: 'rollR', c: 'turn', n: 'შემოგორება →', d: 0.8, f: { x: [-3.5, 'out5'], r: [-160, 'out5'], o: [0, 'out2', 0, 0.3] } },
    { id: 'rollL', c: 'turn', n: 'შემოგორება ←', d: 0.8, f: { x: [3.5, 'out5'], r: [160, 'out5'], o: [0, 'out2', 0, 0.3] } },
    { id: 'hingeR', c: 'turn', n: 'კარი მარჯვნიდან', d: 0.9, a: 'r', f: { r: [-80, 'bounce'], o: [0, 'out2', 0, 0.15] } },
    { id: 'fan', c: 'turn', n: 'მარაო', d: 0.7, a: 'l', f: { r: [-35, 'back'], sx: [0.4, 'out5'], o: [0, 'out2', 0, 0.3] } },
    { id: 'spinStop', c: 'turn', n: 'ტრიალი და გაჩერება', d: 1.0, f: { r: [-720, 'out5'], s: [0.5, 'out5'], o: [0, 'out2', 0, 0.2] } },

    // ---- slide
    { id: 'slideRBack', c: 'slide', n: 'მარცხნიდან გადაცილებით →', d: 0.7, f: { x: ['L', 'back'] } },
    { id: 'slideLBack', c: 'slide', n: 'მარჯვნიდან გადაცილებით ←', d: 0.7, f: { x: ['R', 'back'] } },
    { id: 'slideUBack', c: 'slide', n: 'ქვემოდან გადაცილებით ↑', d: 0.7, f: { y: ['B', 'back'] } },
    { id: 'glideR', c: 'slide', n: 'ნელი შემოცურება →', d: 0.9, f: { x: [-3, 'io3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'glideL', c: 'slide', n: 'ნელი შემოცურება ←', d: 0.9, f: { x: [3, 'io3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'glideU', c: 'slide', n: 'ნელი შემოცურება ↑', d: 0.9, f: { y: [2, 'io3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'glideD', c: 'slide', n: 'ნელი შემოცურება ↓', d: 0.9, f: { y: [-2, 'io3'], o: [0, 'out2', 0, 0.6] } },
    { id: 'diagUR', c: 'slide', n: 'დიაგონალზე ↗', d: 0.6, f: { x: [-2, 'out5'], y: [2, 'out5'], o: [0, 'out2', 0, 0.5] } },
    { id: 'diagDL', c: 'slide', n: 'დიაგონალზე ↙', d: 0.6, f: { x: [2, 'out5'], y: [-2, 'out5'], o: [0, 'out2', 0, 0.5] } },
    { id: 'diagUL', c: 'slide', n: 'დიაგონალზე ↖', d: 0.6, f: { x: [2, 'out5'], y: [2, 'out5'], o: [0, 'out2', 0, 0.5] } },
    { id: 'slideRBlur', c: 'slide', n: 'შემოვარდნა ბუნდოვნად →', d: 0.5, f: { x: ['L', 'out5'], b: [40, 'out5'] } },
    { id: 'slideLBlur', c: 'slide', n: 'შემოვარდნა ბუნდოვნად ←', d: 0.5, f: { x: ['R', 'out5'], b: [40, 'out5'] } }
  ];

  /**
   * Loops: what the text does while it stays on screen. t = seconds since the loop began, k = strength.
   * `span` loops are one slow move over the whole clip (u = 0..1 through it); they run under the in and
   * out animations too, so nothing jumps where those begin and end.
   */
  var TAU = Math.PI * 2;
  var LOOPS = [
    { id: 'pulse', n: 'პულსი', fn: function (t, k) { var s = 1 + 0.04 * k * Math.sin(t * TAU / 1.2); return { s: s }; } },
    { id: 'breathe', n: 'სუნთქვა', fn: function (t, k) { return { s: 1 + 0.02 * k * Math.sin(t * TAU / 3.2) }; } },
    { id: 'float', n: 'ლივლივი', fn: function (t, k) { return { y: 0.12 * k * Math.sin(t * TAU / 2.6) }; } },
    { id: 'sway', n: 'ქანაობა გვერდებზე', fn: function (t, k) { return { x: 0.2 * k * Math.sin(t * TAU / 2.8) }; } },
    { id: 'swingL', n: 'რხევა კუთხით', fn: function (t, k) { return { r: 2.5 * k * Math.sin(t * TAU / 2.2) }; } },
    { id: 'wiggle', n: 'ცოცხალი ხელი', fn: function (t, k) {
      return { x: 0.07 * k * (Math.sin(t * 2.1) + Math.sin(t * 3.7 + 1)), y: 0.07 * k * (Math.sin(t * 2.9 + 2) + Math.sin(t * 4.3)), r: 0.6 * k * Math.sin(t * 1.7) };
    } },
    { id: 'shake', n: 'კანკალი', mb: 0, fn: function (t, k) { var i = Math.floor(t * 14); return { x: (rnd(i, 21) - 0.5) * 0.14 * k, y: (rnd(i, 22) - 0.5) * 0.14 * k }; } },
    { id: 'rage', n: 'ძლიერი რხევა', mb: 0, fn: function (t, k) { var i = Math.floor(t * 20); return { x: (rnd(i, 31) - 0.5) * 0.4 * k, y: (rnd(i, 32) - 0.5) * 0.4 * k, r: (rnd(i, 33) - 0.5) * 3 * k }; } },
    { id: 'flickerL', n: 'ნეონის ციმციმი', mb: 0, fn: function (t) { var i = Math.floor(t * 12); return { o: rnd(i, 41) < 0.14 ? 0.35 : (rnd(i, 42) < 0.1 ? 0.75 : 1) }; } },
    { id: 'blink', n: 'ნელი ციმციმი', fn: function (t) { return { o: 0.65 + 0.35 * Math.cos(t * TAU / 1.4) }; } },
    { id: 'hop', n: 'ხტუნაობა', fn: function (t, k) { return { y: -0.35 * k * Math.abs(Math.sin(t * TAU / 1.1)) }; } },
    { id: 'heart', n: 'გულისცემა', fn: function (t, k) {
      var q = (t % 1.2) / 1.2, b = function (c) { var d = (q - c) / 0.07; return Math.exp(-d * d); };
      return { s: 1 + 0.09 * k * (b(0.1) + 0.7 * b(0.32)) };
    } },
    { id: 'jellyL', n: 'ჟელე', fn: function (t, k) { var w = 0.05 * k * Math.sin(t * TAU / 0.9); return { sx: 1 + w, sy: 1 - w }; } },
    { id: 'pushIn', n: 'ნელი მოახლოება (მთელ კლიპზე)', span: 1, fn: function (t, k, u) { return { s: 1 + 0.1 * k * u }; } },
    { id: 'driftR', n: 'ნელი სრიალი → (მთელ კლიპზე)', span: 1, fn: function (t, k, u) { return { x: 0.9 * k * (u - 0.5) }; } },
    { id: 'spinSlow', n: 'ნელი ბრუნვა (მთელ კლიპზე)', span: 1, fn: function (t, k, u, dur) { return { r: 360 * Math.max(1, Math.round(dur * k / 7)) * u }; } },
    { id: 'nod', n: 'თავის დაქნევა', fn: function (t, k) { return { r: 1.6 * k * Math.sin(t * TAU / 0.8) }; } },
    { id: 'wave', n: 'ტალღა', fn: function (t, k) { return { y: 0.1 * k * Math.sin(t * TAU / 1.8), r: 1.4 * k * Math.cos(t * TAU / 1.8) }; } },
    { id: 'pulseFast', n: 'სწრაფი პულსი', fn: function (t, k) { return { s: 1 + 0.03 * k * Math.sin(t * TAU / 0.5) }; } },
    { id: 'orbit', n: 'წრეზე ტრიალი', fn: function (t, k) { return { x: 0.1 * k * Math.cos(t * TAU / 2.4), y: 0.1 * k * Math.sin(t * TAU / 2.4) }; } },
    { id: 'squashL', n: 'ბრტყელდება და იჭიმება', fn: function (t, k) { var w = 0.06 * k * Math.abs(Math.sin(t * TAU / 1.6)); return { sx: 1 + w, sy: 1 - w }; } },
    { id: 'glitchL', n: 'გლიჩი დროდადრო', mb: 0, fn: function (t, k) {
      var i = Math.floor(t * 10);
      return rnd(i, 81) < 0.14 ? { x: (rnd(i, 82) - 0.5) * 0.8 * k, sx: 1 + rnd(i, 83) * 0.25 * k } : {};
    } },
    { id: 'strobeL', n: 'სტრობი', mb: 0, fn: function (t) { return { o: Math.floor(t * 8) % 2 ? 1 : 0.25 }; } },
    { id: 'tick', n: 'ტიკ-ტაკი', mb: 0, fn: function (t, k) { return { r: (Math.floor(t * 2) % 2 ? 2 : -2) * k }; } },
    { id: 'pullOut', n: 'ნელი დაშორება (მთელ კლიპზე)', span: 1, fn: function (t, k, u) { return { s: 1 + 0.1 * k * (1 - u) }; } },
    { id: 'driftL', n: 'ნელი სრიალი ← (მთელ კლიპზე)', span: 1, fn: function (t, k, u) { return { x: -0.9 * k * (u - 0.5) }; } },
    { id: 'driftUp', n: 'ნელი აწევა (მთელ კლიპზე)', span: 1, fn: function (t, k, u) { return { y: -0.5 * k * (u - 0.5) }; } }
  ];

  function byId(list, id) { for (var i = 0; i < list.length; i++) { if (list[i].id === id) { return list[i]; } } return null; }
  function anim(id) { return byId(ANIMS, id); }
  function loop(id) { return byId(LOOPS, id); }
  function inCategory(cat) { var out = []; for (var i = 0; i < ANIMS.length; i++) { if (ANIMS[i].c === cat) { out.push(ANIMS[i]); } } return out; }

  // ------------------------------------------------------------------ one moment of one animation
  var DEFAULT_BOX = { x: 0.2, y: 0.42, w: 0.6, h: 0.16 };
  function fixBox(b) {
    b = b || DEFAULT_BOX;
    var w = clamp(Number(b.w) || DEFAULT_BOX.w, 0.04, 1), h = clamp(Number(b.h) || DEFAULT_BOX.h, 0.03, 1);
    return { x: clamp(Number(b.x) || 0, 0, 1 - w), y: clamp(Number(b.y) || 0, 0, 1 - h), w: w, h: h };
  }
  function rest() { return { x: 0, y: 0, sx: 1, sy: 1, r: 0, o: 1, b: 0, cl: -1, ct: -1, cr: -1, cb: -1, a: 'c' }; }

  /**
   * The state of animation `def` at progress p (0 hidden … 1 at rest).
   * ctx: { box, aspect (frame width / height), k (strength 0.5…1.5), frame (whole number, for the random ones) }
   * → { x, y (frame heights), sx, sy, r (deg), o (0..1), b (px at 1080p), cl ct cr cb (share of the box hidden, −1 = no crop), a (anchor) }
   */
  function evalIn(def, p, ctx, reversed) {
    var S = rest(), box = ctx.box, k = ctx.k || 1, asp = ctx.aspect || 16 / 9, bh = box.h, bw = box.w * asp;
    S.a = def.a || 'c';
    p = clamp(p, 0, 1);
    var kd = def.box ? 1 : k;
    function dist(v) {
      if (v === 'L') { return -(box.x + box.w) * asp - 0.06; }
      if (v === 'R') { return (1 - box.x) * asp + 0.06; }
      if (v === 'T') { return -(box.y + box.h) - 0.06; }
      if (v === 'B') { return (1 - box.y) + 0.06; }
      return v * bh * kd;
    }
    if (def.fn) {
      var r = def.fn(p, k, ctx.frame || 0) || {};
      if (r.x !== undefined) { S.x = r.x * bh; }
      if (r.y !== undefined) { S.y = r.y * bh; }
      if (r.s !== undefined) { S.sx = r.s; S.sy = r.s; }
      if (r.sx !== undefined) { S.sx = r.sx; }
      if (r.sy !== undefined) { S.sy = r.sy; }
      if (r.r !== undefined) { S.r = r.r; }
      if (r.o !== undefined) { S.o = clamp(r.o, 0, 1); }
      if (r.b !== undefined) { S.b = r.b; }
      return S;
    }
    var f = def.f || {};
    for (var ch in f) {
      if (!f.hasOwnProperty(ch)) { continue; }
      var spec = f[ch], from = spec[0], en = spec[1] || 'out3', t0 = spec[2] === undefined ? 0 : spec[2], t1 = spec[3] === undefined ? 1 : spec[3];
      if (reversed && OUT_EASE[en]) { en = OUT_EASE[en]; }
      var q = clamp((p - t0) / (t1 - t0), 0, 1), e = ease(en, q, k), left = 1 - e;      // left: how much of "from" remains
      if (ch === 'x') { S.x += dist(from) * left; }
      else if (ch === 'xw') { S.x += from * bw * left; }
      else if (ch === 'y') { S.y += dist(from) * left; }
      else if (ch === 's') { var s = 1 + (from - 1) * (from < 1 ? 1 : k) * left; S.sx *= s; S.sy *= s; }
      else if (ch === 'sx') { S.sx *= 1 + (from - 1) * (from < 1 ? 1 : k) * left; }
      else if (ch === 'sy') { S.sy *= 1 + (from - 1) * (from < 1 ? 1 : k) * left; }
      else if (ch === 'r') { S.r += from * (Math.abs(from) >= 180 ? 1 : k) * left; }
      else if (ch === 'o') { S.o *= clamp(1 - (1 - from) * left, 0, 1); }
      else if (ch === 'b') { S.b += from * k * left; }
      else if (ch === 'cl' || ch === 'cr' || ch === 'ct' || ch === 'cb') { S[ch] = p >= 1 ? -1 : clamp(from * left, 0, 1); }
    }
    return S;
  }

  // ------------------------------------------------------------------ the whole stay of a clip
  /**
   * combo: { in: id|'' , out: id|'', loop: id|'', inDur, outDur, k, loopK, mb }
   * clip:  { dur (seconds on the timeline), fps, aspect, box }
   * → plan with the real segment lengths (in and out shrink to fit a short clip).
   */
  function plan(combo, clip) {
    var dur = Math.max(0, Number(clip.dur) || 0), fps = clip.fps > 1 ? clip.fps : 25;
    var a = anim(combo['in']), b = anim(combo.out), l = loop(combo.loop);
    var ti = a ? clamp(Number(combo.inDur) || a.d, 0.08, 6) : 0, to = b ? clamp(Number(combo.outDur) || b.d, 0.08, 6) : 0;
    var room = dur * 0.94;
    if (ti + to > room && ti + to > 0) { var sc = room / (ti + to); ti *= sc; to *= sc; }
    // whole frames, so the last key of "in" and the first key of "out" sit exactly on a frame
    ti = Math.round(ti * fps) / fps; to = Math.round(to * fps) / fps;
    var hold = dur - ti - to;
    return { a: a, b: b, l: (l && (l.span ? dur > 0 : hold > 0.5)) ? l : null, ti: ti, to: to, dur: dur, fps: fps, hold: hold,
      box: fixBox(clip.box), aspect: clip.aspect > 0 ? clip.aspect : 16 / 9, k: clamp(Number(combo.k) || 1, 0.3, 2), lk: clamp(Number(combo.loopK) || 1, 0.3, 2),
      mb: combo.mb !== false && combo.mb !== 0 };
  }

  function rot2(v, deg) { var a = deg * Math.PI / 180, c = Math.cos(a), n = Math.sin(a); return [v[0] * c - v[1] * n, v[0] * n + v[1] * c]; }

  function anchorPoint(box, a) {
    var x = box.x + box.w / 2, y = box.y + box.h / 2;
    if (a === 'l') { x = box.x; } else if (a === 'r') { x = box.x + box.w; }
    else if (a === 't') { y = box.y; } else if (a === 'b') { y = box.y + box.h; }
    return [x, y];
  }

  /**
   * Premiere's Transform turns and scales around one fixed anchor. We always use the middle of the text box,
   * and express everything else (a door that swings on its left edge, a slow push-in under a pop…) by where
   * that middle point ends up: dx, dy (frame heights) from its resting place.
   *   S  — the in/out/loop state, pivoting on its own anchor S.a
   *   sp — optional whole-clip move on top, pivoting on the middle: { s, r, x, y, o }
   */
  function resolve(S, sp, box, asp) {
    var C = [(box.x + box.w / 2) * asp, box.y + box.h / 2], A0 = anchorPoint(box, S.a), A = [A0[0] * asp, A0[1]];
    var v = rot2([(C[0] - A[0]) * S.sx, (C[1] - A[1]) * S.sy], S.r);
    var q = [A[0] + v[0] + S.x, A[1] + v[1] + S.y];
    var s2 = sp ? sp.s : 1, r2 = sp ? sp.r : 0;
    var w = rot2([(q[0] - C[0]) * s2, (q[1] - C[1]) * s2], r2);
    return { dx: w[0] + (sp ? sp.x : 0), dy: w[1] + (sp ? sp.y : 0), sx: S.sx * s2, sy: S.sy * s2, r: S.r + r2,
      o: clamp(S.o * (sp ? sp.o : 1), 0, 1), b: S.b, cl: S.cl, ct: S.ct, cr: S.cr, cb: S.cb };
  }

  /** State at t seconds after the clip's start: { dx, dy, sx, sy, r, o, b, cl, ct, cr, cb }. */
  function stateAt(P, t) {
    var ctx = { box: P.box, aspect: P.aspect, k: P.k, frame: Math.round(t * P.fps) }, S, sp = null, bh = P.box.h, r;
    if (P.a && t < P.ti) { S = evalIn(P.a, t / P.ti, ctx, false); }
    else if (P.b && t > P.dur - P.to) { S = evalIn(P.b, clamp((P.dur - t) / P.to, 0, 1), ctx, true); }
    else { S = rest(); }
    if (P.l && P.l.span) {
      r = P.l.fn(t, P.lk, P.dur > 0 ? clamp(t / P.dur, 0, 1) : 0, P.dur) || {};
      sp = { s: r.s === undefined ? 1 : r.s, r: r.r || 0, x: (r.x || 0) * bh, y: (r.y || 0) * bh, o: r.o === undefined ? 1 : r.o };
    } else if (P.l && t >= P.ti && t <= P.dur - P.to) {
      var lt = t - P.ti, env = clamp(Math.min(lt, P.hold - lt) / 0.3, 0, 1);
      r = P.l.fn(lt, P.lk * env, 0, P.hold) || {};
      if (r.x !== undefined) { S.x = r.x * bh; }
      if (r.y !== undefined) { S.y = r.y * bh; }
      if (r.s !== undefined) { S.sx = r.s; S.sy = r.s; }
      if (r.sx !== undefined) { S.sx = r.sx; }
      if (r.sy !== undefined) { S.sy = r.sy; }
      if (r.r !== undefined) { S.r = r.r; }
      if (r.o !== undefined) { S.o = clamp(1 - (1 - r.o) * env, 0, 1); }
    }
    return resolve(S, sp, P.box, P.aspect);
  }

  /** Crop percentages of the frame for a state (0 = that side is not cropped). A little slack keeps descenders whole. */
  function cropOf(S, box) {
    var pad = box.h * 0.08;
    function pc(v) { return Math.round(clamp(v, 0, 1) * 100000) / 1000; }
    return {
      l: S.cl < 0 ? 0 : pc(box.x - (S.cl === 0 ? pad : 0) + S.cl * box.w),
      r: S.cr < 0 ? 0 : pc(1 - (box.x + box.w) - (S.cr === 0 ? pad : 0) + S.cr * box.w),
      t: S.ct < 0 ? 0 : pc(box.y - (S.ct === 0 ? pad : 0) + S.ct * box.h),
      b: S.cb < 0 ? 0 : pc(1 - (box.y + box.h) - (S.cb === 0 ? pad : 0) + S.cb * box.h)
    };
  }

  // ------------------------------------------------------------------ thinning: keep only the keys that matter
  /** Indexes worth keeping so that straight lines between them stay within `tol` of every sample. vals: array of numbers or [x,y]. */
  function thin(times, vals, tol) {
    var n = times.length, keep = [], i;
    if (!n) { return []; }
    for (i = 0; i < n; i++) { keep.push(false); }
    keep[0] = true; keep[n - 1] = true;
    var dim = typeof vals[0] === 'number' ? 1 : vals[0].length;
    function v(i, d) { return dim === 1 ? vals[i] : vals[i][d]; }
    var stack = [[0, n - 1]];
    while (stack.length) {
      var seg = stack.pop(), a = seg[0], b = seg[1], worst = -1, at = -1;
      if (b - a < 2) { continue; }
      for (i = a + 1; i < b; i++) {
        var u = (times[i] - times[a]) / (times[b] - times[a]), err = 0;
        for (var d = 0; d < dim; d++) { err = Math.max(err, Math.abs(v(i, d) - (v(a, d) + (v(b, d) - v(a, d)) * u))); }
        if (err > worst) { worst = err; at = i; }
      }
      if (worst > tol) { keep[at] = true; stack.push([a, at]); stack.push([at, b]); }
    }
    var out = [];
    for (i = 0; i < n; i++) { if (keep[i]) { out.push(i); } }
    return out;
  }

  function round(n, d) { var m = Math.pow(10, d); return Math.round(n * m) / m; }

  /** One parameter: a plain value when it never changes, otherwise keys [[seconds, value], …]. */
  function track(times, vals, tol, digits) {
    var dim = typeof vals[0] === 'number' ? 1 : vals[0].length, i, d, flat = true;
    function fmt(x) { return dim === 1 ? round(x, digits) : [round(x[0], digits), round(x[1], digits)]; }
    for (i = 1; i < vals.length && flat; i++) {
      for (d = 0; d < dim; d++) { if (Math.abs((dim === 1 ? vals[i] : vals[i][d]) - (dim === 1 ? vals[0] : vals[0][d])) > tol) { flat = false; } }
    }
    if (flat) { return { v: fmt(vals[0]) }; }
    var idx = thin(times, vals, tol), k = [];
    for (i = 0; i < idx.length; i++) { k.push([round(times[idx[i]], 5), fmt(vals[idx[i]])]); }
    // a value simply holds before its first key and after its last one: keys that only repeat it are not needed
    function same(p, q) { return dim === 1 ? p === q : (p[0] === q[0] && p[1] === q[1]); }
    while (k.length > 2 && same(k[k.length - 1][1], k[k.length - 2][1])) { k.pop(); }
    while (k.length > 2 && same(k[0][1], k[1][1])) { k.shift(); }
    return { k: k };
  }

  /**
   * Everything the host needs for one clip.
   * → { ok, effects: [{ role, use, params: [{ id, v | k, hold }] }], keys, frames, plan }
   *   role: 't' Transform, 'b' Gaussian Blur, 'c' Crop. `use` false = leave it neutral (and do not add it).
   */
  function bake(combo, clip) {
    var P = plan(combo, clip), fps = P.fps, H = clip.height > 0 ? clip.height : 1080;
    var n = Math.max(1, Math.min(Math.round(P.dur * fps), 9000)), i;
    var T = [], pos = [], sh = [], sw = [], rot = [], op = [], bl = [], cl = [], ct = [], cr = [], cb = [];
    var C = [P.box.x + P.box.w / 2, P.box.y + P.box.h / 2];
    for (i = 0; i <= n; i++) {
      var t = Math.min(i / fps, P.dur), S = stateAt(P, t), K = cropOf(S, P.box);
      T.push(t);
      pos.push([C[0] + S.dx / P.aspect, C[1] + S.dy]);
      sh.push(S.sy * 100); sw.push(S.sx * 100); rot.push(S.r); op.push(S.o * 100);
      bl.push(Math.max(0, S.b) * H / 1080);
      cl.push(K.l); ct.push(K.t); cr.push(K.r); cb.push(K.b);
    }
    var anchor = { v: [round(C[0], 5), round(C[1], 5)] };
    function P_(id, tr) { tr.id = id; return tr; }
    var blur = track(T, bl, 0.15, 2), crop = [track(T, cl, 0.02, 3), track(T, ct, 0.02, 3), track(T, cr, 0.02, 3), track(T, cb, 0.02, 3)];
    var mbOn = P.mb && !((P.a && P.a.mb === 0) || (P.b && P.b.mb === 0) || (P.l && P.l.mb === 0));
    var fx = [
      { role: 't', use: true, params: [
        P_('anchor', anchor), P_('position', track(T, pos, 0.0004, 5)), P_('uniform', { v: false }),
        P_('scaleH', track(T, sh, 0.12, 2)), P_("scaleW", track(T, sw, 0.12, 2)), P_("rotation", track(T, rot, 0.08, 2)),
        P_('opacity', track(T, op, 0.3, 1)), P_('useComp', { v: false }), P_('shutter', { v: mbOn ? 180 : 0 })
      ] },
      { role: 'b', use: !!blur.k || blur.v > 0, params: [P_('blur', blur)] },
      { role: 'c', use: !!(crop[0].k || crop[1].k || crop[2].k || crop[3].k), params: [P_('left', crop[0]), P_('top', crop[1]), P_('right', crop[2]), P_('bottom', crop[3])] }
    ];
    var keys = 0;
    for (i = 0; i < fx.length; i++) { for (var j = 0; j < fx[i].params.length; j++) { if (fx[i].params[j].k) { keys += fx[i].params[j].k.length; } } }
    return { ok: P.dur > 0, effects: fx, keys: keys, frames: n, plan: { ti: P.ti, to: P.to, hold: P.hold, loop: P.l ? P.l.id : '', mb: mbOn } };
  }

  /** The rig with nothing happening: used to take an animation off a clip. */
  function neutral() {
    function P_(id, v) { return { id: id, v: v }; }
    return { ok: true, keys: 0, effects: [
      { role: 't', use: true, params: [P_('anchor', [0.5, 0.5]), P_('position', [0.5, 0.5]), P_('uniform', false), P_('scaleH', 100), P_('scaleW', 100), P_('rotation', 0), P_('opacity', 100), P_('useComp', false), P_('shutter', 0)] },
      { role: 'b', use: false, params: [P_('blur', 0)] },
      { role: 'c', use: false, params: [P_('left', 0), P_('top', 0), P_('right', 0), P_('bottom', 0)] }
    ] };
  }

  /** Does this combination lean on the text box (masks, or scaling / turning around a point)? */
  function needsBox(combo) {
    var out = { mask: false, anchor: false }, list = [anim(combo['in']), anim(combo.out)];
    for (var i = 0; i < list.length; i++) {
      var d = list[i]; if (!d) { continue; }
      if (d.box) { out.mask = true; }
      if (d.fn || d.a) { out.anchor = true; }
      for (var ch in (d.f || {})) { if (ch === 's' || ch === 'sx' || ch === 'sy' || ch === 'r') { out.anchor = true; } }
    }
    var l = loop(combo.loop);
    if (l && !/^(float|sway|shake|flickerL|blink|hop|driftR|driftL|driftUp|orbit|strobeL)$/.test(l.id)) { out.anchor = true; }
    return out;
  }

  function search(query) {
    var q = String(query || '').toLowerCase().replace(/^\s+|\s+$/g, ''), out = [];
    if (!q) { return out; }
    for (var i = 0; i < ANIMS.length; i++) { if (ANIMS[i].n.toLowerCase().indexOf(q) >= 0 || ANIMS[i].id.toLowerCase().indexOf(q) >= 0) { out.push(ANIMS[i]); } }
    return out;
  }

  return {
    CATS: CATS, ANIMS: ANIMS, LOOPS: LOOPS, DEFAULT_BOX: DEFAULT_BOX,
    anim: anim, loop: loop, inCategory: inCategory, search: search,
    ease: ease, rnd: rnd, fixBox: fixBox, evalIn: evalIn, plan: plan, stateAt: stateAt, resolve: resolve,
    anchorPoint: anchorPoint, cropOf: cropOf, thin: thin, bake: bake, neutral: neutral, needsBox: needsBox
  };
});
