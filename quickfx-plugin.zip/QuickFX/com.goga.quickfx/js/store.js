/*
 * Quick FX — tiny JSON files shared by the search window and the invisible background watcher
 * (they are separate pages, so a file is the simplest thing both can read).
 *   settings.json    { auto: true }
 *   auto-state.json  written by the watcher: heartbeat, last activity, files still waiting
 */
(function (root) {
  'use strict';
  var B = root.QFXBridge;
  var dirPath = null;

  function dir() {
    if (dirPath !== null) { return dirPath; }
    var base = B ? B.userDataPath() : '';
    dirPath = base ? base.replace(/\/+$/, '') + '/QuickFX' : '';
    if (dirPath) { B.makeDir(dirPath); }
    return dirPath;
  }

  var Store = {
    dir: dir,
    read: function (name, dflt) {
      var d = dir();
      if (!d) { return dflt; }
      var text = B.readTextFile(d + '/' + name);
      if (!text) { return dflt; }
      try { var v = JSON.parse(text); return v == null ? dflt : v; } catch (e) { return dflt; }
    },
    write: function (name, value) {
      var d = dir();
      return d ? B.writeTextFile(d + '/' + name, JSON.stringify(value)) : false;
    },
    settings: function () {
      var s = Store.read('settings.json', {}) || {};
      return { auto: s.auto !== false };
    }
  };

  root.QFXStore = Store;
})(this);
