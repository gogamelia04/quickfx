/*
 * Quick FX — invisible background watcher.
 * Starts with Premiere. When a file from outside the project folder is imported (dragging a file
 * from Finder onto the timeline imports it first), it is copied to <project>/Imported/<type>/ and
 * the clip is re-pointed to the copy. Originals are never touched. Files that were already in the
 * project when it was opened are left for the manual "ფაილების შეგროვება" command.
 */
(function () {
  'use strict';

  var B = window.QFXBridge, C = window.QFXCollect, Store = window.QFXStore;
  var VERSION = '1.8.0';
  var TICK_MS = window.__QFX_AUTO_TICK_MS || 2500;
  var RETRY_MS = window.__QFX_AUTO_RETRY_MS || 60000;
  var MIN_SCAN_MS = window.__QFX_AUTO_SCAN_MS || 10000;     // fallback re-scan when Premiere sends no import events
  var FRESH_MS = window.__QFX_AUTO_FRESH_MS == null ? 3000 : window.__QFX_AUTO_FRESH_MS;   // file changed this recently = still being written
  var SETTLE_MS = window.__QFX_AUTO_SETTLE_MS || 5000;
  var STATE_FILE = 'auto-state.json';
  var BIG_BATCH = 1073741824;                                // announce the start of copies above 1 GB

  function nodeFs() {
    try {
      var req = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
      return req ? req('fs') : null;
    } catch (e) { return null; }
  }
  var fs = nodeFs();
  var copier = fs ? C.createCopier(fs) : null;
  var finder = fs ? C.createFinder(fs) : null;

  var st = {
    startedAt: Date.now(), enabled: true, project: '', bound: false, eventsSeen: false,
    lastScan: 0, lastScanMs: 0, scanEvery: MIN_SCAN_MS, dirtySince: 0, items: 0,
    queue: [], parked: [], working: false, current: '',
    batch: { done: [], failed: [] },
    pending: {}, log: [], lastError: null, copied: 0,
    inFlight: {},        // project|path → being copied / waiting to retry / parked
    gaveUp: {}           // project|path → failed 3 times this session: do not loop on it
  };
  function keyOf(project, path) { return project + '|' + path; }
  var prev = Store.read(STATE_FILE, null);
  if (prev && prev.pending && typeof prev.pending === 'object') { st.pending = prev.pending; }

  // ------------------------------------------------------------------ bookkeeping
  function log(kind, text) {
    st.log.push({ t: new Date().toISOString(), kind: kind, text: text });
    if (st.log.length > 30) { st.log.splice(0, st.log.length - 30); }
  }

  function persist() {
    Store.write(STATE_FILE, {
      alive: Date.now(), startedAt: st.startedAt, version: VERSION, node: !!fs, enabled: st.enabled,
      bound: st.bound, eventsSeen: st.eventsSeen, project: st.project, items: st.items,
      scanMs: st.lastScanMs, scanEvery: st.scanEvery, queue: st.queue.length, parked: st.parked.length,
      current: st.current, copied: st.copied, pending: st.pending, lastError: st.lastError, log: st.log
    });
  }

  function addPending(project, path) {
    var list = st.pending[project] || (st.pending[project] = []);
    if (list.indexOf(path) < 0) { list.push(path); }
  }
  function removePending(project, path) {
    var list = st.pending[project];
    if (!list) { return; }
    var i = list.indexOf(path);
    if (i >= 0) { list.splice(i, 1); }
    if (!list.length) { delete st.pending[project]; }
  }

  function notify(kind, text) { return B.call('notify', { kind: kind, text: text }); }

  function relPath(job) {
    var base = job.projectDir.replace(/\/+$/, '') + '/';
    return job.to && job.to.indexOf(base) === 0 ? job.to.slice(base.length) : (job.to || '');
  }

  function ensureHost() {
    var probe = '(typeof QuickFX === "object" && typeof QuickFX.watchPoll === "function") ? "ok" : "no"';
    return B.evalScript(probe).then(function (r) {
      if (r === 'ok') { return true; }
      var path = B.extensionPath() + '/jsx/host.jsx';
      return B.evalScript('$.evalFile(' + JSON.stringify(path) + ')').then(function () { return true; });
    });
  }

  // ------------------------------------------------------------------ copy queue
  function flushBatch() {
    var d = st.batch.done, f = st.batch.failed;
    st.batch = { done: [], failed: [] };
    if (d.length === 1) {
      notify('info', d[0].reused
        ? 'Quick FX: ' + d[0].name + ' უკვე იყო პროექტის საქაღალდეში — მიება (' + relPath(d[0]) + ')'
        : 'Quick FX: ' + d[0].name + ' → ' + relPath(d[0]));
    } else if (d.length > 1) {
      notify('info', 'Quick FX: ' + d.length + ' ფაილი დაკოპირდა → Imported');
    }
    if (f.length) {
      var names = [];
      for (var i = 0; i < f.length && i < 3; i++) { names.push(f[i].name); }
      notify('warning', 'Quick FX: ' + f.length + ' ფაილი ვერ დაკოპირდა Imported-ში: ' + names.join(', ') + (f.length > 3 ? '…' : ''));
    }
  }

  function work() {
    if (st.working || !st.queue.length) { return; }
    st.working = true;
    var job = st.queue[0];
    st.current = job.name;

    // A file that is still being written (a download finishing, a render, Premiere adding its XMP id
    // right after import) would be copied half-done: wait until it has been quiet for a moment.
    if (fs && FRESH_MS) {
      var info = null;
      try { info = fs.statSync(job.path); } catch (eStat) { info = null; }
      if (info && (info.size !== job.size || Date.now() - info.mtimeMs < FRESH_MS) && (job.waits || 0) < 120) {
        job.size = info.size;
        job.waits = (job.waits || 0) + 1;
        st.queue.shift();
        st.working = false;
        st.current = '';
        setTimeout(function () { st.queue.push(job); work(); }, SETTLE_MS);
        work();
        return;
      }
    }

    var existing = null;
    try { existing = finder ? finder.find(job.projectDir, job.name, job.size) : null; } catch (e) { existing = null; }

    var copy;
    if (existing) { copy = Promise.resolve({ to: existing, reused: true, bytes: 0 }); }
    else if (copier) { copy = copier.copyInto(job.path, C.join(job.importedDir, job.cat), job.name); }
    else {
      copy = B.call('copyInto', { from: job.path, dir: C.join(job.importedDir, job.cat), name: job.name }).then(function (r) {
        if (!r || !r.ok) { throw new Error((r && r.code) || 'copyFailed'); }
        return r.data;
      });
    }

    copy.then(function (res) {
      job.to = res.to;
      job.reused = !!res.reused;
      if (finder && !res.reused) { finder.add(job.projectDir, res.to); }
      return B.call('relinkMedia', { pairs: [{ from: job.path, to: res.to }] });
    }).then(function (rr) {
      if (!rr || !rr.ok || rr.data.failed) { throw new Error('relink'); }
      if (rr.data.relinked) { return 'done'; }
      // Nothing uses that file in the project that is open right now.
      return B.call('watchPoll').then(function (pp) {
        var active = pp && pp.ok ? pp.data.project : '';
        return (active && active !== job.project) ? 'parked' : 'gone';
      });
    }).then(function (outcome) {
      if (outcome === 'done') {
        st.batch.done.push(job);
        if (!job.reused) { st.copied++; }
        log('ok', job.name + ' → ' + relPath(job) + (job.reused ? ' (already there)' : ''));
        removePending(job.project, job.path);
        delete st.inFlight[keyOf(job.project, job.path)];
      } else if (outcome === 'parked') {
        st.parked.push(job);                                  // its project is not the active one: relink when it is again
      } else {
        log('info', job.name + ': no longer in the project');
        removePending(job.project, job.path);
        delete st.inFlight[keyOf(job.project, job.path)];
      }
    }).catch(function (e) {
      var reason = String((e && (e.code || e.message)) || e);
      job.tries = (job.tries || 0) + 1;
      if (job.tries < 3 && reason !== 'missing') {
        setTimeout(function () { st.queue.push(job); work(); }, RETRY_MS);
        log('info', job.name + ': retry ' + job.tries + ' (' + reason + ')');
      } else {
        st.batch.failed.push(job);
        log('err', job.name + ': ' + reason);
        removePending(job.project, job.path);
        delete st.inFlight[keyOf(job.project, job.path)];
        st.gaveUp[keyOf(job.project, job.path)] = true;
      }
    }).then(function () {
      st.queue.shift();
      st.working = false;
      st.current = '';
      if (!st.queue.length) { flushBatch(); }
      persist();
      work();
    });
  }

  // ------------------------------------------------------------------ watching
  function scan(project) {
    var t0 = Date.now();
    return B.call('watchScan', { pending: st.pending[project] || [] }).then(function (r) {
      var ms = Date.now() - t0;
      st.lastScan = Date.now();
      st.lastScanMs = ms;
      st.dirtySince = 0;
      // Walking the project runs on Premiere's main thread: keep it to ~1% of the time.
      st.scanEvery = Math.max(st.eventsSeen ? 120000 : MIN_SCAN_MS, ms * 100);
      if (!r || !r.ok) { if (!r || r.code !== 'noProject') { st.lastError = r || { code: 'hostError' }; } return; }
      var d = r.data, i, total = 0, added = 0;
      st.items = d.items;
      if (d.baseline) { st.pending[d.project] = []; }
      for (i = 0; i < d.files.length; i++) {
        var f = d.files[i], key = keyOf(d.project, f.path);
        if (st.inFlight[key] || st.gaveUp[key]) { continue; }
        st.inFlight[key] = true;
        added++;
        f.cat = C.categorize(f.name);
        f.project = d.project; f.projectDir = d.projectDir; f.importedDir = d.importedDir; f.tries = 0;
        total += f.size || 0;
        st.queue.push(f);
        addPending(d.project, f.path);
      }
      if (d.baseline && !(st.pending[d.project] || []).length) { delete st.pending[d.project]; }
      if (added) {
        if (total >= BIG_BATCH) {
          notify('info', 'Quick FX: კოპირდება ' + added + ' ფაილი (' + C.formatBytes(total) + ') → Imported…');
        }
        persist();
        work();
      }
    });
  }

  var lastTick = 0, ticking = false, tickStart = 0, tickN = 0;
  function tick() {
    var now = Date.now();
    if (ticking && now - tickStart > 90000) { ticking = false; }          // a host call never came back
    if (ticking || now - lastTick < TICK_MS * 0.8) { return; }
    lastTick = now; tickStart = now; ticking = true; tickN++;
    function done() { ticking = false; if (tickN % 2 === 0) { persist(); } }

    st.enabled = Store.settings().auto;
    if (!st.enabled) { done(); return; }

    ensureHost().then(function () { return B.call('watchPoll'); }).then(function (r) {
      if (!r || !r.ok) { st.lastError = r || { code: 'hostError' }; return; }
      var d = r.data;
      st.bound = d.bound;
      if (d.events > 0) { st.eventsSeen = true; }
      if (!d.project) { st.project = ''; return; }
      var changed = d.project !== st.project;
      st.project = d.project;
      if (changed && st.parked.length) {
        var keep = [];
        for (var i = 0; i < st.parked.length; i++) {
          if (st.parked[i].project === d.project) { st.queue.push(st.parked[i]); } else { keep.push(st.parked[i]); }
        }
        st.parked = keep;
        work();
      }
      var due = changed || (now - st.lastScan >= st.scanEvery);
      if (d.dirty && !due) {
        if (!st.dirtySince) { st.dirtySince = now; return; }              // let a multi-file import finish first
        due = true;
      }
      if (due) { return scan(d.project); }
    }).catch(function (e) {
      st.lastError = { code: 'exception', message: String((e && e.message) || e) };
    }).then(done);
  }

  function safeTick() { try { tick(); } catch (e) { ticking = false; } }

  function start() {
    log('info', 'started ' + VERSION + (fs ? '' : ' (no Node: copies run inside Premiere)'));
    persist();
    safeTick();
    window.setInterval(safeTick, TICK_MS);
    // Hidden pages can have their timers slowed down; Node's timers are not affected.
    try { if (window.cep_node && window.cep_node.global && window.cep_node.global.setInterval) { window.cep_node.global.setInterval(safeTick, TICK_MS); } } catch (e) { /* DOM timer only */ }
  }

  window.QFXAuto = { state: st, tick: tick, version: VERSION };
  if (B && B.available) { start(); }
})();
