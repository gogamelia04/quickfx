/*
 * Quick FX — "collect files": copy media that lives outside the project folder into
 * <project folder>/Imported/<Video|Audio|Music|Images|Other>/ .
 * Pure helpers + a Node-based copier (CEP gives the panel Node through window.cep_node).
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  if (root) { root.QFXCollect = api; }
})(this, function () {
  'use strict';

  var EXT = {
    Video: ['mp4', 'mov', 'mxf', 'avi', 'mkv', 'm4v', 'mts', 'm2ts', 'mpg', 'mpeg', 'webm', 'wmv', 'braw', 'r3d', 'crm', 'insv', 'osv', '360', 'lrv', '3gp', 'flv', 'ts', 'vob', 'dv'],
    Audio: ['wav', 'aif', 'aiff', 'm4a', 'aac', 'flac', 'ogg', 'wma', 'opus', 'caf', 'mp3'],
    Images: ['png', 'jpg', 'jpeg', 'tif', 'tiff', 'psd', 'psb', 'gif', 'bmp', 'webp', 'heic', 'heif', 'exr', 'tga', 'dpx', 'svg', 'ai', 'eps', 'dng', 'cr2', 'cr3', 'arw', 'nef', 'raf']
  };
  var MUSIC_NAME = /^es_|music|musika|artlist|epidemic|soundtrack|song|მუსიკ/i;
  var CATEGORIES = ['Video', 'Audio', 'Music', 'Images', 'Other'];

  function extOf(name) {
    var m = /\.([A-Za-z0-9]+)$/.exec(String(name || ''));
    return m ? m[1].toLowerCase() : '';
  }
  function baseName(p) {
    var s = String(p || '').replace(/\/+$/, '');
    var i = s.lastIndexOf('/');
    return i < 0 ? s : s.slice(i + 1);
  }
  function dirName(p) {
    var s = String(p || '').replace(/\/+$/, '');
    var i = s.lastIndexOf('/');
    return i <= 0 ? '/' : s.slice(0, i);
  }
  function join(a, b) { return String(a).replace(/\/+$/, '') + '/' + String(b).replace(/^\/+/, ''); }

  /** Which Imported/ subfolder a file belongs in. Music = mp3, or a name that says so (ES_…, music, artlist…). */
  function categorize(name) {
    var ext = extOf(name);
    if (EXT.Video.indexOf(ext) >= 0) { return 'Video'; }
    if (EXT.Images.indexOf(ext) >= 0) { return 'Images'; }
    if (EXT.Audio.indexOf(ext) >= 0) {
      return (ext === 'mp3' || MUSIC_NAME.test(baseName(name))) ? 'Music' : 'Audio';
    }
    return 'Other';
  }

  /** "clip.mp4", 2 -> "clip (2).mp4" */
  function numbered(name, n) {
    var m = /^(.*?)(\.[A-Za-z0-9]+)?$/.exec(name);
    return m[1] + ' (' + n + ')' + (m[2] || '');
  }

  function formatBytes(n) {
    n = Number(n) || 0;
    if (n >= 1073741824) { return (n / 1073741824).toFixed(n >= 10737418240 ? 0 : 1) + ' GB'; }
    if (n >= 1048576) { return Math.round(n / 1048576) + ' MB'; }
    if (n >= 1024) { return Math.round(n / 1024) + ' KB'; }
    return n + ' B';
  }

  /** Totals per category for the summary screen. */
  function summarize(files) {
    var out = { count: 0, bytes: 0, byCat: {} }, i;
    for (i = 0; i < CATEGORIES.length; i++) { out.byCat[CATEGORIES[i]] = { count: 0, bytes: 0 }; }
    for (i = 0; i < files.length; i++) {
      var c = out.byCat[files[i].cat] || out.byCat.Other;
      c.count++; c.bytes += files[i].size || 0;
      out.count++; out.bytes += files[i].size || 0;
    }
    return out;
  }

  /**
   * Copier on top of Node's fs. copyInto(src, dir, name, onProgress) resolves with
   *   { to, reused, bytes }   reused = an identical-size copy was already there.
   * Writes to "<name>.qfxpart" first, so an interrupted copy never leaves a broken file behind.
   */
  function createCopier(fs) {
    function exists(p) { try { fs.statSync(p); return true; } catch (e) { return false; } }
    function sizeOf(p) { try { return fs.statSync(p).size; } catch (e) { return -1; } }
    function mkdirp(dir) {
      if (exists(dir)) { return; }
      var parent = dirName(dir);
      if (parent && parent !== dir) { mkdirp(parent); }
      try { fs.mkdirSync(dir); } catch (e) { if (!exists(dir)) { throw e; } }
    }

    function copyInto(src, dir, name, onProgress) {
      return new Promise(function (resolve, reject) {
        var total = sizeOf(src);
        if (total < 0) { reject(new Error('missing')); return; }
        try { mkdirp(dir); } catch (e) { reject(e); return; }

        var dst = join(dir, name), n = 2;
        while (exists(dst)) {
          if (sizeOf(dst) === total) { resolve({ to: dst, reused: true, bytes: 0 }); return; }
          dst = join(dir, numbered(name, n++));
          if (n > 500) { reject(new Error('too many name collisions')); return; }
        }

        var part = dst + '.qfxpart';
        try { if (exists(part)) { fs.unlinkSync(part); } } catch (e2) { /* overwritten below */ }

        var timer = null;
        if (onProgress) {
          timer = setInterval(function () { var s = sizeOf(part); if (s >= 0) { onProgress(Math.min(s, total), total); } }, 400);
        }
        // FICLONE: on the same APFS volume the copy is an instant clone that takes no extra space; otherwise a normal copy.
        var flags = (fs.constants && fs.constants.COPYFILE_FICLONE) || 0;
        fs.copyFile(src, part, flags, function (err) {
          if (timer) { clearInterval(timer); }
          if (err) { try { fs.unlinkSync(part); } catch (e3) { /* nothing to clean */ } reject(err); return; }
          if (sizeOf(part) !== total) {
            try { fs.unlinkSync(part); } catch (e4) { /* nothing to clean */ }
            reject(new Error('size mismatch after copy'));
            return;
          }
          try { fs.renameSync(part, dst); } catch (e5) { reject(e5); return; }
          if (onProgress) { onProgress(total, total); }
          resolve({ to: dst, reused: false, bytes: total });
        });
      });
    }

    return { copyInto: copyInto };
  }

  /**
   * Looks for a file with the same name and size anywhere in the project folder, so a file that is
   * already there is linked instead of copied a second time. Only names are listed; sizes are read
   * for same-name candidates only.
   */
  var SKIP_DIR = /^(\.|Adobe Premiere Pro (Auto-Save|Audio Previews|Video Previews|Captured Audio|Captured Video)$|node_modules$)/i;
  function createFinder(fs, opts) {
    var maxDepth = (opts && opts.maxDepth) || 6, maxFiles = (opts && opts.maxFiles) || 40000, ttl = (opts && opts.ttl) || 30000;
    var cache = {};

    function build(root) {
      var index = {}, count = 0;
      (function walk(dir, depth) {
        var list;
        try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
        for (var i = 0; i < list.length && count < maxFiles; i++) {
          var e = list[i], name = String(e.name);
          if (e.isDirectory()) {
            if (depth < maxDepth && !SKIP_DIR.test(name)) { walk(join(dir, name), depth + 1); }
          } else if (!/\.qfxpart$/.test(name) && name.charAt(0) !== '.') {
            var key = '$' + name.toLowerCase();
            (index[key] || (index[key] = [])).push(join(dir, name));
            count++;
          }
        }
      })(root, 0);
      return index;
    }

    function find(root, name, size) {
      var c = cache[root], now = Date.now();
      if (!c || now - c.at > ttl) { c = cache[root] = { at: now, index: build(root) }; }
      var list = c.index['$' + String(name).toLowerCase()] || [];
      for (var i = 0; i < list.length; i++) {
        try { if (fs.statSync(list[i]).size === size) { return list[i]; } } catch (e) { /* gone since indexing */ }
      }
      return null;
    }

    function add(root, path) {
      var c = cache[root];
      if (!c) { return; }
      var key = '$' + baseName(path).toLowerCase();
      (c.index[key] || (c.index[key] = [])).push(path);
    }

    return { find: find, add: add, reset: function () { cache = {}; } };
  }

  return {
    CATEGORIES: CATEGORIES,
    categorize: categorize,
    numbered: numbered,
    formatBytes: formatBytes,
    summarize: summarize,
    createCopier: createCopier,
    createFinder: createFinder,
    baseName: baseName,
    dirName: dirName,
    join: join
  };
});
