/*
 * Quick FX — panel UI.
 * Popup mode (Modeless window): type, Enter, it applies and closes.
 * Panel mode (docked): stays open.
 */
(function () {
  'use strict';

  var B = window.QFXBridge, S = window.QFXSearch, P = window.QFXPresets, Store = window.QFXStore;
  var AUTO_ID = 'com.goga.quickfx.auto';
  var VERSION = '1.8.0';
  var extId = B.extensionId();
  var MODE = /\.panel$/.test(extId) ? 'panel' : 'popup';
  var LS = { usage: 'qfx.usage.v1', effects: 'qfx.effects.v1', settings: 'qfx.settings.v1' };
  var RESULT_LIMIT = 80;
  var EMPTY_EFFECT_LIMIT = 120;

  var T = {
    videoFx: 'ვიდეო ეფექტი',
    audioFx: 'აუდიო ეფექტი',
    preset: 'პრესეტი',
    recent: 'ბოლოს გამოყენებული',
    myPresets: 'ჩემი პრესეტები',
    effects: 'ეფექტები',
    loading: 'იტვირთება…',
    nothing: function (q) { return 'ვერაფერი მოიძებნა: <strong>' + esc(q) + '</strong>'; },
    moreHint: 'აკრიფე სახელი, რომ ყველა ეფექტში მოძებნო…',
    noSeq: 'სექვენსი არ არის გახსნილი',
    noSel: 'კლიპი არ არის მონიშნული',
    selected: function (v, a) {
      var parts = [];
      if (v) { parts.push(v + ' ვიდეო'); }
      if (a) { parts.push(a + ' აუდიო'); }
      return parts.join(' · ') + ' მონიშნულია';
    },
    appliedFx: function (name, n) { return '<b>' + esc(name) + '</b> დაედო ' + n + ' კლიპს'; },
    appliedPreset: function (name, n) { return '«' + esc(name) + '» დაედო ' + n + ' კლიპს'; },
    failedSome: function (n) { return n + ' კლიპზე ვერ დაედო'; },
    skippedParams: function (n) { return n + ' პარამეტრი ვერ გადმოვიდა (Lumetri-ს curves/wheels, მასკები და მისთ.)'; },
    missingFx: function (list) { return 'არ არის დაყენებული: ' + list.join(', '); },
    errors: {
      noSequence: 'სექვენსი არ არის გახსნილი',
      noSelection: 'ჯერ მონიშნე კლიპი timeline-ზე',
      noVideoSelected: 'მონიშნულია მხოლოდ აუდიო — ვიდეო ეფექტისთვის ვიდეო კლიპი მონიშნე',
      noAudioSelected: 'მონიშნულია მხოლოდ ვიდეო — აუდიო ეფექტისთვის აუდიო კლიპი მონიშნე',
      effectNotFound: 'ეფექტი ვერ მოიძებნა',
      applyFailed: 'ეფექტი ვერ დაედო',
      presetFailed: 'პრესეტი ვერ დაედო',
      noQE: 'Premiere-ის შიდა API ვერ ჩაირთო',
      noProject: 'პროექტი ვერ ვიპოვე — ჯერ შეინახე',
      noFreeTrack: 'ზედა ტრეკი აქ დაკავებულია და ახალი ვერ დავამატე — დაამატე ცარიელი ვიდეო ტრეკი ზემოთ',
      noZones: 'ამ სექვენსზე ზონა არ დევს',
      zoneWriteFailed: 'ზონის სურათი ვერ შეინახა',
      zoneFileMissing: 'ზონის სურათი ვერ მოიძებნა',
      zoneImportFailed: 'ზონის სურათი პროექტში ვერ შემოვიდა',
      zonePlaceFailed: 'ზონა ტრეკზე ვერ დაიდო',
      zoneReplaceFailed: 'ძველი ზონა ვერ მოიხსნა',
      zoneToggleFailed: 'ზონა ვერ დაიმალა — ტრეკის თვალის ხატულა გამორთე ხელით',
      hostError: 'Premiere-მა არ უპასუხა — დახურე და თავიდან გახსენი Quick FX',
      badReply: 'Premiere-მა გაუგებარი პასუხი დააბრუნა',
      exception: 'შეცდომა'
    },
    commands: 'ბრძანებები',
    z: {
      vertical: 'ვერტიკალური · 9:16',
      horizontal: 'ჰორიზონტალური · 16:9',
      noSeq: 'ჯერ სექვენსი გახსენი',
      willPlace: function (n) { return 'დაიდება ლურჯი ხაზიდან ' + n + ' წამზე. მერე კლიპივით გაწელე ან დაამოკლე.'; },
      seqSize: function (w, h) { return 'სექვენსი ' + w + ' × ' + h; },
      willSwap: function (name) { return 'ლურჯ ხაზზე უკვე დევს: ' + name + '. შეიცვლება, სიგრძე დარჩება.'; },
      hide: 'დამალვა', show: 'ჩვენება',
      visible: function (n) { return 'ჩანს სექვენსზე: ' + n; },
      hidden: function (n) { return 'დამალულია: ' + n; },
      exportHint: 'ექსპორტამდე დამალე — ზონა ჩვეულებრივი კლიპია',
      placed: function (name, secs) { return '<b>' + esc(name) + '</b> ზონა დაიდო · ' + secs + ' წმ'; },
      swapped: function (name) { return 'ზონა შეიცვალა: <b>' + esc(name) + '</b>'; },
      newTrack: 'დაემატა ახალი ტრეკი ზემოთ.',
      notExact: 'სიგრძე ზუსტად ვერ დაყენდა — კლიპი ხელით გაწელე.',
      nowHidden: function (n) { return n + ' ზონა დაიმალა'; },
      nowShown: function (n) { return n + ' ზონა ჩანს'; },
      removed: function (n) { return n + ' ზონა წაიშალა'; },
      cmdMeta: function (n) { return n + ' წმ ლურჯი ხაზიდან'; },
      cmdToggle: 'Safe Zones — დამალვა / ჩვენება'
    },
    auto: {
      title: 'ავტომატური შეგროვება',
      desc: 'ახალი ფაილი, რომელსაც Downloads-იდან, გარე დისკიდან ან ბარათიდან შემოიტან, თავისით დაკოპირდება პროექტის Imported საქაღალდეში.',
      manualTitle: 'პროექტში უკვე არსებული ფაილები',
      manualDesc: 'რაც ადრე შემოიტანე და პროექტის საქაღალდის გარეთ დარჩა: ნახავ სიას და ერთად დააკოპირებ.',
      manualBtn: 'შეგროვება',
      activity: 'ბოლო აქტივობა',
      noActivity: 'ჯერ არაფერი დაკოპირებულა',
      toFx: 'ეფექტები',
      dockOn: 'ელოდება ახალ ფაილებს',
      dockOff: 'გამორთულია',
      dockStarting: 'ირთვება…',
      dockDead: 'ფონი არ პასუხობს',
      dockDeadTip: 'ფონური ნაწილი არ პასუხობს — Premiere სრულად დახურე და თავიდან გახსენი',
      dockLast: function (name) { return 'ბოლო: ' + name; },
      on: 'ავტომატური შეგროვება: მუშაობს',
      off: 'ავტომატური შეგროვება: გამორთულია',
      dead: 'ავტომატური შეგროვება: ფონური ნაწილი არ პასუხობს — Premiere თავიდან გახსენი',
      copying: function (name, left) { return 'კოპირდება: ' + name + (left > 1 ? ' (+' + (left - 1) + ')' : ''); },
      last: 'ბოლო:'
    },
    c: {
      title: 'ფაილების შეგროვება',
      scanning: 'პროექტი მოწმდება…',
      allInside: '✓ ყველა ფაილი უკვე პროექტის საქაღალდეშია',
      checked: function (n) { return 'შემოწმდა ' + n + ' ფაილი'; },
      found: function (n, size) { return n + ' ფაილი · ' + size + ' პროექტის საქაღალდის გარეთაა'; },
      willCopy: 'დაკოპირდება აქ:',
      copy: 'დაკოპირება',
      back: 'უკან',
      stop: 'გაჩერება',
      stopping: 'ჩერდება მიმდინარე ფაილის შემდეგ…',
      close: 'დახურვა',
      keepWorking: 'Premiere-ში მუშაობა შეგიძლია გააგრძელო. ეს ფანჯარა არ დახურო, სანამ არ დასრულდება.',
      mayFreeze: 'დიდი ფაილის კოპირებისას Premiere შეიძლება ცოტა ხნით გაიყინოს.',
      done: '✓ დასრულდა',
      doneWithErrors: 'დასრულდა, მაგრამ ზოგი ფაილი ვერ გადავიდა',
      result: function (copied, reused, relinked) {
        var parts = [copied + ' დაკოპირდა'];
        if (reused) { parts.push(reused + ' უკვე იყო პროექტის საქაღალდეში'); }
        parts.push(relinked + ' კლიპი გადამისამართდა');
        return parts.join(' · ');
      },
      stoppedAt: function (done, total) { return 'გაჩერდა: ' + done + ' / ' + total + '. დანარჩენისთვის ბრძანება თავიდან გაუშვი.'; },
      saveHint: 'ორიგინალები ადგილზეა. პროექტი შეინახე: ⌘S',
      skipped: 'გამოტოვებულია:',
      skip: { offline: 'offline', missing: 'დისკზე ვერ მოიძებნა', linked: 'After Effects / Dynamic Link', sequence: 'სურათების სექვენსი' },
      errReason: { relink: 'დაკოპირდა, მაგრამ ვერ გადამისამართდა', missing: 'ორიგინალი ვერ მოიძებნა', copyFailed: 'ვერ დაკოპირდა', mkdirFailed: 'საქაღალდე ვერ შეიქმნა', ENOSPC: 'დისკზე ადგილი არ არის', EACCES: 'წვდომა არ არის', EPERM: 'წვდომა არ არის' }
    },
    diagCopied: 'დიაგნოსტიკა დაკოპირდა — ჩასვი ჩატში',
    refreshed: function (fx, pr) { return 'განახლდა: ' + fx + ' ეფექტი · ' + pr + ' პრესეტი'; }
  };

  // ------------------------------------------------------------------ state
  var state = {
    effects: { video: [], audio: [] },
    presets: [],
    presetSkipped: [],
    presetFile: null,
    presetError: null,
    info: null,
    items: [],
    rows: [],            // rendered rows (selectable ones only)
    active: 0,
    view: 'list',
    busy: false,
    loaded: false,
    hadFocus: false,
    openedAt: Date.now(),
    lastError: null,
    lastResult: null,
    usage: load(LS.usage, {}),
    settings: assign({ closeOnBlur: true }, load(LS.settings, {}))
  };

  // ------------------------------------------------------------------ DOM
  function $(id) { return document.getElementById(id); }
  var $q = $('q'), $list = $('list'), $sel = $('sel'), $toast = $('toast');
  var $menu = $('menu'), $menuBtn = $('menuBtn'), $busy = $('busy'), $menuInfo = $('menuInfo');
  var $closeOnBlur = $('closeOnBlur'), $blurOpt = $('blurOpt'), $keys = $('keys');
  var $files = $('files'), $fkeys = $('fkeys'), $railDot = $('railDot');
  var $tabs = { fx: $('tabFx'), files: $('tabFiles'), zones: $('tabZones') };
  var VIEW_OF = { fx: 'list', files: 'collect', zones: 'zones' };

  // ------------------------------------------------------------------ utils
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function assign(a, b) { for (var k in b) { if (Object.prototype.hasOwnProperty.call(b, k)) { a[k] = b[k]; } } return a; }
  function load(key, dflt) {
    try { var v = window.localStorage.getItem(key); return v ? JSON.parse(v) : dflt; } catch (e) { return dflt; }
  }
  function save(key, val) {
    try { window.localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* storage full or unavailable */ }
  }
  function highlight(text, idx) {
    if (!idx || !idx.length) { return esc(text); }
    var set = {}, i, out = '', open = false;
    for (i = 0; i < idx.length; i++) { set[idx[i]] = true; }
    for (i = 0; i < text.length; i++) {
      var on = !!set[i];
      if (on && !open) { out += '<mark>'; open = true; }
      if (!on && open) { out += '</mark>'; open = false; }
      out += esc(text.charAt(i));
    }
    if (open) { out += '</mark>'; }
    return out;
  }

  // ------------------------------------------------------------------ items
  function buildItems() {
    var items = COMMANDS.slice(), i;
    for (i = 0; i < state.presets.length; i++) {
      var p = state.presets[i];
      var sum = P.summary(p);
      var kf = P.keyframeCount(p);
      items.push({
        id: p.id, name: p.name, kind: 'preset', ref: p,
        alt: (p.folder ? p.folder + ' ' : '') + sum,
        meta: (p.folder ? p.folder + ' · ' : '') + sum + (kf ? ' · ◆' + kf : '')
      });
    }
    var v = state.effects.video || [], a = state.effects.audio || [];
    for (i = 0; i < v.length; i++) { items.push({ id: 'v:' + v[i], name: v[i], kind: 'video', meta: T.videoFx }); }
    for (i = 0; i < a.length; i++) { items.push({ id: 'a:' + a[i], name: a[i], kind: 'audio', meta: T.audioFx }); }
    state.items = items;
  }

  // ------------------------------------------------------------------ render
  function rowHtml(r, i) {
    var it = r.item;
    var badge = (it.kind === 'command' && it.icon === 'zone') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 7h6M9 17h6"/></svg></span>'
      : it.kind === 'command' ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v10m0 0l-4-4m4 4l4-4M5 18h14"/></svg></span>'
      : it.kind === 'preset' ? '<span class="badge preset"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l2.7 5.6 6.1.8-4.5 4.3 1.1 6.1L12 16.9 6.6 19.8l1.1-6.1L3.2 9.4l6.1-.8z"/></svg></span>'
      : (it.kind === 'audio' ? '<span class="badge audio">AU</span>' : '<span class="badge video">FX</span>');
    return '<div class="row' + (i === state.active ? ' active' : '') + '" data-i="' + i + '" role="option">' +
      badge +
      '<span class="name">' + highlight(it.name, r.idx) + '</span>' +
      '<span class="meta">' + esc(it.meta || '') + '</span>' +
      '<span class="ret">↵</span>' +
      '</div>';
  }

  function render() {
    var q = $q.value;
    var html = [], rows = [], i;
    function section(label) { html.push('<div class="section">' + esc(label) + '</div>'); }
    function push(r) { html.push(rowHtml(r, rows.length)); rows.push(r); }

    var hasFx = false;
    for (i = 0; i < state.items.length; i++) { if (state.items[i].kind !== 'command') { hasFx = true; break; } }

    if (!S.cleanQuery(q)) {
      if (!hasFx) {
        html.push('<div class="empty">' + (!state.loaded ? T.loading
          : (state.lastError ? errorText(state.lastError) : T.errors.noQE)) + '</div>');
      }
      var plain = [];
      for (i = 0; i < state.items.length; i++) { if (state.items[i].kind !== 'command') { plain.push(state.items[i]); } }
      var rec = S.recents(plain, state.usage, 6);
      var shown = {};
      if (rec.length) {
        section(T.recent);
        for (i = 0; i < rec.length; i++) { push(rec[i]); shown[rec[i].item.id] = true; }
      }
      var presetRows = [], fxRows = [];
      for (i = 0; i < state.items.length; i++) {
        var it = state.items[i];
        if (shown[it.id] || it.kind === 'command') { continue; }
        if (it.kind === 'preset') { presetRows.push({ item: it, idx: [] }); }
        else if (fxRows.length < EMPTY_EFFECT_LIMIT) { fxRows.push({ item: it, idx: [] }); }
      }
      if (presetRows.length) {
        section(T.myPresets + ' · ' + presetRows.length);
        for (i = 0; i < presetRows.length; i++) { push(presetRows[i]); }
      }
      if (fxRows.length) {
        section(T.effects);
        for (i = 0; i < fxRows.length; i++) { push(fxRows[i]); }
        html.push('<div class="more">' + esc(T.moreHint) + '</div>');
      }
    } else {
      var res = S.rank(state.items, q, state.usage, RESULT_LIMIT);
      if (!res.length) { html.push('<div class="empty">' + T.nothing(q) + '</div>'); }
      // Commands normally come after effects and presets, so Enter on a half-typed effect name can never
      // run one. They lead only when a command is clearly what was typed and no effect really matches.
      var cmds = [], plainRows = [], bestCmd = 0, bestPlain = 0;
      for (i = 0; i < res.length; i++) {
        if (res[i].item.kind === 'command') { cmds.push(res[i]); bestCmd = Math.max(bestCmd, res[i].score || 0); }
        else { plainRows.push(res[i]); bestPlain = Math.max(bestPlain, res[i].score || 0); }
      }
      var cmdsFirst = cmds.length && bestCmd >= 600 && bestPlain < 600;
      if (cmdsFirst) { for (i = 0; i < cmds.length; i++) { push(cmds[i]); } }
      for (i = 0; i < plainRows.length; i++) { push(plainRows[i]); }
      if (cmds.length && !cmdsFirst) {
        if (rows.length) { section(T.commands); }
        for (i = 0; i < cmds.length; i++) { push(cmds[i]); }
      }
    }

    state.rows = rows;
    if (state.active >= rows.length) { state.active = rows.length ? rows.length - 1 : 0; }
    $list.innerHTML = html.join('');
    scrollActiveIntoView();
  }

  function setActive(i) {
    if (!state.rows.length) { return; }
    var n = state.rows.length;
    i = Math.max(0, Math.min(n - 1, i));
    if (i === state.active) { return; }
    var prev = $list.querySelector('.row.active');
    if (prev) { prev.classList.remove('active'); }
    state.active = i;
    var el = $list.querySelector('.row[data-i="' + i + '"]');
    if (el) { el.classList.add('active'); }
    scrollActiveIntoView();
  }

  function scrollActiveIntoView() {
    var el = $list.querySelector('.row.active');
    if (!el) { return; }
    var top = el.offsetTop, bottom = top + el.offsetHeight;
    var prevSection = el.previousElementSibling;
    if (state.active === 0) { $list.scrollTop = 0; return; }
    if (prevSection && prevSection.classList.contains('section')) { top = prevSection.offsetTop; }
    if (top < $list.scrollTop) { $list.scrollTop = top - 6; }
    else if (bottom > $list.scrollTop + $list.clientHeight) { $list.scrollTop = bottom - $list.clientHeight + 6; }
  }

  // ------------------------------------------------------------------ selection status
  function setSelection(d) {
    var cls = 'sel', text;
    if (!d || !d.hasSequence) { cls += ' none'; text = T.noSeq; }
    else if (!d.video && !d.audio) { cls += ' none'; text = T.noSel; }
    else { cls += ' ok'; text = T.selected(d.video, d.audio); }
    $sel.className = cls;
    $sel.querySelector('.sel-text').textContent = text;
  }

  function refreshSelection() {
    return B.call('selection').then(function (r) { if (r && r.ok) { setSelection(r.data); } });
  }

  // ------------------------------------------------------------------ toast
  var toastTimer = null;
  function toast(kind, html, sub, ms) {
    var icon = kind === 'ok' ? '✓' : (kind === 'warn' ? '!' : '✕');
    $toast.className = 'toast ' + kind;
    $toast.innerHTML = '<span class="ti">' + icon + '</span><span>' + html +
      (sub ? '<span class="tsub">' + sub + '</span>' : '') + '</span>';
    $toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { $toast.hidden = true; }, ms || (kind === 'ok' ? 2200 : 5000));
  }

  function errorText(res) {
    var base = T.errors[res.code] || T.errors.exception;
    var extra = '';
    if (res.code === 'effectNotFound' || res.code === 'applyFailed') { extra = res.message ? ': ' + esc(res.message) : ''; }
    else if (res.code === 'exception' || res.code === 'hostError' || res.code === 'badReply') { extra = res.message ? '<span class="tsub">' + esc(res.message) + '</span>' : ''; }
    else if (res.code === 'presetFailed' && res.extra && res.extra.missing && res.extra.missing.length) {
      extra = '<span class="tsub">' + esc(T.missingFx(res.extra.missing)) + '</span>';
    }
    return base + extra;
  }

  // ------------------------------------------------------------------ busy / host
  function setBusy(on) { state.busy = on; $busy.hidden = !on; }

  function ensureHost() {
    return B.evalScript('typeof QuickFX').then(function (r) {
      if (r === 'object') { return true; }
      var path = B.extensionPath() + '/jsx/host.jsx';
      return B.evalScript('$.evalFile(' + JSON.stringify(path) + ')').then(function () { return true; });
    });
  }

  function choosePresetFile(files, appVersion) {
    if (!files || !files.length) { return null; }
    var major = String(appVersion || '').split('.')[0];
    var same = files.filter(function (f) { return String(f.version).split('.')[0] === major; });
    var pool = (same.length ? same : files).slice();
    pool.sort(function (a, b) { return (b.modified || 0) - (a.modified || 0); });
    return pool[0];
  }

  function loadPresets() {
    var f = choosePresetFile(state.info && state.info.presetFiles, state.info && state.info.appVersion);
    state.presetFile = f;
    state.presetError = null;
    if (!f) { state.presets = []; return; }
    var text = B.readTextFile(f.path);
    if (text == null) { state.presetError = 'cannot read ' + f.path; state.presets = []; return; }
    try {
      var res = P.parse(text);
      state.presets = res.presets;
      state.presetSkipped = res.skipped;
    } catch (e) {
      state.presetError = String(e && e.message || e);
      state.presets = [];
    }
  }

  function loadEverything(announce) {
    setBusy(true);
    return ensureHost()
      .then(function () { return Promise.all([B.call('info'), B.call('listEffects'), B.call('selection')]); })
      .then(function (r) {
        var info = r[0], fx = r[1], sel = r[2];
        if (info.ok) { state.info = info.data; } else { state.lastError = info; }
        if (fx.ok) {
          state.effects = fx.data;
          save(LS.effects, { at: Date.now(), app: state.info && state.info.appVersion, data: fx.data });
        } else { state.lastError = fx; }
        if (sel.ok) { setSelection(sel.data); }
        loadPresets();
        state.loaded = true;
        buildItems();
        render();
        updateMenuInfo();
        setBusy(false);
        if (announce) { toast('ok', T.refreshed((state.effects.video || []).length + (state.effects.audio || []).length, state.presets.length)); }
      })
      .catch(function (e) {
        setBusy(false);
        state.loaded = true;
        state.lastError = { code: 'exception', message: String(e && e.message || e) };
        render();
      });
  }

  // ------------------------------------------------------------------ apply
  function recordUsage(item) {
    var u = state.usage[item.id] || { count: 0, last: 0 };
    u.count += 1;
    u.last = Date.now();
    state.usage[item.id] = u;
    var keys = Object.keys(state.usage);
    if (keys.length > 600) {
      keys.sort(function (a, b) { return state.usage[a].last - state.usage[b].last; });
      for (var i = 0; i < keys.length - 500; i++) { delete state.usage[keys[i]]; }
    }
    save(LS.usage, state.usage);
  }

  function apply(row, keepOpen) {
    if (!row || state.busy) { return; }
    var item = row.item;
    if (item.kind === 'command') { item.run(); return; }
    setBusy(true);
    var call = item.kind === 'preset'
      ? B.call('applyPreset', { preset: P.compact(item.ref) })
      : B.call('applyEffect', { kind: item.kind, name: item.name });

    call.then(function (res) {
      setBusy(false);
      state.lastResult = { item: item.id, res: res, at: new Date().toISOString() };
      if (!res || !res.ok) {
        state.lastError = res;
        toast('err', errorText(res || { code: 'hostError' }));
        return;
      }
      recordUsage(item);
      var d = res.data, sub = [], kind = 'ok', msg;
      if (item.kind === 'preset') {
        msg = T.appliedPreset(item.name, d.clips);
        if (d.missing && d.missing.length) { sub.push(esc(T.missingFx(d.missing))); kind = 'warn'; }
        if (d.paramsSkipped) { sub.push(esc(T.skippedParams(d.paramsSkipped))); kind = 'warn'; }
        if (d.clips < d.total) { sub.push(esc(T.failedSome(d.total - d.clips))); kind = 'warn'; }
      } else {
        msg = T.appliedFx(item.name, d.applied);
        if (d.failed) { sub.push(esc(T.failedSome(d.failed))); kind = 'warn'; }
      }
      toast(kind, msg, sub.join('<br>'), kind === 'ok' ? 1600 : 4500);

      if (MODE === 'popup' && !keepOpen) {
        setTimeout(function () { B.close(); }, kind === 'ok' ? 380 : 2600);
      } else {
        refreshSelection();
        $q.focus();
        $q.select();
      }
    });
  }

  // ------------------------------------------------------------------ collect files
  var C = window.QFXCollect;
  var CAT_LABEL = { Video: 'Video', Audio: 'Audio', Music: 'Music', Images: 'Images', Other: 'Other' };
  var collect = { phase: 'idle' };

  function nodeFs() {
    try {
      var req = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
      return req ? req('fs') : null;
    } catch (e) { return null; }
  }

  function keysHtml(pairs) {
    var out = '';
    for (var i = 0; i < pairs.length; i++) { out += '<span><kbd>' + pairs[i][0] + '</kbd> ' + esc(pairs[i][1]) + '</span>'; }
    return out;
  }

  // The Files tab: 'home' (auto switch, activity) → scan → ready → copy → done.
  function switchTab(tab) {
    if (collect.phase === 'copy') { return; }                 // a manual copy is running: stay on it
    if (!$tabs[tab]) { return; }
    state.view = VIEW_OF[tab];
    for (var t in $tabs) { if ($tabs.hasOwnProperty(t)) { $tabs[t].hidden = t !== tab; } }
    var btns = document.querySelectorAll('.rail-btn[data-tab]');
    for (var i = 0; i < btns.length; i++) { btns[i].classList.toggle('active', btns[i].getAttribute('data-tab') === tab); }
    openMenu(false, true);
    collect = { phase: tab === 'files' ? 'home' : 'idle' };
    if (tab !== 'fx' && document.activeElement && document.activeElement.blur) { document.activeElement.blur(); }
    if (tab === 'files') { renderCollect(); }
    else if (tab === 'zones') { renderZoneList(); renderZoneSide(); refreshZones(); }
    else { render(); refreshSelection(); $q.focus(); }
  }

  function openCollect() {
    if (state.view !== 'collect') { switchTab('files'); }
    collect = { phase: 'scan', scan: null, files: [], sum: null, done: 0, bytesDone: 0, bytesFile: 0, current: '',
      errors: [], copied: 0, reused: 0, relinked: 0, cancel: false, engine: null, error: null };
    renderCollect();
    B.call('scanMedia').then(function (r) {
      if (state.view !== 'collect' || collect.phase !== 'scan') { return; }
      if (!r || !r.ok) { collect.phase = 'error'; collect.error = r || { code: 'hostError' }; state.lastError = collect.error; renderCollect(); return; }
      var d = r.data;
      for (var i = 0; i < d.files.length; i++) { d.files[i].cat = C.categorize(d.files[i].name); }
      d.files.sort(function (a, b) { return (b.size || 0) - (a.size || 0); });
      collect.scan = d;
      collect.files = d.files;
      collect.sum = C.summarize(d.files);
      collect.phase = d.files.length ? 'ready' : 'empty';
      renderCollect();
    });
  }

  /** Phases where closing the window would lose what the user is doing. */
  function collectBusy() { return collect.phase === 'scan' || collect.phase === 'ready' || collect.phase === 'copy'; }

  function collectHome() {
    if (state.view !== 'collect') { return; }
    collect = { phase: 'home' };
    renderCollect();
  }

  // ---- Files tab, home screen
  function autoStatus() {
    var a = autoState(), cls = 'dock-status', text, tip = '', kind = 'off';
    if (!a.settings.auto) { text = T.auto.dockOff; }
    else if (!a.alive) {
      if (Date.now() - state.openedAt < 9000) { text = T.auto.dockStarting; kind = 'on'; }
      else { cls += ' err'; text = T.auto.dockDead; tip = T.auto.dockDeadTip; kind = 'err'; }
    } else if (a.state.queue) { cls += ' busy'; text = T.auto.copying(a.state.current || '…', a.state.queue); kind = 'busy'; }
    else { cls += ' on'; text = T.auto.dockOn; kind = 'on'; }
    return { cls: cls, text: text, tip: tip || text, kind: kind, auto: a };
  }

  function activityHtml(a) {
    var log = (a.state && a.state.log) || [], out = [], i;
    for (i = log.length - 1; i >= 0 && out.length < 8; i--) {
      var e = log[i];
      if (e.kind !== 'ok' && e.kind !== 'err') { continue; }
      var parts = String(e.text).split(' → ');
      var time = '';
      try { var d = new Date(e.t); if (!isNaN(d.getTime())) { time = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); } } catch (eT) { time = ''; }
      out.push('<div class="c-file"><span class="c-tag' + (e.kind === 'err' ? ' err' : ' okk') + '">' + (e.kind === 'err' ? '!' : '✓') + '</span>' +
        '<span class="c-name">' + esc(parts[0]) + '</span><span class="c-from">' + esc(parts.length > 1 ? '→ ' + parts.slice(1).join(' → ') : '') +
        '</span><span class="c-size">' + esc(time) + '</span></div>');
    }
    return out.length ? '<div class="c-files">' + out.join('') + '</div>' : '<div class="c-note">' + esc(T.auto.noActivity) + '</div>';
  }

  function homeHtml() {
    var s = autoStatus();
    return '<div class="f-card"><div class="f-main"><div class="f-title">' + esc(T.auto.title) + '</div>' +
      '<div class="f-desc">' + esc(T.auto.desc) + '</div>' +
      '<div id="fStatus" class="' + s.cls + '" title="' + esc(s.tip) + '"><i class="dot"></i><span class="dock-text">' + esc(s.text) + '</span></div></div>' +
      '<label class="switch"><input type="checkbox" id="autoCollect"' + (s.auto.settings.auto ? ' checked' : '') + '><i></i></label></div>' +
      '<div class="f-card"><div class="f-main"><div class="f-title">' + esc(T.auto.manualTitle) + '</div>' +
      '<div class="f-desc">' + esc(T.auto.manualDesc) + '</div></div>' +
      '<button class="c-btn primary" data-cact="scan">' + esc(T.auto.manualBtn) + ' <kbd>↵</kbd></button></div>' +
      '<div class="f-section">' + esc(T.auto.activity) + '</div><div id="fLog">' + activityHtml(s.auto) + '</div>';
  }

  /** Every 2 s: the dot on the rail button, and (on the Files home screen) status + activity. */
  function updateAuto() {
    var s = autoStatus();
    $railDot.className = 'rail-dot ' + s.kind;
    if (state.view === 'collect' && collect.phase === 'home') {
      var el = $('fStatus'), lg = $('fLog');
      if (el) { el.className = s.cls; el.title = s.tip; el.querySelector('.dock-text').textContent = s.text; }
      if (lg) { var html = activityHtml(s.auto); if (lg.innerHTML !== html) { lg.innerHTML = html; } }
    }
  }

  function skippedHtml(list) {
    if (!list || !list.length) { return ''; }
    var by = {}, i, out = [];
    for (i = 0; i < list.length; i++) { by[list[i].reason] = (by[list[i].reason] || 0) + 1; }
    for (var k in by) { if (by.hasOwnProperty(k)) { out.push(by[k] + ' — ' + (T.c.skip[k] || k)); } }
    return '<div class="c-note">' + esc(T.c.skipped) + ' ' + esc(out.join(' · ')) + '</div>';
  }

  function renderCollect() {
    var c = collect, h = [], i;
    var locked = c.phase === 'copy';
    var rb = document.querySelectorAll('.rail-btn[data-tab]');
    for (i = 0; i < rb.length; i++) { rb[i].disabled = locked; }
    if (c.phase === 'home') {
      h.push(homeHtml());
      $fkeys.innerHTML = keysHtml([['↵', T.auto.manualBtn], ['esc', T.auto.toFx]]);
    } else if (c.phase === 'scan') {
      h.push('<div class="empty">' + esc(T.c.scanning) + '</div>');
      $fkeys.innerHTML = keysHtml([['esc', T.c.back]]);
    } else if (c.phase === 'error') {
      h.push('<div class="empty">' + errorText(c.error) + '</div>');
      $fkeys.innerHTML = keysHtml([['esc', T.c.back]]);
    } else if (c.phase === 'empty') {
      h.push('<div class="c-head"><div class="c-big">' + esc(T.c.allInside) + '</div>' +
        '<div class="c-sub">' + esc(T.c.checked(c.scan.total)) + '</div></div>' + skippedHtml(c.scan.skipped));
      $fkeys.innerHTML = keysHtml([['esc', T.c.back]]);
    } else if (c.phase === 'ready') {
      h.push('<div class="c-head"><div class="c-big">' + esc(T.c.found(c.sum.count, C.formatBytes(c.sum.bytes))) + '</div>' +
        '<div class="c-sub">' + esc(T.c.willCopy) + ' <span class="c-path">' + esc(c.scan.importedDir) + '</span></div></div>');
      h.push('<div class="c-cats">');
      for (i = 0; i < C.CATEGORIES.length; i++) {
        var cat = C.CATEGORIES[i], s = c.sum.byCat[cat];
        if (s.count) { h.push('<span class="c-cat"><b>' + CAT_LABEL[cat] + '</b> ' + s.count + ' · ' + C.formatBytes(s.bytes) + '</span>'); }
      }
      h.push('</div>' + skippedHtml(c.scan.skipped));
      h.push('<div class="c-actions"><button class="c-btn primary" data-cact="start">' + esc(T.c.copy) + ' <kbd>↵</kbd></button>' +
        '<button class="c-btn" data-cact="back">' + esc(T.c.back) + '</button></div>');
      h.push('<div class="c-files">');
      for (i = 0; i < c.files.length && i < 200; i++) {
        var f = c.files[i];
        h.push('<div class="c-file"><span class="c-tag">' + CAT_LABEL[f.cat] + '</span><span class="c-name">' + esc(f.name) +
          '</span><span class="c-from">' + esc(C.dirName(f.path)) + '</span><span class="c-size">' + C.formatBytes(f.size) + '</span></div>');
      }
      h.push('</div>');
      $fkeys.innerHTML = keysHtml([['↵', T.c.copy], ['esc', T.c.back]]);
    } else if (c.phase === 'copy') {
      h.push('<div class="c-head"><div class="c-big" id="cCount">' + c.done + ' / ' + c.files.length + '</div>' +
        '<div class="c-sub" id="cCurrent">' + esc(c.current) + '</div></div>' +
        '<div class="c-bar"><div class="c-fill" id="cFill"></div></div>' +
        '<div class="c-sub" id="cBytes"></div>' +
        '<div class="c-note">' + esc(c.engine === 'node' ? T.c.keepWorking : T.c.mayFreeze) + '</div>' +
        '<div class="c-actions"><button class="c-btn" data-cact="stop">' + esc(c.cancel ? T.c.stopping : T.c.stop) + '</button></div>');
      $fkeys.innerHTML = keysHtml([['esc', T.c.stop]]);
    } else if (c.phase === 'done') {
      var bad = c.errors.length;
      h.push('<div class="c-head"><div class="c-big">' + esc(bad ? T.c.doneWithErrors : T.c.done) + '</div>' +
        '<div class="c-sub">' + esc(T.c.result(c.copied, c.reused, c.relinked)) + '</div></div>');
      if (c.cancel && c.done < c.files.length) { h.push('<div class="c-note">' + esc(T.c.stoppedAt(c.done, c.files.length)) + '</div>'); }
      h.push('<div class="c-note strong">' + esc(T.c.saveHint) + '</div>');
      h.push('<div class="c-actions"><button class="c-btn primary" data-cact="close">' + esc(T.c.close) + ' <kbd>↵</kbd></button></div>');
      if (bad) {
        h.push('<div class="c-files">');
        for (i = 0; i < c.errors.length; i++) {
          h.push('<div class="c-file"><span class="c-tag err">!</span><span class="c-name">' + esc(c.errors[i].name) +
            '</span><span class="c-from">' + esc(T.c.errReason[c.errors[i].reason] || c.errors[i].reason) + '</span></div>');
        }
        h.push('</div>');
      }
      $fkeys.innerHTML = keysHtml([['↵', T.c.close]]);
    }
    $files.innerHTML = h.join('');
    $files.scrollTop = 0;
    if (c.phase === 'copy') { updateCollectProgress(); }
  }

  function updateCollectProgress() {
    var c = collect;
    var fill = $('cFill'), bytes = $('cBytes');
    if (!fill || !c.sum) { return; }
    var done = c.bytesDone + c.bytesFile, total = c.sum.bytes || 1;
    fill.style.width = Math.max(0, Math.min(100, done / total * 100)).toFixed(1) + '%';
    bytes.textContent = C.formatBytes(done) + ' / ' + C.formatBytes(c.sum.bytes);
  }

  function startCopy() {
    var c = collect;
    if (c.phase !== 'ready') { return; }
    var fs = nodeFs();
    var copier = fs ? C.createCopier(fs) : null;
    var finder = fs ? C.createFinder(fs) : null;
    c.engine = copier ? 'node' : 'host';
    c.phase = 'copy';
    setBusy(true);
    var i = 0;

    function finish() {
      setBusy(false);
      c.phase = 'done';
      state.lastResult = { item: 'c:collect', at: new Date().toISOString(),
        res: { engine: c.engine, files: c.files.length, copied: c.copied, reused: c.reused, relinked: c.relinked, errors: c.errors } };
      if (state.view === 'collect') { renderCollect(); }
    }

    function next() {
      if (c.cancel || i >= c.files.length) { finish(); return; }
      var f = c.files[i++];
      c.current = f.name;
      c.bytesFile = 0;
      renderCollect();
      var dir = C.join(c.scan.importedDir, f.cat);
      var existing = null;
      try { existing = finder ? finder.find(c.scan.projectDir, f.name, f.size) : null; } catch (eFind) { existing = null; }
      var job = existing ? Promise.resolve({ to: existing, reused: true, bytes: 0 }) : copier
        ? copier.copyInto(f.path, dir, f.name, function (doneBytes) { c.bytesFile = doneBytes; updateCollectProgress(); })
        : B.call('copyInto', { from: f.path, dir: dir, name: f.name }).then(function (r) {
            if (!r || !r.ok) { throw new Error((r && r.code) || 'copyFailed'); }
            return r.data;
          });
      job.then(function (res) {
        if (finder && !res.reused) { finder.add(c.scan.projectDir, res.to); }
        return B.call('relinkMedia', { pairs: [{ from: f.path, to: res.to }] }).then(function (rr) {
          if (res.reused) { c.reused++; } else { c.copied++; }
          if (rr && rr.ok && rr.data.relinked && !rr.data.failed) { c.relinked += rr.data.relinked; }
          else { c.errors.push({ name: f.name, reason: 'relink' }); }
        });
      }).catch(function (e) {
        c.errors.push({ name: f.name, reason: String((e && (e.code || e.message)) || e) });
      }).then(function () {
        c.done++;
        c.bytesDone += f.size || 0;
        c.bytesFile = 0;
        next();
      });
    }
    next();
  }

  function collectAction(act) {
    var c = collect;
    if (act === 'scan') { if (c.phase === 'home') { openCollect(); } }
    else if (act === 'start') { startCopy(); }
    else if (act === 'stop') { if (c.phase === 'copy' && !c.cancel) { c.cancel = true; renderCollect(); } }
    else if (act === 'close') { if (MODE === 'popup') { B.close(); } else { collectHome(); } }
    else if (act === 'back') { if (c.phase !== 'copy') { collectHome(); } }
  }

  function collectKey(e) {
    var c = collect;
    if (e.key === 'Enter') {
      e.preventDefault();
      if (c.phase === 'home') { collectAction('scan'); }
      else if (c.phase === 'ready') { collectAction('start'); }
      else if (c.phase === 'done') { collectAction('close'); }
      else if (c.phase === 'empty' || c.phase === 'error') { collectAction('back'); }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false, true); }
      else if (c.phase === 'home') { switchTab('fx'); }
      else if (c.phase === 'copy') { collectAction('stop'); }
      else if (c.phase === 'done') { collectAction('close'); }
      else { collectAction('back'); }
    }
  }

  /** ⌘1 / ⌘2 switch tools from anywhere. */
  function tabKey(e) {
    if (!(e.metaKey || e.ctrlKey) || e.altKey) { return false; }
    if (e.key === '1') { e.preventDefault(); switchTab('fx'); return true; }
    if (e.key === '2') { e.preventDefault(); switchTab('files'); return true; }
    if (e.key === '3') { e.preventDefault(); switchTab('zones'); return true; }
    return false;
  }

  var COMMANDS = [
    { id: 'c:collect', name: 'ფაილების შეგროვება', kind: 'command', run: openCollect,
      alt: 'collect files imported copy media consolidate gather ფაილები კოპირება იმპორტი პროექტის საქაღალდე',
      meta: 'გარე ფაილები → Imported' }
  ];

  // ------------------------------------------------------------------ safe zones
  var Z = window.QFXZones;
  var ZONE_SECONDS = 10, ZONE_REV = 'v2';                     // bump ZONE_REV when the drawings change: old PNGs are then left alone
  var $zList = $('zList'), $zPreview = $('zPreview'), $zInfo = $('zInfo'), $zStatus = $('zStatus'), $zHint = $('zHint');
  var $zApply = $('zApply'), $zToggle = $('zToggle'), $zRemove = $('zRemove'), $railDotZ = $('railDotZ');
  var zones = { active: 0, state: null, busy: false };

  function zoneFrame(p) {
    var s = zones.state;
    return (s && s.hasSequence && s.width > 0 && s.height > 0) ? [s.width, s.height] : p.base.slice();
  }

  function renderZoneList() {
    var h = [], group = '';
    for (var i = 0; i < Z.PLATFORMS.length; i++) {
      var p = Z.PLATFORMS[i];
      if (p.group !== group) { group = p.group; h.push('<div class="section">' + esc(group === 'v' ? T.z.vertical : T.z.horizontal) + '</div>'); }
      h.push('<div class="row' + (i === zones.active ? ' active' : '') + '" data-z="' + i + '" role="option">' +
        '<span class="badge z-badge"><i class="' + (p.group === 'v' ? 'tall' : 'wide') + (p.id === 'all' ? ' dash' : '') + '"></i></span>' +
        '<span class="name">' + esc(p.name) + '</span>' +
        '<span class="meta">' + esc(p.note || (p.base[0] + ' × ' + p.base[1])) + '</span>' +
        '<span class="ret">↵</span></div>');
    }
    $zList.innerHTML = h.join('');
  }

  function renderZoneSide() {
    var p = Z.PLATFORMS[zones.active], fr = zoneFrame(p), s = zones.state;
    // preview: the sequence's own shape, fitted into the side column
    var maxW = MODE === 'panel' ? 110 : 204, maxH = MODE === 'panel' ? 150 : 178;
    var k = Math.min(maxW / fr[0], maxH / fr[1]);
    var cw = Math.max(40, Math.round(fr[0] * k)), ch = Math.max(40, Math.round(fr[1] * k)), dpr = 2;
    $zPreview.width = cw * dpr; $zPreview.height = ch * dpr;
    $zPreview.style.width = cw + 'px'; $zPreview.style.height = ch + 'px';
    var ctx = $zPreview.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(cw * dpr / fr[0], ch * dpr / fr[1]);
    Z.draw(ctx, p.id, fr[0], fr[1], { background: '#2E3238' });

    var info;
    if (!s || !s.hasSequence) { info = T.z.noSeq; }
    else if (s.under) { info = T.z.willSwap((Z.get(s.under) || { name: s.under }).name); }
    else { info = T.z.willPlace(ZONE_SECONDS); }
    $zInfo.textContent = info;

    var vis = s ? s.visible : 0, hid = s ? s.hidden : 0;
    $zToggle.textContent = (vis || !hid) ? T.z.hide : T.z.show;
    $zToggle.disabled = !(vis || hid);
    $zRemove.disabled = !(vis || hid);
    $zApply.disabled = !(s && s.hasSequence);
    $zStatus.className = 'z-status' + (vis ? ' on' : '');
    $zStatus.textContent = vis ? T.z.visible(vis) : (hid ? T.z.hidden(hid) : (s && s.hasSequence ? T.z.seqSize(s.width, s.height) : ''));
    $zHint.textContent = vis ? T.z.exportHint : '';
    updateZoneDot();
  }

  function updateZoneDot() {
    var vis = zones.state ? zones.state.visible : 0;
    $railDotZ.hidden = !vis;
    $railDotZ.className = 'rail-dot on';
  }

  function refreshZones() {
    return B.call('zoneState').then(function (r) {
      zones.state = (r && r.ok) ? r.data : null;
      if (state.view === 'zones') { renderZoneSide(); } else { updateZoneDot(); }
      return zones.state;
    });
  }

  function setZoneActive(i) {
    var n = Z.PLATFORMS.length;
    zones.active = (i + n) % n;
    renderZoneList();
    renderZoneSide();
    var el = $zList.querySelector('.row.active');
    if (el && el.scrollIntoView) { el.scrollIntoView({ block: 'nearest' }); }
  }

  /** Draw the overlay at the sequence's frame size and save it as a PNG next to the project. */
  function zoneFile(p, W, H) {
    var s = zones.state || {};
    var dir = s.projectDir ? s.projectDir + '/Quick FX/Safe Zones' : (Store.dir() ? Store.dir() + '/zones' : '');
    if (!dir) { return null; }
    var path = dir + '/' + Z.fileName(p.id, W, H).replace(/\.png$/, '-' + ZONE_REV + '.png');
    if (B.fileExists(path)) { return path; }
    var c = document.createElement('canvas');
    c.width = W; c.height = H;
    Z.draw(c.getContext('2d'), p.id, W, H, {});
    var b64 = c.toDataURL('image/png').split(',')[1];
    B.makeDirs(dir);
    return B.writeBase64File(path, b64) ? path : null;
  }

  function applyZone(id, fromSearch) {
    var p = Z.get(id);
    if (!p || zones.busy || state.busy) { return; }
    zones.busy = true;
    setBusy(true);
    refreshZones().then(function (s) {
      if (!s || !s.hasSequence) { return { ok: false, code: 'noSequence' }; }
      var path = zoneFile(p, s.width, s.height);
      if (!path) { return { ok: false, code: 'zoneWriteFailed' }; }
      return B.call('zoneApply', { path: path, id: p.id, seconds: ZONE_SECONDS });
    }).then(function (res) {
      zones.busy = false;
      setBusy(false);
      state.lastResult = { item: 'zone:' + id, at: new Date().toISOString(), res: res };
      if (!res || !res.ok) { state.lastError = res; toast('err', errorText(res)); return refreshZones(); }
      var d = res.data, secs = Math.round(d.seconds * 10) / 10;
      toast('ok', d.replaced ? T.z.swapped(p.name) : T.z.placed(p.name, secs),
        (d.addedTrack ? T.z.newTrack + ' ' : '') + (d.exact ? '' : T.z.notExact), 2600);
      if (MODE === 'popup' && d.exact) { setTimeout(function () { B.close(); }, 700); }
      return refreshZones();
    });
  }

  function zoneToggle() {
    var s = zones.state;
    if (!s || !(s.visible || s.hidden)) { return; }
    var hide = s.visible > 0;
    B.call('zoneToggle', { hidden: hide }).then(function (r) {
      if (!r || !r.ok) { state.lastError = r; toast('err', errorText(r)); }
      else { toast('ok', hide ? T.z.nowHidden(r.data.count) : T.z.nowShown(r.data.count)); }
      refreshZones();
    });
  }

  function zoneRemove() {
    B.call('zoneRemoveAll').then(function (r) {
      if (!r || !r.ok) { state.lastError = r; toast('err', errorText(r)); }
      else { toast('ok', T.z.removed(r.data.removed)); }
      refreshZones();
    });
  }

  function zonesKey(e) {
    var k = e.key;
    if (k === 'ArrowDown') { e.preventDefault(); setZoneActive(zones.active + 1); }
    else if (k === 'ArrowUp') { e.preventDefault(); setZoneActive(zones.active - 1); }
    else if (k === 'Enter') { e.preventDefault(); applyZone(Z.PLATFORMS[zones.active].id); }
    else if (k === 'Escape') { e.preventDefault(); if (!$menu.hidden) { openMenu(false, true); } else { switchTab('fx'); } }
  }

  $zList.addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.row[data-z]') : null;
    if (!row) { return; }
    var i = Number(row.getAttribute('data-z'));
    if (i === zones.active && e.detail >= 2) { applyZone(Z.PLATFORMS[i].id); return; }
    setZoneActive(i);
  });
  $zApply.addEventListener('click', function () { applyZone(Z.PLATFORMS[zones.active].id); });
  $zToggle.addEventListener('click', zoneToggle);
  $zRemove.addEventListener('click', zoneRemove);

  // also reachable from the search box: "tiktok", "safe", "ზონ" …
  (function () {
    function runner(id) { return function () { applyZone(id, true); }; }
    for (var i = 0; i < Z.PLATFORMS.length; i++) {
      var p = Z.PLATFORMS[i];
      COMMANDS.push({ id: 'c:zone:' + p.id, name: p.group === 'h' ? p.name : 'Safe Zone — ' + p.name, kind: 'command', icon: 'zone', run: runner(p.id),
        alt: 'safe zone safezone ზონა ზონები უსაფრთხო ' + p.alt, meta: T.z.cmdMeta(ZONE_SECONDS) });
    }
    COMMANDS.push({ id: 'c:zone:toggle', name: T.z.cmdToggle, kind: 'command', icon: 'zone',
      run: function () { refreshZones().then(zoneToggle); },
      alt: 'safe zone hide show ზონა ზონები დამალვა ჩვენება ექსპორტი export', meta: 'Safe Zones' });
  })();


  // ------------------------------------------------------------------ background watcher
  function autoState() {
    var a = Store.read('auto-state.json', null);
    return { settings: Store.settings(), state: a, alive: !!(a && a.alive && Date.now() - a.alive < 15000) };
  }

  /** The watcher normally starts with Premiere; if it is not running, opening Quick FX starts it. */
  function wakeWatcher() {
    if (!B.available) { return; }
    var a = autoState();
    if (a.settings.auto && !a.alive) { B.openExtension(AUTO_ID); }
  }

  function autoInfoHtml() {
    var a = autoState();
    if (!a.settings.auto) { return esc(T.auto.off); }
    if (!a.alive) { return '<span style="color:var(--err)">' + esc(T.auto.dead) + '</span>'; }
    var out = esc(T.auto.on), st = a.state, i;
    if (st.queue) { out += '<br>' + esc(T.auto.copying(st.current || '…', st.queue)); }
    for (i = (st.log || []).length - 1; i >= 0; i--) {
      if (st.log[i].kind === 'ok' || st.log[i].kind === 'err') {
        out += '<br>' + esc(T.auto.last) + ' ' + (st.log[i].kind === 'err' ? '✕ ' : '') + esc(st.log[i].text);
        break;
      }
    }
    return out;
  }

  // ------------------------------------------------------------------ menu
  function updateMenuInfo() {
    var fxCount = (state.effects.video || []).length + (state.effects.audio || []).length;
    var lines = [];
    lines.push('ეფექტები: ' + fxCount + ' · პრესეტები: ' + state.presets.length);
    if (state.presetFile) { lines.push('პრესეტების ფაილი: ' + esc(state.presetFile.path)); }
    else { lines.push('პრესეტების ფაილი ვერ მოიძებნა'); }
    if (state.presetError) { lines.push('<span style="color:var(--err)">' + esc(state.presetError) + '</span>'); }
    lines.push(autoInfoHtml());
    if (state.info) { lines.push('Premiere ' + esc(state.info.appVersion) + ' · Quick FX ' + VERSION); }
    $menuInfo.innerHTML = lines.join('<br>');
  }

  function openMenu(open, keepFocus) {
    $menu.hidden = !open;
    $menuBtn.classList.toggle('open', open);
    if (open) { updateMenuInfo(); }
    else if (!keepFocus && state.view === 'list') { $q.focus(); }
  }

  function copyDiagnostics() {
    var d = {
      quickfx: VERSION, mode: MODE, extensionId: extId,
      info: state.info,
      effects: { video: (state.effects.video || []).length, audio: (state.effects.audio || []).length },
      presetFile: state.presetFile, presets: state.presets.length,
      presetSkipped: state.presetSkipped.length, presetError: state.presetError,
      lastError: state.lastError, lastResult: state.lastResult,
      collect: { phase: collect.phase, engine: collect.engine || null, node: !!nodeFs() },
      auto: autoState(),
      zones: zones.state,
      userAgent: navigator.userAgent
    };
    var ta = document.createElement('textarea');
    ta.value = JSON.stringify(d, null, 2);
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { /* ignore */ }
    document.body.removeChild(ta);
    openMenu(false);
    toast('ok', T.diagCopied);
  }

  // ------------------------------------------------------------------ events
  $q.addEventListener('input', function () { state.active = 0; render(); });

  $q.addEventListener('keydown', function (e) {
    if (e.isComposing) { return; }
    if (tabKey(e)) { return; }
    var k = e.key;
    if (k === 'ArrowDown' || (e.ctrlKey && (k === 'n' || k === 'j'))) { setActive(state.active + 1); e.preventDefault(); }
    else if (k === 'ArrowUp' || (e.ctrlKey && (k === 'p' || k === 'k'))) { setActive(state.active - 1); e.preventDefault(); }
    else if (k === 'PageDown') { setActive(state.active + 8); e.preventDefault(); }
    else if (k === 'PageUp') { setActive(state.active - 8); e.preventDefault(); }
    else if (k === 'Tab') { setActive(state.active + (e.shiftKey ? -1 : 1)); e.preventDefault(); }
    else if (k === 'Enter') { apply(state.rows[state.active], e.shiftKey || MODE === 'panel'); e.preventDefault(); }
    else if (k === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false); }
      else if ($q.value) { $q.value = ''; state.active = 0; render(); }
      else if (MODE === 'popup') { B.close(); }
    }
    else if ((e.metaKey || e.ctrlKey) && (k === 'r' || k === 'R')) { e.preventDefault(); loadEverything(true); }
  });

  // typing anywhere goes to the search field
  document.addEventListener('keydown', function (e) {
    if (document.activeElement !== $q && tabKey(e)) { return; }
    if (state.view === 'collect') { collectKey(e); return; }
    if (state.view === 'zones') { zonesKey(e); return; }
    if (document.activeElement === $q || e.metaKey || e.ctrlKey || e.altKey) { return; }
    if (e.key === 'Escape') { if (!$menu.hidden) { openMenu(false); } else if (MODE === 'popup') { B.close(); } return; }
    if (e.key && e.key.length === 1) { $q.focus(); }
  });

  var lastMouse = { x: -1, y: -1 };
  $list.addEventListener('mousemove', function (e) {
    if (e.clientX === lastMouse.x && e.clientY === lastMouse.y) { return; }
    lastMouse = { x: e.clientX, y: e.clientY };
    var row = e.target.closest ? e.target.closest('.row') : null;
    if (row) { setActive(Number(row.getAttribute('data-i'))); }
  });
  $list.addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.row') : null;
    if (!row) { return; }
    var i = Number(row.getAttribute('data-i'));
    state.active = i;
    apply(state.rows[i], e.shiftKey || MODE === 'panel');
  });

  $menuBtn.addEventListener('click', function () { openMenu($menu.hidden); });
  $menu.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button[data-act]') : null;
    if (!b) { return; }
    var act = b.getAttribute('data-act');
    if (act === 'refresh') { openMenu(false); loadEverything(true); }
    if (act === 'diag') { copyDiagnostics(); }
  });
  $files.addEventListener('click', function (e) {
    var cb = e.target.closest ? e.target.closest('[data-cact]') : null;
    if (cb) { collectAction(cb.getAttribute('data-cact')); }
  });
  $files.addEventListener('change', function (e) {
    if (!e.target || e.target.id !== 'autoCollect') { return; }
    Store.write('settings.json', { auto: e.target.checked });
    if (e.target.checked) { state.openedAt = Date.now(); wakeWatcher(); }
    updateAuto();
  });
  $('rail').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('.rail-btn[data-tab]') : null;
    if (b && !b.disabled) { switchTab(b.getAttribute('data-tab')); }
  });
  $closeOnBlur.checked = !!state.settings.closeOnBlur;
  $closeOnBlur.addEventListener('change', function () {
    state.settings.closeOnBlur = $closeOnBlur.checked;
    save(LS.settings, state.settings);
  });
  document.addEventListener('mousedown', function (e) {
    if (!$menu.hidden && !$menu.contains(e.target) && !$menuBtn.contains(e.target)) { openMenu(false); }
  });

  window.addEventListener('focus', function () {
    state.hadFocus = true;
    if (state.view !== 'list') { return; }
    if ($menu.hidden) { $q.focus(); }
    refreshSelection();
  });

  window.addEventListener('blur', function () {
    if (MODE !== 'popup' || !state.settings.closeOnBlur || !state.hadFocus || state.busy || collectBusy()) { return; }
    if (Date.now() - state.openedAt < 900) { return; }
    setTimeout(function () {
      if (!document.hasFocus() && !state.busy && !collectBusy()) { B.close(); }
    }, 200);
  });

  // ------------------------------------------------------------------ init
  function init() {
    document.documentElement.classList.add('mode-' + MODE);
    if (MODE === 'panel') {
      $blurOpt.hidden = true;
    }
    B.registerKeys();

    // instant results from the last session while Premiere answers
    var cached = load(LS.effects, null);
    if (cached && cached.data) { state.effects = cached.data; buildItems(); }
    render();
    switchTab('fx');
    updateAuto();
    $q.focus();
    setTimeout(function () { if (state.view === 'list') { $q.focus(); } }, 60);

    if (!B.available) { state.loaded = true; render(); return; }
    loadEverything(false);
    setTimeout(wakeWatcher, 1500);
    setTimeout(refreshZones, 900);
    setInterval(function () { if (!document.hidden) { updateAuto(); } }, 2000);
    setInterval(function () { if (!document.hidden && state.view === 'zones' && !zones.busy) { refreshZones(); } }, 2500);
    if (MODE === 'panel') {
      setInterval(function () { if (!document.hidden && !state.busy && state.view === 'list') { refreshSelection(); } }, 2500);
    }
  }

  // exposed for tests / debugging
  window.QuickFXUI = { state: state, render: render, apply: apply, loadEverything: loadEverything, mode: MODE };

  init();
})();
