/*
 * Quick FX — panel UI.
 * Popup mode (Modeless window): type, Enter, it applies and closes.
 * Panel mode (docked): stays open.
 */
(function () {
  'use strict';

  var B = window.QFXBridge, S = window.QFXSearch, P = window.QFXPresets, Store = window.QFXStore;
  var AUTO_ID = 'com.goga.quickfx.auto';
  var VERSION = '1.15.0';
  var extId = B.extensionId();
  var MODE = /\.panel$/.test(extId) ? 'panel' : 'popup';
  var LS = { usage: 'qfx.usage.v1', effects: 'qfx.effects.v1', settings: 'qfx.settings.v1', favs: 'qfx.favs.v1' };
  var RESULT_LIMIT = 80;
  var EMPTY_EFFECT_LIMIT = 120;

  var T = {
    videoFx: 'ვიდეო ეფექტი',
    audioFx: 'აუდიო ეფექტი',
    preset: 'პრესეტი',
    recent: 'ბოლოს გამოყენებული',
    favs: 'რჩეულები', favTip: 'რჩეული  ⌘D', favOn: function (name) { return '★ რჩეულებში: <b>' + esc(name) + '</b>'; }, favOff: function (name) { return 'რჩეულებიდან ამოვიდა: <b>' + esc(name) + '</b>'; },
    myPresets: 'ჩემი პრესეტები',
    effects: 'ეფექტები',
    loading: 'იტვირთება…',
    nothing: function (q) { return 'ვერაფერი მოიძებნა: <strong>' + esc(q) + '</strong>'; },
    moreHint: 'აკრიფე სახელი, რომ ყველა ეფექტში მოძებნო…',
    noSeq: 'სექვენსი არ არის გახსნილი',
    noSel: 'კლიპი არ არის მონიშნული',
    selected: function (v, a) {
      var parts = [];
      if (v) { parts.push(v + ' ვიდეო'); }
      if (a) { parts.push(a + ' აუდიო'); }
      return parts.join(' · ') + ' მონიშნულია';
    },
    appliedFx: function (name, n) { return '<b>' + esc(name) + '</b> დაედო ' + n + ' კლიპს'; },
    appliedPreset: function (name, n) { return '«' + esc(name) + '» დაედო ' + n + ' კლიპს'; },
    failedSome: function (n) { return n + ' კლიპზე ვერ დაედო'; },
    skippedParams: function (n) { return n + ' პარამეტრი ვერ გადმოვიდა (Lumetri-ს curves/wheels, მასკები და მისთ.)'; },
    missingFx: function (list) { return 'არ არის დაყენებული: ' + list.join(', '); },
    errors: {
      noSequence: 'სექვენსი არ არის გახსნილი',
      noSelection: 'ჯერ მონიშნე კლიპი timeline-ზე',
      noVideoSelected: 'მონიშნულია მხოლოდ აუდიო — ვიდეო ეფექტისთვის ვიდეო კლიპი მონიშნე',
      noAudioSelected: 'მონიშნულია მხოლოდ ვიდეო — აუდიო ეფექტისთვის აუდიო კლიპი მონიშნე',
      effectNotFound: 'ეფექტი ვერ მოიძებნა',
      applyFailed: 'ეფექტი ვერ დაედო',
      presetFailed: 'პრესეტი ვერ დაედო',
      noQE: 'Premiere-ის შიდა API ვერ ჩაირთო',
      noProject: 'პროექტი ვერ ვიპოვე — ჯერ შეინახე',
      noFreeTrack: 'ზედა ტრეკი აქ დაკავებულია და ახალი ვერ დავამატე — დაამატე ცარიელი ვიდეო ტრეკი ზემოთ',
      noZones: 'ამ სექვენსზე ზონა არ დევს',
      noEaseTarget: 'ლურჯი ხაზი ორ keyframe-ს შორის დააყენე (მონიშნულ კლიპზე)',
      noKeyframes: 'მონიშნულ კლიპზე keyframe-ები არ არის',
      undoMissing: 'ვერ გაუქმდა: კლიპი ან ეფექტი ვეღარ ვიპოვე',
      noParams: 'ჯერ მონიშნე, რომელ პარამეტრს დაედოს მრუდი',
      easeNothing: 'ამ keyframe-ებზე მრუდი ვერ დაედო: მნიშვნელობა არ იცვლება ან მოძრაობა ძალიან მოკლეა',
      zoneWriteFailed: 'ზონის სურათი ვერ შეინახა',
      zoneFileMissing: 'ზონის სურათი ვერ მოიძებნა',
      zoneImportFailed: 'ზონის სურათი პროექტში ვერ შემოვიდა',
      zonePlaceFailed: 'ზონა ტრეკზე ვერ დაიდო',
      zoneReplaceFailed: 'ძველი ზონა ვერ მოიხსნა',
      zoneToggleFailed: 'ზონა ვერ დაიმალა — ტრეკის თვალის ხატულა გამორთე ხელით',
      hostError: 'Premiere-მა არ უპასუხა — დახურე და თავიდან გახსენი Quick FX',
      badReply: 'Premiere-მა გაუგებარი პასუხი დააბრუნა',
      exception: 'შეცდომა'
    },
    commands: 'ბრძანებები',
    e: {
      out: 'გასვლა', inn: 'შესვლა', mine: 'ჩემი', del: 'წაშლა', sec: 'წმ', moves: 'მოძრაობა',
      clips: function (n) { return 'მონიშნულია ' + n + ' კლიპი'; },
      selectClip: 'მონიშნე კლიპი, რომელზეც keyframe-ებია',
      parkPlayhead: 'ლურჯი ხაზი ორ keyframe-ს შორის დააყენე',
      noKeys: 'მონიშნულ კლიპზე keyframe-ები არ არის',
      applied: function (params, keys) { return 'მრუდი დაედო: ' + params + ' პარამეტრი · ' + keys + ' keyframe'; },
      linearDone: function (params) { return 'Linear: ' + params + ' პარამეტრი დაბრუნდა'; },
      partial: 'ძალიან ბევრი keyframe იყო — ნაწილზე დაედო, დანარჩენზე თავიდან გაუშვი.',
      flat: function (n) { return n + ' პარამეტრში მნიშვნელობა არ იცვლება.'; },
      tooShort: function (n) { return n + ' მოძრაობა ძალიან მოკლეა.'; },
      unsupported: function (n) { return n + ' პარამეტრს მრუდი არ ედება.'; },
      saved: function (name) { return 'შეინახა: <b>' + esc(name) + '</b>'; },
      saveFailed: 'პრესეტი ვერ შეინახა',
      undone: function (n) { return 'გაუქმდა: ' + n + ' პარამეტრი დაბრუნდა'; },
      undoMissing: function (n) { return n + ' პარამეტრი ვეღარ ვიპოვე (კლიპი ან ეფექტი შეიცვალა).'; },
      undoTip: function (n) { return 'ბოლო დადების გაუქმება · დარჩენილია ' + n + ' ნაბიჯი'; },
      undoNone: 'გასაუქმებელი არაფერია',
      params: 'რაზე დაედოს', all: 'ყველა', none: 'არცერთი',
      noParamsYet: 'აქ გამოჩნდება keyframe-იანი პარამეტრები',
      pickParams: 'მონიშნე პარამეტრი მარჯვნივ',
      chosen: function (n, of) { return 'არჩეულია ' + n + ' / ' + of; },
      cmdMeta: 'keyframe-ები ლურჯ ხაზზე'
    },
    z: {
      vertical: 'ვერტიკალური · 9:16',
      horizontal: 'ჰორიზონტალური · 16:9',
      noSeq: 'ჯერ სექვენსი გახსენი',
      willPlace: function (n) { return 'დაიდება ლურჯი ხაზიდან ' + n + ' წამზე. მერე კლიპივით გაწელე ან დაამოკლე.'; },
      seqSize: function (w, h) { return 'სექვენსი ' + w + ' × ' + h; },
      willSwap: function (name) { return 'ლურჯ ხაზზე უკვე დევს: ' + name + '. შეიცვლება, სიგრძე დარჩება.'; },
      hide: 'დამალვა', show: 'ჩვენება',
      visible: function (n) { return 'ჩანს სექვენსზე: ' + n; },
      hidden: function (n) { return 'დამალულია: ' + n; },
      exportHint: 'ექსპორტამდე დამალე — ზონა ჩვეულებრივი კლიპია',
      placed: function (name, secs) { return '<b>' + esc(name) + '</b> ზონა დაიდო · ' + secs + ' წმ'; },
      swapped: function (name) { return 'ზონა შეიცვალა: <b>' + esc(name) + '</b>'; },
      newTrack: 'დაემატა ახალი ტრეკი ზემოთ.',
      notExact: 'სიგრძე ზუსტად ვერ დაყენდა — კლიპი ხელით გაწელე.',
      nowHidden: function (n) { return n + ' ზონა დაიმალა'; },
      nowShown: function (n) { return n + ' ზონა ჩანს'; },
      removed: function (n) { return n + ' ზონა წაიშალა'; },
      cmdMeta: function (n) { return n + ' წმ ლურჯი ხაზიდან'; },
      cmdToggle: 'Safe Zones — დამალვა / ჩვენება'
    },
    auto: {
      title: 'ავტომატური შეგროვება',
      desc: 'ახალი ფაილი, რომელსაც Downloads-იდან, გარე დისკიდან ან ბარათიდან შემოიტან, თავისით დაკოპირდება პროექტის Imported საქაღალდეში.',
      manualTitle: 'პროექტში უკვე არსებული ფაილები',
      manualDesc: 'რაც ადრე შემოიტანე და პროექტის საქაღალდის გარეთ დარჩა: ნახავ სიას და ერთად დააკოპირებ.',
      manualBtn: 'შეგროვება',
      activity: 'ბოლო აქტივობა',
      noActivity: 'ჯერ არაფერი დაკოპირებულა',
      toFx: 'ეფექტები',
      dockOn: 'ელოდება ახალ ფაილებს',
      dockOff: 'გამორთულია',
      dockStarting: 'ირთვება…',
      dockDead: 'ფონი არ პასუხობს',
      dockDeadTip: 'ფონური ნაწილი არ პასუხობს — Premiere სრულად დახურე და თავიდან გახსენი',
      dockLast: function (name) { return 'ბოლო: ' + name; },
      on: 'ავტომატური შეგროვება: მუშაობს',
      off: 'ავტომატური შეგროვება: გამორთულია',
      dead: 'ავტომატური შეგროვება: ფონური ნაწილი არ პასუხობს — Premiere თავიდან გახსენი',
      copying: function (name, left) { return 'კოპირდება: ' + name + (left > 1 ? ' (+' + (left - 1) + ')' : ''); },
      last: 'ბოლო:'
    },
    c: {
      title: 'ფაილების შეგროვება',
      scanning: 'პროექტი მოწმდება…',
      allInside: '✓ ყველა ფაილი უკვე პროექტის საქაღალდეშია',
      checked: function (n) { return 'შემოწმდა ' + n + ' ფაილი'; },
      found: function (n, size) { return n + ' ფაილი · ' + size + ' პროექტის საქაღალდის გარეთაა'; },
      willCopy: 'დაკოპირდება აქ:',
      copy: 'დაკოპირება',
      back: 'უკან',
      stop: 'გაჩერება',
      stopping: 'ჩერდება მიმდინარე ფაილის შემდეგ…',
      close: 'დახურვა',
      keepWorking: 'Premiere-ში მუშაობა შეგიძლია გააგრძელო. ეს ფანჯარა არ დახურო, სანამ არ დასრულდება.',
      mayFreeze: 'დიდი ფაილის კოპირებისას Premiere შეიძლება ცოტა ხნით გაიყინოს.',
      done: '✓ დასრულდა',
      doneWithErrors: 'დასრულდა, მაგრამ ზოგი ფაილი ვერ გადავიდა',
      result: function (copied, reused, relinked) {
        var parts = [copied + ' დაკოპირდა'];
        if (reused) { parts.push(reused + ' უკვე იყო პროექტის საქაღალდეში'); }
        parts.push(relinked + ' კლიპი გადამისამართდა');
        return parts.join(' · ');
      },
      stoppedAt: function (done, total) { return 'გაჩერდა: ' + done + ' / ' + total + '. დანარჩენისთვის ბრძანება თავიდან გაუშვი.'; },
      saveHint: 'ორიგინალები ადგილზეა. პროექტი შეინახე: ⌘S',
      skipped: 'გამოტოვებულია:',
      skip: { offline: 'offline', missing: 'დისკზე ვერ მოიძებნა', linked: 'After Effects / Dynamic Link', sequence: 'სურათების სექვენსი' },
      errReason: { relink: 'დაკოპირდა, მაგრამ ვერ გადამისამართდა', missing: 'ორიგინალი ვერ მოიძებნა', copyFailed: 'ვერ დაკოპირდა', mkdirFailed: 'საქაღალდე ვერ შეიქმნა', ENOSPC: 'დისკზე ადგილი არ არის', EACCES: 'წვდომა არ არის', EPERM: 'წვდომა არ არის' }
    },
    y: {
      cmd: 'YouTube / TikTok — ვიდეოს ჩაწერა', cmdMeta: 'ბმული → Project პანელი',
      idleTitle: 'ჩასვი YouTube-ის ან TikTok-ის ბმული',
      idle: ['დააკოპირე ბმული ბრაუზერიდან', 'ჩასვი ზემოთ: ⌘V ან „ჩასმა“', 'აირჩიე რა გინდა და რა ხარისხით — ფაილი თავისით დაემატება Project პანელში'],
      setupTitle: 'პირველი გამოყენება: ჩამოტვირთვის ძრავა',
      setupDesc: 'ერთხელ უნდა ჩამოიტვირთოს სამი ღია კოდის ხელსაწყო (yt-dlp, ffmpeg, deno), დაახლოებით 120–160 MB. ინახება ამ კომპიუტერზე, Quick FX-ის საქაღალდეში; სისტემაში არაფერი იცვლება.',
      setupBtn: 'დაყენება',
      installing: function (i, n, name) { return 'იტვირთება ' + name + ' · ' + (i + 1) + ' / ' + n; },
      checking: function (name) { return 'მოწმდება ' + name + '…'; },
      installed: 'ძრავა დაყენდა',
      loading: 'ვიდეო მოწმდება…', loadingSub: 'ჩვეულებრივ 5–15 წამი',
      updating: 'ძრავა ახლდება…',
      what: 'რა ჩამოვტვირთო', quality: 'ხარისხი',
      modes: { both: 'ვიდეო + ხმა', video: 'მხოლოდ ვიდეო', audio: 'მხოლოდ ხმა' },
      audioNote: 'ხმა ჩამოიტვირთება საუკეთესო ხარისხით (M4A / AAC) — Premiere პირდაპირ ხსნის.',
      convertNote: 'YouTube 1080p-ზე მაღლა H.264-ს არ იძლევა. ჩამოტვირთვის შემდეგ ფაილი გადაკეთდება H.264-ში, რომ Premiere-მა გახსნას — ამას რამდენიმე წუთი სჭირდება.',
      convertTip: 'ჩამოტვირთვის შემდეგ გადაკეთდება H.264-ში',
      noAudio: 'ამ ვიდეოს ხმა არ აქვს',
      sec: { label: 'რამდენი', all: 'მთლიანი ვიდეო', part: 'მხოლოდ მონაკვეთი', from: 'დან', to: 'მდე', toEnd: 'ბოლომდე',
        len: function (t) { return 'ჩამოვა ' + t + ' — ზუსტად ამ წამებზე გაჭრილი, H.264'; },
        lenAudio: function (t) { return 'ჩამოვა ' + t; },
        empty: 'მიუთითე დრო, მაგ. 0:45 და 1:20',
        badFrom: 'დასაწყისი ვერ გავიგე — დაწერე ასე: 0:45 ან 1:02:05',
        badTo: 'დასასრული ვერ გავიგე — დაწერე ასე: 1:20 ან 1:02:05',
        order: 'დასასრული დასაწყისის შემდეგ უნდა იყოს',
        past: function (t) { return 'ვიდეო სულ ' + t + ' გრძელდება'; } },
      about: function (size) { return '≈ ' + size; },
      destSaved: '→ Imported/YouTube · Project: „YouTube“ ბინი',
      destSite: function (name) { return '→ Imported/' + name + ' · Project: „' + name + '“ ბინი'; },
      clean: 'ორიგინალი, watermark-ის გარეშე',
      hevcTip: 'HEVC (H.265) — ამ ხარისხს TikTok მხოლოდ ასე იძლევა; Premiere ხსნის',
      convertOther: 'ამ ფორმატს Premiere პირდაპირ ვერ ხსნის. ჩამოტვირთვის შემდეგ გადაკეთდება H.264-ში — ამას ცოტა დრო სჭირდება.',
      audioOwn: 'ჩამოვა ამ ვიდეოს საკუთარი ხმა (M4A / AAC), არა მხოლოდ მუსიკის ტრეკი.',
      destUnsaved: 'პროექტი შენახული არ არის → Downloads/Quick FX',
      go: 'ჩამოტვირთვა', fetch: 'ნახვა', again: 'კიდევ ერთი', retry: 'თავიდან ცდა', cancel: 'გაუქმება',
      q: { title: 'ჩამოტვირთვები', wait: 'რიგშია', clear: 'დასრულებულების მოშორება', add: 'რიგში დამატება',
        added: function (n) { return 'რიგში დაემატა — წინ ' + n + ' ჩამოტვირთვაა'; },
        dup: 'ეს უკვე რიგშია', inProject: 'Project პანელშია', existed: 'უკვე ჩამოტვირთული იყო — Project პანელშია',
        noImport: 'ჩამოიტვირთა, მაგრამ პროექტში ვერ დაემატა — ხელით ჩააგდე',
        cancelTip: 'გაუქმება', removeTip: 'სიიდან მოშორება', retryTip: 'თავიდან ცდა',
        allDone: function (n) { return n + ' ჩამოტვირთვა დასრულდა'; },
        onlyVideo: 'მხოლოდ ვიდეო', audio: 'ხმა' },
      part: { video: 'ვიდეო', audio: 'ხმა', section: 'მონაკვეთი იწერება', merge: 'ვიდეო და ხმა ერთიანდება…', convert: 'გადადის H.264-ში…', fix: 'სრულდება…', start: 'იწყება…' },
      elapsed: function (t) { return 'გავიდა ' + t; },
      left: function (eta) { return 'დარჩა ' + eta; },
      done: 'დაემატა Project პანელში', doneExisted: 'უკვე ჩამოტვირთული იყო — Project პანელშია',
      doneNoImport: 'ჩამოიტვირთა, მაგრამ პროექტში ვერ დაემატა — ხელით ჩააგდე:',
      doneToast: function (name) { return 'ჩამოიტვირთა: <b>' + esc(name) + '</b>'; },
      cancelled: 'ჩამოტვირთვა გაუქმდა',
      stillBusy: 'ჩამოტვირთვა მიმდინარეობს — ფანჯარა არ დაიხურება, სანამ რიგი არ დასრულდება',
      cookies: 'ვცადო Chrome-ის ანგარიშით',
      cookiesNote: 'წაიკითხავს ამ საიტზე შენს შესვლას ამ კომპიუტერის Chrome-იდან. macOS-მა შეიძლება Keychain-ის პაროლი გკითხოს.',
      err: {
        ytLogin: 'საიტი ამ ვიდეოზე შესვლას ითხოვს (ასაკის შეზღუდვა ან ბოტის შემოწმება)',
        ytUnavailable: 'ვიდეო მიუწვდომელია: პირადია, წაშლილია ან ამ ქვეყანაში არ ჩანს',
        ytBadUrl: 'ეს ბმული ვერ გავიგე — ვიდეოს გვერდის ბმული ჩასვი',
        ytNoFormat: 'ეს ხარისხი ამ ვიდეოსთვის ვერ მოიძებნა — სხვა აირჩიე',
        ytNetwork: 'ინტერნეტთან კავშირი ვერ მოხერხდა',
        ytBusy: 'საიტი დროებით ზღუდავს მოთხოვნებს — რამდენიმე წუთში სცადე',
        ytLive: 'ეს პირდაპირი ეთერია — დასრულების შემდეგ ჩამოიტვირთება',
        ytFailed: 'ჩამოტვირთვა ვერ მოხერხდა',
        ENOSPC: 'დისკზე ადგილი არ არის',
        noNode: 'Quick FX-ის ეს ნაწილი ვერ ჩაირთო — Premiere სრულად დახურე და თავიდან გახსენი',
        installFailed: 'ძრავა ვერ ჩამოიტვირთა — ინტერნეტი შეამოწმე და თავიდან სცადე',
        ytToolBroken: 'ძრავის ნაწილი ამ კომპიუტერზე ვერ გაეშვა — დიაგნოსტიკა დააკოპირე და გამომიგზავნე'
      }
    },
    diagCopied: 'დიაგნოსტიკა დაკოპირდა — ჩასვი ჩატში',
    refreshed: function (fx, pr) { return 'განახლდა: ' + fx + ' ეფექტი · ' + pr + ' პრესეტი'; }
  };

  // ------------------------------------------------------------------ state
  var state = {
    effects: { video: [], audio: [] },
    presets: [],
    presetSkipped: [],
    presetFile: null,
    presetError: null,
    info: null,
    items: [],
    rows: [],            // rendered rows (selectable ones only)
    active: 0,
    view: 'list',
    busy: false,
    loaded: false,
    hadFocus: false,
    openedAt: Date.now(),
    lastError: null,
    lastResult: null,
    usage: load(LS.usage, {}),
    favs: load(LS.favs, {}),             // starred effects / presets: id → when it was starred
    settings: assign({ closeOnBlur: true }, load(LS.settings, {}))
  };

  // ------------------------------------------------------------------ DOM
  function $(id) { return document.getElementById(id); }
  var $q = $('q'), $list = $('list'), $sel = $('sel'), $toast = $('toast');
  var $menu = $('menu'), $menuBtn = $('menuBtn'), $busy = $('busy'), $menuInfo = $('menuInfo');
  var $closeOnBlur = $('closeOnBlur'), $blurOpt = $('blurOpt'), $keys = $('keys');
  var $files = $('files'), $fkeys = $('fkeys'), $railDot = $('railDot');
  var $tabs = { fx: $('tabFx'), files: $('tabFiles'), zones: $('tabZones'), ease: $('tabEase'), yt: $('tabYt') };
  var VIEW_OF = { fx: 'list', files: 'collect', zones: 'zones', ease: 'ease', yt: 'yt' };

  // ------------------------------------------------------------------ utils
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function assign(a, b) { for (var k in b) { if (Object.prototype.hasOwnProperty.call(b, k)) { a[k] = b[k]; } } return a; }
  function load(key, dflt) {
    try { var v = window.localStorage.getItem(key); return v ? JSON.parse(v) : dflt; } catch (e) { return dflt; }
  }
  function save(key, val) {
    try { window.localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* storage full or unavailable */ }
  }
  function highlight(text, idx) {
    if (!idx || !idx.length) { return esc(text); }
    var set = {}, i, out = '', open = false;
    for (i = 0; i < idx.length; i++) { set[idx[i]] = true; }
    for (i = 0; i < text.length; i++) {
      var on = !!set[i];
      if (on && !open) { out += '<mark>'; open = true; }
      if (!on && open) { out += '</mark>'; open = false; }
      out += esc(text.charAt(i));
    }
    if (open) { out += '</mark>'; }
    return out;
  }

  // ------------------------------------------------------------------ items
  function buildItems() {
    var items = COMMANDS.slice(), i;
    for (i = 0; i < state.presets.length; i++) {
      var p = state.presets[i];
      var sum = P.summary(p);
      var kf = P.keyframeCount(p);
      items.push({
        id: p.id, name: p.name, kind: 'preset', ref: p,
        alt: (p.folder ? p.folder + ' ' : '') + sum,
        meta: (p.folder ? p.folder + ' · ' : '') + sum + (kf ? ' · ◆' + kf : '')
      });
    }
    var v = state.effects.video || [], a = state.effects.audio || [];
    for (i = 0; i < v.length; i++) { items.push({ id: 'v:' + v[i], name: v[i], kind: 'video', meta: T.videoFx }); }
    for (i = 0; i < a.length; i++) { items.push({ id: 'a:' + a[i], name: a[i], kind: 'audio', meta: T.audioFx }); }
    state.items = items;
  }

  // ------------------------------------------------------------------ render
  function rowHtml(r, i) {
    var it = r.item;
    var badge = (it.kind === 'command' && it.icon === 'yt') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v10.5m0 0l-4-4m4 4l4-4"/><path d="M4.5 16.5v1.5a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-1.5"/></svg></span>'
      : (it.kind === 'command' && it.icon === 'ease') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 19c5 0 5-14 9-14s4 14 9 14"/></svg></span>'
      : (it.kind === 'command' && it.icon === 'zone') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 7h6M9 17h6"/></svg></span>'
      : it.kind === 'command' ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v10m0 0l-4-4m4 4l4-4M5 18h14"/></svg></span>'
      : it.kind === 'preset' ? '<span class="badge preset"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l2.7 5.6 6.1.8-4.5 4.3 1.1 6.1L12 16.9 6.6 19.8l1.1-6.1L3.2 9.4l6.1-.8z"/></svg></span>'
      : (it.kind === 'audio' ? '<span class="badge audio">AU</span>' : '<span class="badge video">FX</span>');
    return '<div class="row' + (i === state.active ? ' active' : '') + '" data-i="' + i + '" role="option">' +
      badge +
      '<span class="name">' + highlight(it.name, r.idx) + '</span>' +
      '<span class="meta">' + esc(it.meta || '') + '</span>' +
      (it.kind === 'command' ? '' : '<span class="star' + (state.favs[it.id] ? ' on' : '') + '" data-star="1" title="' + esc(T.favTip) + '">★</span>') +
      '<span class="ret">↵</span>' +
      '</div>';
  }

  function render() {
    var q = $q.value;
    var html = [], rows = [], i;
    function section(label) { html.push('<div class="section">' + esc(label) + '</div>'); }
    function push(r) { html.push(rowHtml(r, rows.length)); rows.push(r); }

    var hasFx = false;
    for (i = 0; i < state.items.length; i++) { if (state.items[i].kind !== 'command') { hasFx = true; break; } }

    if (!S.cleanQuery(q)) {
      if (!hasFx) {
        html.push('<div class="empty">' + (!state.loaded ? T.loading
          : (state.lastError ? errorText(state.lastError) : T.errors.noQE)) + '</div>');
      }
      var plain = [];
      for (i = 0; i < state.items.length; i++) { if (state.items[i].kind !== 'command') { plain.push(state.items[i]); } }
      var shown = {}, favRows = [];
      for (i = 0; i < plain.length; i++) { if (state.favs[plain[i].id]) { favRows.push({ item: plain[i], idx: [] }); } }
      favRows.sort(function (x, y) { return state.favs[x.item.id] - state.favs[y.item.id]; });
      if (favRows.length) {
        section(T.favs + ' · ' + favRows.length);
        for (i = 0; i < favRows.length; i++) { push(favRows[i]); shown[favRows[i].item.id] = true; }
      }
      var notFav = [];
      for (i = 0; i < plain.length; i++) { if (!shown[plain[i].id]) { notFav.push(plain[i]); } }
      var rec = S.recents(notFav, state.usage, 6);
      if (rec.length) {
        section(T.recent);
        for (i = 0; i < rec.length; i++) { push(rec[i]); shown[rec[i].item.id] = true; }
      }
      var presetRows = [], fxRows = [];
      for (i = 0; i < state.items.length; i++) {
        var it = state.items[i];
        if (shown[it.id] || it.kind === 'command') { continue; }
        if (it.kind === 'preset') { presetRows.push({ item: it, idx: [] }); }
        else if (fxRows.length < EMPTY_EFFECT_LIMIT) { fxRows.push({ item: it, idx: [] }); }
      }
      if (presetRows.length) {
        section(T.myPresets + ' · ' + presetRows.length);
        for (i = 0; i < presetRows.length; i++) { push(presetRows[i]); }
      }
      if (fxRows.length) {
        section(T.effects);
        for (i = 0; i < fxRows.length; i++) { push(fxRows[i]); }
        html.push('<div class="more">' + esc(T.moreHint) + '</div>');
      }
    } else {
      var res = S.rank(state.items, q, state.usage, RESULT_LIMIT);
      if (!res.length) { html.push('<div class="empty">' + T.nothing(q) + '</div>'); }
      // Commands normally come after effects and presets, so Enter on a half-typed effect name can never
      // run one. They lead only when a command is clearly what was typed and no effect really matches.
      var cmds = [], plainRows = [], bestCmd = 0, bestPlain = 0;
      for (i = 0; i < res.length; i++) {
        if (res[i].item.kind === 'command') { cmds.push(res[i]); bestCmd = Math.max(bestCmd, res[i].score || 0); }
        else { plainRows.push(res[i]); bestPlain = Math.max(bestPlain, res[i].score || 0); }
      }
      // starred ones lead among what matches — but a weak fuzzy hit on a starred effect does not jump over a real match
      var lead = [], rest = [];
      for (i = 0; i < plainRows.length; i++) {
        if (state.favs[plainRows[i].item.id] && (plainRows[i].score || 0) >= bestPlain * 0.5) { lead.push(plainRows[i]); } else { rest.push(plainRows[i]); }
      }
      plainRows = lead.concat(rest);
      var cmdsFirst = cmds.length && bestCmd >= 600 && bestPlain < 600;
      if (cmdsFirst) { for (i = 0; i < cmds.length; i++) { push(cmds[i]); } }
      for (i = 0; i < plainRows.length; i++) { push(plainRows[i]); }
      if (cmds.length && !cmdsFirst) {
        if (rows.length) { section(T.commands); }
        for (i = 0; i < cmds.length; i++) { push(cmds[i]); }
      }
    }

    state.rows = rows;
    if (state.active >= rows.length) { state.active = rows.length ? rows.length - 1 : 0; }
    $list.innerHTML = html.join('');
    scrollActiveIntoView();
  }

  /** Star / unstar; the highlight stays on the same effect wherever it moves in the list. */
  function toggleFav(item) {
    if (!item || item.kind === 'command') { return; }
    if (state.favs[item.id]) { delete state.favs[item.id]; } else { state.favs[item.id] = Date.now(); }
    save(LS.favs, state.favs);
    render();
    for (var i = 0; i < state.rows.length; i++) { if (state.rows[i].item.id === item.id) { state.active = i; break; } }
    render();
    toast('ok', state.favs[item.id] ? T.favOn(item.name) : T.favOff(item.name), '', 1300);
  }

  function setActive(i) {
    if (!state.rows.length) { return; }
    var n = state.rows.length;
    i = Math.max(0, Math.min(n - 1, i));
    if (i === state.active) { return; }
    var prev = $list.querySelector('.row.active');
    if (prev) { prev.classList.remove('active'); }
    state.active = i;
    var el = $list.querySelector('.row[data-i="' + i + '"]');
    if (el) { el.classList.add('active'); }
    scrollActiveIntoView();
  }

  function scrollActiveIntoView() {
    var el = $list.querySelector('.row.active');
    if (!el) { return; }
    var top = el.offsetTop, bottom = top + el.offsetHeight;
    var prevSection = el.previousElementSibling;
    if (state.active === 0) { $list.scrollTop = 0; return; }
    if (prevSection && prevSection.classList.contains('section')) { top = prevSection.offsetTop; }
    if (top < $list.scrollTop) { $list.scrollTop = top - 6; }
    else if (bottom > $list.scrollTop + $list.clientHeight) { $list.scrollTop = bottom - $list.clientHeight + 6; }
  }

  // ------------------------------------------------------------------ selection status
  function setSelection(d) {
    var cls = 'sel', text;
    if (!d || !d.hasSequence) { cls += ' none'; text = T.noSeq; }
    else if (!d.video && !d.audio) { cls += ' none'; text = T.noSel; }
    else { cls += ' ok'; text = T.selected(d.video, d.audio); }
    $sel.className = cls;
    $sel.querySelector('.sel-text').textContent = text;
  }

  function refreshSelection() {
    return B.call('selection').then(function (r) { if (r && r.ok) { setSelection(r.data); } });
  }

  // ------------------------------------------------------------------ toast
  var toastTimer = null;
  function toast(kind, html, sub, ms) {
    var icon = kind === 'ok' ? '✓' : (kind === 'warn' ? '!' : '✕');
    $toast.className = 'toast ' + kind;
    $toast.innerHTML = '<span class="ti">' + icon + '</span><span>' + html +
      (sub ? '<span class="tsub">' + sub + '</span>' : '') + '</span>';
    $toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { $toast.hidden = true; }, ms || (kind === 'ok' ? 2200 : 5000));
  }

  function errorText(res) {
    var base = T.errors[res.code] || T.errors.exception;
    var extra = '';
    if (res.code === 'effectNotFound' || res.code === 'applyFailed') { extra = res.message ? ': ' + esc(res.message) : ''; }
    else if (res.code === 'exception' || res.code === 'hostError' || res.code === 'badReply') { extra = res.message ? '<span class="tsub">' + esc(res.message) + '</span>' : ''; }
    else if (res.code === 'presetFailed' && res.extra && res.extra.missing && res.extra.missing.length) {
      extra = '<span class="tsub">' + esc(T.missingFx(res.extra.missing)) + '</span>';
    }
    return base + extra;
  }

  // ------------------------------------------------------------------ busy / host
  function setBusy(on) { state.busy = on; $busy.hidden = !on; }

  /** The floating window closes itself after most actions — but never in the middle of a download. */
  function closeWindow() {
    if (ytBusy()) { if (state.view !== 'yt') { toast('warn', T.y.stillBusy); } return; }
    B.close();
  }

  function ensureHost() {
    return B.evalScript('typeof QuickFX').then(function (r) {
      if (r === 'object') { return true; }
      var path = B.extensionPath() + '/jsx/host.jsx';
      return B.evalScript('$.evalFile(' + JSON.stringify(path) + ')').then(function () { return true; });
    });
  }

  function choosePresetFile(files, appVersion) {
    if (!files || !files.length) { return null; }
    var major = String(appVersion || '').split('.')[0];
    var same = files.filter(function (f) { return String(f.version).split('.')[0] === major; });
    var pool = (same.length ? same : files).slice();
    pool.sort(function (a, b) { return (b.modified || 0) - (a.modified || 0); });
    return pool[0];
  }

  function loadPresets() {
    var f = choosePresetFile(state.info && state.info.presetFiles, state.info && state.info.appVersion);
    state.presetFile = f;
    state.presetError = null;
    if (!f) { state.presets = []; return; }
    var text = B.readTextFile(f.path);
    if (text == null) { state.presetError = 'cannot read ' + f.path; state.presets = []; return; }
    try {
      var res = P.parse(text);
      state.presets = res.presets;
      state.presetSkipped = res.skipped;
    } catch (e) {
      state.presetError = String(e && e.message || e);
      state.presets = [];
    }
  }

  function loadEverything(announce) {
    setBusy(true);
    return ensureHost()
      .then(function () { return Promise.all([B.call('info'), B.call('listEffects'), B.call('selection')]); })
      .then(function (r) {
        var info = r[0], fx = r[1], sel = r[2];
        if (info.ok) { state.info = info.data; } else { state.lastError = info; }
        if (fx.ok) {
          state.effects = fx.data;
          save(LS.effects, { at: Date.now(), app: state.info && state.info.appVersion, data: fx.data });
        } else { state.lastError = fx; }
        if (sel.ok) { setSelection(sel.data); }
        loadPresets();
        state.loaded = true;
        buildItems();
        render();
        updateMenuInfo();
        setBusy(false);
        if (announce) { toast('ok', T.refreshed((state.effects.video || []).length + (state.effects.audio || []).length, state.presets.length)); }
      })
      .catch(function (e) {
        setBusy(false);
        state.loaded = true;
        state.lastError = { code: 'exception', message: String(e && e.message || e) };
        render();
      });
  }

  // ------------------------------------------------------------------ apply
  function recordUsage(item) {
    var u = state.usage[item.id] || { count: 0, last: 0 };
    u.count += 1;
    u.last = Date.now();
    state.usage[item.id] = u;
    var keys = Object.keys(state.usage);
    if (keys.length > 600) {
      keys.sort(function (a, b) { return state.usage[a].last - state.usage[b].last; });
      for (var i = 0; i < keys.length - 500; i++) { delete state.usage[keys[i]]; }
    }
    save(LS.usage, state.usage);
  }

  function apply(row, keepOpen) {
    if (!row || state.busy) { return; }
    var item = row.item;
    if (item.kind === 'command') { item.run(); return; }
    setBusy(true);
    var call = item.kind === 'preset'
      ? B.call('applyPreset', { preset: P.compact(item.ref) })
      : B.call('applyEffect', { kind: item.kind, name: item.name });

    call.then(function (res) {
      setBusy(false);
      state.lastResult = { item: item.id, res: res, at: new Date().toISOString() };
      if (!res || !res.ok) {
        state.lastError = res;
        toast('err', errorText(res || { code: 'hostError' }));
        return;
      }
      recordUsage(item);
      var d = res.data, sub = [], kind = 'ok', msg;
      if (item.kind === 'preset') {
        msg = T.appliedPreset(item.name, d.clips);
        if (d.missing && d.missing.length) { sub.push(esc(T.missingFx(d.missing))); kind = 'warn'; }
        if (d.paramsSkipped) { sub.push(esc(T.skippedParams(d.paramsSkipped))); kind = 'warn'; }
        if (d.clips < d.total) { sub.push(esc(T.failedSome(d.total - d.clips))); kind = 'warn'; }
      } else {
        msg = T.appliedFx(item.name, d.applied);
        if (d.failed) { sub.push(esc(T.failedSome(d.failed))); kind = 'warn'; }
      }
      toast(kind, msg, sub.join('<br>'), kind === 'ok' ? 1600 : 4500);

      if (MODE === 'popup' && !keepOpen) {
        setTimeout(function () { closeWindow(); }, kind === 'ok' ? 380 : 2600);
      } else {
        refreshSelection();
        $q.focus();
        $q.select();
      }
    });
  }

  // ------------------------------------------------------------------ collect files
  var C = window.QFXCollect;
  var CAT_LABEL = { Video: 'Video', Audio: 'Audio', Music: 'Music', Images: 'Images', Other: 'Other' };
  var collect = { phase: 'idle' };

  function nodeFs() {
    try {
      var req = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
      return req ? req('fs') : null;
    } catch (e) { return null; }
  }

  function keysHtml(pairs) {
    var out = '';
    for (var i = 0; i < pairs.length; i++) { out += '<span><kbd>' + pairs[i][0] + '</kbd> ' + esc(pairs[i][1]) + '</span>'; }
    return out;
  }

  // The Files tab: 'home' (auto switch, activity) → scan → ready → copy → done.
  function switchTab(tab) {
    if (collect.phase === 'copy') { return; }                 // a manual copy is running: stay on it
    if (!$tabs[tab]) { return; }
    state.view = VIEW_OF[tab];
    for (var t in $tabs) { if ($tabs.hasOwnProperty(t)) { $tabs[t].hidden = t !== tab; } }
    var btns = document.querySelectorAll('.rail-btn[data-tab]');
    for (var i = 0; i < btns.length; i++) { btns[i].classList.toggle('active', btns[i].getAttribute('data-tab') === tab); }
    openMenu(false, true);
    collect = { phase: tab === 'files' ? 'home' : 'idle' };
    if (tab !== 'fx' && document.activeElement && document.activeElement.blur) { document.activeElement.blur(); }
    if (tab === 'files') { renderCollect(); }
    else if (tab === 'zones') { renderZoneList(); renderZoneSide(); refreshZones(); }
    else if (tab === 'ease') { openEase(); }
    else if (tab === 'yt') { openYt(); }
    else { render(); refreshSelection(); $q.focus(); }
  }

  function openCollect() {
    if (state.view !== 'collect') { switchTab('files'); }
    collect = { phase: 'scan', scan: null, files: [], sum: null, done: 0, bytesDone: 0, bytesFile: 0, current: '',
      errors: [], copied: 0, reused: 0, relinked: 0, cancel: false, engine: null, error: null };
    renderCollect();
    B.call('scanMedia').then(function (r) {
      if (state.view !== 'collect' || collect.phase !== 'scan') { return; }
      if (!r || !r.ok) { collect.phase = 'error'; collect.error = r || { code: 'hostError' }; state.lastError = collect.error; renderCollect(); return; }
      var d = r.data;
      for (var i = 0; i < d.files.length; i++) { d.files[i].cat = C.categorize(d.files[i].name); }
      d.files.sort(function (a, b) { return (b.size || 0) - (a.size || 0); });
      collect.scan = d;
      collect.files = d.files;
      collect.sum = C.summarize(d.files);
      collect.phase = d.files.length ? 'ready' : 'empty';
      renderCollect();
    });
  }

  /** Phases where closing the window would lose what the user is doing. */
  function collectBusy() { return collect.phase === 'scan' || collect.phase === 'ready' || collect.phase === 'copy' || state.view === 'ease' || state.view === 'yt' || ytBusy(); }

  function collectHome() {
    if (state.view !== 'collect') { return; }
    collect = { phase: 'home' };
    renderCollect();
  }

  // ---- Files tab, home screen
  function autoStatus() {
    var a = autoState(), cls = 'dock-status', text, tip = '', kind = 'off';
    if (!a.settings.auto) { text = T.auto.dockOff; }
    else if (!a.alive) {
      if (Date.now() - state.openedAt < 9000) { text = T.auto.dockStarting; kind = 'on'; }
      else { cls += ' err'; text = T.auto.dockDead; tip = T.auto.dockDeadTip; kind = 'err'; }
    } else if (a.state.queue) { cls += ' busy'; text = T.auto.copying(a.state.current || '…', a.state.queue); kind = 'busy'; }
    else { cls += ' on'; text = T.auto.dockOn; kind = 'on'; }
    return { cls: cls, text: text, tip: tip || text, kind: kind, auto: a };
  }

  function activityHtml(a) {
    var log = (a.state && a.state.log) || [], out = [], i;
    for (i = log.length - 1; i >= 0 && out.length < 8; i--) {
      var e = log[i];
      if (e.kind !== 'ok' && e.kind !== 'err') { continue; }
      var parts = String(e.text).split(' → ');
      var time = '';
      try { var d = new Date(e.t); if (!isNaN(d.getTime())) { time = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); } } catch (eT) { time = ''; }
      out.push('<div class="c-file"><span class="c-tag' + (e.kind === 'err' ? ' err' : ' okk') + '">' + (e.kind === 'err' ? '!' : '✓') + '</span>' +
        '<span class="c-name">' + esc(parts[0]) + '</span><span class="c-from">' + esc(parts.length > 1 ? '→ ' + parts.slice(1).join(' → ') : '') +
        '</span><span class="c-size">' + esc(time) + '</span></div>');
    }
    return out.length ? '<div class="c-files">' + out.join('') + '</div>' : '<div class="c-note">' + esc(T.auto.noActivity) + '</div>';
  }

  function homeHtml() {
    var s = autoStatus();
    return '<div class="f-card"><div class="f-main"><div class="f-title">' + esc(T.auto.title) + '</div>' +
      '<div class="f-desc">' + esc(T.auto.desc) + '</div>' +
      '<div id="fStatus" class="' + s.cls + '" title="' + esc(s.tip) + '"><i class="dot"></i><span class="dock-text">' + esc(s.text) + '</span></div></div>' +
      '<label class="switch"><input type="checkbox" id="autoCollect"' + (s.auto.settings.auto ? ' checked' : '') + '><i></i></label></div>' +
      '<div class="f-card"><div class="f-main"><div class="f-title">' + esc(T.auto.manualTitle) + '</div>' +
      '<div class="f-desc">' + esc(T.auto.manualDesc) + '</div></div>' +
      '<button class="c-btn primary" data-cact="scan">' + esc(T.auto.manualBtn) + ' <kbd>↵</kbd></button></div>' +
      '<div class="f-section">' + esc(T.auto.activity) + '</div><div id="fLog">' + activityHtml(s.auto) + '</div>';
  }

  /** Every 2 s: the dot on the rail button, and (on the Files home screen) status + activity. */
  function updateAuto() {
    var s = autoStatus();
    $railDot.className = 'rail-dot ' + s.kind;
    if (state.view === 'collect' && collect.phase === 'home') {
      var el = $('fStatus'), lg = $('fLog');
      if (el) { el.className = s.cls; el.title = s.tip; el.querySelector('.dock-text').textContent = s.text; }
      if (lg) { var html = activityHtml(s.auto); if (lg.innerHTML !== html) { lg.innerHTML = html; } }
    }
  }

  function skippedHtml(list) {
    if (!list || !list.length) { return ''; }
    var by = {}, i, out = [];
    for (i = 0; i < list.length; i++) { by[list[i].reason] = (by[list[i].reason] || 0) + 1; }
    for (var k in by) { if (by.hasOwnProperty(k)) { out.push(by[k] + ' — ' + (T.c.skip[k] || k)); } }
    return '<div class="c-note">' + esc(T.c.skipped) + ' ' + esc(out.join(' · ')) + '</div>';
  }

  function renderCollect() {
    var c = collect, h = [], i;
    var locked = c.phase === 'copy';
    var rb = document.querySelectorAll('.rail-btn[data-tab]');
    for (i = 0; i < rb.length; i++) { rb[i].disabled = locked; }
    if (c.phase === 'home') {
      h.push(homeHtml());
      $fkeys.innerHTML = keysHtml([['↵', T.auto.manualBtn], ['esc', T.auto.toFx]]);
    } else if (c.phase === 'scan') {
      h.push('<div class="empty">' + esc(T.c.scanning) + '</div>');
      $fkeys.innerHTML = keysHtml([['esc', T.c.back]]);
    } else if (c.phase === 'error') {
      h.push('<div class="empty">' + errorText(c.error) + '</div>');
      $fkeys.innerHTML = keysHtml([['esc', T.c.back]]);
    } else if (c.phase === 'empty') {
      h.push('<div class="c-head"><div class="c-big">' + esc(T.c.allInside) + '</div>' +
        '<div class="c-sub">' + esc(T.c.checked(c.scan.total)) + '</div></div>' + skippedHtml(c.scan.skipped));
      $fkeys.innerHTML = keysHtml([['esc', T.c.back]]);
    } else if (c.phase === 'ready') {
      h.push('<div class="c-head"><div class="c-big">' + esc(T.c.found(c.sum.count, C.formatBytes(c.sum.bytes))) + '</div>' +
        '<div class="c-sub">' + esc(T.c.willCopy) + ' <span class="c-path">' + esc(c.scan.importedDir) + '</span></div></div>');
      h.push('<div class="c-cats">');
      for (i = 0; i < C.CATEGORIES.length; i++) {
        var cat = C.CATEGORIES[i], s = c.sum.byCat[cat];
        if (s.count) { h.push('<span class="c-cat"><b>' + CAT_LABEL[cat] + '</b> ' + s.count + ' · ' + C.formatBytes(s.bytes) + '</span>'); }
      }
      h.push('</div>' + skippedHtml(c.scan.skipped));
      h.push('<div class="c-actions"><button class="c-btn primary" data-cact="start">' + esc(T.c.copy) + ' <kbd>↵</kbd></button>' +
        '<button class="c-btn" data-cact="back">' + esc(T.c.back) + '</button></div>');
      h.push('<div class="c-files">');
      for (i = 0; i < c.files.length && i < 200; i++) {
        var f = c.files[i];
        h.push('<div class="c-file"><span class="c-tag">' + CAT_LABEL[f.cat] + '</span><span class="c-name">' + esc(f.name) +
          '</span><span class="c-from">' + esc(C.dirName(f.path)) + '</span><span class="c-size">' + C.formatBytes(f.size) + '</span></div>');
      }
      h.push('</div>');
      $fkeys.innerHTML = keysHtml([['↵', T.c.copy], ['esc', T.c.back]]);
    } else if (c.phase === 'copy') {
      h.push('<div class="c-head"><div class="c-big" id="cCount">' + c.done + ' / ' + c.files.length + '</div>' +
        '<div class="c-sub" id="cCurrent">' + esc(c.current) + '</div></div>' +
        '<div class="c-bar"><div class="c-fill" id="cFill"></div></div>' +
        '<div class="c-sub" id="cBytes"></div>' +
        '<div class="c-note">' + esc(c.engine === 'node' ? T.c.keepWorking : T.c.mayFreeze) + '</div>' +
        '<div class="c-actions"><button class="c-btn" data-cact="stop">' + esc(c.cancel ? T.c.stopping : T.c.stop) + '</button></div>');
      $fkeys.innerHTML = keysHtml([['esc', T.c.stop]]);
    } else if (c.phase === 'done') {
      var bad = c.errors.length;
      h.push('<div class="c-head"><div class="c-big">' + esc(bad ? T.c.doneWithErrors : T.c.done) + '</div>' +
        '<div class="c-sub">' + esc(T.c.result(c.copied, c.reused, c.relinked)) + '</div></div>');
      if (c.cancel && c.done < c.files.length) { h.push('<div class="c-note">' + esc(T.c.stoppedAt(c.done, c.files.length)) + '</div>'); }
      h.push('<div class="c-note strong">' + esc(T.c.saveHint) + '</div>');
      h.push('<div class="c-actions"><button class="c-btn primary" data-cact="close">' + esc(T.c.close) + ' <kbd>↵</kbd></button></div>');
      if (bad) {
        h.push('<div class="c-files">');
        for (i = 0; i < c.errors.length; i++) {
          h.push('<div class="c-file"><span class="c-tag err">!</span><span class="c-name">' + esc(c.errors[i].name) +
            '</span><span class="c-from">' + esc(T.c.errReason[c.errors[i].reason] || c.errors[i].reason) + '</span></div>');
        }
        h.push('</div>');
      }
      $fkeys.innerHTML = keysHtml([['↵', T.c.close]]);
    }
    $files.innerHTML = h.join('');
    $files.scrollTop = 0;
    if (c.phase === 'copy') { updateCollectProgress(); }
  }

  function updateCollectProgress() {
    var c = collect;
    var fill = $('cFill'), bytes = $('cBytes');
    if (!fill || !c.sum) { return; }
    var done = c.bytesDone + c.bytesFile, total = c.sum.bytes || 1;
    fill.style.width = Math.max(0, Math.min(100, done / total * 100)).toFixed(1) + '%';
    bytes.textContent = C.formatBytes(done) + ' / ' + C.formatBytes(c.sum.bytes);
  }

  function startCopy() {
    var c = collect;
    if (c.phase !== 'ready') { return; }
    var fs = nodeFs();
    var copier = fs ? C.createCopier(fs) : null;
    var finder = fs ? C.createFinder(fs) : null;
    c.engine = copier ? 'node' : 'host';
    c.phase = 'copy';
    setBusy(true);
    var i = 0;

    function finish() {
      setBusy(false);
      c.phase = 'done';
      state.lastResult = { item: 'c:collect', at: new Date().toISOString(),
        res: { engine: c.engine, files: c.files.length, copied: c.copied, reused: c.reused, relinked: c.relinked, errors: c.errors } };
      if (state.view === 'collect') { renderCollect(); }
    }

    function next() {
      if (c.cancel || i >= c.files.length) { finish(); return; }
      var f = c.files[i++];
      c.current = f.name;
      c.bytesFile = 0;
      renderCollect();
      var dir = C.join(c.scan.importedDir, f.cat);
      var existing = null;
      try { existing = finder ? finder.find(c.scan.projectDir, f.name, f.size) : null; } catch (eFind) { existing = null; }
      var job = existing ? Promise.resolve({ to: existing, reused: true, bytes: 0 }) : copier
        ? copier.copyInto(f.path, dir, f.name, function (doneBytes) { c.bytesFile = doneBytes; updateCollectProgress(); })
        : B.call('copyInto', { from: f.path, dir: dir, name: f.name }).then(function (r) {
            if (!r || !r.ok) { throw new Error((r && r.code) || 'copyFailed'); }
            return r.data;
          });
      job.then(function (res) {
        if (finder && !res.reused) { finder.add(c.scan.projectDir, res.to); }
        return B.call('relinkMedia', { pairs: [{ from: f.path, to: res.to }] }).then(function (rr) {
          if (res.reused) { c.reused++; } else { c.copied++; }
          if (rr && rr.ok && rr.data.relinked && !rr.data.failed) { c.relinked += rr.data.relinked; }
          else { c.errors.push({ name: f.name, reason: 'relink' }); }
        });
      }).catch(function (e) {
        c.errors.push({ name: f.name, reason: String((e && (e.code || e.message)) || e) });
      }).then(function () {
        c.done++;
        c.bytesDone += f.size || 0;
        c.bytesFile = 0;
        next();
      });
    }
    next();
  }

  function collectAction(act) {
    var c = collect;
    if (act === 'scan') { if (c.phase === 'home') { openCollect(); } }
    else if (act === 'start') { startCopy(); }
    else if (act === 'stop') { if (c.phase === 'copy' && !c.cancel) { c.cancel = true; renderCollect(); } }
    else if (act === 'close') { if (MODE === 'popup') { closeWindow(); } else { collectHome(); } }
    else if (act === 'back') { if (c.phase !== 'copy') { collectHome(); } }
  }

  function collectKey(e) {
    var c = collect;
    if (e.key === 'Enter') {
      e.preventDefault();
      if (c.phase === 'home') { collectAction('scan'); }
      else if (c.phase === 'ready') { collectAction('start'); }
      else if (c.phase === 'done') { collectAction('close'); }
      else if (c.phase === 'empty' || c.phase === 'error') { collectAction('back'); }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false, true); }
      else if (c.phase === 'home') { switchTab('fx'); }
      else if (c.phase === 'copy') { collectAction('stop'); }
      else if (c.phase === 'done') { collectAction('close'); }
      else { collectAction('back'); }
    }
  }

  /** ⌘1 / ⌘2 switch tools from anywhere. */
  function tabKey(e) {
    if (!(e.metaKey || e.ctrlKey) || e.altKey) { return false; }
    if (e.key === '1') { e.preventDefault(); switchTab('fx'); return true; }
    if (e.key === '2') { e.preventDefault(); switchTab('files'); return true; }
    if (e.key === '3') { e.preventDefault(); switchTab('zones'); return true; }
    if (e.key === '4') { e.preventDefault(); switchTab('ease'); return true; }
    if (e.key === '5') { e.preventDefault(); switchTab('yt'); return true; }
    return false;
  }

  var COMMANDS = [
    { id: 'c:collect', name: 'ფაილების შეგროვება', kind: 'command', run: openCollect,
      alt: 'collect files imported copy media consolidate gather ფაილები კოპირება იმპორტი პროექტის საქაღალდე',
      meta: 'გარე ფაილები → Imported' }
  ];

  // ------------------------------------------------------------------ safe zones
  var Z = window.QFXZones;
  var ZONE_SECONDS = 10, ZONE_REV = 'v2';                     // bump ZONE_REV when the drawings change: old PNGs are then left alone
  var $zList = $('zList'), $zPreview = $('zPreview'), $zInfo = $('zInfo'), $zStatus = $('zStatus'), $zHint = $('zHint');
  var $zApply = $('zApply'), $zToggle = $('zToggle'), $zRemove = $('zRemove'), $railDotZ = $('railDotZ');
  var zones = { active: 0, state: null, busy: false };

  function zoneFrame(p) {
    var s = zones.state;
    return (s && s.hasSequence && s.width > 0 && s.height > 0) ? [s.width, s.height] : p.base.slice();
  }

  function renderZoneList() {
    var h = [], group = '';
    for (var i = 0; i < Z.PLATFORMS.length; i++) {
      var p = Z.PLATFORMS[i];
      if (p.group !== group) { group = p.group; h.push('<div class="section">' + esc(group === 'v' ? T.z.vertical : T.z.horizontal) + '</div>'); }
      h.push('<div class="row' + (i === zones.active ? ' active' : '') + '" data-z="' + i + '" role="option">' +
        '<span class="badge z-badge"><i class="' + (p.group === 'v' ? 'tall' : 'wide') + (p.id === 'all' ? ' dash' : '') + '"></i></span>' +
        '<span class="name">' + esc(p.name) + '</span>' +
        '<span class="meta">' + esc(p.note || (p.base[0] + ' × ' + p.base[1])) + '</span>' +
        '<span class="ret">↵</span></div>');
    }
    $zList.innerHTML = h.join('');
  }

  function renderZoneSide() {
    var p = Z.PLATFORMS[zones.active], fr = zoneFrame(p), s = zones.state;
    // preview: the sequence's own shape, fitted into the side column
    var maxW = MODE === 'panel' ? 110 : 204, maxH = MODE === 'panel' ? 150 : 178;
    var k = Math.min(maxW / fr[0], maxH / fr[1]);
    var cw = Math.max(40, Math.round(fr[0] * k)), ch = Math.max(40, Math.round(fr[1] * k)), dpr = 2;
    $zPreview.width = cw * dpr; $zPreview.height = ch * dpr;
    $zPreview.style.width = cw + 'px'; $zPreview.style.height = ch + 'px';
    var ctx = $zPreview.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(cw * dpr / fr[0], ch * dpr / fr[1]);
    Z.draw(ctx, p.id, fr[0], fr[1], { background: '#2E3238' });

    var info;
    if (!s || !s.hasSequence) { info = T.z.noSeq; }
    else if (s.under) { info = T.z.willSwap((Z.get(s.under) || { name: s.under }).name); }
    else { info = T.z.willPlace(ZONE_SECONDS); }
    $zInfo.textContent = info;

    var vis = s ? s.visible : 0, hid = s ? s.hidden : 0;
    $zToggle.textContent = (vis || !hid) ? T.z.hide : T.z.show;
    $zToggle.disabled = !(vis || hid);
    $zRemove.disabled = !(vis || hid);
    $zApply.disabled = !(s && s.hasSequence);
    $zStatus.className = 'z-status' + (vis ? ' on' : '');
    $zStatus.textContent = vis ? T.z.visible(vis) : (hid ? T.z.hidden(hid) : (s && s.hasSequence ? T.z.seqSize(s.width, s.height) : ''));
    $zHint.textContent = vis ? T.z.exportHint : '';
    updateZoneDot();
  }

  function updateZoneDot() {
    var vis = zones.state ? zones.state.visible : 0;
    $railDotZ.hidden = !vis;
    $railDotZ.className = 'rail-dot on';
  }

  function refreshZones() {
    return B.call('zoneState').then(function (r) {
      zones.state = (r && r.ok) ? r.data : null;
      if (state.view === 'zones') { renderZoneSide(); } else { updateZoneDot(); }
      return zones.state;
    });
  }

  function setZoneActive(i) {
    var n = Z.PLATFORMS.length;
    zones.active = (i + n) % n;
    renderZoneList();
    renderZoneSide();
    var el = $zList.querySelector('.row.active');
    if (el && el.scrollIntoView) { el.scrollIntoView({ block: 'nearest' }); }
  }

  /** Draw the overlay at the sequence's frame size and save it as a PNG next to the project. */
  function zoneFile(p, W, H) {
    var s = zones.state || {};
    var dir = s.projectDir ? s.projectDir + '/Quick FX/Safe Zones' : (Store.dir() ? Store.dir() + '/zones' : '');
    if (!dir) { return null; }
    var path = dir + '/' + Z.fileName(p.id, W, H).replace(/\.png$/, '-' + ZONE_REV + '.png');
    if (B.fileExists(path)) { return path; }
    var c = document.createElement('canvas');
    c.width = W; c.height = H;
    Z.draw(c.getContext('2d'), p.id, W, H, {});
    var b64 = c.toDataURL('image/png').split(',')[1];
    B.makeDirs(dir);
    return B.writeBase64File(path, b64) ? path : null;
  }

  function applyZone(id, fromSearch) {
    var p = Z.get(id);
    if (!p || zones.busy || state.busy) { return; }
    zones.busy = true;
    setBusy(true);
    refreshZones().then(function (s) {
      if (!s || !s.hasSequence) { return { ok: false, code: 'noSequence' }; }
      var path = zoneFile(p, s.width, s.height);
      if (!path) { return { ok: false, code: 'zoneWriteFailed' }; }
      return B.call('zoneApply', { path: path, id: p.id, seconds: ZONE_SECONDS });
    }).then(function (res) {
      zones.busy = false;
      setBusy(false);
      state.lastResult = { item: 'zone:' + id, at: new Date().toISOString(), res: res };
      if (!res || !res.ok) { state.lastError = res; toast('err', errorText(res)); return refreshZones(); }
      var d = res.data, secs = Math.round(d.seconds * 10) / 10;
      toast('ok', d.replaced ? T.z.swapped(p.name) : T.z.placed(p.name, secs),
        (d.addedTrack ? T.z.newTrack + ' ' : '') + (d.exact ? '' : T.z.notExact), 2600);
      if (MODE === 'popup' && d.exact) { setTimeout(function () { closeWindow(); }, 700); }
      return refreshZones();
    });
  }

  function zoneToggle() {
    var s = zones.state;
    if (!s || !(s.visible || s.hidden)) { return; }
    var hide = s.visible > 0;
    B.call('zoneToggle', { hidden: hide }).then(function (r) {
      if (!r || !r.ok) { state.lastError = r; toast('err', errorText(r)); }
      else { toast('ok', hide ? T.z.nowHidden(r.data.count) : T.z.nowShown(r.data.count)); }
      refreshZones();
    });
  }

  function zoneRemove() {
    B.call('zoneRemoveAll').then(function (r) {
      if (!r || !r.ok) { state.lastError = r; toast('err', errorText(r)); }
      else { toast('ok', T.z.removed(r.data.removed)); }
      refreshZones();
    });
  }

  function zonesKey(e) {
    var k = e.key;
    if (k === 'ArrowDown') { e.preventDefault(); setZoneActive(zones.active + 1); }
    else if (k === 'ArrowUp') { e.preventDefault(); setZoneActive(zones.active - 1); }
    else if (k === 'Enter') { e.preventDefault(); applyZone(Z.PLATFORMS[zones.active].id); }
    else if (k === 'Escape') { e.preventDefault(); if (!$menu.hidden) { openMenu(false, true); } else { switchTab('fx'); } }
  }

  $zList.addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.row[data-z]') : null;
    if (!row) { return; }
    var i = Number(row.getAttribute('data-z'));
    if (i === zones.active && e.detail >= 2) { applyZone(Z.PLATFORMS[i].id); return; }
    setZoneActive(i);
  });
  $zApply.addEventListener('click', function () { applyZone(Z.PLATFORMS[zones.active].id); });
  $zToggle.addEventListener('click', zoneToggle);
  $zRemove.addEventListener('click', zoneRemove);

  // also reachable from the search box: "tiktok", "safe", "ზონ" …
  (function () {
    function runner(id) { return function () { applyZone(id, true); }; }
    for (var i = 0; i < Z.PLATFORMS.length; i++) {
      var p = Z.PLATFORMS[i];
      COMMANDS.push({ id: 'c:zone:' + p.id, name: p.group === 'h' ? p.name : 'Safe Zone — ' + p.name, kind: 'command', icon: 'zone', run: runner(p.id),
        alt: 'safe zone safezone ზონა ზონები უსაფრთხო ' + p.alt, meta: T.z.cmdMeta(ZONE_SECONDS) });
    }
    COMMANDS.push({ id: 'c:zone:toggle', name: T.z.cmdToggle, kind: 'command', icon: 'zone',
      run: function () { refreshZones().then(zoneToggle); },
      alt: 'safe zone hide show ზონა ზონები დამალვა ჩვენება ექსპორტი export', meta: 'Safe Zones' });
  })();


  // ------------------------------------------------------------------ keyframe easing ("მრუდი")
  var E = window.QFXEase;
  var $eGraph = $('eGraph'), $eOut = $('eOut'), $eIn = $('eIn'), $eBez = $('eBez'), $eList = $('eList');
  var $eName = $('eName'), $eSave = $('eSave'), $eMode = $('eMode'), $eTarget = $('eTarget'), $eApply = $('eApply'), $eStatus = $('eStatus');
  var EASE_PRESETS_FILE = 'ease-presets.json', EASE_RECORDS_FILE = 'ease-records.json', EASE_UNDO_FILE = 'ease-undo.json';
  var $eUndo = $('eUndo'), $eParams = $('eParams'), $eAll = $('eAll');
  var ease = {
    cur: E.normalize(state.settings.easeCur || E.builtin('easy')),
    mode: state.settings.easeMode === 'all' ? 'all' : 'playhead',
    info: null, busy: false, drag: null, hover: -1, scale: null, geo: null, user: [],
    include: state.settings.easeInclude || {},        // parameters ticked before (by effect + name): ticked again next time
    paramsSig: ''
  };

  // Which parameters get the curve. Premiere cannot tell a script which keyframes are selected,
  // so they are ticked here. A parameter is pre-ticked only if it is the only one or was ticked before.
  function easeParams() { return (ease.info && ease.info.params) || []; }
  function easeTicked() {
    var ps = easeParams(), out = [];
    if (ps.length === 1) { return [ps[0].id]; }
    for (var i = 0; i < ps.length; i++) { if (ease.include[ps[i].id]) { out.push(ps[i].id); } }
    return out;
  }
  function easeSetTick(ids, on) {
    for (var i = 0; i < ids.length; i++) { if (on) { ease.include[ids[i]] = 1; } else { delete ease.include[ids[i]]; } }
    var keys = [], k;
    for (k in ease.include) { if (ease.include.hasOwnProperty(k)) { keys.push(k); } }
    if (keys.length > 300) { for (i = 0; i < keys.length - 300; i++) { delete ease.include[keys[i]]; } }
    state.settings.easeInclude = ease.include; save(LS.settings, state.settings);
    ease.paramsSig = '';
    renderEaseTarget();
  }
  function renderEaseParams() {
    var ps = easeParams(), ticked = easeTicked(), sig = '', i;
    for (i = 0; i < ps.length; i++) { sig += ps[i].id + ':' + (ticked.indexOf(ps[i].id) >= 0 ? 1 : 0) + ':' + ps[i].clips + ';'; }
    if (sig === ease.paramsSig) { return; }
    ease.paramsSig = sig;
    var h = [];
    for (i = 0; i < ps.length; i++) {
      var on = ticked.indexOf(ps[i].id) >= 0;
      h.push('<button class="e-param' + (on ? ' on' : '') + '" data-id="' + esc(ps[i].id) + '" role="checkbox" aria-checked="' + (on ? 'true' : 'false') + '" title="' + esc(ps[i].name) + '">' +
        '<i class="e-check"></i><span class="e-pname">' + esc(ps[i].param) + '</span><span class="e-pcomp">' + esc(ps[i].comp) + (ps[i].clips > 1 ? ' ×' + ps[i].clips : '') + '</span></button>');
    }
    $eParams.innerHTML = h.length ? h.join('') : '<div class="e-none">' + esc(T.e.noParamsYet) + '</div>';
    $eAll.hidden = ps.length < 2;
    $eAll.textContent = ticked.length === ps.length ? T.e.none : T.e.all;
  }

  function easeUserPresets() {
    var list = Store.read(EASE_PRESETS_FILE, []), out = [];
    if (list && list.length) {
      for (var i = 0; i < list.length; i++) { if (list[i] && list[i].name) { out.push(assign({ name: String(list[i].name), own: true }, E.normalize(list[i]))); } }
    }
    return out;
  }

  // ---- what was baked where, and the undo history: kept NEXT TO THE PROJECT, so they travel with it —
  //      another editor (or this one on another Mac) can still re-curve, return to Linear, or undo.
  //      <project folder>/Quick FX/Curves/<project name>.json   { records: [...], undo: [...] }
  var easeCache = { project: '', at: 0, data: null }, easeLocalOnly = {};
  function easePath(project) {
    var p = String(project || '').replace(/\\/g, '/');
    return p ? C.dirName(p) + '/Quick FX/Curves/' + C.baseName(p).replace(/\.prproj$/i, '') + '.json' : '';
  }
  function easeParse(text) {
    if (!text) { return null; }
    try { var d = JSON.parse(text); return (d && typeof d === 'object' && !(d instanceof Array)) ? d : null; } catch (e) { return null; }
  }
  /** Saved under a new name (v3 → v4)? The clips are the same ones, so the newest neighbour's records still apply. */
  function easeSibling(file) {
    var dir = C.dirName(file), names = B.listDir(dir), best = null;
    for (var i = 0; i < names.length; i++) {
      if (!/\.json$/i.test(names[i]) || dir + '/' + names[i] === file) { continue; }
      var d = easeParse(B.readTextFile(dir + '/' + names[i]));
      if (d && d.records && d.records.length && (!best || (d.saved || 0) > (best.saved || 0))) { best = d; }
    }
    return best ? best.records : null;
  }
  function easeLoad(project) {
    if (!project) { return { records: [], undo: [], where: 'none' }; }
    if (easeCache.project === project && easeCache.data && Date.now() - easeCache.at < 8000) { return easeCache.data; }
    var data = null, file = easePath(project);
    var d = easeLocalOnly[project] ? null : easeParse(B.readTextFile(file));
    if (d) { data = { records: d.records || [], undo: d.undo || [], where: 'project' }; }
    if (!data) {                                                 // this computer, before 1.14 (or a folder that cannot be written)
      var oldR = (Store.read(EASE_RECORDS_FILE, {}) || {})[project], oldU = (Store.read(EASE_UNDO_FILE, {}) || {})[project];
      if ((oldR && oldR.length) || (oldU && oldU.length)) { data = { records: oldR || [], undo: oldU || [], where: 'computer' }; }
    }
    if (!data) { var sib = easeSibling(file); data = sib ? { records: sib, undo: [], where: 'sibling' } : { records: [], undo: [], where: 'new' }; }
    easeCache = { project: project, at: Date.now(), data: data };
    return data;
  }
  function easeSave(project, data) {
    if (!project) { return; }
    var file = easePath(project), okFile = false;
    if (!easeLocalOnly[project]) {
      B.makeDirs(C.dirName(file));
      okFile = B.writeTextFile(file, JSON.stringify({ v: 1, project: C.baseName(String(project).replace(/\\/g, '/')), saved: Date.now(), records: data.records, undo: data.undo }));
    }
    if (!okFile) {
      // read-only volume, no rights: keep working from this computer's own files, as before
      easeLocalOnly[project] = true;
      var allR = Store.read(EASE_RECORDS_FILE, {}) || {}, allU = Store.read(EASE_UNDO_FILE, {}) || {};
      allR[project] = data.records;
      if (data.undo.length) { allU[project] = data.undo; } else { delete allU[project]; }
      Store.write(EASE_RECORDS_FILE, allR); Store.write(EASE_UNDO_FILE, allU);
    }
    data.where = okFile ? 'project' : 'computer';
    easeCache = { project: project, at: Date.now(), data: data };
  }

  function easeRecords(project) { return easeLoad(project).records; }
  function easeSaveRecords(project, drop, add) {
    if (!project) { return []; }
    var data = easeLoad(project), list = data.records, keep = [], displaced = [], i, j;
    for (i = 0; i < list.length; i++) {
      var r = list[i], gone = false;
      for (j = 0; j < drop.length; j++) {
        var d = drop[j];
        if (r.c === d.c && r.k === d.k && r.p === d.p && r.a < d.b - 0.0005 && r.b > d.a + 0.0005) { gone = true; break; }
      }
      if (gone) { displaced.push(r); } else { keep.push(r); }
    }
    for (i = 0; i < add.length; i++) { keep.push(add[i]); }
    if (keep.length > 1500) { keep = keep.slice(keep.length - 1500); }
    easeSave(project, { records: keep, undo: data.undo });
    return displaced;
  }

  // ---- undo: the last few Applies per project, kept on disk so closing the window does not lose them
  function easeUndoStack(project) { return easeLoad(project).undo.slice(); }
  function easeUndoWrite(project, stack) {
    if (!project) { return; }
    while (stack.length > 12) { stack.shift(); }
    while (stack.length > 1 && JSON.stringify(stack).length > 700000) { stack.shift(); }
    easeSave(project, { records: easeLoad(project).records, undo: stack });
  }

  function undoEase() {
    var project = ease.info ? ease.info.project : '';
    var stack = easeUndoStack(project);
    if (!stack.length || ease.busy || state.busy) { return; }
    var step = stack[stack.length - 1];
    ease.busy = true; setBusy(true); renderEaseTarget();
    B.call('easeUndo', { ops: step.ops }).then(function (res) {
      ease.busy = false; setBusy(false);
      state.lastResult = { item: 'ease-undo', at: new Date().toISOString(), res: res };
      stack.pop();
      easeUndoWrite(project, stack);
      if (!res || !res.ok) { state.lastError = res; toast('err', errorText(res)); return refreshEase(); }
      easeSaveRecords(project, step.recAdd || [], step.recBack || []);
      toast(res.data.missing ? 'warn' : 'ok', T.e.undone(res.data.params), res.data.missing ? T.e.undoMissing(res.data.missing) : '', res.data.missing ? 4200 : 1800);
      return refreshEase();
    });
  }

  // ---- the speed graph (time →, speed ↑), After Effects style
  function easeGeometry() {
    var r = $eGraph.getBoundingClientRect(), dpr = 2;
    var w = Math.max(160, Math.round(r.width)), h = Math.max(120, Math.round(r.height));
    if ($eGraph.width !== w * dpr || $eGraph.height !== h * dpr) { $eGraph.width = w * dpr; $eGraph.height = h * dpr; }
    var sc = ease.scale;
    if (!sc) {
      var rg = E.range(ease.cur);
      var hi = Math.max(1.6, rg.max, ease.cur.v0, ease.cur.v1) * 1.14;
      var lo = Math.min(0, rg.min, ease.cur.v0, ease.cur.v1);
      sc = { min: lo < 0 ? lo * 1.2 - 0.1 : -hi * 0.06, max: hi };
    }
    var g = { w: w, h: h, dpr: dpr, L: 16, T: 14, W: w - 32, H: h - 34, min: sc.min, max: sc.max };
    g.px = function (x) { return g.L + x * g.W; };
    g.py = function (s) { return g.T + (g.max - s) / (g.max - g.min) * g.H; };
    g.sOf = function (py) { return g.max - (py - g.T) / g.H * (g.max - g.min); };
    ease.geo = g;
    return g;
  }

  function drawEase() {
    var g = easeGeometry(), c = $eGraph.getContext('2d'), e = ease.cur, i;
    c.setTransform(g.dpr, 0, 0, g.dpr, 0, 0);
    c.clearRect(0, 0, g.w, g.h);
    // grid
    c.lineWidth = 1;
    for (i = 0; i <= 10; i++) {
      c.strokeStyle = (i === 0 || i === 5 || i === 10) ? '#2A2A2A' : '#191919';
      c.beginPath(); c.moveTo(Math.round(g.px(i / 10)) + 0.5, g.T); c.lineTo(Math.round(g.px(i / 10)) + 0.5, g.T + g.H); c.stroke();
    }
    var stepS = g.max - g.min > 5 ? 1 : 0.5;
    for (var s = Math.ceil(g.min / stepS) * stepS; s <= g.max; s += stepS) {
      if (Math.abs(s) < 1e-6) { continue; }
      c.strokeStyle = '#191919';
      c.beginPath(); c.moveTo(g.L, Math.round(g.py(s)) + 0.5); c.lineTo(g.L + g.W, Math.round(g.py(s)) + 0.5); c.stroke();
    }
    // average speed (what a linear move would be)
    c.save(); c.strokeStyle = '#4A4A4A'; c.setLineDash([3, 5]);
    c.beginPath(); c.moveTo(g.L, Math.round(g.py(1)) + 0.5); c.lineTo(g.L + g.W, Math.round(g.py(1)) + 0.5); c.stroke(); c.restore();
    c.fillStyle = '#6E6E6E'; c.font = '10px -apple-system, "Helvetica Neue", Arial, sans-serif'; c.textBaseline = 'bottom';
    c.fillText('linear', g.L + 4, g.py(1) - 3);
    // zero line, dotted like AE's
    c.save(); c.strokeStyle = 'rgba(253,74,0,0.6)'; c.setLineDash([1.5, 3]);
    c.beginPath(); c.moveTo(g.L, Math.round(g.py(0)) + 0.5); c.lineTo(g.L + g.W, Math.round(g.py(0)) + 0.5); c.stroke(); c.restore();
    // reference: how far the move has got (0 → 100%), drawn over the full height
    var bz = E.toBezier(e);
    c.strokeStyle = '#4A4A4A'; c.lineWidth = 1.25; c.beginPath();
    for (i = 0; i <= 60; i++) {
      var vy = E.valueAt(bz, i / 60), yy = g.py(0) - Math.max(-0.08, Math.min(1.04, vy)) * (g.py(0) - g.T - 4);
      if (i === 0) { c.moveTo(g.px(0), yy); } else { c.lineTo(g.px(i / 60), yy); }
    }
    c.stroke();
    // the speed curve
    var pts = E.speedCurve(e, 140);
    c.beginPath(); c.moveTo(g.px(pts[0].x), g.py(0));
    for (i = 0; i < pts.length; i++) { c.lineTo(g.px(pts[i].x), g.py(pts[i].s)); }
    c.lineTo(g.px(pts[pts.length - 1].x), g.py(0)); c.closePath();
    c.fillStyle = 'rgba(253,74,0,0.11)'; c.fill();
    c.beginPath();
    for (i = 0; i < pts.length; i++) { if (i === 0) { c.moveTo(g.px(pts[i].x), g.py(pts[i].s)); } else { c.lineTo(g.px(pts[i].x), g.py(pts[i].s)); } }
    c.strokeStyle = '#FD4A00'; c.lineWidth = 2.5; c.lineJoin = 'round'; c.stroke();
    // handles: length = influence, height = speed at the keyframe
    var hs = [[0, e.v0, e.i0, e.v0], [1, e.v1, 1 - e.i1, e.v1]];
    for (i = 0; i < 2; i++) {
      var h = hs[i], hot = ease.hover === i || (ease.drag && ease.drag.which === i);
      c.strokeStyle = '#FFFFFF'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(g.px(h[0]), g.py(h[1])); c.lineTo(g.px(h[2]), g.py(h[3])); c.stroke();
      c.fillStyle = '#FD4A00'; c.fillRect(g.px(h[0]) - 4, g.py(h[1]) - 4, 8, 8);                    // the keyframe
      c.beginPath(); c.arc(g.px(h[2]), g.py(h[3]), hot ? 6.5 : 5, 0, Math.PI * 2);
      c.fillStyle = '#FFFFFF'; c.fill();
      if (hot) { c.lineWidth = 2; c.strokeStyle = '#FD4A00'; c.stroke(); }
    }
    // readouts
    function pc(n) { return Math.round(n * 100) + '%'; }
    function sp(n) { return (Math.round(n * 100) / 100) + '×'; }
    $eOut.innerHTML = esc(T.e.out) + ' <b>' + pc(e.i0) + '</b>' + (Math.abs(e.v0) > 0.005 ? ' · ' + sp(e.v0) : '');
    $eIn.innerHTML = esc(T.e.inn) + ' <b>' + pc(e.i1) + '</b>' + (Math.abs(e.v1) > 0.005 ? ' · ' + sp(e.v1) : '');
    $eBez.textContent = E.label(e);
  }

  function drawThumb(cv, e) {
    var w = 46, h = 26, dpr = 2, c = cv.getContext('2d'), pts = E.speedCurve(e, 40), rg = E.range(e), i;
    cv.width = w * dpr; cv.height = h * dpr;
    var hi = Math.max(1.2, rg.max) * 1.1, lo = Math.min(0, rg.min);
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.strokeStyle = cv.getAttribute('data-on') ? '#000000' : '#FD4A00'; c.lineWidth = 1.6; c.lineJoin = 'round'; c.beginPath();
    for (i = 0; i < pts.length; i++) {
      var x = 2 + pts[i].x * (w - 4), y = 3 + (hi - pts[i].s) / (hi - lo) * (h - 6);
      if (i === 0) { c.moveTo(x, y); } else { c.lineTo(x, y); }
    }
    c.stroke();
  }

  function renderEaseList() {
    ease.user = easeUserPresets();
    var all = E.PRESETS.concat(ease.user), h = [], i;
    for (i = 0; i < all.length; i++) {
      var p = all[i], on = E.same(p, ease.cur);
      if (i === E.PRESETS.length) { h.push('<div class="e-label e-mine">' + esc(T.e.mine) + '</div>'); }
      h.push('<div class="e-row' + (on ? ' on' : '') + '" data-p="' + i + '"><canvas class="e-thumb"' + (on ? ' data-on="1"' : '') + '></canvas>' +
        '<span class="e-name">' + esc(p.name) + '</span>' + (p.key ? '<kbd>' + p.key + '</kbd>' : '') +
        (p.own ? '<button class="e-del" data-del="' + (i - E.PRESETS.length) + '" title="' + esc(T.e.del) + '" aria-label="' + esc(T.e.del) + '">×</button>' : '') + '</div>');
    }
    $eList.innerHTML = h.join('');
    var cvs = $eList.querySelectorAll('.e-thumb');
    for (i = 0; i < cvs.length; i++) { drawThumb(cvs[i], all[i]); }
  }

  function setEase(e, keepScale) {
    ease.cur = E.normalize(e);
    if (!keepScale) { ease.scale = null; }
    state.settings.easeCur = ease.cur;
    save(LS.settings, state.settings);
    drawEase();
    if (!keepScale) { renderEaseList(); }
  }

  function renderEaseTarget() {
    var d = ease.info, text, can = false;
    if (!d || !d.hasSequence) { text = T.z.noSeq; }
    else if (!d.clips) { text = T.e.selectClip; }
    else if (!d.segments) { text = ease.mode === 'all' ? T.e.noKeys : T.e.parkPlayhead; }
    else {
      var ticked = easeTicked();
      can = ticked.length > 0;
      text = can
        ? T.e.chosen(ticked.length, d.params.length) + (ease.mode === 'playhead' && d.seconds ? ' · ' + (Math.round(d.seconds * 100) / 100) + ' ' + T.e.sec : '')
        : T.e.pickParams;
    }
    renderEaseParams();
    $eTarget.textContent = text;
    $eTarget.title = '';
    $eTarget.className = 'e-target' + (can ? ' ok' : '');
    $eApply.disabled = !can || ease.busy;
    var steps = easeUndoStack(d ? d.project : '').length;
    $eUndo.disabled = !steps || ease.busy;
    $eUndo.title = steps ? T.e.undoTip(steps) : T.e.undoNone;
    $eStatus.textContent = d && d.clips ? T.e.clips(d.clips) : '';
    var qb = document.querySelectorAll('[data-ease]');
    for (var i = 0; i < qb.length; i++) { qb[i].disabled = !can || ease.busy; }
    var mb = $eMode.querySelectorAll('button');
    for (i = 0; i < mb.length; i++) { mb[i].classList.toggle('on', mb[i].getAttribute('data-mode') === ease.mode); }
  }

  function refreshEase() {
    var project = ease.info ? ease.info.project : '';
    return B.call('easeInfo', { mode: ease.mode, records: easeRecords(project) }).then(function (r) {
      var d = (r && r.ok) ? r.data : null;
      // the first answer tells us which project it is: ask again with that project's records
      if (d && d.project !== project && easeRecords(d.project).length) { ease.info = d; return refreshEase(); }
      ease.info = d;
      if (state.view === 'ease') { renderEaseTarget(); }
      return d;
    });
  }

  /** e = {i0,v0,i1,v1} or null for "back to linear". */
  function applyEase(e, fromSearch) {
    if (ease.busy || state.busy) { return; }
    ease.busy = true; setBusy(true); renderEaseTarget();
    refreshEase().then(function (d) {
      if (!d || !d.hasSequence) { return { ok: false, code: 'noSequence' }; }
      var only = easeTicked();
      if (d.segments && !only.length) { return { ok: false, code: 'noParams' }; }
      return B.call('easeApply', { mode: ease.mode, lut: e ? E.lut(e) : null, records: easeRecords(d.project), only: only });
    }).then(function (res) {
      ease.busy = false; setBusy(false);
      state.lastResult = { item: 'ease', at: new Date().toISOString(), res: res && res.ok ? assign(assign({}, res.data), { add: res.data.add.length, drop: res.data.drop.length, undo: (res.data.undo || []).length }) : res };
      if (!res || !res.ok) {
        state.lastError = res; toast('err', errorText(res));
        if (res && res.code === 'noParams' && state.view !== 'ease') { switchTab('ease'); }      // came from the search box: go and tick
        return refreshEase();
      }
      var d = res.data, notes = [];
      var project = ease.info ? ease.info.project : '';
      var displaced = easeSaveRecords(project, d.drop, d.add);
      if (d.undo && d.undo.length) {
        var stack = easeUndoStack(project);
        stack.push({ at: Date.now(), ops: d.undo, recAdd: d.add, recBack: displaced });
        easeUndoWrite(project, stack);
      }
      if (d.partial) { notes.push(T.e.partial); }
      if (d.skipped.flat) { notes.push(T.e.flat(d.skipped.flat)); }
      if (d.skipped.tooShort) { notes.push(T.e.tooShort(d.skipped.tooShort)); }
      if (d.skipped.unsupported) { notes.push(T.e.unsupported(d.skipped.unsupported)); }
      toast(d.partial ? 'warn' : 'ok', d.linear ? T.e.linearDone(d.params) : T.e.applied(d.params, d.added), notes.join(' '), notes.length ? 4200 : 2200);
      if (fromSearch && MODE === 'popup' && !notes.length) { setTimeout(function () { closeWindow(); }, 600); }
      return refreshEase();
    });
  }

  function easeQuick(id, fromSearch) {
    if (id === 'linear') { applyEase(null, fromSearch); return; }
    var p = E.builtin(id);
    if (!p) { return; }
    if (state.view === 'ease') { setEase(p); }
    applyEase(p, fromSearch);
  }

  // ---- dragging the handles
  function easePoint(ev) {
    var r = $eGraph.getBoundingClientRect();
    return { x: ev.clientX - r.left, y: ev.clientY - r.top };
  }
  function easeHit(pt) {
    var g = ease.geo, e = ease.cur;
    if (!g) { return -1; }
    var ks = [[g.px(e.i0), g.py(e.v0)], [g.px(1 - e.i1), g.py(e.v1)]], best = -1, bd = 18 * 18;
    for (var i = 0; i < 2; i++) {
      var dx = ks[i][0] - pt.x, dy = ks[i][1] - pt.y, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
  $eGraph.addEventListener('mousedown', function (ev) {
    var which = easeHit(easePoint(ev));
    if (which < 0) { return; }
    ev.preventDefault();
    ease.drag = { which: which };
    ease.scale = { min: ease.geo.min, max: ease.geo.max };               // keep the axes still while dragging
    drawEase();
  });
  window.addEventListener('mousemove', function (ev) {
    if (state.view !== 'ease') { return; }
    var pt = easePoint(ev), g = ease.geo;
    if (!ease.drag) {
      var hv = easeHit(pt);
      if (hv !== ease.hover) { ease.hover = hv; $eGraph.style.cursor = hv >= 0 ? 'grab' : 'default'; drawEase(); }
      return;
    }
    var x = Math.max(0, Math.min(1, (pt.x - g.L) / g.W)), s = g.sOf(pt.y), e = assign({}, ease.cur);
    if (Math.abs(s) < (g.max - g.min) * 0.035) { s = 0; }                 // snaps to "at rest" and to "linear"
    else if (Math.abs(s - 1) < (g.max - g.min) * 0.03) { s = 1; }
    if (ev.shiftKey) { s = ease.drag.which === 0 ? e.v0 : e.v1; }         // ⇧ = only the length
    if (ease.drag.which === 0) { e.i0 = x; e.v0 = s; } else { e.i1 = 1 - x; e.v1 = s; }
    setEase(e, true);
  });
  window.addEventListener('mouseup', function () {
    if (!ease.drag) { return; }
    ease.drag = null; ease.scale = null;
    drawEase(); renderEaseList();
  });

  $eList.addEventListener('click', function (ev) {
    var del = ev.target.closest ? ev.target.closest('[data-del]') : null;
    if (del) {
      var list = easeUserPresets(); list.splice(Number(del.getAttribute('data-del')), 1);
      Store.write(EASE_PRESETS_FILE, list); renderEaseList(); return;
    }
    var row = ev.target.closest ? ev.target.closest('.e-row') : null;
    if (!row) { return; }
    var p = E.PRESETS.concat(ease.user)[Number(row.getAttribute('data-p'))];
    if (!p) { return; }
    setEase(p);
    if (ev.detail >= 2 && !$eApply.disabled) { applyEase(ease.cur); }
  });
  function easeSavePreset() {
    var name = String($eName.value || '').replace(/^\s+|\s+$/g, '');
    if (!name) { $eName.focus(); return; }
    var list = easeUserPresets(), found = false;
    for (var i = 0; i < list.length; i++) { if (list[i].name.toLowerCase() === name.toLowerCase()) { list[i] = assign({ name: name }, ease.cur); found = true; } }
    if (!found) { list.push(assign({ name: name }, ease.cur)); }
    for (i = 0; i < list.length; i++) { delete list[i].own; }
    if (!Store.write(EASE_PRESETS_FILE, list)) { toast('err', T.e.saveFailed); return; }
    $eName.value = ''; $eName.blur();
    renderEaseList();
    toast('ok', T.e.saved(name));
  }
  $eSave.addEventListener('click', easeSavePreset);
  $eApply.addEventListener('click', function () { applyEase(ease.cur); });
  $eUndo.addEventListener('click', undoEase);
  $eParams.addEventListener('click', function (ev) {
    var b = ev.target.closest ? ev.target.closest('.e-param') : null;
    if (!b) { return; }
    var id = b.getAttribute('data-id');
    easeSetTick([id], easeTicked().indexOf(id) < 0);
  });
  $eAll.addEventListener('click', function () {
    var ps = easeParams(), ids = [], i;
    for (i = 0; i < ps.length; i++) { ids.push(ps[i].id); }
    easeSetTick(ids, easeTicked().length !== ps.length);
  });
  $eMode.addEventListener('click', function (ev) {
    var b = ev.target.closest ? ev.target.closest('button[data-mode]') : null;
    if (!b) { return; }
    ease.mode = b.getAttribute('data-mode');
    state.settings.easeMode = ease.mode; save(LS.settings, state.settings);
    renderEaseTarget(); refreshEase();
  });
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest ? ev.target.closest('[data-ease]') : null;
    if (b && !b.disabled) { easeQuick(b.getAttribute('data-ease')); }
  });

  function easeKey(e) {
    var typing = document.activeElement === $eName;
    if (e.key === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false, true); } else if (typing) { $eName.blur(); } else { switchTab('fx'); }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (typing) { easeSavePreset(); } else if (!$eApply.disabled) { applyEase(ease.cur); }
    } else if (e.key === 'F9') { e.preventDefault(); easeQuick('easy'); }
  }

  function openEase() { ease.scale = null; drawEase(); renderEaseList(); renderEaseTarget(); refreshEase(); }
  window.addEventListener('resize', function () { if (state.view === 'ease') { drawEase(); } });

  // from the search box too: "easy ease", "ease in", "მრუდი" …
  (function () {
    function runner(id) { return function () { easeQuick(id, true); }; }
    var items = [['easy', 'Easy Ease', 'F9'], ['in', 'Ease In', ''], ['out', 'Ease Out', ''], ['linear', 'Linear keyframes', '']];
    for (var i = 0; i < items.length; i++) {
      COMMANDS.push({ id: 'c:ease:' + items[i][0], name: items[i][1], kind: 'command', icon: 'ease', run: runner(items[i][0]),
        alt: 'ease easing keyframe keyframes f9 smooth მრუდი ეიზი ქეიფრეიმი სიჩქარე ' + items[i][1], meta: T.e.cmdMeta });
    }
  })();

  // ------------------------------------------------------------------ YouTube: link → file in the Project panel
  var Y = window.QFXYt;
  var $yUrl = $('yUrl'), $yMain = $('yMain'), $yGo = $('yGo'), $yQueue = $('yQueue'), $yDest = $('yDest'), $yStatus = $('yStatus');
  var $yPaste = $('yPaste'), $railDotY = $('railDotY');
  var YT_FRESH_MS = 3 * 24 * 3600 * 1000;                       // yt-dlp checks for its own update this often
  var yt = {
    phase: 'idle',            // the chooser: setup | install | idle | loading | info | error
    queue: [], job: null, seq: 0,                                // downloads: waiting, running (job), finished — one runs at a time
    url: '', info: null, token: 0, timer: null,
    mode: state.settings.ytMode || 'both', height: Number(state.settings.ytHeight) || 1080,
    target: null, prog: null, error: null, result: null, cookies: '', install: null, home: '',
    sec: { on: false, from: '', to: '' }                        // only a part of the video: typed times, as typed
  };

  function ytEngine() {
    if (window.__QFX_YT_ENGINE) { return window.__QFX_YT_ENGINE; }
    if (yt.engine !== undefined) { return yt.engine; }
    yt.engine = null;
    try {
      var req = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
      if (!req) { throw new Error('node is not available'); }
      var os = req('os'), dir = Store.dir();
      if (!dir) { throw new Error('no user data folder'); }
      yt.home = os.homedir();
      yt.engine = Y.createEngine({ fs: req('fs'), os: os, child_process: req('child_process'), https: req('https'), http: req('http'),
        process: (window.cep_node && window.cep_node.process) || req('process') }, { binDir: dir + '/bin', arch: os.arch() });
    } catch (e) { yt.engineError = String(e && e.message || e); }
    return yt.engine;
  }

  /** Text on the macOS clipboard (pbpaste), or null when it cannot be read this way. */
  function ytClipboard() {
    if (typeof window.__QFX_CLIPBOARD === 'function') { return window.__QFX_CLIPBOARD(); }
    try {
      var req = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
      if (!req) { return null; }
      return String(req('child_process').execFileSync('/usr/bin/pbpaste', [], { encoding: 'utf8', timeout: 2000 }));
    } catch (e) { return null; }
  }

  function ytWaiting() { var n = 0; for (var i = 0; i < yt.queue.length; i++) { if (yt.queue[i].state === 'wait') { n++; } } return n; }
  function ytBusy() { return yt.phase === 'install' || !!yt.job || ytWaiting() > 0; }
  function ytDiag() {
    var st = null;
    try { st = yt.engine ? yt.engine.status() : null; } catch (e) { st = String(e); }
    var q = [];
    for (var i = 0; i < yt.queue.length; i++) { q.push({ state: yt.queue[i].state, tag: yt.queue[i].tag, error: yt.queue[i].error || null }); }
    return { phase: yt.phase, error: yt.error, engine: st, engineError: yt.engineError || null, target: yt.target, mode: yt.mode, height: yt.height, queue: q };
  }

  function ytQualities() {
    var all = (yt.info && yt.info.qualities) || [], out = [];
    for (var i = 0; i < all.length; i++) { if (all[i].height >= 360) { out.push(all[i]); } }
    return out.length ? out : all;
  }
  /** The quality that will be downloaded: the remembered one when this video has it, else the best that needs no converting. */
  function ytChosen() {
    var list = ytQualities(), i;
    for (i = 0; i < list.length; i++) { if (list[i].height === yt.height) { return list[i]; } }
    for (i = 0; i < list.length; i++) { if (list[i].height <= yt.height) { return list[i]; } }
    for (i = 0; i < list.length; i++) { if (list[i].direct) { return list[i]; } }
    return list[0] || null;
  }
  /** The part to download: { start, end } in seconds · null for the whole video · { error } while the typed times do not make sense. */
  function ytSection() {
    if (!yt.sec.on || !yt.info) { return null; }
    var dur = yt.info.duration || 0, f = yt.sec.from.replace(/\s/g, ''), t = yt.sec.to.replace(/\s/g, '');
    if (!f && !t) { return { error: T.y.sec.empty }; }
    var a = f ? Y.parseTime(f) : 0, b = t ? Y.parseTime(t) : (dur || null);
    if (a === null) { return { error: T.y.sec.badFrom }; }
    if (b === null) { return { error: T.y.sec.badTo }; }
    if (dur && a >= dur) { return { error: T.y.sec.past(Y.clock(dur)) }; }
    if (dur && b > dur) { b = dur; }
    if (b <= a) { return { error: T.y.sec.order }; }
    return { start: a, end: b };
  }
  function ytSize() {
    var q = ytChosen(), i = yt.info, bytes = 0, sec = ytSection();
    if (!i || (sec && sec.error)) { return ''; }
    if (yt.mode !== 'audio' && q) { bytes += q.bytes || 0; }
    if (yt.mode !== 'video') { bytes += i.audioBytes || 0; }
    if (sec && i.duration) { bytes = bytes * (sec.end - sec.start) / i.duration; }
    return bytes > 0 ? T.y.about(C.formatBytes(bytes)) : '';
  }
  function ytSecText() {
    var sec = ytSection();
    if (!sec) { return ''; }
    if (sec.error) { return sec.error; }
    var len = Y.clock(sec.end - sec.start) + (sec.end - sec.start < 60 ? ' წმ' : '');
    return (yt.mode === 'audio' ? T.y.sec.lenAudio : T.y.sec.len)(len.replace(/^0:(\d\d) წმ$/, function (m, s2) { return Number(s2) + ' წმ'; }));
  }
  /** While typing in the two time fields nothing is re-drawn (the caret would jump): only the line under them and the button. */
  function ytSecUpdate() {
    var sec = ytSection(), $i = $('ySecInfo');
    if ($i) { $i.textContent = ytSecText(); $i.className = 'y-secinfo' + (sec && sec.error ? ' bad' : ''); }
    $yStatus.textContent = yt.phase === 'info' ? ytSize() : '';
    if (yt.phase === 'info') { $yGo.disabled = !!(sec && sec.error); }
  }
  function ytSiteName() { return (yt.info && yt.info.siteName) || 'YouTube'; }
  /** <project folder>/Imported/<YouTube | TikTok | …>; without a saved project: ~/Downloads/Quick FX */
  function ytDir() {
    if (yt.target && yt.target.projectDir) { return yt.target.projectDir + '/Imported/' + ytSiteName(); }
    return (yt.home || '') + '/Downloads/Quick FX';
  }

  function ytCardHtml() {
    var i = yt.info;
    return '<div class="y-card">' + (i.thumbnail ? '<img class="y-thumb" src="' + esc(i.thumbnail) + '" alt="" onerror="this.style.visibility=\'hidden\'">' : '<span class="y-thumb"></span>') +
      '<div class="y-meta"><div class="y-title">' + esc(i.title || yt.url) + '</div><div class="y-by">' +
      (i.site && i.site !== 'youtube' ? '<b class="y-site">' + esc(i.siteName) + '</b>' : '') + esc(i.uploader) +
      (i.duration ? (i.uploader ? ' · ' : '') + Y.clock(i.duration) : '') +
      (i.clean ? '<span class="y-clean">✓ ' + esc(T.y.clean) + '</span>' : '') + '</div></div></div>';
  }

  function ytProgressHtml() {
    return '<div class="y-prog"><div class="y-prow"><span id="yPhase" class="y-phase"></span><span id="yPct" class="y-pct"></span></div>' +
      '<div class="c-bar" id="yBarWrap"><div class="c-fill" id="yBar"></div></div><div id="yRate" class="y-rate"></div></div>';
  }

  function renderYt() {
    var h = [], p = yt.phase, i;
    if (p === 'setup' || p === 'install') {
      h.push('<div class="f-card y-setup"><div class="f-main"><div class="f-title">' + esc(T.y.setupTitle) + '</div><div class="f-desc">' + esc(T.y.setupDesc) + '</div>' +
        (p === 'install' ? ytProgressHtml() : '') + '</div>' +
        (p === 'setup' ? '<button class="c-btn primary" data-yact="install">' + esc(T.y.setupBtn) + '</button>' : '') + '</div>');
    } else if (p === 'idle') {
      h.push('<div class="y-empty"><div class="y-big">' + esc(T.y.idleTitle) + '</div><ol>');
      for (i = 0; i < T.y.idle.length; i++) { h.push('<li>' + esc(T.y.idle[i]) + '</li>'); }
      h.push('</ol></div>');
    } else if (p === 'loading') {
      h.push('<div class="y-empty y-wait"><span class="spinner"></span><div class="y-big">' + esc(yt.updating ? T.y.updating : T.y.loading) + '</div><div class="c-note">' + esc(T.y.loadingSub) + '</div></div>');
    } else if (p === 'info') {
      var list = ytQualities(), q = ytChosen(), modes = ['both', 'video', 'audio'];
      h.push(ytCardHtml());
      h.push('<div class="y-label">' + esc(T.y.what) + '</div><div class="seg y-seg" role="group">');
      for (i = 0; i < modes.length; i++) {
        var off = (modes[i] !== 'video' && !yt.info.hasAudio) || (modes[i] !== 'audio' && !list.length);
        h.push('<button data-ymode="' + modes[i] + '"' + (yt.mode === modes[i] ? ' class="on"' : '') + (off ? ' disabled' : '') + '>' + esc(T.y.modes[modes[i]]) + '</button>');
      }
      h.push('</div>');
      if (yt.mode === 'audio') {
        h.push('<div class="c-note">' + esc(yt.info.site === 'tiktok' ? T.y.audioOwn : T.y.audioNote) + '</div>');
      } else {
        h.push('<div class="y-label">' + esc(T.y.quality) + '</div><div class="y-chips">');
        for (i = 0; i < list.length; i++) {
          h.push('<button class="y-chip' + (q && list[i].height === q.height ? ' on' : '') + (list[i].direct ? '' : ' conv') + '" data-yq="' + list[i].height + '"' +
            (list[i].direct ? (list[i].codec === 'hevc' ? ' title="' + esc(T.y.hevcTip) + '"' : '') : ' title="' + esc(T.y.convertTip) + '"') + '>' + esc(Y.label(list[i])) +
            (list[i].direct ? (list[i].codec === 'hevc' ? '<i>HEVC</i>' : '') : '<i>H.264 ⟳</i>') + '</button>');
        }
        h.push('</div>');
        if (q && !q.direct && !yt.sec.on) { h.push('<div class="c-note y-warn">' + esc(yt.info.site === 'youtube' ? T.y.convertNote : T.y.convertOther) + '</div>'); }
      }
      var sec = ytSection();
      h.push('<div class="y-label">' + esc(T.y.sec.label) + '</div><div class="y-secrow"><div class="seg y-seg" role="group">' +
        '<button data-ysec="all"' + (yt.sec.on ? '' : ' class="on"') + '>' + esc(T.y.sec.all) + '</button>' +
        '<button data-ysec="part"' + (yt.sec.on ? ' class="on"' : '') + '>' + esc(T.y.sec.part) + '</button></div>');
      if (yt.sec.on) {
        h.push('<label class="y-time"><input id="yFrom" type="text" autocomplete="off" spellcheck="false" placeholder="0:00" value="' + esc(yt.sec.from) + '" aria-label="' + esc(T.y.sec.from) + '"><span>' + esc(T.y.sec.from) + '</span></label>' +
          '<label class="y-time"><input id="yTo" type="text" autocomplete="off" spellcheck="false" placeholder="' + esc(yt.info.duration ? Y.clock(yt.info.duration) : T.y.sec.toEnd) + '" value="' + esc(yt.sec.to) + '" aria-label="' + esc(T.y.sec.to) + '"><span>' + esc(T.y.sec.to) + '</span></label>');
      }
      h.push('</div>' + (yt.sec.on ? '<div id="ySecInfo" class="y-secinfo' + (sec && sec.error ? ' bad' : '') + '">' + esc(ytSecText()) + '</div>' : ''));
    } else if (p === 'error') {
      var e = yt.error || {}, code = T.y.err[e.code] ? e.code : 'ytFailed';
      h.push('<div class="y-err"><div class="y-big">' + esc(T.y.err[code]) + '</div>' + (e.message ? '<div class="c-note y-tech">' + esc(e.message) + '</div>' : '') +
        '<div class="c-actions"><button class="c-btn" data-yact="retry">' + esc(T.y.retry) + '</button>' +
        (e.code === 'ytLogin' && !yt.cookies ? '<button class="c-btn" data-yact="cookies">' + esc(T.y.cookies) + '</button>' : '') + '</div>' +
        (e.code === 'ytLogin' && !yt.cookies ? '<div class="c-note">' + esc(T.y.cookiesNote) + '</div>' : '') + '</div>');
    }
    $yMain.innerHTML = h.join('');
    $yUrl.disabled = $yPaste.disabled = p === 'setup' || p === 'install';
    $yGo.hidden = p === 'setup' || p === 'install';
    $yGo.disabled = !((p === 'info' && !(ytSection() || {}).error) || ((p === 'idle' || p === 'error') && Y.isUrl($yUrl.value)));
    $yGo.innerHTML = esc(p === 'info' ? (yt.job || ytWaiting() ? T.y.q.add : T.y.go) : T.y.fetch) + ' <kbd>↵</kbd>';
    $yDest.textContent = (yt.target && yt.target.saved) ? T.y.destSite(ytSiteName()) : (yt.target ? T.y.destUnsaved : '');
    $yDest.className = 'e-target' + (yt.target && !yt.target.saved ? ' y-unsaved' : '');
    $yDest.title = ytDir();
    $yStatus.textContent = p === 'info' ? ytSize() : '';
    $railDotY.hidden = !ytBusy();
    if (p === 'install') { ytProgress(); }
    renderYtQueue();
  }

  // ---- the queue strip
  function ytJobSub(j) {
    if (j.state === 'wait') { return T.y.q.wait; }
    if (j.state === 'error') { return (T.y.err[j.error && j.error.code] || T.y.err.ytFailed); }
    if (j.state === 'done') {
      var r = j.result || {};
      return (r.importError ? T.y.q.noImport : (r.existed ? T.y.q.existed : T.y.q.inProject)) + (r.bytes ? ' · ' + C.formatBytes(r.bytes) : '');
    }
    var g = j.prog || {}, spin = g.phase === 'merge' || g.phase === 'convert' || g.phase === 'fix' || (g.phase === 'download' && !g.part), bits = [g.label || T.y.part.start];
    if (!spin) {
      bits[0] += ' ' + Math.floor(Math.max(0, Math.min(100, g.overall || 0))) + '%';
      if (g.speed) { bits.push(String(g.speed).replace('iB', 'B')); }
      if (g.eta) { bits.push(T.y.left(g.eta)); }
    } else if (g.phase !== 'download') { bits.push(T.y.elapsed(Y.clock((Date.now() - g.since) / 1000))); }
    return bits.join(' · ');
  }
  function renderYtQueue() {
    var q = yt.queue, h = [], finished = 0, i;
    $yQueue.hidden = !q.length;
    if (!q.length) { $yQueue.innerHTML = ''; return; }
    for (i = 0; i < q.length; i++) { if (q[i].state === 'done' || q[i].state === 'error') { finished++; } }
    h.push('<div class="yq-head"><span>' + esc(T.y.q.title) + ' · ' + q.length + '</span>' +
      (finished ? '<button class="yq-clear" data-yq-clear="1">' + esc(T.y.q.clear) + '</button>' : '') + '</div><div class="yq-list">');
    for (i = 0; i < q.length; i++) {
      var j = q[i], ico = j.state === 'done' ? ((j.result || {}).importError ? '!' : '✓') : (j.state === 'error' ? '✕' : (j.state === 'wait' ? '' : ''));
      h.push('<div class="yq-row st-' + j.state + ((j.result || {}).importError ? ' warn' : '') + '" data-yjob="' + j.id + '"' +
        ((j.result || {}).importError ? ' title="' + esc(j.result.path) + '"' : (j.error && j.error.message ? ' title="' + esc(j.error.message) + '"' : '')) + '>' +
        '<span class="yq-ico">' + (j.state === 'down' ? '<span class="spinner"></span>' : (j.state === 'wait' ? '<i class="yq-dot"></i>' : ico)) + '</span>' +
        '<span class="yq-main"><span class="yq-title">' + esc(j.title) + '</span>' +
        '<span class="yq-sub"><b>' + esc(j.tag) + '</b><span class="yq-state">' + esc(ytJobSub(j)) + '</span></span></span>' +
        (j.state === 'error' ? '<button class="yq-btn" data-yq-retry="' + j.id + '" title="' + esc(T.y.q.retryTip) + '">↻</button>' : '') +
        '<button class="yq-btn" data-yq-x="' + j.id + '" title="' + esc(j.state === 'down' || j.state === 'wait' ? T.y.q.cancelTip : T.y.q.removeTip) + '">✕</button>' +
        (j.state === 'down' ? '<span class="yq-bar"><i></i></span>' : '') + '</div>');
    }
    h.push('</div>');
    $yQueue.innerHTML = h.join('');
    ytJobProgress();
  }
  /** The running row only: its text and its bar (no re-draw, so buttons do not jump under the mouse). */
  function ytJobProgress() {
    var j = yt.job;
    if (!j) { return; }
    var row = $yQueue.querySelector('[data-yjob="' + j.id + '"]');
    if (!row) { return; }
    var g = j.prog || {}, spin = g.phase === 'merge' || g.phase === 'convert' || g.phase === 'fix' || (g.phase === 'download' && !g.part);
    var st = row.querySelector('.yq-state'), bar = row.querySelector('.yq-bar');
    if (st) { st.textContent = ytJobSub(j); }
    if (bar) { bar.className = 'yq-bar' + (spin ? ' y-spin' : ''); bar.firstChild.style.width = (spin ? 100 : Math.max(0, Math.min(100, g.overall || 0))) + '%'; }
  }

  function ytProgress() {
    var g = yt.prog, $bar = $('yBar'), $phase = $('yPhase');
    if (!g || !$bar || !$phase) { return; }
    var spin = g.phase === 'merge' || g.phase === 'convert' || g.phase === 'fix' || (g.phase === 'download' && !g.part);
    var pct = Math.max(0, Math.min(100, g.overall || 0));
    $('yBarWrap').className = 'c-bar' + (spin ? ' y-spin' : '');
    $bar.style.width = (spin ? 100 : pct) + '%';
    $phase.textContent = g.label || '';
    $('yPct').textContent = spin ? '' : Math.floor(pct) + '%';
    var bits = [];
    if (!spin && g.speed) { bits.push(g.speed.replace('iB', 'B')); }
    if (!spin && g.eta) { bits.push(T.y.left(g.eta)); }
    if (!spin && g.cut && g.part) { bits.push(Y.clock(g.done || 0) + ' / ' + Y.clock(g.cut)); }
    if (spin && g.phase !== 'download') { bits.push(T.y.elapsed(Y.clock((Date.now() - g.since) / 1000))); }
    $('yRate').textContent = bits.join(' · ');
  }

  function ytFail(e) {
    yt.error = { code: (e && e.code) || 'ytFailed', message: (e && e.message) || '', log: (e && e.log) || '' };
    state.lastError = yt.error;
    yt.phase = 'error';
    renderYt();
  }

  /** Is the engine there? → 'setup' card when not. Also asks Premiere where downloads go. */
  function openYt() {
    var eng = ytEngine();
    if (yt.phase !== 'install') {
      if (!eng) { yt.error = { code: 'noNode', message: yt.engineError || '' }; yt.phase = 'error'; }
      else if (!eng.status().ready) { yt.phase = 'setup'; }
      else if (yt.phase === 'setup' || (yt.phase === 'error' && yt.error && yt.error.code === 'noNode')) { yt.phase = 'idle'; }
    }
    renderYt();
    B.call('ytTarget').then(function (r) { if (r && r.ok) { yt.target = r.data; if (state.view === 'yt') { renderYt(); } } });
    if (!$yUrl.disabled) { $yUrl.focus(); $yUrl.select(); }
  }

  function ytInstall() {
    var eng = ytEngine();
    if (!eng || yt.phase === 'install') { return; }
    yt.phase = 'install';
    yt.prog = { phase: 'download', part: 1, overall: 0, label: T.y.part.start, since: Date.now() };
    renderYt();
    eng.install(function (i, n, name, pct) {
      if (pct < 0) { yt.prog.phase = 'fix'; yt.prog.label = T.y.checking(name); }
      else { yt.prog.overall = (i + pct / 100) / n * 100; yt.prog.label = T.y.installing(i, n, name); }
      ytProgress();
    }).then(function () {
      state.settings.ytUpdated = Date.now(); save(LS.settings, state.settings);
      yt.phase = 'idle'; renderYt();
      toast('ok', T.y.installed);
      if (Y.isUrl($yUrl.value)) { ytFetch($yUrl.value); } else if (state.view === 'yt') { $yUrl.focus(); }
    }, function (e) {
      yt.phase = 'setup';
      ytFail({ code: e && e.code === 'ytToolBroken' ? 'ytToolBroken' : 'installFailed', message: String(e && e.message || e) });
    });
  }

  function ytSetUrl(text) {
    $yUrl.value = String(text || '').replace(/^\s+|\s+$/g, '');
    if (Y.isUrl($yUrl.value)) { ytFetch($yUrl.value); } else { renderYt(); }
  }

  function ytFetch(url) {
    var eng = ytEngine();
    url = String(url || '').replace(/^\s+|\s+$/g, '');
    if (!eng || yt.phase === 'install' || !Y.isUrl(url)) { return; }
    if (!eng.status().ready) { yt.phase = 'setup'; renderYt(); return; }
    var token = ++yt.token;
    if (url !== yt.url) { yt.cookies = ''; }
    if (url !== yt.url) { var t0 = Y.timeFromUrl(url); yt.sec = { on: false, from: t0 ? Y.clock(t0) : '', to: '' }; }
    yt.url = url; yt.info = null; yt.error = null; yt.result = null; yt.phase = 'loading';
    var stale = !yt.job && Date.now() - (Number(state.settings.ytUpdated) || 0) > YT_FRESH_MS;   // never swap the engine under a running download
    yt.updating = stale;
    renderYt();
    var first = !stale ? Promise.resolve() : eng.update().then(function () {
      state.settings.ytUpdated = Date.now(); save(LS.settings, state.settings);
    }, function () {}).then(function () { yt.updating = false; if (token === yt.token && state.view === 'yt') { renderYt(); } });
    first.then(function () { return eng.info(url, yt.cookies); }).then(function (info) {
      if (token !== yt.token) { return; }
      if (info.live) { ytFail({ code: 'ytLive' }); return; }
      yt.info = info;
      if (!info.qualities.length && info.hasAudio) { yt.mode = 'audio'; }
      else if (!info.hasAudio && yt.mode !== 'video') { yt.mode = 'video'; }
      yt.phase = 'info';
      renderYt();
    }, function (e) { if (token === yt.token && e.code !== 'ytCancelled') { ytFail(e); } });
  }

  function ytJobTag(mode, q, sec) {
    var bits = [];
    if (mode === 'audio') { bits.push(T.y.q.audio); }
    else { bits.push(Y.label(q)); if (mode === 'video') { bits.push(T.y.q.onlyVideo); } }
    if (sec) { bits.push(Y.clock(sec.start) + '–' + Y.clock(sec.end)); }
    return bits.join(' · ');
  }

  /** The chooser's button: put what is chosen into the queue. The chooser stays, so the next part or quality of the same video is one more click. */
  function ytStart() {
    var eng = ytEngine(), info = yt.info, q = ytChosen(), sec = ytSection();
    if (!eng || !info || yt.phase !== 'info' || (yt.mode !== 'audio' && !q) || (sec && sec.error)) { return; }
    var mode = yt.mode, both = mode === 'both', dir = ytDir(), base = Y.outBase(info, mode, q, sec), i;
    for (i = 0; i < yt.queue.length; i++) {
      var o = yt.queue[i];
      if ((o.state === 'wait' || o.state === 'down') && o.opts.dir === dir && o.opts.base === base) { toast('warn', T.y.q.dup, '', 2000); return; }
    }
    for (i = yt.queue.length - 1; i >= 0; i--) {                 // the same thing asked again after it finished or failed: one row, not two
      if (yt.queue[i].opts.dir === dir && yt.queue[i].opts.base === base) { yt.queue.splice(i, 1); }
    }
    var vBytes = (q && q.bytes) || 0, aBytes = info.audioBytes || 0;
    var ahead = ytWaiting() + (yt.job ? 1 : 0);
    yt.queue.push({
      id: ++yt.seq, state: 'wait', title: info.title || yt.url, tag: ytJobTag(mode, q, sec), mode: mode,
      w: !both ? [1] : (vBytes && aBytes ? [vBytes / (vBytes + aBytes), aBytes / (vBytes + aBytes)] : [0.92, 0.08]),
      cut: sec ? sec.end - sec.start : 0, prog: null, result: null, error: null,
      bin: info.siteName || 'YouTube',
      opts: { url: info.url || yt.url, mode: mode, height: q ? q.height : 0, px: q ? q.px : 0, fps: q ? q.fps : 0, direct: q ? q.direct : true,
        dir: dir, base: base, cookies: yt.cookies, section: sec, site: info.site || 'youtube', fid: q ? q.fid : '', sound: q ? !!q.sound : false }
    });
    if (ahead) { toast('ok', T.y.q.added(ahead), '', 1800); }
    ytPump();
    renderYt();
  }

  /** Starts the next waiting download when nothing is running. */
  function ytPump() {
    var eng = ytEngine(), job = null, i;
    if (!eng || yt.job || yt.phase === 'install') { return; }
    for (i = 0; i < yt.queue.length; i++) { if (yt.queue[i].state === 'wait') { job = yt.queue[i]; break; } }
    if (!job) { return; }
    var mode = job.mode, both = mode === 'both', w = job.w;
    function partLabel(n) { return mode === 'audio' || (both && n === 2) ? T.y.part.audio : T.y.part.video; }
    function finish() {
      yt.job = null;
      var left = ytWaiting();
      if (!left && state.view !== 'yt') {
        var done = 0;
        for (var k = 0; k < yt.queue.length; k++) { if (yt.queue[k].state === 'done') { done++; } }
        if (done) { toast('ok', done === 1 ? T.y.doneToast(job.title) : T.y.q.allDone(done), '', 3500); }
      }
      ytPump();
      if (state.view === 'yt') { renderYt(); } else { $railDotY.hidden = !ytBusy(); }
    }
    job.state = 'down'; yt.job = job;
    job.prog = { phase: 'download', part: 0, overall: 0, label: T.y.part.start, since: Date.now(), speed: '', eta: '', cut: job.cut, done: 0 };
    eng.download(job.opts, function (ev) {
      var g = job.prog;
      if (g.cut) {
        // a section is one ffmpeg run (picture and sound together): its clock is the progress
        if (ev.type === 'time') {
          g.part = 1; g.phase = 'download'; g.label = T.y.part.section;
          g.done = Math.min(ev.sec, g.cut); g.overall = g.done / g.cut * 100;
          g.eta = ev.speed > 0 ? Y.clock((g.cut - g.done) / ev.speed) : '';
        } else if (ev.type === 'phase') { g.phase = ev.phase; g.label = T.y.part[ev.phase] || ''; g.since = Date.now(); }
      }
      else if (ev.type === 'part') { g.part = Math.min(g.part + 1, w.length); g.phase = 'download'; g.label = partLabel(g.part); }
      else if (ev.type === 'progress') {
        if (!g.part) { g.part = 1; g.label = partLabel(1); }
        if (g.phase !== 'download') { return; }
        var before = 0;
        for (var k = 0; k < g.part - 1; k++) { before += w[k]; }
        if (ev.pct != null) { g.overall = (before + w[g.part - 1] * ev.pct / 100) * 100; }
        g.speed = ev.speed; g.eta = ev.eta;
      } else if (ev.type === 'phase') { g.phase = ev.phase; g.label = T.y.part[ev.phase] || ''; g.since = Date.now(); }
      if (state.view === 'yt') { ytJobProgress(); }
    }).then(function (res) {
      return B.call('ytImport', { path: res.path, bin: job.bin }).then(function (r) {
        job.result = { path: res.path, bytes: res.bytes, existed: !!res.existed, name: r && r.ok ? r.data.name : '', importError: !(r && r.ok) };
        if (!(r && r.ok)) { state.lastError = r; }
        state.lastResult = job.result;
        job.state = 'done';
        finish();
      });
    }, function (e) {
      if (e && e.code === 'ytCancelled') {
        var at = yt.queue.indexOf(job);
        if (at >= 0) { yt.queue.splice(at, 1); }
        if (state.view === 'yt') { toast('warn', T.y.cancelled, '', 1800); }
      } else {
        job.state = 'error';
        job.error = { code: (e && e.code) || 'ytFailed', message: (e && e.message) || '', log: (e && e.log) || '' };
        state.lastError = job.error;
      }
      finish();
    });
  }

  function ytPrimary() {
    if (yt.phase === 'info') { ytStart(); }
    else if (yt.phase === 'idle' || yt.phase === 'error') { ytFetch($yUrl.value); }
  }

  /** A link from the clipboard into the link field (whole field replaced) → looked up. False when the clipboard cannot be read this way. */
  function ytPasteLink() {
    var clip = ytClipboard();
    if (clip === null) { return false; }
    var v = clip.replace(/^\s+|\s+$/g, '').split(/\s/)[0] || '';
    if (!Y.isUrl(v)) { toast('warn', T.y.err.ytBadUrl, '', 2200); return true; }
    if ($yUrl.disabled) { return true; }
    $yUrl.value = v; clearTimeout(yt.timer);
    if (v !== yt.url || (yt.phase !== 'info' && yt.phase !== 'loading')) { ytFetch(v); }
    return true;
  }
  function isPasteKey(e) { return (e.metaKey || e.ctrlKey) && !e.altKey && (e.keyCode === 86 || e.code === 'KeyV'); }

  function ytKey(e) {
    // ⌘V anywhere on this screen (except while typing a time) pastes the link — read from the macOS clipboard,
    // so it works whatever Premiere thinks has keyboard focus
    if (isPasteKey(e) && !(document.activeElement && (document.activeElement.id === 'yFrom' || document.activeElement.id === 'yTo'))) {
      if (ytPasteLink()) { e.preventDefault(); } else if (!$yUrl.disabled) { $yUrl.focus(); $yUrl.select(); }
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false, true); }
      else if (document.activeElement && (document.activeElement.id === 'yFrom' || document.activeElement.id === 'yTo')) { document.activeElement.blur(); }
      else if (document.activeElement === $yUrl && $yUrl.value) { $yUrl.value = ''; yt.token++; yt.url = ''; yt.info = null; yt.phase = 'idle'; renderYt(); }
      else { switchTab('fx'); }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (document.activeElement && (document.activeElement.id === 'yFrom' || document.activeElement.id === 'yTo')) {
        if (document.activeElement.id === 'yFrom' && !yt.sec.to && $('yTo')) { $('yTo').focus(); }       // ↵ in "from" → on to "to"
        else if (!$yGo.disabled) { ytPrimary(); }
      }
      else if (document.activeElement === $yUrl && Y.isUrl($yUrl.value) && $yUrl.value.replace(/^\s+|\s+$/g, '') !== yt.url) { ytFetch($yUrl.value); }
      else if (!$yGo.disabled && !$yGo.hidden) { ytPrimary(); }
    }
  }

  $yUrl.addEventListener('input', function () {
    clearTimeout(yt.timer);
    var v = $yUrl.value.replace(/^\s+|\s+$/g, '');
    if (Y.isUrl(v) && v !== yt.url) { yt.timer = setTimeout(function () { ytFetch(v); }, 250); }
    else if (yt.phase !== 'setup' && yt.phase !== 'install') { $yGo.disabled = !((yt.phase === 'info' && !(ytSection() || {}).error) || ((yt.phase === 'idle' || yt.phase === 'error') && Y.isUrl(v))); }
  });
  $yUrl.addEventListener('paste', function (e) {
    var text = '';
    try { text = (e.clipboardData || window.clipboardData).getData('text') || ''; } catch (e2) { text = ''; }
    var v = text.replace(/^\s+|\s+$/g, '').split(/\s/)[0] || '';
    if (!v) { return; }
    e.preventDefault();
    $yUrl.value = v; clearTimeout(yt.timer);
    if (Y.isUrl(v) && (v !== yt.url || (yt.phase !== 'info' && yt.phase !== 'loading'))) { ytFetch(v); } else if (yt.phase !== 'info') { renderYt(); }
  });
  $yPaste.addEventListener('click', function () {
    $yUrl.focus(); $yUrl.select();
    var okPaste = false, clip = ytClipboard();
    if (clip !== null) { $yUrl.value = clip.replace(/^\s+|\s+$/g, '').split(/\s/)[0] || ''; okPaste = true; }
    else { try { okPaste = document.execCommand('paste'); } catch (e) { okPaste = false; } }
    var v = $yUrl.value.replace(/^\s+|\s+$/g, '');
    if (okPaste && v && !Y.isUrl(v)) { $yUrl.value = ''; toast('warn', T.y.err.ytBadUrl, '', 2500); return; }
    if (Y.isUrl(v) && v !== yt.url) { clearTimeout(yt.timer); ytFetch(v); }
  });
  $yMain.addEventListener('input', function (e) {
    if (!e.target || (e.target.id !== 'yFrom' && e.target.id !== 'yTo')) { return; }
    yt.sec[e.target.id === 'yFrom' ? 'from' : 'to'] = e.target.value;
    ytSecUpdate();
  });
  $yGo.addEventListener('click', ytPrimary);
  $yQueue.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-yq-x],[data-yq-retry],[data-yq-clear]') : null;
    if (!t) { return; }
    var i, id, job = null;
    if (t.hasAttribute('data-yq-clear')) {
      for (i = yt.queue.length - 1; i >= 0; i--) { if (yt.queue[i].state === 'done' || yt.queue[i].state === 'error') { yt.queue.splice(i, 1); } }
      renderYt(); return;
    }
    id = Number(t.getAttribute('data-yq-x') || t.getAttribute('data-yq-retry'));
    for (i = 0; i < yt.queue.length; i++) { if (yt.queue[i].id === id) { job = yt.queue[i]; break; } }
    if (!job) { return; }
    if (t.hasAttribute('data-yq-retry')) { job.state = 'wait'; job.error = null; ytPump(); renderYt(); return; }
    if (job.state === 'down') { var eng = ytEngine(); if (eng) { eng.cancel(); } return; }        // the row goes when the engine confirms
    yt.queue.splice(yt.queue.indexOf(job), 1);
    renderYt();
  });
  $yMain.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-ymode],[data-yq],[data-yact],[data-ysec]') : null;
    if (!t || t.disabled) { return; }
    if (t.hasAttribute('data-ysec')) {
      yt.sec.on = t.getAttribute('data-ysec') === 'part';
      renderYt();
      if (yt.sec.on && $('yFrom')) { var $f = yt.sec.from && !yt.sec.to ? $('yTo') : $('yFrom'); $f.focus(); $f.select(); }
      return;
    }
    if (t.hasAttribute('data-ymode')) { yt.mode = t.getAttribute('data-ymode'); state.settings.ytMode = yt.mode; save(LS.settings, state.settings); renderYt(); }
    else if (t.hasAttribute('data-yq')) { yt.height = Number(t.getAttribute('data-yq')); state.settings.ytHeight = yt.height; save(LS.settings, state.settings); renderYt(); }
    else {
      var act = t.getAttribute('data-yact');
      if (act === 'install') { ytInstall(); }
      else if (act === 'retry' || act === 'cookies') {
        if (act === 'cookies') { yt.cookies = 'chrome'; }
        var eng = ytEngine();
        if (!eng) { openYt(); }
        else if (!eng.status().ready) { ytInstall(); }
        else { ytFetch(yt.url || $yUrl.value); }
      }
    }
  });
  setInterval(function () { if (state.view === 'yt') { if (yt.phase === 'install') { ytProgress(); } if (yt.job) { ytJobProgress(); } } }, 1000);
  window.addEventListener('beforeunload', function () { try { if (yt.engine && yt.job) { yt.engine.cancel(); } } catch (e) {} });

  COMMANDS.push({ id: 'c:yt', name: T.y.cmd, kind: 'command', icon: 'yt', run: function () { switchTab('yt'); },
    alt: 'youtube tiktok download yt video audio mp3 mp4 link url watermark იუთუბი იუთუბიდან ტიკტოკი ტიკტოკიდან ჩამოტვირთვა ჩაწერა ვიდეო აუდიო ლინკი ბმული', meta: T.y.cmdMeta });

  // ------------------------------------------------------------------ background watcher
  function autoState() {
    var a = Store.read('auto-state.json', null);
    return { settings: Store.settings(), state: a, alive: !!(a && a.alive && Date.now() - a.alive < 15000) };
  }

  /** The watcher normally starts with Premiere; if it is not running, opening Quick FX starts it. */
  function wakeWatcher() {
    if (!B.available) { return; }
    var a = autoState();
    if (a.settings.auto && !a.alive) { B.openExtension(AUTO_ID); }
  }

  function autoInfoHtml() {
    var a = autoState();
    if (!a.settings.auto) { return esc(T.auto.off); }
    if (!a.alive) { return '<span style="color:var(--err)">' + esc(T.auto.dead) + '</span>'; }
    var out = esc(T.auto.on), st = a.state, i;
    if (st.queue) { out += '<br>' + esc(T.auto.copying(st.current || '…', st.queue)); }
    for (i = (st.log || []).length - 1; i >= 0; i--) {
      if (st.log[i].kind === 'ok' || st.log[i].kind === 'err') {
        out += '<br>' + esc(T.auto.last) + ' ' + (st.log[i].kind === 'err' ? '✕ ' : '') + esc(st.log[i].text);
        break;
      }
    }
    return out;
  }

  // ------------------------------------------------------------------ menu
  function updateMenuInfo() {
    var fxCount = (state.effects.video || []).length + (state.effects.audio || []).length;
    var lines = [];
    lines.push('ეფექტები: ' + fxCount + ' · პრესეტები: ' + state.presets.length);
    if (state.presetFile) { lines.push('პრესეტების ფაილი: ' + esc(state.presetFile.path)); }
    else { lines.push('პრესეტების ფაილი ვერ მოიძებნა'); }
    if (state.presetError) { lines.push('<span style="color:var(--err)">' + esc(state.presetError) + '</span>'); }
    lines.push(autoInfoHtml());
    if (state.info) { lines.push('Premiere ' + esc(state.info.appVersion) + ' · Quick FX ' + VERSION); }
    lines.push('<span class="menu-brand">MELIA VISION PLUGIN</span>');
    $menuInfo.innerHTML = lines.join('<br>');
  }

  function openMenu(open, keepFocus) {
    $menu.hidden = !open;
    $menuBtn.classList.toggle('open', open);
    if (open) { updateMenuInfo(); }
    else if (!keepFocus && state.view === 'list') { $q.focus(); }
  }

  function copyDiagnostics() {
    var d = {
      quickfx: VERSION, mode: MODE, extensionId: extId,
      info: state.info,
      effects: { video: (state.effects.video || []).length, audio: (state.effects.audio || []).length },
      presetFile: state.presetFile, presets: state.presets.length,
      presetSkipped: state.presetSkipped.length, presetError: state.presetError,
      lastError: state.lastError, lastResult: state.lastResult,
      collect: { phase: collect.phase, engine: collect.engine || null, node: !!nodeFs() },
      auto: autoState(),
      zones: zones.state,
      youtube: ytDiag(),
      ease: { file: ease.info && ease.info.project ? easePath(ease.info.project) : '', where: easeCache.data ? easeCache.data.where : '', records: easeCache.data ? easeCache.data.records.length : 0, undo: easeCache.data ? easeCache.data.undo.length : 0 },
      userAgent: navigator.userAgent
    };
    var ta = document.createElement('textarea');
    ta.value = JSON.stringify(d, null, 2);
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { /* ignore */ }
    document.body.removeChild(ta);
    openMenu(false);
    toast('ok', T.diagCopied);
  }

  // ------------------------------------------------------------------ events
  $q.addEventListener('input', function () {
    if (Y && Y.isUrl($q.value)) { var link = $q.value; $q.value = ''; switchTab('yt'); ytSetUrl(link); return; }
    state.active = 0; render();
  });

  $q.addEventListener('keydown', function (e) {
    if (e.isComposing) { return; }
    if (tabKey(e)) { return; }
    if (isPasteKey(e)) {
      var clip = ytClipboard(), link = clip === null ? '' : (clip.replace(/^\s+|\s+$/g, '').split(/\s/)[0] || '');
      if (Y.isUrl(link)) { e.preventDefault(); e.stopPropagation(); switchTab('yt'); ytSetUrl(link); }
      return;
    }
    var k = e.key;
    if (k === 'ArrowDown' || (e.ctrlKey && (k === 'n' || k === 'j'))) { setActive(state.active + 1); e.preventDefault(); }
    else if (k === 'ArrowUp' || (e.ctrlKey && (k === 'p' || k === 'k'))) { setActive(state.active - 1); e.preventDefault(); }
    else if (k === 'PageDown') { setActive(state.active + 8); e.preventDefault(); }
    else if (k === 'PageUp') { setActive(state.active - 8); e.preventDefault(); }
    else if (k === 'Tab') { setActive(state.active + (e.shiftKey ? -1 : 1)); e.preventDefault(); }
    else if (k === 'Enter') { apply(state.rows[state.active], e.shiftKey || MODE === 'panel'); e.preventDefault(); }
    else if (k === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false); }
      else if ($q.value) { $q.value = ''; state.active = 0; render(); }
      else if (MODE === 'popup') { closeWindow(); }
    }
    else if ((e.metaKey || e.ctrlKey) && (k === 'r' || k === 'R')) { e.preventDefault(); loadEverything(true); }
    else if ((e.metaKey || e.ctrlKey) && !e.altKey && (e.keyCode === 68 || e.code === 'KeyD')) { e.preventDefault(); toggleFav(state.rows[state.active] && state.rows[state.active].item); }
  });

  // typing anywhere goes to the search field
  document.addEventListener('keydown', function (e) {
    if (document.activeElement !== $q && document.activeElement !== $('eName') && document.activeElement !== $('yUrl') && tabKey(e)) { return; }
    if (state.view === 'collect') { collectKey(e); return; }
    if (state.view === 'zones') { zonesKey(e); return; }
    if (state.view === 'ease') { easeKey(e); return; }
    if (state.view === 'yt') { ytKey(e); return; }
    if (document.activeElement === $q || e.metaKey || e.ctrlKey || e.altKey) { return; }
    if (e.key === 'Escape') { if (!$menu.hidden) { openMenu(false); } else if (MODE === 'popup') { closeWindow(); } return; }
    if (e.key && e.key.length === 1) { $q.focus(); }
  });

  var lastMouse = { x: -1, y: -1 };
  $list.addEventListener('mousemove', function (e) {
    if (e.clientX === lastMouse.x && e.clientY === lastMouse.y) { return; }
    lastMouse = { x: e.clientX, y: e.clientY };
    var row = e.target.closest ? e.target.closest('.row') : null;
    if (row) { setActive(Number(row.getAttribute('data-i'))); }
  });
  $list.addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.row') : null;
    if (!row) { return; }
    var i = Number(row.getAttribute('data-i'));
    if (e.target.closest('[data-star]')) { toggleFav(state.rows[i] && state.rows[i].item); $q.focus(); return; }
    state.active = i;
    apply(state.rows[i], e.shiftKey || MODE === 'panel');
  });

  $menuBtn.addEventListener('click', function () { openMenu($menu.hidden); });
  $menu.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button[data-act]') : null;
    if (!b) { return; }
    var act = b.getAttribute('data-act');
    if (act === 'refresh') { openMenu(false); loadEverything(true); }
    if (act === 'diag') { copyDiagnostics(); }
  });
  $files.addEventListener('click', function (e) {
    var cb = e.target.closest ? e.target.closest('[data-cact]') : null;
    if (cb) { collectAction(cb.getAttribute('data-cact')); }
  });
  $files.addEventListener('change', function (e) {
    if (!e.target || e.target.id !== 'autoCollect') { return; }
    Store.write('settings.json', { auto: e.target.checked });
    if (e.target.checked) { state.openedAt = Date.now(); wakeWatcher(); }
    updateAuto();
  });
  $('rail').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('.rail-btn[data-tab]') : null;
    if (b && !b.disabled) { switchTab(b.getAttribute('data-tab')); }
  });
  $closeOnBlur.checked = !!state.settings.closeOnBlur;
  $closeOnBlur.addEventListener('change', function () {
    state.settings.closeOnBlur = $closeOnBlur.checked;
    save(LS.settings, state.settings);
  });
  document.addEventListener('mousedown', function (e) {
    if (!$menu.hidden && !$menu.contains(e.target) && !$menuBtn.contains(e.target)) { openMenu(false); }
  });

  window.addEventListener('focus', function () {
    state.hadFocus = true;
    if (state.view !== 'list') { return; }
    if ($menu.hidden) { $q.focus(); }
    refreshSelection();
  });

  window.addEventListener('blur', function () {
    if (MODE !== 'popup' || !state.settings.closeOnBlur || !state.hadFocus || state.busy || collectBusy()) { return; }
    if (Date.now() - state.openedAt < 900) { return; }
    setTimeout(function () {
      if (!document.hasFocus() && !state.busy && !collectBusy()) { closeWindow(); }
    }, 200);
  });

  // ------------------------------------------------------------------ init
  function init() {
    document.documentElement.classList.add('mode-' + MODE);
    if (MODE === 'panel') {
      $blurOpt.hidden = true;
    }
    B.registerKeys();

    // instant results from the last session while Premiere answers
    var cached = load(LS.effects, null);
    if (cached && cached.data) { state.effects = cached.data; buildItems(); }
    render();
    switchTab('fx');
    updateAuto();
    $q.focus();
    setTimeout(function () { if (state.view === 'list') { $q.focus(); } }, 60);

    if (!B.available) { state.loaded = true; render(); return; }
    loadEverything(false);
    setTimeout(wakeWatcher, 1500);
    setTimeout(refreshZones, 900);
    setInterval(function () { if (!document.hidden) { updateAuto(); } }, 2000);
    setInterval(function () { if (!document.hidden && state.view === 'zones' && !zones.busy) { refreshZones(); } }, 2500);
    setInterval(function () { if (!document.hidden && state.view === 'ease' && !ease.busy && !ease.drag) { refreshEase(); } }, 1800);
    if (MODE === 'panel') {
      setInterval(function () { if (!document.hidden && !state.busy && state.view === 'list') { refreshSelection(); } }, 2500);
    }
  }

  // exposed for tests / debugging
  window.QuickFXUI = { state: state, render: render, apply: apply, loadEverything: loadEverything, mode: MODE };

  init();
})();
