/*
 * Quick FX — panel UI.
 * Popup mode (Modeless window): type, Enter, it applies and closes.
 * Panel mode (docked): stays open.
 */
(function () {
  'use strict';

  var B = window.QFXBridge, S = window.QFXSearch, P = window.QFXPresets, Store = window.QFXStore;
  var AUTO_ID = 'com.goga.quickfx.auto';
  var VERSION = '1.27.0';
  var extId = B.extensionId();
  var MODE = /\.panel$/.test(extId) ? 'panel' : 'popup';
  var LS = { usage: 'qfx.usage.v1', effects: 'qfx.effects.v1', settings: 'qfx.settings.v1', favs: 'qfx.favs.v1' };
  var RESULT_LIMIT = 80;
  var EMPTY_EFFECT_LIMIT = 120;

  var T = {
    videoFx: 'ვიდეო ეფექტი',
    audioFx: 'აუდიო ეფექტი',
    preset: 'პრესეტი',
    recent: 'ბოლოს გამოყენებული',
    favs: 'რჩეულები', favTip: 'რჩეული  ⌘D', favOn: function (name) { return '★ რჩეულებში: <b>' + esc(name) + '</b>'; }, favOff: function (name) { return 'რჩეულებიდან ამოვიდა: <b>' + esc(name) + '</b>'; },
    myPresets: 'ჩემი პრესეტები',
    effects: 'ეფექტები',
    loading: 'იტვირთება…',
    nothing: function (q) { return 'ვერაფერი მოიძებნა: <strong>' + esc(q) + '</strong>'; },
    moreHint: 'აკრიფე სახელი, რომ ყველა ეფექტში მოძებნო…',
    noSeq: 'სექვენსი არ არის გახსნილი',
    noSel: 'კლიპი არ არის მონიშნული',
    selected: function (v, a) {
      var parts = [];
      if (v) { parts.push(v + ' ვიდეო'); }
      if (a) { parts.push(a + ' აუდიო'); }
      return parts.join(' · ') + ' მონიშნულია';
    },
    appliedFx: function (name, n) { return '<b>' + esc(name) + '</b> დაედო ' + n + ' კლიპს'; },
    appliedPreset: function (name, n) { return '«' + esc(name) + '» დაედო ' + n + ' კლიპს'; },
    failedSome: function (n) { return n + ' კლიპზე ვერ დაედო'; },
    skippedParams: function (n) { return n + ' პარამეტრი ვერ გადმოვიდა (Lumetri-ს curves/wheels, მასკები და მისთ.)'; },
    missingFx: function (list) { return 'არ არის დაყენებული: ' + list.join(', '); },
    errors: {
      noSequence: 'სექვენსი არ არის გახსნილი',
      noSelection: 'ჯერ მონიშნე კლიპი timeline-ზე',
      noVideoSelected: 'მონიშნულია მხოლოდ აუდიო — ვიდეო ეფექტისთვის ვიდეო კლიპი მონიშნე',
      noAudioSelected: 'მონიშნულია მხოლოდ ვიდეო — აუდიო ეფექტისთვის აუდიო კლიპი მონიშნე',
      effectNotFound: 'ეფექტი ვერ მოიძებნა',
      applyFailed: 'ეფექტი ვერ დაედო',
      presetFailed: 'პრესეტი ვერ დაედო',
      noQE: 'Premiere-ის შიდა API ვერ ჩაირთო',
      noProject: 'პროექტი ვერ ვიპოვე — ჯერ შეინახე',
      noFreeTrack: 'ზედა ტრეკი აქ დაკავებულია და ახალი ვერ დავამატე — დაამატე ცარიელი ვიდეო ტრეკი ზემოთ',
      noZones: 'ამ სექვენსზე ზონა არ დევს',
      noEaseTarget: 'ლურჯი ხაზი ორ keyframe-ს შორის დააყენე (მონიშნულ კლიპზე)',
      noKeyframes: 'მონიშნულ კლიპზე keyframe-ები არ არის',
      undoMissing: 'ვერ გაუქმდა: კლიპი ან ეფექტი ვეღარ ვიპოვე',
      noParams: 'ჯერ მონიშნე, რომელ პარამეტრს დაედოს მრუდი',
      easeNothing: 'ამ keyframe-ებზე მრუდი ვერ დაედო: მნიშვნელობა არ იცვლება ან მოძრაობა ძალიან მოკლეა',
      zoneWriteFailed: 'ზონის სურათი ვერ შეინახა',
      zoneFileMissing: 'ზონის სურათი ვერ მოიძებნა',
      zoneImportFailed: 'ზონის სურათი პროექტში ვერ შემოვიდა',
      zonePlaceFailed: 'ზონა ტრეკზე ვერ დაიდო',
      zoneReplaceFailed: 'ძველი ზონა ვერ მოიხსნა',
      zoneToggleFailed: 'ზონა ვერ დაიმალა — ტრეკის თვალის ხატულა გამორთე ხელით',
      hostError: 'Premiere-მა არ უპასუხა — დახურე და თავიდან გახსენი Quick FX',
      badReply: 'Premiere-მა გაუგებარი პასუხი დააბრუნა',
      exception: 'შეცდომა'
    },
    commands: 'ბრძანებები',
    e: {
      out: 'გასვლა', inn: 'შესვლა', mine: 'ჩემი', del: 'წაშლა', sec: 'წმ', moves: 'მოძრაობა',
      clips: function (n) { return 'მონიშნულია ' + n + ' კლიპი'; },
      selectClip: 'მონიშნე კლიპი, რომელზეც keyframe-ებია',
      parkPlayhead: 'ლურჯი ხაზი ორ keyframe-ს შორის დააყენე',
      noKeys: 'მონიშნულ კლიპზე keyframe-ები არ არის',
      applied: function (params, keys) { return 'მრუდი დაედო: ' + params + ' პარამეტრი · ' + keys + ' keyframe'; },
      linearDone: function (params) { return 'Linear: ' + params + ' პარამეტრი დაბრუნდა'; },
      partial: 'ძალიან ბევრი keyframe იყო — ნაწილზე დაედო, დანარჩენზე თავიდან გაუშვი.',
      flat: function (n) { return n + ' პარამეტრში მნიშვნელობა არ იცვლება.'; },
      tooShort: function (n) { return n + ' მოძრაობა ძალიან მოკლეა.'; },
      unsupported: function (n) { return n + ' პარამეტრს მრუდი არ ედება.'; },
      saved: function (name) { return 'შეინახა: <b>' + esc(name) + '</b>'; },
      saveFailed: 'პრესეტი ვერ შეინახა',
      undone: function (n) { return 'გაუქმდა: ' + n + ' პარამეტრი დაბრუნდა'; },
      undoMissing: function (n) { return n + ' პარამეტრი ვეღარ ვიპოვე (კლიპი ან ეფექტი შეიცვალა).'; },
      undoTip: function (n) { return 'ბოლო დადების გაუქმება · დარჩენილია ' + n + ' ნაბიჯი'; },
      undoNone: 'გასაუქმებელი არაფერია',
      params: 'რაზე დაედოს', all: 'ყველა', none: 'არცერთი',
      noParamsYet: 'აქ გამოჩნდება keyframe-იანი პარამეტრები',
      pickParams: 'მონიშნე პარამეტრი მარჯვნივ',
      chosen: function (n, of) { return 'არჩეულია ' + n + ' / ' + of; },
      cmdMeta: 'keyframe-ები ლურჯ ხაზზე'
    },
    z: {
      vertical: 'ვერტიკალური · 9:16',
      horizontal: 'ჰორიზონტალური · 16:9',
      noSeq: 'ჯერ სექვენსი გახსენი',
      willPlace: function (n) { return 'დაიდება ლურჯი ხაზიდან ' + n + ' წამზე. მერე კლიპივით გაწელე ან დაამოკლე.'; },
      seqSize: function (w, h) { return 'სექვენსი ' + w + ' × ' + h; },
      willSwap: function (name) { return 'ლურჯ ხაზზე უკვე დევს: ' + name + '. შეიცვლება, სიგრძე დარჩება.'; },
      hide: 'დამალვა', show: 'ჩვენება',
      visible: function (n) { return 'ჩანს სექვენსზე: ' + n; },
      hidden: function (n) { return 'დამალულია: ' + n; },
      exportHint: 'ექსპორტამდე დამალე — ზონა ჩვეულებრივი კლიპია',
      placed: function (name, secs) { return '<b>' + esc(name) + '</b> ზონა დაიდო · ' + secs + ' წმ'; },
      swapped: function (name) { return 'ზონა შეიცვალა: <b>' + esc(name) + '</b>'; },
      newTrack: 'დაემატა ახალი ტრეკი ზემოთ.',
      notExact: 'სიგრძე ზუსტად ვერ დაყენდა — კლიპი ხელით გაწელე.',
      nowHidden: function (n) { return n + ' ზონა დაიმალა'; },
      nowShown: function (n) { return n + ' ზონა ჩანს'; },
      removed: function (n) { return n + ' ზონა წაიშალა'; },
      cmdMeta: function (n) { return n + ' წმ ლურჯი ხაზიდან'; },
      cmdToggle: 'Safe Zones — დამალვა / ჩვენება'
    },
    auto: {
      title: 'ავტომატური შეგროვება',
      desc: 'ახალი ფაილი, რომელსაც Downloads-იდან, გარე დისკიდან ან ბარათიდან შემოიტან, თავისით დაკოპირდება პროექტის Imported საქაღალდეში.',
      manualTitle: 'პროექტში უკვე არსებული ფაილები',
      manualDesc: 'რაც ადრე შემოიტანე და პროექტის საქაღალდის გარეთ დარჩა: ნახავ სიას და ერთად დააკოპირებ.',
      manualBtn: 'შეგროვება',
      activity: 'ბოლო აქტივობა',
      noActivity: 'ჯერ არაფერი დაკოპირებულა',
      toFx: 'ეფექტები',
      dockOn: 'ელოდება ახალ ფაილებს',
      dockOff: 'გამორთულია',
      dockStarting: 'ირთვება…',
      dockDead: 'ფონი არ პასუხობს',
      dockDeadTip: 'ფონური ნაწილი არ პასუხობს — Premiere სრულად დახურე და თავიდან გახსენი',
      dockLast: function (name) { return 'ბოლო: ' + name; },
      on: 'ავტომატური შეგროვება: მუშაობს',
      off: 'ავტომატური შეგროვება: გამორთულია',
      dead: 'ავტომატური შეგროვება: ფონური ნაწილი არ პასუხობს — Premiere თავიდან გახსენი',
      copying: function (name, left) { return 'კოპირდება: ' + name + (left > 1 ? ' (+' + (left - 1) + ')' : ''); },
      last: 'ბოლო:'
    },
    c: {
      title: 'ფაილების შეგროვება',
      scanning: 'პროექტი მოწმდება…',
      allInside: '✓ ყველა ფაილი უკვე პროექტის საქაღალდეშია',
      checked: function (n) { return 'შემოწმდა ' + n + ' ფაილი'; },
      found: function (n, size) { return n + ' ფაილი · ' + size + ' პროექტის საქაღალდის გარეთაა'; },
      willCopy: 'დაკოპირდება აქ:',
      copy: 'დაკოპირება',
      back: 'უკან',
      stop: 'გაჩერება',
      stopping: 'ჩერდება მიმდინარე ფაილის შემდეგ…',
      close: 'დახურვა',
      keepWorking: 'Premiere-ში მუშაობა შეგიძლია გააგრძელო. ეს ფანჯარა არ დახურო, სანამ არ დასრულდება.',
      mayFreeze: 'დიდი ფაილის კოპირებისას Premiere შეიძლება ცოტა ხნით გაიყინოს.',
      done: '✓ დასრულდა',
      doneWithErrors: 'დასრულდა, მაგრამ ზოგი ფაილი ვერ გადავიდა',
      result: function (copied, reused, relinked) {
        var parts = [copied + ' დაკოპირდა'];
        if (reused) { parts.push(reused + ' უკვე იყო პროექტის საქაღალდეში'); }
        parts.push(relinked + ' კლიპი გადამისამართდა');
        return parts.join(' · ');
      },
      stoppedAt: function (done, total) { return 'გაჩერდა: ' + done + ' / ' + total + '. დანარჩენისთვის ბრძანება თავიდან გაუშვი.'; },
      saveHint: 'ორიგინალები ადგილზეა. პროექტი შეინახე: ⌘S',
      skipped: 'გამოტოვებულია:',
      skip: { offline: 'offline', missing: 'დისკზე ვერ მოიძებნა', linked: 'After Effects / Dynamic Link', sequence: 'სურათების სექვენსი' },
      errReason: { relink: 'დაკოპირდა, მაგრამ ვერ გადამისამართდა', missing: 'ორიგინალი ვერ მოიძებნა', copyFailed: 'ვერ დაკოპირდა', mkdirFailed: 'საქაღალდე ვერ შეიქმნა', ENOSPC: 'დისკზე ადგილი არ არის', EACCES: 'წვდომა არ არის', EPERM: 'წვდომა არ არის' }
    },
    y: {
      cmd: 'YouTube / TikTok — ვიდეოს ჩაწერა', cmdMeta: 'ბმული → Project პანელი',
      idleTitle: 'ჩასვი YouTube-ის ან TikTok-ის ბმული',
      idle: ['დააკოპირე ბმული ბრაუზერიდან', 'ჩასვი ზემოთ: ⌘V ან „ჩასმა“', 'აირჩიე რა გინდა და რა ხარისხით — ფაილი თავისით დაემატება Project პანელში'],
      setupTitle: 'პირველი გამოყენება: ჩამოტვირთვის ძრავა',
      setupDesc: 'ერთხელ უნდა ჩამოიტვირთოს სამი ღია კოდის ხელსაწყო (yt-dlp, ffmpeg, deno), დაახლოებით 120–160 MB. ინახება ამ კომპიუტერზე, Quick FX-ის საქაღალდეში; სისტემაში არაფერი იცვლება.',
      setupBtn: 'დაყენება',
      installing: function (i, n, name) { return 'იტვირთება ' + name + ' · ' + (i + 1) + ' / ' + n; },
      checking: function (name) { return 'მოწმდება ' + name + '…'; },
      installed: 'ძრავა დაყენდა',
      loading: 'ვიდეო მოწმდება…', loadingSub: 'ჩვეულებრივ 5–15 წამი',
      updating: 'ძრავა ახლდება…',
      what: 'რა ჩამოვტვირთო', quality: 'ხარისხი',
      modes: { both: 'ვიდეო + ხმა', video: 'მხოლოდ ვიდეო', audio: 'მხოლოდ ხმა' },
      audioNote: 'ხმა ჩამოიტვირთება საუკეთესო ხარისხით (M4A / AAC) — Premiere პირდაპირ ხსნის.',
      convertNote: 'YouTube 1080p-ზე მაღლა H.264-ს არ იძლევა. ჩამოტვირთვის შემდეგ ფაილი გადაკეთდება H.264-ში, რომ Premiere-მა გახსნას — ამას რამდენიმე წუთი სჭირდება.',
      convertTip: 'ჩამოტვირთვის შემდეგ გადაკეთდება H.264-ში',
      noAudio: 'ამ ვიდეოს ხმა არ აქვს',
      sec: { label: 'რამდენი', all: 'მთლიანი ვიდეო', part: 'მხოლოდ მონაკვეთი', from: 'დან', to: 'მდე', toEnd: 'ბოლომდე',
        len: function (t) { return 'ჩამოვა ' + t + ' — ზუსტად ამ წამებზე გაჭრილი, H.264'; },
        lenAudio: function (t) { return 'ჩამოვა ' + t; },
        empty: 'მიუთითე დრო, მაგ. 0:45 და 1:20',
        badFrom: 'დასაწყისი ვერ გავიგე — დაწერე ასე: 0:45 ან 1:02:05',
        badTo: 'დასასრული ვერ გავიგე — დაწერე ასე: 1:20 ან 1:02:05',
        order: 'დასასრული დასაწყისის შემდეგ უნდა იყოს',
        past: function (t) { return 'ვიდეო სულ ' + t + ' გრძელდება'; } },
      about: function (size) { return '≈ ' + size; },
      destSaved: '→ Imported/YouTube · Project: „YouTube“ ბინი',
      destSite: function (name) { return '→ Imported/' + name + ' · Project: „' + name + '“ ბინი'; },
      clean: 'ორიგინალი, watermark-ის გარეშე',
      hevcTip: 'HEVC (H.265) — ამ ხარისხს TikTok მხოლოდ ასე იძლევა; Premiere ხსნის',
      convertOther: 'ამ ფორმატს Premiere პირდაპირ ვერ ხსნის. ჩამოტვირთვის შემდეგ გადაკეთდება H.264-ში — ამას ცოტა დრო სჭირდება.',
      audioOwn: 'ჩამოვა ამ ვიდეოს საკუთარი ხმა (M4A / AAC), არა მხოლოდ მუსიკის ტრეკი.',
      destUnsaved: 'პროექტი შენახული არ არის → Downloads/Quick FX',
      go: 'ჩამოტვირთვა', fetch: 'ნახვა', again: 'კიდევ ერთი', retry: 'თავიდან ცდა', cancel: 'გაუქმება',
      q: { title: 'ჩამოტვირთვები', wait: 'რიგშია', clear: 'დასრულებულების მოშორება', add: 'რიგში დამატება',
        added: function (n) { return 'რიგში დაემატა — წინ ' + n + ' ჩამოტვირთვაა'; },
        dup: 'ეს უკვე რიგშია', inProject: 'Project პანელშია', existed: 'უკვე ჩამოტვირთული იყო — Project პანელშია',
        noImport: 'ჩამოიტვირთა, მაგრამ პროექტში ვერ დაემატა — ხელით ჩააგდე',
        cancelTip: 'გაუქმება', removeTip: 'სიიდან მოშორება', retryTip: 'თავიდან ცდა',
        allDone: function (n) { return n + ' ჩამოტვირთვა დასრულდა'; },
        onlyVideo: 'მხოლოდ ვიდეო', audio: 'ხმა' },
      part: { video: 'ვიდეო', audio: 'ხმა', section: 'მონაკვეთი იწერება', merge: 'ვიდეო და ხმა ერთიანდება…', convert: 'გადადის H.264-ში…', fix: 'სრულდება…', start: 'იწყება…' },
      elapsed: function (t) { return 'გავიდა ' + t; },
      left: function (eta) { return 'დარჩა ' + eta; },
      done: 'დაემატა Project პანელში', doneExisted: 'უკვე ჩამოტვირთული იყო — Project პანელშია',
      doneNoImport: 'ჩამოიტვირთა, მაგრამ პროექტში ვერ დაემატა — ხელით ჩააგდე:',
      doneToast: function (name) { return 'ჩამოიტვირთა: <b>' + esc(name) + '</b>'; },
      cancelled: 'ჩამოტვირთვა გაუქმდა',
      stillBusy: 'ჩამოტვირთვა მიმდინარეობს — ფანჯარა არ დაიხურება, სანამ რიგი არ დასრულდება',
      cookies: 'ვცადო Chrome-ის ანგარიშით',
      cookiesNote: 'წაიკითხავს ამ საიტზე შენს შესვლას ამ კომპიუტერის Chrome-იდან. macOS-მა შეიძლება Keychain-ის პაროლი გკითხოს.',
      err: {
        ytLogin: 'საიტი ამ ვიდეოზე შესვლას ითხოვს (ასაკის შეზღუდვა ან ბოტის შემოწმება)',
        ytUnavailable: 'ვიდეო მიუწვდომელია: პირადია, წაშლილია ან ამ ქვეყანაში არ ჩანს',
        ytBadUrl: 'ეს ბმული ვერ გავიგე — ვიდეოს გვერდის ბმული ჩასვი',
        ytNoFormat: 'ეს ხარისხი ამ ვიდეოსთვის ვერ მოიძებნა — სხვა აირჩიე',
        ytNetwork: 'ინტერნეტთან კავშირი ვერ მოხერხდა',
        ytBusy: 'საიტი დროებით ზღუდავს მოთხოვნებს — რამდენიმე წუთში სცადე',
        ytLive: 'ეს პირდაპირი ეთერია — დასრულების შემდეგ ჩამოიტვირთება',
        ytFailed: 'ჩამოტვირთვა ვერ მოხერხდა',
        ENOSPC: 'დისკზე ადგილი არ არის',
        noNode: 'Quick FX-ის ეს ნაწილი ვერ ჩაირთო — Premiere სრულად დახურე და თავიდან გახსენი',
        installFailed: 'ძრავა ვერ ჩამოიტვირთა — ინტერნეტი შეამოწმე და თავიდან სცადე',
        ytToolBroken: 'ძრავის ნაწილი ამ კომპიუტერზე ვერ გაეშვა — დიაგნოსტიკა დააკოპირე და გამომიგზავნე'
      }
    },
    s: {
      cmd: 'პაუზების ამოჭრა', cmdMeta: 'სიჩუმე → ახალი სექვენსი',
      noSeq: 'გახსენი სექვენსი, რომელშიც მოლაპარაკე კადრებია',
      none: 'ამ სექვენსში ვერ ვიპოვე კლიპი, რომლის ხმასაც გავაანალიზებდი',
      picked: function (n, t) { return 'მონიშნულია ' + n + ' კლიპი · ' + t; },
      whole: function (n, t) { return 'არაფერია მონიშნული — ავიღებ პირველი ტრეკის ყველა კლიპს (' + n + ' · ' + t + ')'; },
      how: ['ხმას წაიკითხავს და პაუზებს იპოვის — ჯერ არაფერი იცვლება', 'ნახავ რამდენი ამოიჭრება და მოარგებ', 'გაკეთდება ახალი სექვენსი პაუზების გარეშე; ეს სექვენსი ხელუხლებელი რჩება'],
      why: { nested: 'ჩადგმული სექვენსია', offline: 'ფაილი ვერ მოიძებნა', speed: 'სიჩქარე შეცვლილია', noAudio: 'ხმა არ აქვს' },
      skipped: 'გამოტოვებულია:',
      setupTitle: 'ხმის ანალიზს ძრავა სჭირდება', setupDesc: 'იგივე ძრავაა, რასაც „ჩაწერა“ იყენებს (ffmpeg). ერთხელ ჩამოიტვირთება, 120–160 MB.',
      scan: function (i, n, name) { return 'ხმა იკითხება · ' + (i + 1) + ' / ' + n + ' · ' + name; },
      cancel: 'გაუქმება', analyze: 'ანალიზი', again: 'თავიდან',
      pauses: 'პაუზა', cut: 'ამოიჭრება', stay: 'დარჩება', pieces: 'ნაჭერი',
      thr: 'რა ითვლება სიჩუმედ', thrTip: 'ხაზის ქვემოთ ყველაფერი სიჩუმეა. თუ სიტყვებს ჭრის — ჩამოსწიე; თუ პაუზებს ტოვებს — ასწიე.',
      auto: 'ავტო', minPause: 'უმოკლესი პაუზა, რომელიც იჭრება', pad: 'მარაგი ფრაზის წინ და შემდეგ', sec: 'წმ',
      note: function (name) { return 'გაკეთდება ახალი სექვენსი „' + name + '“. ნაჭრებზე გადადის ზომა და პოზიცია; სხვა ეფექტები — არა, ამიტომ პაუზები ეფექტებამდე ამოჭერი.'; },
      suffix: ' — პაუზების გარეშე',
      go: 'ახალი სექვენსი', mark: 'მარკერებით მონიშვნა', unmark: 'მარკერების მოშორება',
      marked: function (n) { return n + ' პაუზა მოინიშნა მარკერებით'; }, unmarked: 'მარკერები მოშორდა',
      nothing: 'ამ პარამეტრებით ამოსაჭრელი პაუზა არ არის',
      tooMany: function (n) { return n + ' ნაჭერი ძალიან ბევრია — გაზარდე უმოკლესი პაუზა'; },
      applyCopy: 'სექვენსის ასლი კეთდება…', applyClear: function (n) { return 'ასლი სუფთავდება… დარჩა ' + n; },
      applyPlace: function (i, n) { return 'ნაჭრები ლაგდება · ' + i + ' / ' + n; }, applyEnd: 'სრულდება…',
      done: 'მზადაა', doneLine: function (n, now, was) { return n + ' ნაჭერი · ' + now + ' (იყო ' + was + ')'; },
      doneHint: 'ახალი სექვენსი გახსნილია. ძველი ხელუხლებელია.',
      half: function (name) { return 'დაუმთავრებელი სექვენსი „' + name + '“ პროექტში დარჩა — შეგიძლია წაშალო.'; },
      hint: 'ეს სექვენსი არ იცვლება',
      stillBusy: 'სექვენსი კეთდება — ფანჯარა არ დაიხურება, სანამ არ დასრულდება',
      err: {
        noSequence: 'სექვენსი გახსნილი არ არის', silCloneFailed: 'სექვენსის ასლი ვერ გაკეთდა', silClearFailed: 'ასლის გასუფთავება ვერ მოხერხდა',
        silPlaceFailed: 'ნაჭრის ჩადება ვერ მოხერხდა', silItemMissing: 'კლიპი პროექტში ვეღარ ვიპოვე', silSeqMissing: 'ახალი სექვენსი ვეღარ ვიპოვე',
        silNoTracks: 'ახალ სექვენსს ტრეკები არ აქვს', silMarkFailed: 'მარკერების დასმა ვერ მოხერხდა', silFailed: 'ხმის წაკითხვა ვერ მოხერხდა',
        noNode: 'Quick FX-ის ეს ნაწილი ვერ ჩაირთო — Premiere სრულად დახურე და თავიდან გახსენი', failed: 'ვერ მოხერხდა'
      }
    },
    x: {
      cmd: 'ხმები — საუნდ ეფექტები', cmdMeta: 'მოსმენა და ჩასმა',
      none: 'კატეგორიის გარეშე', newCat: '＋ ახალი კატეგორია', newCatPh: 'კატეგორიის სახელი…', catExists: 'ასეთი კატეგორია უკვე არის',
      emptyTitle: 'ხმების ბიბლიოთეკა ცარიელია',
      empty: ['ხმების პაკეტი (QuickFX-Sounds.zip) გახსენი ამ საქაღალდეში — ან', 'ქვემოთ, მარცხნივ აირჩიე სხვა საქაღალდე (მაგ. გუნდის საერთო დისკზე) — ან', 'შექმენი კატეგორია და დაამატე შენი ხმები'],
      emptyCat: 'ამ კატეგორიაში ჯერ ხმა არ არის — „＋ ხმის დამატება“',
      noMatch: 'ასეთი ხმა ვერ ვიპოვე',
      add: '＋ ხმის დამატება', addTitle: 'აირჩიე ხმის ფაილები', pickDir: 'აირჩიე ხმების ბიბლიოთეკის საქაღალდე', go: 'ჩასმა',
      added: function (n, cat) { return n + ' ხმა დაემატა: <b>' + esc(cat) + '</b>'; }, addFailed: 'ფაილი ვერ დაკოპირდა',
      catMade: function (cat) { return 'კატეგორია შეიქმნა: <b>' + esc(cat) + '</b>'; },
      placed: function (name, track) { return 'A' + track + '-ზე დაიდო: <b>' + esc(name) + '</b>'; },
      imported: { noSequence: 'Project-ში დაემატა (სექვენსი ღია არ არის)', noFreeTrack: 'Project-ში დაემატა — playhead-თან თავისუფალი აუდიო ტრეკი არ არის, ხელით ჩააგდე',
        placeFailed: 'Project-ში დაემატა, მაგრამ timeline-ზე ვერ დაიდო — ხელით ჩააგდე', importOnly: 'Project-ში დაემატა' },
      sounds: function (n) { return n + ' ხმა'; }, noNode: 'ხმების ეკრანი ვერ ჩაირთო — Premiere სრულად დახურე და თავიდან გახსენი',
      keys: 'Space მოსმენა · ←→ ვარიაცია · ↵ ჩასმა',
      err: { sfxFileMissing: 'ხმის ფაილი ვეღარ ვიპოვე', sfxImportFailed: 'ხმა პროექტში ვერ დაემატა' }
    },
    t: {
      cmd: 'ტექსტი — მზა ანიმაციები', cmdMeta: 'შემოსვლა, გასვლა, ლუპი',
      slot: { 'in': 'შემოსვლა', out: 'გასვლა', loop: 'ლუპი' },
      none: '— არაფერი —', empty: 'არ არის', loops: 'ლუპები', loopsHint: 'რას აკეთებს ტექსტი, სანამ ეკრანზეა',
      native: 'ასო-ასო', nativeHint: 'Premiere-ის ჩაშენებული ხელსაწყო (25.5+) — საცდელი',
      nativeNote: 'Premiere-ის საკუთარი ხელსაწყო: ამოძრავებს ასო-ასო, სიტყვა-სიტყვა ან ხაზ-ხაზ. ჩაჯდება ნაგულისხმევი სახით — სტილს Effect Controls-ში აირჩევ. აქ გადახედვა არ აქვს.',
      nativeItems: [{ id: 'n:animator', n: 'Text Animator — ასო-ასო ანიმაცია', names: ['Text Animator'] }, { id: 'n:typewriter', n: 'Typewriter — საბეჭდი მანქანა', names: ['Typewriter'] }],
      box: 'ჩარჩო', sec: function (n) { return (Math.round(n * 100) / 100) + ' წმ'; },
      hintBox: 'ჩარჩო = სად დგას ტექსტი კადრში', hintMask: 'ეს ანიმაცია ნიღაბს იყენებს: ჩარჩო ზუსტად მოარგე ტექსტს',
      hintAnchor: 'ჩარჩო დასვი ტექსტზე — ზომა და ბრუნვა მის ცენტრს მიჰყვება', hintFree: '',
      selNone: 'მონიშნე ტექსტის კლიპი', selN: function (n) { return n + ' კლიპი მონიშნულია'; }, noSeq: 'სექვენსი არ არის გახსნილი',
      pick: 'ჯერ აირჩიე ანიმაცია', noSel: 'ჯერ მონიშნე ტექსტის კლიპი timeline-ზე',
      applied: function (n) { return n === 1 ? 'ანიმაცია დაედო' : 'ანიმაცია დაედო ' + n + ' კლიპს'; },
      removed: function (n) { return n === 1 ? 'ანიმაცია მოიხსნა' : 'ანიმაცია მოიხსნა ' + n + ' კლიპიდან'; },
      partial: function (list) { return 'Premiere-ში ვერ ვიპოვე ეფექტი: ' + list.join(', ') + ' — ანიმაციის ეს ნაწილი გამოტოვებულია'; },
      params: 'ზოგი პარამეტრი ვერ ჩაიწერა — ⋯ → დიაგნოსტიკის კოპირება და გამომიგზავნე',
      nativeOk: function (name, n) { return '<b>' + esc(name) + '</b> დაემატა' + (n > 1 ? ' ' + n + ' კლიპს' : '') + ' — სტილი: Effect Controls'; },
      keys: '↑↓ არჩევა · ←→ ჩანართი · ↵ ახალი ტექსტი · ⇧↵ მონიშნულზე',
      dragTip: 'გადაათრიე timeline-ზე — ან ↵ და ტექსტი playhead-თან გაჩნდება',
      viaMotion: 'ტექსტი ანიმაციით გაჩნდა, ოღონდ Motion-ზე: Premiere-მა Transform ეფექტი არ დამადებინა',
      lost: function (list) { var ka = { 'Gaussian Blur': 'ბლური', 'Crop': 'ნიღაბი' }, o = []; for (var i = 0; i < list.length; i++) { o.push(ka[list[i]] || list[i]); } return 'ამ გზით გამოტოვებულია: ' + o.join(', '); },
      whyOf: function (why) {
        var m = { noEffect: 'ეფექტი სიაში არ არის', noQeItem: 'Premiere კლიპს ჯერ ვერ ხედავს', addFailed: 'ეფექტის დამატებაზე უარი', notSeen: 'ეფექტი დაემატა, მაგრამ კლიპზე არ ჩანს' };
        return why ? (m[why] || why) + ' (' + why + ')' : '';
      },
      created: function (track) { return 'ტექსტი გაჩნდა V' + track + '-ზე — ჩაწერე შენი (ორმაგი დაწკაპება ტექსტზე)'; },
      createdN: function (n) { return n + ' ტექსტი გაჩნდა timeline-ზე'; },
      stylePick: 'სხვა ფაილი…', styleNone: 'შაბლონი არ არის', pickTitle: 'აირჩიე ტექსტის შაბლონი (.mogrt)',
      noStyle: 'ჯერ ტექსტის შაბლონია საჭირო — ნახე ბარათი სიის თავში',
      setupTitle: 'ერთხელ გასაკეთებელი: ტექსტის შაბლონი', helpTitle: 'შენი სტილი ახალი ტექსტისთვის',
      setupWhy: 'Premiere სკრიპტს ტექსტის შექმნას მხოლოდ შაბლონიდან (.mogrt) აძლევს. გააკეთე ერთი — შენი ფონტით და ზომით — და ყველა ახალი ტექსტი ასეთი გაჩნდება:',
      setupSteps: ['Premiere-ში დაწერე ნებისმიერი ტექსტი (T) შენი ფონტით და ზომით', 'კლიპზე მარჯვენა ღილაკი → Export As Motion Graphics Template…', 'Name: Quick FX Text · Destination: Local Templates Folder → OK', 'აქ დააჭირე „შემოწმება“'],
      setupMore: 'რამდენიმე სტილიც შეიძლება (სათაური, სუბტიტრი…): ყველა შენახული შაბლონი სიაში გამოჩნდება.',
      setupCheck: 'შემოწმება', setupPick: 'ფაილის არჩევა…', setupClose: 'დახურვა',
      found: function (n) { return n === 1 ? 'შაბლონი ვიპოვე' : n + ' შაბლონი ვიპოვე'; }, notFound: 'შაბლონი ჯერ ვერ ვიპოვე',
      err: {
        animFxMissing: 'Premiere-ში ვერ ვიპოვე ეფექტი, რომელიც ანიმაციას სჭირდება', animFailed: 'ანიმაცია ვერ დაედო',
        animNoReach: 'Premiere-მა კლიპზე ეფექტი არ დამადებინა — სცადე კიდევ ერთხელ „მონიშნულზე“ (⇧↵)',
        animNothing: 'მონიშნულ კლიპებზე Quick FX-ის ანიმაცია არ დევს',
        animNoNative: 'ეს ხელსაწყო შენს Premiere-ში ვერ ვიპოვე (სჭირდება 25.5 ან ახალი). Effects პანელში მოძებნე „Text Animator“',
        animNativeFailed: 'Premiere-მა ხელსაწყო არ დაამატა — Effects პანელიდან გადაათრიე ტექსტის დასაწყისზე',
        textNoTemplate: 'ტექსტის შაბლონის ფაილი ვეღარ ვიპოვე', textImportFailed: 'Premiere-მა შაბლონი timeline-ზე არ დასვა'
      }
    },
    diagCopied: 'დიაგნოსტიკა დაკოპირდა — ჩასვი ჩატში',
    refreshed: function (fx, pr) { return 'განახლდა: ' + fx + ' ეფექტი · ' + pr + ' პრესეტი'; }
  };

  // ------------------------------------------------------------------ state
  var state = {
    effects: { video: [], audio: [] },
    presets: [],
    presetSkipped: [],
    presetFile: null,
    presetError: null,
    info: null,
    items: [],
    rows: [],            // rendered rows (selectable ones only)
    active: 0,
    view: 'list',
    busy: false,
    loaded: false,
    hadFocus: false,
    openedAt: Date.now(),
    lastError: null,
    lastResult: null,
    usage: load(LS.usage, {}),
    favs: load(LS.favs, {}),             // starred effects / presets: id → when it was starred
    settings: assign({ closeOnBlur: true }, load(LS.settings, {}))
  };

  // ------------------------------------------------------------------ DOM
  function $(id) { return document.getElementById(id); }
  var $q = $('q'), $list = $('list'), $sel = $('sel'), $toast = $('toast');
  var $menu = $('menu'), $menuBtn = $('menuBtn'), $busy = $('busy'), $menuInfo = $('menuInfo');
  var $closeOnBlur = $('closeOnBlur'), $blurOpt = $('blurOpt'), $keys = $('keys');
  var $files = $('files'), $fkeys = $('fkeys'), $railDot = $('railDot');
  var $tabs = { fx: $('tabFx'), files: $('tabFiles'), zones: $('tabZones'), ease: $('tabEase'), yt: $('tabYt'), gfx: $('tabGfx'), sfx: $('tabSfx'), txt: $('tabTxt') };
  var VIEW_OF = { fx: 'list', files: 'collect', zones: 'zones', ease: 'ease', yt: 'yt', gfx: 'gfx', sfx: 'sfx', txt: 'txt' };

  // ------------------------------------------------------------------ utils
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function assign(a, b) { for (var k in b) { if (Object.prototype.hasOwnProperty.call(b, k)) { a[k] = b[k]; } } return a; }
  function load(key, dflt) {
    try { var v = window.localStorage.getItem(key); return v ? JSON.parse(v) : dflt; } catch (e) { return dflt; }
  }
  function save(key, val) {
    try { window.localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* storage full or unavailable */ }
  }
  function highlight(text, idx) {
    if (!idx || !idx.length) { return esc(text); }
    var set = {}, i, out = '', open = false;
    for (i = 0; i < idx.length; i++) { set[idx[i]] = true; }
    for (i = 0; i < text.length; i++) {
      var on = !!set[i];
      if (on && !open) { out += '<mark>'; open = true; }
      if (!on && open) { out += '</mark>'; open = false; }
      out += esc(text.charAt(i));
    }
    if (open) { out += '</mark>'; }
    return out;
  }

  // ------------------------------------------------------------------ items
  function buildItems() {
    var items = COMMANDS.slice(), i;
    for (i = 0; i < state.presets.length; i++) {
      var p = state.presets[i];
      var sum = P.summary(p);
      var kf = P.keyframeCount(p);
      items.push({
        id: p.id, name: p.name, kind: 'preset', ref: p,
        alt: (p.folder ? p.folder + ' ' : '') + sum,
        meta: (p.folder ? p.folder + ' · ' : '') + sum + (kf ? ' · ◆' + kf : '')
      });
    }
    var v = state.effects.video || [], a = state.effects.audio || [];
    for (i = 0; i < v.length; i++) { items.push({ id: 'v:' + v[i], name: v[i], kind: 'video', meta: T.videoFx }); }
    for (i = 0; i < a.length; i++) { items.push({ id: 'a:' + a[i], name: a[i], kind: 'audio', meta: T.audioFx }); }
    state.items = items;
  }

  // ------------------------------------------------------------------ render
  function rowHtml(r, i) {
    var it = r.item;
    var badge = (it.kind === 'command' && it.icon === 'txt') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6h11M14.5 6v12"/><path d="M3 9.5h4M4.5 13h3M3 16.5h4.5"/></svg></span>'
      : (it.kind === 'command' && it.icon === 'sfx') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9.5v5h3.5L12 18V6L7.5 9.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/></svg></span>'
      : (it.kind === 'command' && it.icon === 'sil') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12v0M6 8v8M9 5v14"/><path d="M12 11v2M15 11v2" stroke-dasharray="1 2.4"/><path d="M18 7v10M21 10v4"/></svg></span>'
      : (it.kind === 'command' && it.icon === 'yt') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v10.5m0 0l-4-4m4 4l4-4"/><path d="M4.5 16.5v1.5a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-1.5"/></svg></span>'
      : (it.kind === 'command' && it.icon === 'ease') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 19c5 0 5-14 9-14s4 14 9 14"/></svg></span>'
      : (it.kind === 'command' && it.icon === 'zone') ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 7h6M9 17h6"/></svg></span>'
      : it.kind === 'command' ? '<span class="badge cmd"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v10m0 0l-4-4m4 4l4-4M5 18h14"/></svg></span>'
      : it.kind === 'preset' ? '<span class="badge preset"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l2.7 5.6 6.1.8-4.5 4.3 1.1 6.1L12 16.9 6.6 19.8l1.1-6.1L3.2 9.4l6.1-.8z"/></svg></span>'
      : (it.kind === 'audio' ? '<span class="badge audio">AU</span>' : '<span class="badge video">FX</span>');
    return '<div class="row' + (i === state.active ? ' active' : '') + '" data-i="' + i + '" role="option">' +
      badge +
      '<span class="name">' + highlight(it.name, r.idx) + '</span>' +
      '<span class="meta">' + esc(it.meta || '') + '</span>' +
      (it.kind === 'command' ? '' : '<span class="star' + (state.favs[it.id] ? ' on' : '') + '" data-star="1" title="' + esc(T.favTip) + '">★</span>') +
      '<span class="ret">↵</span>' +
      '</div>';
  }

  function render() {
    var q = $q.value;
    var html = [], rows = [], i;
    function section(label) { html.push('<div class="section">' + esc(label) + '</div>'); }
    function push(r) { html.push(rowHtml(r, rows.length)); rows.push(r); }

    var hasFx = false;
    for (i = 0; i < state.items.length; i++) { if (state.items[i].kind !== 'command') { hasFx = true; break; } }

    if (!S.cleanQuery(q)) {
      if (!hasFx) {
        html.push('<div class="empty">' + (!state.loaded ? T.loading
          : (state.lastError ? errorText(state.lastError) : T.errors.noQE)) + '</div>');
      }
      var plain = [];
      for (i = 0; i < state.items.length; i++) { if (state.items[i].kind !== 'command') { plain.push(state.items[i]); } }
      var shown = {}, favRows = [];
      for (i = 0; i < plain.length; i++) { if (state.favs[plain[i].id]) { favRows.push({ item: plain[i], idx: [] }); } }
      favRows.sort(function (x, y) { return state.favs[x.item.id] - state.favs[y.item.id]; });
      if (favRows.length) {
        section(T.favs + ' · ' + favRows.length);
        for (i = 0; i < favRows.length; i++) { push(favRows[i]); shown[favRows[i].item.id] = true; }
      }
      var notFav = [];
      for (i = 0; i < plain.length; i++) { if (!shown[plain[i].id]) { notFav.push(plain[i]); } }
      var rec = S.recents(notFav, state.usage, 6);
      if (rec.length) {
        section(T.recent);
        for (i = 0; i < rec.length; i++) { push(rec[i]); shown[rec[i].item.id] = true; }
      }
      var presetRows = [], fxRows = [];
      for (i = 0; i < state.items.length; i++) {
        var it = state.items[i];
        if (shown[it.id] || it.kind === 'command') { continue; }
        if (it.kind === 'preset') { presetRows.push({ item: it, idx: [] }); }
        else if (fxRows.length < EMPTY_EFFECT_LIMIT) { fxRows.push({ item: it, idx: [] }); }
      }
      if (presetRows.length) {
        section(T.myPresets + ' · ' + presetRows.length);
        for (i = 0; i < presetRows.length; i++) { push(presetRows[i]); }
      }
      if (fxRows.length) {
        section(T.effects);
        for (i = 0; i < fxRows.length; i++) { push(fxRows[i]); }
        html.push('<div class="more">' + esc(T.moreHint) + '</div>');
      }
    } else {
      var res = S.rank(state.items, q, state.usage, RESULT_LIMIT);
      if (!res.length) { html.push('<div class="empty">' + T.nothing(q) + '</div>'); }
      // Commands normally come after effects and presets, so Enter on a half-typed effect name can never
      // run one. They lead only when a command is clearly what was typed and no effect really matches.
      var cmds = [], plainRows = [], bestCmd = 0, bestPlain = 0;
      for (i = 0; i < res.length; i++) {
        if (res[i].item.kind === 'command') { cmds.push(res[i]); bestCmd = Math.max(bestCmd, res[i].score || 0); }
        else { plainRows.push(res[i]); bestPlain = Math.max(bestPlain, res[i].score || 0); }
      }
      // starred ones lead among what matches — but a weak fuzzy hit on a starred effect does not jump over a real match
      var lead = [], rest = [];
      for (i = 0; i < plainRows.length; i++) {
        if (state.favs[plainRows[i].item.id] && (plainRows[i].score || 0) >= bestPlain * 0.5) { lead.push(plainRows[i]); } else { rest.push(plainRows[i]); }
      }
      plainRows = lead.concat(rest);
      var cmdsFirst = cmds.length && bestCmd >= 600 && bestPlain < 600;
      if (cmdsFirst) { for (i = 0; i < cmds.length; i++) { push(cmds[i]); } }
      for (i = 0; i < plainRows.length; i++) { push(plainRows[i]); }
      if (cmds.length && !cmdsFirst) {
        if (rows.length) { section(T.commands); }
        for (i = 0; i < cmds.length; i++) { push(cmds[i]); }
      }
    }

    state.rows = rows;
    if (state.active >= rows.length) { state.active = rows.length ? rows.length - 1 : 0; }
    $list.innerHTML = html.join('');
    scrollActiveIntoView();
  }

  /** Star / unstar; the highlight stays on the same effect wherever it moves in the list. */
  function toggleFav(item) {
    if (!item || item.kind === 'command') { return; }
    if (state.favs[item.id]) { delete state.favs[item.id]; } else { state.favs[item.id] = Date.now(); }
    save(LS.favs, state.favs);
    render();
    for (var i = 0; i < state.rows.length; i++) { if (state.rows[i].item.id === item.id) { state.active = i; break; } }
    render();
    toast('ok', state.favs[item.id] ? T.favOn(item.name) : T.favOff(item.name), '', 1300);
  }

  function setActive(i) {
    if (!state.rows.length) { return; }
    var n = state.rows.length;
    i = Math.max(0, Math.min(n - 1, i));
    if (i === state.active) { return; }
    var prev = $list.querySelector('.row.active');
    if (prev) { prev.classList.remove('active'); }
    state.active = i;
    var el = $list.querySelector('.row[data-i="' + i + '"]');
    if (el) { el.classList.add('active'); }
    scrollActiveIntoView();
  }

  function scrollActiveIntoView() {
    var el = $list.querySelector('.row.active');
    if (!el) { return; }
    var top = el.offsetTop, bottom = top + el.offsetHeight;
    var prevSection = el.previousElementSibling;
    if (state.active === 0) { $list.scrollTop = 0; return; }
    if (prevSection && prevSection.classList.contains('section')) { top = prevSection.offsetTop; }
    if (top < $list.scrollTop) { $list.scrollTop = top - 6; }
    else if (bottom > $list.scrollTop + $list.clientHeight) { $list.scrollTop = bottom - $list.clientHeight + 6; }
  }

  // ------------------------------------------------------------------ selection status
  function setSelection(d) {
    var cls = 'sel', text;
    if (!d || !d.hasSequence) { cls += ' none'; text = T.noSeq; }
    else if (!d.video && !d.audio) { cls += ' none'; text = T.noSel; }
    else { cls += ' ok'; text = T.selected(d.video, d.audio); }
    $sel.className = cls;
    $sel.querySelector('.sel-text').textContent = text;
  }

  function refreshSelection() {
    return B.call('selection').then(function (r) { if (r && r.ok) { setSelection(r.data); } });
  }

  // ------------------------------------------------------------------ toast
  var toastTimer = null;
  function toast(kind, html, sub, ms) {
    var icon = kind === 'ok' ? '✓' : (kind === 'warn' ? '!' : '✕');
    $toast.className = 'toast ' + kind;
    $toast.innerHTML = '<span class="ti">' + icon + '</span><span>' + html +
      (sub ? '<span class="tsub">' + sub + '</span>' : '') + '</span>';
    $toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { $toast.hidden = true; }, ms || (kind === 'ok' ? 2200 : 5000));
  }

  function errorText(res) {
    var base = T.errors[res.code] || T.errors.exception;
    var extra = '';
    if (res.code === 'effectNotFound' || res.code === 'applyFailed') { extra = res.message ? ': ' + esc(res.message) : ''; }
    else if (res.code === 'exception' || res.code === 'hostError' || res.code === 'badReply') { extra = res.message ? '<span class="tsub">' + esc(res.message) + '</span>' : ''; }
    else if (res.code === 'presetFailed' && res.extra && res.extra.missing && res.extra.missing.length) {
      extra = '<span class="tsub">' + esc(T.missingFx(res.extra.missing)) + '</span>';
    }
    return base + extra;
  }

  // ------------------------------------------------------------------ busy / host
  function setBusy(on) { state.busy = on; $busy.hidden = !on; }

  /** The floating window closes itself after most actions — but never in the middle of a download. */
  function closeWindow() {
    if (ytBusy()) { if (state.view !== 'yt') { toast('warn', T.y.stillBusy); } return; }
    B.close();
  }

  function ensureHost() {
    return B.evalScript('typeof QuickFX').then(function (r) {
      if (r === 'object') { return true; }
      var path = B.extensionPath() + '/jsx/host.jsx';
      return B.evalScript('$.evalFile(' + JSON.stringify(path) + ')').then(function () { return true; });
    });
  }

  function choosePresetFile(files, appVersion) {
    if (!files || !files.length) { return null; }
    var major = String(appVersion || '').split('.')[0];
    var same = files.filter(function (f) { return String(f.version).split('.')[0] === major; });
    var pool = (same.length ? same : files).slice();
    pool.sort(function (a, b) { return (b.modified || 0) - (a.modified || 0); });
    return pool[0];
  }

  function loadPresets() {
    var f = choosePresetFile(state.info && state.info.presetFiles, state.info && state.info.appVersion);
    state.presetFile = f;
    state.presetError = null;
    if (!f) { state.presets = []; return; }
    var text = B.readTextFile(f.path);
    if (text == null) { state.presetError = 'cannot read ' + f.path; state.presets = []; return; }
    try {
      var res = P.parse(text);
      state.presets = res.presets;
      state.presetSkipped = res.skipped;
    } catch (e) {
      state.presetError = String(e && e.message || e);
      state.presets = [];
    }
  }

  function loadEverything(announce) {
    setBusy(true);
    return ensureHost()
      .then(function () { return Promise.all([B.call('info'), B.call('listEffects'), B.call('selection')]); })
      .then(function (r) {
        var info = r[0], fx = r[1], sel = r[2];
        if (info.ok) { state.info = info.data; } else { state.lastError = info; }
        if (fx.ok) {
          state.effects = fx.data;
          save(LS.effects, { at: Date.now(), app: state.info && state.info.appVersion, data: fx.data });
        } else { state.lastError = fx; }
        if (sel.ok) { setSelection(sel.data); }
        loadPresets();
        state.loaded = true;
        buildItems();
        render();
        updateMenuInfo();
        setBusy(false);
        if (announce) { toast('ok', T.refreshed((state.effects.video || []).length + (state.effects.audio || []).length, state.presets.length)); }
      })
      .catch(function (e) {
        setBusy(false);
        state.loaded = true;
        state.lastError = { code: 'exception', message: String(e && e.message || e) };
        render();
      });
  }

  // ------------------------------------------------------------------ apply
  function recordUsage(item) {
    var u = state.usage[item.id] || { count: 0, last: 0 };
    u.count += 1;
    u.last = Date.now();
    state.usage[item.id] = u;
    var keys = Object.keys(state.usage);
    if (keys.length > 600) {
      keys.sort(function (a, b) { return state.usage[a].last - state.usage[b].last; });
      for (var i = 0; i < keys.length - 500; i++) { delete state.usage[keys[i]]; }
    }
    save(LS.usage, state.usage);
  }

  function apply(row, keepOpen) {
    if (!row || state.busy) { return; }
    var item = row.item;
    if (item.kind === 'command') { item.run(); return; }
    setBusy(true);
    var call = item.kind === 'preset'
      ? B.call('applyPreset', { preset: P.compact(item.ref) })
      : B.call('applyEffect', { kind: item.kind, name: item.name });

    call.then(function (res) {
      setBusy(false);
      state.lastResult = { item: item.id, res: res, at: new Date().toISOString() };
      if (!res || !res.ok) {
        state.lastError = res;
        toast('err', errorText(res || { code: 'hostError' }));
        return;
      }
      recordUsage(item);
      var d = res.data, sub = [], kind = 'ok', msg;
      if (item.kind === 'preset') {
        msg = T.appliedPreset(item.name, d.clips);
        if (d.missing && d.missing.length) { sub.push(esc(T.missingFx(d.missing))); kind = 'warn'; }
        if (d.paramsSkipped) { sub.push(esc(T.skippedParams(d.paramsSkipped))); kind = 'warn'; }
        if (d.clips < d.total) { sub.push(esc(T.failedSome(d.total - d.clips))); kind = 'warn'; }
      } else {
        msg = T.appliedFx(item.name, d.applied);
        if (d.failed) { sub.push(esc(T.failedSome(d.failed))); kind = 'warn'; }
      }
      toast(kind, msg, sub.join('<br>'), kind === 'ok' ? 1600 : 4500);

      if (MODE === 'popup' && !keepOpen) {
        setTimeout(function () { closeWindow(); }, kind === 'ok' ? 380 : 2600);
      } else {
        refreshSelection();
        $q.focus();
        $q.select();
      }
    });
  }

  // ------------------------------------------------------------------ collect files
  var C = window.QFXCollect;
  var CAT_LABEL = { Video: 'Video', Audio: 'Audio', Music: 'Music', Images: 'Images', Other: 'Other' };
  var collect = { phase: 'idle' };

  function nodeFs() {
    try {
      var req = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
      return req ? req('fs') : null;
    } catch (e) { return null; }
  }

  function keysHtml(pairs) {
    var out = '';
    for (var i = 0; i < pairs.length; i++) { out += '<span><kbd>' + pairs[i][0] + '</kbd> ' + esc(pairs[i][1]) + '</span>'; }
    return out;
  }

  // The Files tab: 'home' (auto switch, activity) → scan → ready → copy → done.
  function switchTab(tab) {
    if (collect.phase === 'copy') { return; }                 // a manual copy is running: stay on it
    if (!$tabs[tab]) { return; }
    state.view = VIEW_OF[tab];
    for (var t in $tabs) { if ($tabs.hasOwnProperty(t)) { $tabs[t].hidden = t !== tab; } }
    var btns = document.querySelectorAll('.rail-btn[data-tab]');
    for (var i = 0; i < btns.length; i++) { btns[i].classList.toggle('active', btns[i].getAttribute('data-tab') === tab); }
    openMenu(false, true);
    collect = { phase: tab === 'files' ? 'home' : 'idle' };
    if (tab !== 'fx' && document.activeElement && document.activeElement.blur) { document.activeElement.blur(); }
    if (tab === 'files') { renderCollect(); }
    else if (tab === 'zones') { renderZoneList(); renderZoneSide(); refreshZones(); }
    else if (tab === 'ease') { openEase(); }
    else if (tab === 'yt') { openYt(); }
    else if (tab === 'gfx') { openGfx(); }
    else if (tab === 'sfx') { openSfx(); }
    else if (tab === 'txt') { openTxt(); }
    if (tab !== 'sfx') { sfxStop(); }
    if (tab !== 'txt') { txtStop(); }
    if (tab !== 'gfx') { gfxStop(); }
    else { render(); refreshSelection(); $q.focus(); }
  }

  function openCollect() {
    if (state.view !== 'collect') { switchTab('files'); }
    collect = { phase: 'scan', scan: null, files: [], sum: null, done: 0, bytesDone: 0, bytesFile: 0, current: '',
      errors: [], copied: 0, reused: 0, relinked: 0, cancel: false, engine: null, error: null };
    renderCollect();
    B.call('scanMedia').then(function (r) {
      if (state.view !== 'collect' || collect.phase !== 'scan') { return; }
      if (!r || !r.ok) { collect.phase = 'error'; collect.error = r || { code: 'hostError' }; state.lastError = collect.error; renderCollect(); return; }
      var d = r.data;
      for (var i = 0; i < d.files.length; i++) { d.files[i].cat = C.categorize(d.files[i].name); }
      d.files.sort(function (a, b) { return (b.size || 0) - (a.size || 0); });
      collect.scan = d;
      collect.files = d.files;
      collect.sum = C.summarize(d.files);
      collect.phase = d.files.length ? 'ready' : 'empty';
      renderCollect();
    });
  }

  /** Phases where closing the window would lose what the user is doing. */
  function collectBusy() { return collect.phase === 'scan' || collect.phase === 'ready' || collect.phase === 'copy' || state.view === 'ease' || state.view === 'yt' || state.view === 'gfx' || state.view === 'sfx' || state.view === 'txt' || ytBusy(); }

  function collectHome() {
    if (state.view !== 'collect') { return; }
    collect = { phase: 'home' };
    renderCollect();
  }

  // ---- Files tab, home screen
  function autoStatus() {
    var a = autoState(), cls = 'dock-status', text, tip = '', kind = 'off';
    if (!a.settings.auto) { text = T.auto.dockOff; }
    else if (!a.alive) {
      if (Date.now() - state.openedAt < 9000) { text = T.auto.dockStarting; kind = 'on'; }
      else { cls += ' err'; text = T.auto.dockDead; tip = T.auto.dockDeadTip; kind = 'err'; }
    } else if (a.state.queue) { cls += ' busy'; text = T.auto.copying(a.state.current || '…', a.state.queue); kind = 'busy'; }
    else { cls += ' on'; text = T.auto.dockOn; kind = 'on'; }
    return { cls: cls, text: text, tip: tip || text, kind: kind, auto: a };
  }

  function activityHtml(a) {
    var log = (a.state && a.state.log) || [], out = [], i;
    for (i = log.length - 1; i >= 0 && out.length < 8; i--) {
      var e = log[i];
      if (e.kind !== 'ok' && e.kind !== 'err') { continue; }
      var parts = String(e.text).split(' → ');
      var time = '';
      try { var d = new Date(e.t); if (!isNaN(d.getTime())) { time = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); } } catch (eT) { time = ''; }
      out.push('<div class="c-file"><span class="c-tag' + (e.kind === 'err' ? ' err' : ' okk') + '">' + (e.kind === 'err' ? '!' : '✓') + '</span>' +
        '<span class="c-name">' + esc(parts[0]) + '</span><span class="c-from">' + esc(parts.length > 1 ? '→ ' + parts.slice(1).join(' → ') : '') +
        '</span><span class="c-size">' + esc(time) + '</span></div>');
    }
    return out.length ? '<div class="c-files">' + out.join('') + '</div>' : '<div class="c-note">' + esc(T.auto.noActivity) + '</div>';
  }

  function homeHtml() {
    var s = autoStatus();
    return '<div class="f-card"><div class="f-main"><div class="f-title">' + esc(T.auto.title) + '</div>' +
      '<div class="f-desc">' + esc(T.auto.desc) + '</div>' +
      '<div id="fStatus" class="' + s.cls + '" title="' + esc(s.tip) + '"><i class="dot"></i><span class="dock-text">' + esc(s.text) + '</span></div></div>' +
      '<label class="switch"><input type="checkbox" id="autoCollect"' + (s.auto.settings.auto ? ' checked' : '') + '><i></i></label></div>' +
      '<div class="f-card"><div class="f-main"><div class="f-title">' + esc(T.auto.manualTitle) + '</div>' +
      '<div class="f-desc">' + esc(T.auto.manualDesc) + '</div></div>' +
      '<button class="c-btn primary" data-cact="scan">' + esc(T.auto.manualBtn) + ' <kbd>↵</kbd></button></div>' +
      '<div class="f-section">' + esc(T.auto.activity) + '</div><div id="fLog">' + activityHtml(s.auto) + '</div>';
  }

  /** Every 2 s: the dot on the rail button, and (on the Files home screen) status + activity. */
  function updateAuto() {
    var s = autoStatus();
    $railDot.className = 'rail-dot ' + s.kind;
    if (state.view === 'collect' && collect.phase === 'home') {
      var el = $('fStatus'), lg = $('fLog');
      if (el) { el.className = s.cls; el.title = s.tip; el.querySelector('.dock-text').textContent = s.text; }
      if (lg) { var html = activityHtml(s.auto); if (lg.innerHTML !== html) { lg.innerHTML = html; } }
    }
  }

  function skippedHtml(list) {
    if (!list || !list.length) { return ''; }
    var by = {}, i, out = [];
    for (i = 0; i < list.length; i++) { by[list[i].reason] = (by[list[i].reason] || 0) + 1; }
    for (var k in by) { if (by.hasOwnProperty(k)) { out.push(by[k] + ' — ' + (T.c.skip[k] || k)); } }
    return '<div class="c-note">' + esc(T.c.skipped) + ' ' + esc(out.join(' · ')) + '</div>';
  }

  function renderCollect() {
    var c = collect, h = [], i;
    var locked = c.phase === 'copy';
    var rb = document.querySelectorAll('.rail-btn[data-tab]');
    for (i = 0; i < rb.length; i++) { rb[i].disabled = locked; }
    if (c.phase === 'home') {
      h.push(homeHtml());
      $fkeys.innerHTML = keysHtml([['↵', T.auto.manualBtn], ['esc', T.auto.toFx]]);
    } else if (c.phase === 'scan') {
      h.push('<div class="empty">' + esc(T.c.scanning) + '</div>');
      $fkeys.innerHTML = keysHtml([['esc', T.c.back]]);
    } else if (c.phase === 'error') {
      h.push('<div class="empty">' + errorText(c.error) + '</div>');
      $fkeys.innerHTML = keysHtml([['esc', T.c.back]]);
    } else if (c.phase === 'empty') {
      h.push('<div class="c-head"><div class="c-big">' + esc(T.c.allInside) + '</div>' +
        '<div class="c-sub">' + esc(T.c.checked(c.scan.total)) + '</div></div>' + skippedHtml(c.scan.skipped));
      $fkeys.innerHTML = keysHtml([['esc', T.c.back]]);
    } else if (c.phase === 'ready') {
      h.push('<div class="c-head"><div class="c-big">' + esc(T.c.found(c.sum.count, C.formatBytes(c.sum.bytes))) + '</div>' +
        '<div class="c-sub">' + esc(T.c.willCopy) + ' <span class="c-path">' + esc(c.scan.importedDir) + '</span></div></div>');
      h.push('<div class="c-cats">');
      for (i = 0; i < C.CATEGORIES.length; i++) {
        var cat = C.CATEGORIES[i], s = c.sum.byCat[cat];
        if (s.count) { h.push('<span class="c-cat"><b>' + CAT_LABEL[cat] + '</b> ' + s.count + ' · ' + C.formatBytes(s.bytes) + '</span>'); }
      }
      h.push('</div>' + skippedHtml(c.scan.skipped));
      h.push('<div class="c-actions"><button class="c-btn primary" data-cact="start">' + esc(T.c.copy) + ' <kbd>↵</kbd></button>' +
        '<button class="c-btn" data-cact="back">' + esc(T.c.back) + '</button></div>');
      h.push('<div class="c-files">');
      for (i = 0; i < c.files.length && i < 200; i++) {
        var f = c.files[i];
        h.push('<div class="c-file"><span class="c-tag">' + CAT_LABEL[f.cat] + '</span><span class="c-name">' + esc(f.name) +
          '</span><span class="c-from">' + esc(C.dirName(f.path)) + '</span><span class="c-size">' + C.formatBytes(f.size) + '</span></div>');
      }
      h.push('</div>');
      $fkeys.innerHTML = keysHtml([['↵', T.c.copy], ['esc', T.c.back]]);
    } else if (c.phase === 'copy') {
      h.push('<div class="c-head"><div class="c-big" id="cCount">' + c.done + ' / ' + c.files.length + '</div>' +
        '<div class="c-sub" id="cCurrent">' + esc(c.current) + '</div></div>' +
        '<div class="c-bar"><div class="c-fill" id="cFill"></div></div>' +
        '<div class="c-sub" id="cBytes"></div>' +
        '<div class="c-note">' + esc(c.engine === 'node' ? T.c.keepWorking : T.c.mayFreeze) + '</div>' +
        '<div class="c-actions"><button class="c-btn" data-cact="stop">' + esc(c.cancel ? T.c.stopping : T.c.stop) + '</button></div>');
      $fkeys.innerHTML = keysHtml([['esc', T.c.stop]]);
    } else if (c.phase === 'done') {
      var bad = c.errors.length;
      h.push('<div class="c-head"><div class="c-big">' + esc(bad ? T.c.doneWithErrors : T.c.done) + '</div>' +
        '<div class="c-sub">' + esc(T.c.result(c.copied, c.reused, c.relinked)) + '</div></div>');
      if (c.cancel && c.done < c.files.length) { h.push('<div class="c-note">' + esc(T.c.stoppedAt(c.done, c.files.length)) + '</div>'); }
      h.push('<div class="c-note strong">' + esc(T.c.saveHint) + '</div>');
      h.push('<div class="c-actions"><button class="c-btn primary" data-cact="close">' + esc(T.c.close) + ' <kbd>↵</kbd></button></div>');
      if (bad) {
        h.push('<div class="c-files">');
        for (i = 0; i < c.errors.length; i++) {
          h.push('<div class="c-file"><span class="c-tag err">!</span><span class="c-name">' + esc(c.errors[i].name) +
            '</span><span class="c-from">' + esc(T.c.errReason[c.errors[i].reason] || c.errors[i].reason) + '</span></div>');
        }
        h.push('</div>');
      }
      $fkeys.innerHTML = keysHtml([['↵', T.c.close]]);
    }
    $files.innerHTML = h.join('');
    $files.scrollTop = 0;
    if (c.phase === 'copy') { updateCollectProgress(); }
  }

  function updateCollectProgress() {
    var c = collect;
    var fill = $('cFill'), bytes = $('cBytes');
    if (!fill || !c.sum) { return; }
    var done = c.bytesDone + c.bytesFile, total = c.sum.bytes || 1;
    fill.style.width = Math.max(0, Math.min(100, done / total * 100)).toFixed(1) + '%';
    bytes.textContent = C.formatBytes(done) + ' / ' + C.formatBytes(c.sum.bytes);
  }

  function startCopy() {
    var c = collect;
    if (c.phase !== 'ready') { return; }
    var fs = nodeFs();
    var copier = fs ? C.createCopier(fs) : null;
    var finder = fs ? C.createFinder(fs) : null;
    c.engine = copier ? 'node' : 'host';
    c.phase = 'copy';
    setBusy(true);
    var i = 0;

    function finish() {
      setBusy(false);
      c.phase = 'done';
      state.lastResult = { item: 'c:collect', at: new Date().toISOString(),
        res: { engine: c.engine, files: c.files.length, copied: c.copied, reused: c.reused, relinked: c.relinked, errors: c.errors } };
      if (state.view === 'collect') { renderCollect(); }
    }

    function next() {
      if (c.cancel || i >= c.files.length) { finish(); return; }
      var f = c.files[i++];
      c.current = f.name;
      c.bytesFile = 0;
      renderCollect();
      var dir = C.join(c.scan.importedDir, f.cat);
      var existing = null;
      try { existing = finder ? finder.find(c.scan.projectDir, f.name, f.size) : null; } catch (eFind) { existing = null; }
      var job = existing ? Promise.resolve({ to: existing, reused: true, bytes: 0 }) : copier
        ? copier.copyInto(f.path, dir, f.name, function (doneBytes) { c.bytesFile = doneBytes; updateCollectProgress(); })
        : B.call('copyInto', { from: f.path, dir: dir, name: f.name }).then(function (r) {
            if (!r || !r.ok) { throw new Error((r && r.code) || 'copyFailed'); }
            return r.data;
          });
      job.then(function (res) {
        if (finder && !res.reused) { finder.add(c.scan.projectDir, res.to); }
        return B.call('relinkMedia', { pairs: [{ from: f.path, to: res.to }] }).then(function (rr) {
          if (res.reused) { c.reused++; } else { c.copied++; }
          if (rr && rr.ok && rr.data.relinked && !rr.data.failed) { c.relinked += rr.data.relinked; }
          else { c.errors.push({ name: f.name, reason: 'relink' }); }
        });
      }).catch(function (e) {
        c.errors.push({ name: f.name, reason: String((e && (e.code || e.message)) || e) });
      }).then(function () {
        c.done++;
        c.bytesDone += f.size || 0;
        c.bytesFile = 0;
        next();
      });
    }
    next();
  }

  function collectAction(act) {
    var c = collect;
    if (act === 'scan') { if (c.phase === 'home') { openCollect(); } }
    else if (act === 'start') { startCopy(); }
    else if (act === 'stop') { if (c.phase === 'copy' && !c.cancel) { c.cancel = true; renderCollect(); } }
    else if (act === 'close') { if (MODE === 'popup') { closeWindow(); } else { collectHome(); } }
    else if (act === 'back') { if (c.phase !== 'copy') { collectHome(); } }
  }

  function collectKey(e) {
    var c = collect;
    if (e.key === 'Enter') {
      e.preventDefault();
      if (c.phase === 'home') { collectAction('scan'); }
      else if (c.phase === 'ready') { collectAction('start'); }
      else if (c.phase === 'done') { collectAction('close'); }
      else if (c.phase === 'empty' || c.phase === 'error') { collectAction('back'); }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false, true); }
      else if (c.phase === 'home') { switchTab('fx'); }
      else if (c.phase === 'copy') { collectAction('stop'); }
      else if (c.phase === 'done') { collectAction('close'); }
      else { collectAction('back'); }
    }
  }

  /** ⌘1 / ⌘2 switch tools from anywhere. */
  function tabKey(e) {
    if (!(e.metaKey || e.ctrlKey) || e.altKey) { return false; }
    if (e.key === '1') { e.preventDefault(); switchTab('fx'); return true; }
    if (e.key === '2') { e.preventDefault(); switchTab('files'); return true; }
    if (e.key === '3') { e.preventDefault(); switchTab('zones'); return true; }
    if (e.key === '4') { e.preventDefault(); switchTab('ease'); return true; }
    if (e.key === '5') { e.preventDefault(); switchTab('yt'); return true; }
    if (e.key === '6') { e.preventDefault(); switchTab('gfx'); return true; }
    if (e.key === '7') { e.preventDefault(); switchTab('sfx'); return true; }
    if (e.key === '8') { e.preventDefault(); switchTab('txt'); return true; }
    return false;
  }

  var COMMANDS = [
    { id: 'c:collect', name: 'ფაილების შეგროვება', kind: 'command', run: openCollect,
      alt: 'collect files imported copy media consolidate gather ფაილები კოპირება იმპორტი პროექტის საქაღალდე',
      meta: 'გარე ფაილები → Imported' }
  ];

  // ------------------------------------------------------------------ safe zones
  var Z = window.QFXZones;
  var ZONE_SECONDS = 10, ZONE_REV = 'v2';                     // bump ZONE_REV when the drawings change: old PNGs are then left alone
  var $zList = $('zList'), $zPreview = $('zPreview'), $zInfo = $('zInfo'), $zStatus = $('zStatus'), $zHint = $('zHint');
  var $zApply = $('zApply'), $zToggle = $('zToggle'), $zRemove = $('zRemove'), $railDotZ = $('railDotZ');
  var zones = { active: 0, state: null, busy: false };

  function zoneFrame(p) {
    var s = zones.state;
    return (s && s.hasSequence && s.width > 0 && s.height > 0) ? [s.width, s.height] : p.base.slice();
  }

  function renderZoneList() {
    var h = [], group = '';
    for (var i = 0; i < Z.PLATFORMS.length; i++) {
      var p = Z.PLATFORMS[i];
      if (p.group !== group) { group = p.group; h.push('<div class="section">' + esc(group === 'v' ? T.z.vertical : T.z.horizontal) + '</div>'); }
      h.push('<div class="row' + (i === zones.active ? ' active' : '') + '" data-z="' + i + '" role="option">' +
        '<span class="badge z-badge"><i class="' + (p.group === 'v' ? 'tall' : 'wide') + (p.id === 'all' ? ' dash' : '') + '"></i></span>' +
        '<span class="name">' + esc(p.name) + '</span>' +
        '<span class="meta">' + esc(p.note || (p.base[0] + ' × ' + p.base[1])) + '</span>' +
        '<span class="ret">↵</span></div>');
    }
    $zList.innerHTML = h.join('');
  }

  function renderZoneSide() {
    var p = Z.PLATFORMS[zones.active], fr = zoneFrame(p), s = zones.state;
    // preview: the sequence's own shape, fitted into the side column
    var maxW = MODE === 'panel' ? 110 : 204, maxH = MODE === 'panel' ? 150 : 178;
    var k = Math.min(maxW / fr[0], maxH / fr[1]);
    var cw = Math.max(40, Math.round(fr[0] * k)), ch = Math.max(40, Math.round(fr[1] * k)), dpr = 2;
    $zPreview.width = cw * dpr; $zPreview.height = ch * dpr;
    $zPreview.style.width = cw + 'px'; $zPreview.style.height = ch + 'px';
    var ctx = $zPreview.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(cw * dpr / fr[0], ch * dpr / fr[1]);
    Z.draw(ctx, p.id, fr[0], fr[1], { background: '#2E3238' });

    var info;
    if (!s || !s.hasSequence) { info = T.z.noSeq; }
    else if (s.under) { info = T.z.willSwap((Z.get(s.under) || { name: s.under }).name); }
    else { info = T.z.willPlace(ZONE_SECONDS); }
    $zInfo.textContent = info;

    var vis = s ? s.visible : 0, hid = s ? s.hidden : 0;
    $zToggle.textContent = (vis || !hid) ? T.z.hide : T.z.show;
    $zToggle.disabled = !(vis || hid);
    $zRemove.disabled = !(vis || hid);
    $zApply.disabled = !(s && s.hasSequence);
    $zStatus.className = 'z-status' + (vis ? ' on' : '');
    $zStatus.textContent = vis ? T.z.visible(vis) : (hid ? T.z.hidden(hid) : (s && s.hasSequence ? T.z.seqSize(s.width, s.height) : ''));
    $zHint.textContent = vis ? T.z.exportHint : '';
    updateZoneDot();
  }

  function updateZoneDot() {
    var vis = zones.state ? zones.state.visible : 0;
    $railDotZ.hidden = !vis;
    $railDotZ.className = 'rail-dot on';
  }

  function refreshZones() {
    return B.call('zoneState').then(function (r) {
      zones.state = (r && r.ok) ? r.data : null;
      if (state.view === 'zones') { renderZoneSide(); } else { updateZoneDot(); }
      return zones.state;
    });
  }

  function setZoneActive(i) {
    var n = Z.PLATFORMS.length;
    zones.active = (i + n) % n;
    renderZoneList();
    renderZoneSide();
    var el = $zList.querySelector('.row.active');
    if (el && el.scrollIntoView) { el.scrollIntoView({ block: 'nearest' }); }
  }

  /** Draw the overlay at the sequence's frame size and save it as a PNG next to the project. */
  function zoneFile(p, W, H) {
    var s = zones.state || {};
    var dir = s.projectDir ? s.projectDir + '/Quick FX/Safe Zones' : (Store.dir() ? Store.dir() + '/zones' : '');
    if (!dir) { return null; }
    var path = dir + '/' + Z.fileName(p.id, W, H).replace(/\.png$/, '-' + ZONE_REV + '.png');
    if (B.fileExists(path)) { return path; }
    var c = document.createElement('canvas');
    c.width = W; c.height = H;
    Z.draw(c.getContext('2d'), p.id, W, H, {});
    var b64 = c.toDataURL('image/png').split(',')[1];
    B.makeDirs(dir);
    return B.writeBase64File(path, b64) ? path : null;
  }

  function applyZone(id, fromSearch) {
    var p = Z.get(id);
    if (!p || zones.busy || state.busy) { return; }
    zones.busy = true;
    setBusy(true);
    refreshZones().then(function (s) {
      if (!s || !s.hasSequence) { return { ok: false, code: 'noSequence' }; }
      var path = zoneFile(p, s.width, s.height);
      if (!path) { return { ok: false, code: 'zoneWriteFailed' }; }
      return B.call('zoneApply', { path: path, id: p.id, seconds: ZONE_SECONDS });
    }).then(function (res) {
      zones.busy = false;
      setBusy(false);
      state.lastResult = { item: 'zone:' + id, at: new Date().toISOString(), res: res };
      if (!res || !res.ok) { state.lastError = res; toast('err', errorText(res)); return refreshZones(); }
      var d = res.data, secs = Math.round(d.seconds * 10) / 10;
      toast('ok', d.replaced ? T.z.swapped(p.name) : T.z.placed(p.name, secs),
        (d.addedTrack ? T.z.newTrack + ' ' : '') + (d.exact ? '' : T.z.notExact), 2600);
      if (MODE === 'popup' && d.exact) { setTimeout(function () { closeWindow(); }, 700); }
      return refreshZones();
    });
  }

  function zoneToggle() {
    var s = zones.state;
    if (!s || !(s.visible || s.hidden)) { return; }
    var hide = s.visible > 0;
    B.call('zoneToggle', { hidden: hide }).then(function (r) {
      if (!r || !r.ok) { state.lastError = r; toast('err', errorText(r)); }
      else { toast('ok', hide ? T.z.nowHidden(r.data.count) : T.z.nowShown(r.data.count)); }
      refreshZones();
    });
  }

  function zoneRemove() {
    B.call('zoneRemoveAll').then(function (r) {
      if (!r || !r.ok) { state.lastError = r; toast('err', errorText(r)); }
      else { toast('ok', T.z.removed(r.data.removed)); }
      refreshZones();
    });
  }

  function zonesKey(e) {
    var k = e.key;
    if (k === 'ArrowDown') { e.preventDefault(); setZoneActive(zones.active + 1); }
    else if (k === 'ArrowUp') { e.preventDefault(); setZoneActive(zones.active - 1); }
    else if (k === 'Enter') { e.preventDefault(); applyZone(Z.PLATFORMS[zones.active].id); }
    else if (k === 'Escape') { e.preventDefault(); if (!$menu.hidden) { openMenu(false, true); } else { switchTab('fx'); } }
  }

  $zList.addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.row[data-z]') : null;
    if (!row) { return; }
    var i = Number(row.getAttribute('data-z'));
    if (i === zones.active && e.detail >= 2) { applyZone(Z.PLATFORMS[i].id); return; }
    setZoneActive(i);
  });
  $zApply.addEventListener('click', function () { applyZone(Z.PLATFORMS[zones.active].id); });
  $zToggle.addEventListener('click', zoneToggle);
  $zRemove.addEventListener('click', zoneRemove);

  // also reachable from the search box: "tiktok", "safe", "ზონ" …
  (function () {
    function runner(id) { return function () { applyZone(id, true); }; }
    for (var i = 0; i < Z.PLATFORMS.length; i++) {
      var p = Z.PLATFORMS[i];
      COMMANDS.push({ id: 'c:zone:' + p.id, name: p.group === 'h' ? p.name : 'Safe Zone — ' + p.name, kind: 'command', icon: 'zone', run: runner(p.id),
        alt: 'safe zone safezone ზონა ზონები უსაფრთხო ' + p.alt, meta: T.z.cmdMeta(ZONE_SECONDS) });
    }
    COMMANDS.push({ id: 'c:zone:toggle', name: T.z.cmdToggle, kind: 'command', icon: 'zone',
      run: function () { refreshZones().then(zoneToggle); },
      alt: 'safe zone hide show ზონა ზონები დამალვა ჩვენება ექსპორტი export', meta: 'Safe Zones' });
  })();


  // ------------------------------------------------------------------ keyframe easing ("მრუდი")
  var E = window.QFXEase;
  var $eGraph = $('eGraph'), $eOut = $('eOut'), $eIn = $('eIn'), $eBez = $('eBez'), $eList = $('eList');
  var $eName = $('eName'), $eSave = $('eSave'), $eMode = $('eMode'), $eTarget = $('eTarget'), $eApply = $('eApply'), $eStatus = $('eStatus');
  var EASE_PRESETS_FILE = 'ease-presets.json', EASE_RECORDS_FILE = 'ease-records.json', EASE_UNDO_FILE = 'ease-undo.json';
  var $eUndo = $('eUndo'), $eParams = $('eParams'), $eAll = $('eAll');
  var ease = {
    cur: E.normalize(state.settings.easeCur || E.builtin('easy')),
    mode: state.settings.easeMode === 'all' ? 'all' : 'playhead',
    info: null, busy: false, drag: null, hover: -1, scale: null, geo: null, user: [],
    include: state.settings.easeInclude || {},        // parameters ticked before (by effect + name): ticked again next time
    paramsSig: ''
  };

  // Which parameters get the curve. Premiere cannot tell a script which keyframes are selected,
  // so they are ticked here. A parameter is pre-ticked only if it is the only one or was ticked before.
  function easeParams() { return (ease.info && ease.info.params) || []; }
  function easeTicked() {
    var ps = easeParams(), out = [];
    if (ps.length === 1) { return [ps[0].id]; }
    for (var i = 0; i < ps.length; i++) { if (ease.include[ps[i].id]) { out.push(ps[i].id); } }
    return out;
  }
  function easeSetTick(ids, on) {
    for (var i = 0; i < ids.length; i++) { if (on) { ease.include[ids[i]] = 1; } else { delete ease.include[ids[i]]; } }
    var keys = [], k;
    for (k in ease.include) { if (ease.include.hasOwnProperty(k)) { keys.push(k); } }
    if (keys.length > 300) { for (i = 0; i < keys.length - 300; i++) { delete ease.include[keys[i]]; } }
    state.settings.easeInclude = ease.include; save(LS.settings, state.settings);
    ease.paramsSig = '';
    renderEaseTarget();
  }
  function renderEaseParams() {
    var ps = easeParams(), ticked = easeTicked(), sig = '', i;
    for (i = 0; i < ps.length; i++) { sig += ps[i].id + ':' + (ticked.indexOf(ps[i].id) >= 0 ? 1 : 0) + ':' + ps[i].clips + ';'; }
    if (sig === ease.paramsSig) { return; }
    ease.paramsSig = sig;
    var h = [];
    for (i = 0; i < ps.length; i++) {
      var on = ticked.indexOf(ps[i].id) >= 0;
      h.push('<button class="e-param' + (on ? ' on' : '') + '" data-id="' + esc(ps[i].id) + '" role="checkbox" aria-checked="' + (on ? 'true' : 'false') + '" title="' + esc(ps[i].name) + '">' +
        '<i class="e-check"></i><span class="e-pname">' + esc(ps[i].param) + '</span><span class="e-pcomp">' + esc(ps[i].comp) + (ps[i].clips > 1 ? ' ×' + ps[i].clips : '') + '</span></button>');
    }
    $eParams.innerHTML = h.length ? h.join('') : '<div class="e-none">' + esc(T.e.noParamsYet) + '</div>';
    $eAll.hidden = ps.length < 2;
    $eAll.textContent = ticked.length === ps.length ? T.e.none : T.e.all;
  }

  function easeUserPresets() {
    var list = Store.read(EASE_PRESETS_FILE, []), out = [];
    if (list && list.length) {
      for (var i = 0; i < list.length; i++) { if (list[i] && list[i].name) { out.push(assign({ name: String(list[i].name), own: true }, E.normalize(list[i]))); } }
    }
    return out;
  }

  // ---- what was baked where, and the undo history: kept NEXT TO THE PROJECT, so they travel with it —
  //      another editor (or this one on another Mac) can still re-curve, return to Linear, or undo.
  //      <project folder>/Quick FX/Curves/<project name>.json   { records: [...], undo: [...] }
  var easeCache = { project: '', at: 0, data: null }, easeLocalOnly = {};
  function easePath(project) {
    var p = String(project || '').replace(/\\/g, '/');
    return p ? C.dirName(p) + '/Quick FX/Curves/' + C.baseName(p).replace(/\.prproj$/i, '') + '.json' : '';
  }
  function easeParse(text) {
    if (!text) { return null; }
    try { var d = JSON.parse(text); return (d && typeof d === 'object' && !(d instanceof Array)) ? d : null; } catch (e) { return null; }
  }
  /** Saved under a new name (v3 → v4)? The clips are the same ones, so the newest neighbour's records still apply. */
  function easeSibling(file) {
    var dir = C.dirName(file), names = B.listDir(dir), best = null;
    for (var i = 0; i < names.length; i++) {
      if (!/\.json$/i.test(names[i]) || dir + '/' + names[i] === file) { continue; }
      var d = easeParse(B.readTextFile(dir + '/' + names[i]));
      if (d && d.records && d.records.length && (!best || (d.saved || 0) > (best.saved || 0))) { best = d; }
    }
    return best ? best.records : null;
  }
  function easeLoad(project) {
    if (!project) { return { records: [], undo: [], where: 'none' }; }
    if (easeCache.project === project && easeCache.data && Date.now() - easeCache.at < 8000) { return easeCache.data; }
    var data = null, file = easePath(project);
    var d = easeLocalOnly[project] ? null : easeParse(B.readTextFile(file));
    if (d) { data = { records: d.records || [], undo: d.undo || [], where: 'project' }; }
    if (!data) {                                                 // this computer, before 1.14 (or a folder that cannot be written)
      var oldR = (Store.read(EASE_RECORDS_FILE, {}) || {})[project], oldU = (Store.read(EASE_UNDO_FILE, {}) || {})[project];
      if ((oldR && oldR.length) || (oldU && oldU.length)) { data = { records: oldR || [], undo: oldU || [], where: 'computer' }; }
    }
    if (!data) { var sib = easeSibling(file); data = sib ? { records: sib, undo: [], where: 'sibling' } : { records: [], undo: [], where: 'new' }; }
    easeCache = { project: project, at: Date.now(), data: data };
    return data;
  }
  function easeSave(project, data) {
    if (!project) { return; }
    var file = easePath(project), okFile = false;
    if (!easeLocalOnly[project]) {
      B.makeDirs(C.dirName(file));
      okFile = B.writeTextFile(file, JSON.stringify({ v: 1, project: C.baseName(String(project).replace(/\\/g, '/')), saved: Date.now(), records: data.records, undo: data.undo }));
    }
    if (!okFile) {
      // read-only volume, no rights: keep working from this computer's own files, as before
      easeLocalOnly[project] = true;
      var allR = Store.read(EASE_RECORDS_FILE, {}) || {}, allU = Store.read(EASE_UNDO_FILE, {}) || {};
      allR[project] = data.records;
      if (data.undo.length) { allU[project] = data.undo; } else { delete allU[project]; }
      Store.write(EASE_RECORDS_FILE, allR); Store.write(EASE_UNDO_FILE, allU);
    }
    data.where = okFile ? 'project' : 'computer';
    easeCache = { project: project, at: Date.now(), data: data };
  }

  function easeRecords(project) { return easeLoad(project).records; }
  function easeSaveRecords(project, drop, add) {
    if (!project) { return []; }
    var data = easeLoad(project), list = data.records, keep = [], displaced = [], i, j;
    for (i = 0; i < list.length; i++) {
      var r = list[i], gone = false;
      for (j = 0; j < drop.length; j++) {
        var d = drop[j];
        if (r.c === d.c && r.k === d.k && r.p === d.p && r.a < d.b - 0.0005 && r.b > d.a + 0.0005) { gone = true; break; }
      }
      if (gone) { displaced.push(r); } else { keep.push(r); }
    }
    for (i = 0; i < add.length; i++) { keep.push(add[i]); }
    if (keep.length > 1500) { keep = keep.slice(keep.length - 1500); }
    easeSave(project, { records: keep, undo: data.undo });
    return displaced;
  }

  // ---- undo: the last few Applies per project, kept on disk so closing the window does not lose them
  function easeUndoStack(project) { return easeLoad(project).undo.slice(); }
  function easeUndoWrite(project, stack) {
    if (!project) { return; }
    while (stack.length > 12) { stack.shift(); }
    while (stack.length > 1 && JSON.stringify(stack).length > 700000) { stack.shift(); }
    easeSave(project, { records: easeLoad(project).records, undo: stack });
  }

  function undoEase() {
    var project = ease.info ? ease.info.project : '';
    var stack = easeUndoStack(project);
    if (!stack.length || ease.busy || state.busy) { return; }
    var step = stack[stack.length - 1];
    ease.busy = true; setBusy(true); renderEaseTarget();
    B.call('easeUndo', { ops: step.ops }).then(function (res) {
      ease.busy = false; setBusy(false);
      state.lastResult = { item: 'ease-undo', at: new Date().toISOString(), res: res };
      stack.pop();
      easeUndoWrite(project, stack);
      if (!res || !res.ok) { state.lastError = res; toast('err', errorText(res)); return refreshEase(); }
      easeSaveRecords(project, step.recAdd || [], step.recBack || []);
      toast(res.data.missing ? 'warn' : 'ok', T.e.undone(res.data.params), res.data.missing ? T.e.undoMissing(res.data.missing) : '', res.data.missing ? 4200 : 1800);
      return refreshEase();
    });
  }

  // ---- the speed graph (time →, speed ↑), After Effects style
  function easeGeometry() {
    var r = $eGraph.getBoundingClientRect(), dpr = 2;
    var w = Math.max(160, Math.round(r.width)), h = Math.max(120, Math.round(r.height));
    if ($eGraph.width !== w * dpr || $eGraph.height !== h * dpr) { $eGraph.width = w * dpr; $eGraph.height = h * dpr; }
    var sc = ease.scale;
    if (!sc) {
      var rg = E.range(ease.cur);
      var hi = Math.max(1.6, rg.max, ease.cur.v0, ease.cur.v1) * 1.14;
      var lo = Math.min(0, rg.min, ease.cur.v0, ease.cur.v1);
      sc = { min: lo < 0 ? lo * 1.2 - 0.1 : -hi * 0.06, max: hi };
    }
    var g = { w: w, h: h, dpr: dpr, L: 16, T: 14, W: w - 32, H: h - 34, min: sc.min, max: sc.max };
    g.px = function (x) { return g.L + x * g.W; };
    g.py = function (s) { return g.T + (g.max - s) / (g.max - g.min) * g.H; };
    g.sOf = function (py) { return g.max - (py - g.T) / g.H * (g.max - g.min); };
    ease.geo = g;
    return g;
  }

  function drawEase() {
    var g = easeGeometry(), c = $eGraph.getContext('2d'), e = ease.cur, i;
    c.setTransform(g.dpr, 0, 0, g.dpr, 0, 0);
    c.clearRect(0, 0, g.w, g.h);
    // grid
    c.lineWidth = 1;
    for (i = 0; i <= 10; i++) {
      c.strokeStyle = (i === 0 || i === 5 || i === 10) ? '#2A2A2A' : '#191919';
      c.beginPath(); c.moveTo(Math.round(g.px(i / 10)) + 0.5, g.T); c.lineTo(Math.round(g.px(i / 10)) + 0.5, g.T + g.H); c.stroke();
    }
    var stepS = g.max - g.min > 5 ? 1 : 0.5;
    for (var s = Math.ceil(g.min / stepS) * stepS; s <= g.max; s += stepS) {
      if (Math.abs(s) < 1e-6) { continue; }
      c.strokeStyle = '#191919';
      c.beginPath(); c.moveTo(g.L, Math.round(g.py(s)) + 0.5); c.lineTo(g.L + g.W, Math.round(g.py(s)) + 0.5); c.stroke();
    }
    // average speed (what a linear move would be)
    c.save(); c.strokeStyle = '#4A4A4A'; c.setLineDash([3, 5]);
    c.beginPath(); c.moveTo(g.L, Math.round(g.py(1)) + 0.5); c.lineTo(g.L + g.W, Math.round(g.py(1)) + 0.5); c.stroke(); c.restore();
    c.fillStyle = '#6E6E6E'; c.font = '10px -apple-system, "Helvetica Neue", Arial, sans-serif'; c.textBaseline = 'bottom';
    c.fillText('linear', g.L + 4, g.py(1) - 3);
    // zero line, dotted like AE's
    c.save(); c.strokeStyle = 'rgba(253,74,0,0.6)'; c.setLineDash([1.5, 3]);
    c.beginPath(); c.moveTo(g.L, Math.round(g.py(0)) + 0.5); c.lineTo(g.L + g.W, Math.round(g.py(0)) + 0.5); c.stroke(); c.restore();
    // reference: how far the move has got (0 → 100%), drawn over the full height
    var bz = E.toBezier(e);
    c.strokeStyle = '#4A4A4A'; c.lineWidth = 1.25; c.beginPath();
    for (i = 0; i <= 60; i++) {
      var vy = E.valueAt(bz, i / 60), yy = g.py(0) - Math.max(-0.08, Math.min(1.04, vy)) * (g.py(0) - g.T - 4);
      if (i === 0) { c.moveTo(g.px(0), yy); } else { c.lineTo(g.px(i / 60), yy); }
    }
    c.stroke();
    // the speed curve
    var pts = E.speedCurve(e, 140);
    c.beginPath(); c.moveTo(g.px(pts[0].x), g.py(0));
    for (i = 0; i < pts.length; i++) { c.lineTo(g.px(pts[i].x), g.py(pts[i].s)); }
    c.lineTo(g.px(pts[pts.length - 1].x), g.py(0)); c.closePath();
    c.fillStyle = 'rgba(253,74,0,0.11)'; c.fill();
    c.beginPath();
    for (i = 0; i < pts.length; i++) { if (i === 0) { c.moveTo(g.px(pts[i].x), g.py(pts[i].s)); } else { c.lineTo(g.px(pts[i].x), g.py(pts[i].s)); } }
    c.strokeStyle = '#FD4A00'; c.lineWidth = 2.5; c.lineJoin = 'round'; c.stroke();
    // handles: length = influence, height = speed at the keyframe
    var hs = [[0, e.v0, e.i0, e.v0], [1, e.v1, 1 - e.i1, e.v1]];
    for (i = 0; i < 2; i++) {
      var h = hs[i], hot = ease.hover === i || (ease.drag && ease.drag.which === i);
      c.strokeStyle = '#FFFFFF'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(g.px(h[0]), g.py(h[1])); c.lineTo(g.px(h[2]), g.py(h[3])); c.stroke();
      c.fillStyle = '#FD4A00'; c.fillRect(g.px(h[0]) - 4, g.py(h[1]) - 4, 8, 8);                    // the keyframe
      c.beginPath(); c.arc(g.px(h[2]), g.py(h[3]), hot ? 6.5 : 5, 0, Math.PI * 2);
      c.fillStyle = '#FFFFFF'; c.fill();
      if (hot) { c.lineWidth = 2; c.strokeStyle = '#FD4A00'; c.stroke(); }
    }
    // readouts
    function pc(n) { return Math.round(n * 100) + '%'; }
    function sp(n) { return (Math.round(n * 100) / 100) + '×'; }
    $eOut.innerHTML = esc(T.e.out) + ' <b>' + pc(e.i0) + '</b>' + (Math.abs(e.v0) > 0.005 ? ' · ' + sp(e.v0) : '');
    $eIn.innerHTML = esc(T.e.inn) + ' <b>' + pc(e.i1) + '</b>' + (Math.abs(e.v1) > 0.005 ? ' · ' + sp(e.v1) : '');
    $eBez.textContent = E.label(e);
  }

  function drawThumb(cv, e) {
    var w = 46, h = 26, dpr = 2, c = cv.getContext('2d'), pts = E.speedCurve(e, 40), rg = E.range(e), i;
    cv.width = w * dpr; cv.height = h * dpr;
    var hi = Math.max(1.2, rg.max) * 1.1, lo = Math.min(0, rg.min);
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.strokeStyle = cv.getAttribute('data-on') ? '#000000' : '#FD4A00'; c.lineWidth = 1.6; c.lineJoin = 'round'; c.beginPath();
    for (i = 0; i < pts.length; i++) {
      var x = 2 + pts[i].x * (w - 4), y = 3 + (hi - pts[i].s) / (hi - lo) * (h - 6);
      if (i === 0) { c.moveTo(x, y); } else { c.lineTo(x, y); }
    }
    c.stroke();
  }

  function renderEaseList() {
    ease.user = easeUserPresets();
    var all = E.PRESETS.concat(ease.user), h = [], i;
    for (i = 0; i < all.length; i++) {
      var p = all[i], on = E.same(p, ease.cur);
      if (i === E.PRESETS.length) { h.push('<div class="e-label e-mine">' + esc(T.e.mine) + '</div>'); }
      h.push('<div class="e-row' + (on ? ' on' : '') + '" data-p="' + i + '"><canvas class="e-thumb"' + (on ? ' data-on="1"' : '') + '></canvas>' +
        '<span class="e-name">' + esc(p.name) + '</span>' + (p.key ? '<kbd>' + p.key + '</kbd>' : '') +
        (p.own ? '<button class="e-del" data-del="' + (i - E.PRESETS.length) + '" title="' + esc(T.e.del) + '" aria-label="' + esc(T.e.del) + '">×</button>' : '') + '</div>');
    }
    $eList.innerHTML = h.join('');
    var cvs = $eList.querySelectorAll('.e-thumb');
    for (i = 0; i < cvs.length; i++) { drawThumb(cvs[i], all[i]); }
  }

  function setEase(e, keepScale) {
    ease.cur = E.normalize(e);
    if (!keepScale) { ease.scale = null; }
    state.settings.easeCur = ease.cur;
    save(LS.settings, state.settings);
    drawEase();
    if (!keepScale) { renderEaseList(); }
  }

  function renderEaseTarget() {
    var d = ease.info, text, can = false;
    if (!d || !d.hasSequence) { text = T.z.noSeq; }
    else if (!d.clips) { text = T.e.selectClip; }
    else if (!d.segments) { text = ease.mode === 'all' ? T.e.noKeys : T.e.parkPlayhead; }
    else {
      var ticked = easeTicked();
      can = ticked.length > 0;
      text = can
        ? T.e.chosen(ticked.length, d.params.length) + (ease.mode === 'playhead' && d.seconds ? ' · ' + (Math.round(d.seconds * 100) / 100) + ' ' + T.e.sec : '')
        : T.e.pickParams;
    }
    renderEaseParams();
    $eTarget.textContent = text;
    $eTarget.title = '';
    $eTarget.className = 'e-target' + (can ? ' ok' : '');
    $eApply.disabled = !can || ease.busy;
    var steps = easeUndoStack(d ? d.project : '').length;
    $eUndo.disabled = !steps || ease.busy;
    $eUndo.title = steps ? T.e.undoTip(steps) : T.e.undoNone;
    $eStatus.textContent = d && d.clips ? T.e.clips(d.clips) : '';
    var qb = document.querySelectorAll('[data-ease]');
    for (var i = 0; i < qb.length; i++) { qb[i].disabled = !can || ease.busy; }
    var mb = $eMode.querySelectorAll('button');
    for (i = 0; i < mb.length; i++) { mb[i].classList.toggle('on', mb[i].getAttribute('data-mode') === ease.mode); }
  }

  function refreshEase() {
    var project = ease.info ? ease.info.project : '';
    return B.call('easeInfo', { mode: ease.mode, records: easeRecords(project) }).then(function (r) {
      var d = (r && r.ok) ? r.data : null;
      // the first answer tells us which project it is: ask again with that project's records
      if (d && d.project !== project && easeRecords(d.project).length) { ease.info = d; return refreshEase(); }
      ease.info = d;
      if (state.view === 'ease') { renderEaseTarget(); }
      return d;
    });
  }

  /** e = {i0,v0,i1,v1} or null for "back to linear". */
  function applyEase(e, fromSearch) {
    if (ease.busy || state.busy) { return; }
    ease.busy = true; setBusy(true); renderEaseTarget();
    refreshEase().then(function (d) {
      if (!d || !d.hasSequence) { return { ok: false, code: 'noSequence' }; }
      var only = easeTicked();
      if (d.segments && !only.length) { return { ok: false, code: 'noParams' }; }
      return B.call('easeApply', { mode: ease.mode, lut: e ? E.lut(e) : null, records: easeRecords(d.project), only: only });
    }).then(function (res) {
      ease.busy = false; setBusy(false);
      state.lastResult = { item: 'ease', at: new Date().toISOString(), res: res && res.ok ? assign(assign({}, res.data), { add: res.data.add.length, drop: res.data.drop.length, undo: (res.data.undo || []).length }) : res };
      if (!res || !res.ok) {
        state.lastError = res; toast('err', errorText(res));
        if (res && res.code === 'noParams' && state.view !== 'ease') { switchTab('ease'); }      // came from the search box: go and tick
        return refreshEase();
      }
      var d = res.data, notes = [];
      var project = ease.info ? ease.info.project : '';
      var displaced = easeSaveRecords(project, d.drop, d.add);
      if (d.undo && d.undo.length) {
        var stack = easeUndoStack(project);
        stack.push({ at: Date.now(), ops: d.undo, recAdd: d.add, recBack: displaced });
        easeUndoWrite(project, stack);
      }
      if (d.partial) { notes.push(T.e.partial); }
      if (d.skipped.flat) { notes.push(T.e.flat(d.skipped.flat)); }
      if (d.skipped.tooShort) { notes.push(T.e.tooShort(d.skipped.tooShort)); }
      if (d.skipped.unsupported) { notes.push(T.e.unsupported(d.skipped.unsupported)); }
      toast(d.partial ? 'warn' : 'ok', d.linear ? T.e.linearDone(d.params) : T.e.applied(d.params, d.added), notes.join(' '), notes.length ? 4200 : 2200);
      if (fromSearch && MODE === 'popup' && !notes.length) { setTimeout(function () { closeWindow(); }, 600); }
      return refreshEase();
    });
  }

  function easeQuick(id, fromSearch) {
    if (id === 'linear') { applyEase(null, fromSearch); return; }
    var p = E.builtin(id);
    if (!p) { return; }
    if (state.view === 'ease') { setEase(p); }
    applyEase(p, fromSearch);
  }

  // ---- dragging the handles
  function easePoint(ev) {
    var r = $eGraph.getBoundingClientRect();
    return { x: ev.clientX - r.left, y: ev.clientY - r.top };
  }
  function easeHit(pt) {
    var g = ease.geo, e = ease.cur;
    if (!g) { return -1; }
    var ks = [[g.px(e.i0), g.py(e.v0)], [g.px(1 - e.i1), g.py(e.v1)]], best = -1, bd = 18 * 18;
    for (var i = 0; i < 2; i++) {
      var dx = ks[i][0] - pt.x, dy = ks[i][1] - pt.y, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
  $eGraph.addEventListener('mousedown', function (ev) {
    var which = easeHit(easePoint(ev));
    if (which < 0) { return; }
    ev.preventDefault();
    ease.drag = { which: which };
    ease.scale = { min: ease.geo.min, max: ease.geo.max };               // keep the axes still while dragging
    drawEase();
  });
  window.addEventListener('mousemove', function (ev) {
    if (state.view !== 'ease') { return; }
    var pt = easePoint(ev), g = ease.geo;
    if (!ease.drag) {
      var hv = easeHit(pt);
      if (hv !== ease.hover) { ease.hover = hv; $eGraph.style.cursor = hv >= 0 ? 'grab' : 'default'; drawEase(); }
      return;
    }
    var x = Math.max(0, Math.min(1, (pt.x - g.L) / g.W)), s = g.sOf(pt.y), e = assign({}, ease.cur);
    if (Math.abs(s) < (g.max - g.min) * 0.035) { s = 0; }                 // snaps to "at rest" and to "linear"
    else if (Math.abs(s - 1) < (g.max - g.min) * 0.03) { s = 1; }
    if (ev.shiftKey) { s = ease.drag.which === 0 ? e.v0 : e.v1; }         // ⇧ = only the length
    if (ease.drag.which === 0) { e.i0 = x; e.v0 = s; } else { e.i1 = 1 - x; e.v1 = s; }
    setEase(e, true);
  });
  window.addEventListener('mouseup', function () {
    if (!ease.drag) { return; }
    ease.drag = null; ease.scale = null;
    drawEase(); renderEaseList();
  });

  $eList.addEventListener('click', function (ev) {
    var del = ev.target.closest ? ev.target.closest('[data-del]') : null;
    if (del) {
      var list = easeUserPresets(); list.splice(Number(del.getAttribute('data-del')), 1);
      Store.write(EASE_PRESETS_FILE, list); renderEaseList(); return;
    }
    var row = ev.target.closest ? ev.target.closest('.e-row') : null;
    if (!row) { return; }
    var p = E.PRESETS.concat(ease.user)[Number(row.getAttribute('data-p'))];
    if (!p) { return; }
    setEase(p);
    if (ev.detail >= 2 && !$eApply.disabled) { applyEase(ease.cur); }
  });
  function easeSavePreset() {
    var name = String($eName.value || '').replace(/^\s+|\s+$/g, '');
    if (!name) { $eName.focus(); return; }
    var list = easeUserPresets(), found = false;
    for (var i = 0; i < list.length; i++) { if (list[i].name.toLowerCase() === name.toLowerCase()) { list[i] = assign({ name: name }, ease.cur); found = true; } }
    if (!found) { list.push(assign({ name: name }, ease.cur)); }
    for (i = 0; i < list.length; i++) { delete list[i].own; }
    if (!Store.write(EASE_PRESETS_FILE, list)) { toast('err', T.e.saveFailed); return; }
    $eName.value = ''; $eName.blur();
    renderEaseList();
    toast('ok', T.e.saved(name));
  }
  $eSave.addEventListener('click', easeSavePreset);
  $eApply.addEventListener('click', function () { applyEase(ease.cur); });
  $eUndo.addEventListener('click', undoEase);
  $eParams.addEventListener('click', function (ev) {
    var b = ev.target.closest ? ev.target.closest('.e-param') : null;
    if (!b) { return; }
    var id = b.getAttribute('data-id');
    easeSetTick([id], easeTicked().indexOf(id) < 0);
  });
  $eAll.addEventListener('click', function () {
    var ps = easeParams(), ids = [], i;
    for (i = 0; i < ps.length; i++) { ids.push(ps[i].id); }
    easeSetTick(ids, easeTicked().length !== ps.length);
  });
  $eMode.addEventListener('click', function (ev) {
    var b = ev.target.closest ? ev.target.closest('button[data-mode]') : null;
    if (!b) { return; }
    ease.mode = b.getAttribute('data-mode');
    state.settings.easeMode = ease.mode; save(LS.settings, state.settings);
    renderEaseTarget(); refreshEase();
  });
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest ? ev.target.closest('[data-ease]') : null;
    if (b && !b.disabled) { easeQuick(b.getAttribute('data-ease')); }
  });

  function easeKey(e) {
    var typing = document.activeElement === $eName;
    if (e.key === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false, true); } else if (typing) { $eName.blur(); } else { switchTab('fx'); }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (typing) { easeSavePreset(); } else if (!$eApply.disabled) { applyEase(ease.cur); }
    } else if (e.key === 'F9') { e.preventDefault(); easeQuick('easy'); }
  }

  function openEase() { ease.scale = null; drawEase(); renderEaseList(); renderEaseTarget(); refreshEase(); }
  window.addEventListener('resize', function () { if (state.view === 'ease') { drawEase(); } });

  // from the search box too: "easy ease", "ease in", "მრუდი" …
  (function () {
    function runner(id) { return function () { easeQuick(id, true); }; }
    var items = [['easy', 'Easy Ease', 'F9'], ['in', 'Ease In', ''], ['out', 'Ease Out', ''], ['linear', 'Linear keyframes', '']];
    for (var i = 0; i < items.length; i++) {
      COMMANDS.push({ id: 'c:ease:' + items[i][0], name: items[i][1], kind: 'command', icon: 'ease', run: runner(items[i][0]),
        alt: 'ease easing keyframe keyframes f9 smooth მრუდი ეიზი ქეიფრეიმი სიჩქარე ' + items[i][1], meta: T.e.cmdMeta });
    }
  })();

  // ------------------------------------------------------------------ YouTube: link → file in the Project panel
  var Y = window.QFXYt;
  var $yUrl = $('yUrl'), $yMain = $('yMain'), $yGo = $('yGo'), $yQueue = $('yQueue'), $yDest = $('yDest'), $yStatus = $('yStatus');
  var $yPaste = $('yPaste'), $railDotY = $('railDotY');
  var YT_FRESH_MS = 3 * 24 * 3600 * 1000;                       // yt-dlp checks for its own update this often
  var yt = {
    phase: 'idle',            // the chooser: setup | install | idle | loading | info | error
    queue: [], job: null, seq: 0,                                // downloads: waiting, running (job), finished — one runs at a time
    url: '', info: null, token: 0, timer: null,
    mode: state.settings.ytMode || 'both', height: Number(state.settings.ytHeight) || 1080,
    target: null, prog: null, error: null, result: null, cookies: '', install: null, home: '',
    sec: { on: false, from: '', to: '' }                        // only a part of the video: typed times, as typed
  };

  function nodeReq() { return (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null); }

  function ytEngine() {
    if (window.__QFX_YT_ENGINE) { return window.__QFX_YT_ENGINE; }
    if (yt.engine !== undefined) { return yt.engine; }
    yt.engine = null;
    try {
      var req = nodeReq();
      if (!req) { throw new Error('node is not available'); }
      var os = req('os'), dir = Store.dir();
      if (!dir) { throw new Error('no user data folder'); }
      yt.home = os.homedir();
      yt.engine = Y.createEngine({ fs: req('fs'), os: os, child_process: req('child_process'), https: req('https'), http: req('http'),
        process: (window.cep_node && window.cep_node.process) || req('process') }, { binDir: dir + '/bin', arch: os.arch() });
    } catch (e) { yt.engineError = String(e && e.message || e); }
    return yt.engine;
  }

  /** Text on the macOS clipboard (pbpaste), or null when it cannot be read this way. */
  function ytClipboard() {
    if (typeof window.__QFX_CLIPBOARD === 'function') { return window.__QFX_CLIPBOARD(); }
    try {
      var req = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
      if (!req) { return null; }
      return String(req('child_process').execFileSync('/usr/bin/pbpaste', [], { encoding: 'utf8', timeout: 2000 }));
    } catch (e) { return null; }
  }

  function ytWaiting() { var n = 0; for (var i = 0; i < yt.queue.length; i++) { if (yt.queue[i].state === 'wait') { n++; } } return n; }
  function ytBusy() { return yt.phase === 'install' || !!yt.job || ytWaiting() > 0; }
  function ytDiag() {
    var st = null;
    try { st = yt.engine ? yt.engine.status() : null; } catch (e) { st = String(e); }
    var q = [];
    for (var i = 0; i < yt.queue.length; i++) { q.push({ state: yt.queue[i].state, tag: yt.queue[i].tag, error: yt.queue[i].error || null }); }
    return { phase: yt.phase, error: yt.error, engine: st, engineError: yt.engineError || null, target: yt.target, mode: yt.mode, height: yt.height, queue: q };
  }

  function ytQualities() {
    var all = (yt.info && yt.info.qualities) || [], out = [];
    for (var i = 0; i < all.length; i++) { if (all[i].height >= 360) { out.push(all[i]); } }
    return out.length ? out : all;
  }
  /** The quality that will be downloaded: the remembered one when this video has it, else the best that needs no converting. */
  function ytChosen() {
    var list = ytQualities(), i;
    for (i = 0; i < list.length; i++) { if (list[i].height === yt.height) { return list[i]; } }
    for (i = 0; i < list.length; i++) { if (list[i].height <= yt.height) { return list[i]; } }
    for (i = 0; i < list.length; i++) { if (list[i].direct) { return list[i]; } }
    return list[0] || null;
  }
  /** The part to download: { start, end } in seconds · null for the whole video · { error } while the typed times do not make sense. */
  function ytSection() {
    if (!yt.sec.on || !yt.info) { return null; }
    var dur = yt.info.duration || 0, f = yt.sec.from.replace(/\s/g, ''), t = yt.sec.to.replace(/\s/g, '');
    if (!f && !t) { return { error: T.y.sec.empty }; }
    var a = f ? Y.parseTime(f) : 0, b = t ? Y.parseTime(t) : (dur || null);
    if (a === null) { return { error: T.y.sec.badFrom }; }
    if (b === null) { return { error: T.y.sec.badTo }; }
    if (dur && a >= dur) { return { error: T.y.sec.past(Y.clock(dur)) }; }
    if (dur && b > dur) { b = dur; }
    if (b <= a) { return { error: T.y.sec.order }; }
    return { start: a, end: b };
  }
  function ytSize() {
    var q = ytChosen(), i = yt.info, bytes = 0, sec = ytSection();
    if (!i || (sec && sec.error)) { return ''; }
    if (yt.mode !== 'audio' && q) { bytes += q.bytes || 0; }
    if (yt.mode !== 'video') { bytes += i.audioBytes || 0; }
    if (sec && i.duration) { bytes = bytes * (sec.end - sec.start) / i.duration; }
    return bytes > 0 ? T.y.about(C.formatBytes(bytes)) : '';
  }
  function ytSecText() {
    var sec = ytSection();
    if (!sec) { return ''; }
    if (sec.error) { return sec.error; }
    var len = Y.clock(sec.end - sec.start) + (sec.end - sec.start < 60 ? ' წმ' : '');
    return (yt.mode === 'audio' ? T.y.sec.lenAudio : T.y.sec.len)(len.replace(/^0:(\d\d) წმ$/, function (m, s2) { return Number(s2) + ' წმ'; }));
  }
  /** While typing in the two time fields nothing is re-drawn (the caret would jump): only the line under them and the button. */
  function ytSecUpdate() {
    var sec = ytSection(), $i = $('ySecInfo');
    if ($i) { $i.textContent = ytSecText(); $i.className = 'y-secinfo' + (sec && sec.error ? ' bad' : ''); }
    $yStatus.textContent = yt.phase === 'info' ? ytSize() : '';
    if (yt.phase === 'info') { $yGo.disabled = !!(sec && sec.error); }
  }
  function ytSiteName() { return (yt.info && yt.info.siteName) || 'YouTube'; }
  /** <project folder>/Imported/<YouTube | TikTok | …>; without a saved project: ~/Downloads/Quick FX */
  function ytDir() {
    if (yt.target && yt.target.projectDir) { return yt.target.projectDir + '/Imported/' + ytSiteName(); }
    return (yt.home || '') + '/Downloads/Quick FX';
  }

  function ytCardHtml() {
    var i = yt.info;
    return '<div class="y-card">' + (i.thumbnail ? '<img class="y-thumb" src="' + esc(i.thumbnail) + '" alt="" onerror="this.style.visibility=\'hidden\'">' : '<span class="y-thumb"></span>') +
      '<div class="y-meta"><div class="y-title">' + esc(i.title || yt.url) + '</div><div class="y-by">' +
      (i.site && i.site !== 'youtube' ? '<b class="y-site">' + esc(i.siteName) + '</b>' : '') + esc(i.uploader) +
      (i.duration ? (i.uploader ? ' · ' : '') + Y.clock(i.duration) : '') +
      (i.clean ? '<span class="y-clean">✓ ' + esc(T.y.clean) + '</span>' : '') + '</div></div></div>';
  }

  function ytProgressHtml() {
    return '<div class="y-prog"><div class="y-prow"><span id="yPhase" class="y-phase"></span><span id="yPct" class="y-pct"></span></div>' +
      '<div class="c-bar" id="yBarWrap"><div class="c-fill" id="yBar"></div></div><div id="yRate" class="y-rate"></div></div>';
  }

  function renderYt() {
    var h = [], p = yt.phase, i;
    if (p === 'setup' || p === 'install') {
      h.push('<div class="f-card y-setup"><div class="f-main"><div class="f-title">' + esc(T.y.setupTitle) + '</div><div class="f-desc">' + esc(T.y.setupDesc) + '</div>' +
        (p === 'install' ? ytProgressHtml() : '') + '</div>' +
        (p === 'setup' ? '<button class="c-btn primary" data-yact="install">' + esc(T.y.setupBtn) + '</button>' : '') + '</div>');
    } else if (p === 'idle') {
      h.push('<div class="y-empty"><div class="y-big">' + esc(T.y.idleTitle) + '</div><ol>');
      for (i = 0; i < T.y.idle.length; i++) { h.push('<li>' + esc(T.y.idle[i]) + '</li>'); }
      h.push('</ol></div>');
    } else if (p === 'loading') {
      h.push('<div class="y-empty y-wait"><span class="spinner"></span><div class="y-big">' + esc(yt.updating ? T.y.updating : T.y.loading) + '</div><div class="c-note">' + esc(T.y.loadingSub) + '</div></div>');
    } else if (p === 'info') {
      var list = ytQualities(), q = ytChosen(), modes = ['both', 'video', 'audio'];
      h.push(ytCardHtml());
      h.push('<div class="y-label">' + esc(T.y.what) + '</div><div class="seg y-seg" role="group">');
      for (i = 0; i < modes.length; i++) {
        var off = (modes[i] !== 'video' && !yt.info.hasAudio) || (modes[i] !== 'audio' && !list.length);
        h.push('<button data-ymode="' + modes[i] + '"' + (yt.mode === modes[i] ? ' class="on"' : '') + (off ? ' disabled' : '') + '>' + esc(T.y.modes[modes[i]]) + '</button>');
      }
      h.push('</div>');
      if (yt.mode === 'audio') {
        h.push('<div class="c-note">' + esc(yt.info.site === 'tiktok' ? T.y.audioOwn : T.y.audioNote) + '</div>');
      } else {
        h.push('<div class="y-label">' + esc(T.y.quality) + '</div><div class="y-chips">');
        for (i = 0; i < list.length; i++) {
          h.push('<button class="y-chip' + (q && list[i].height === q.height ? ' on' : '') + (list[i].direct ? '' : ' conv') + '" data-yq="' + list[i].height + '"' +
            (list[i].direct ? (list[i].codec === 'hevc' ? ' title="' + esc(T.y.hevcTip) + '"' : '') : ' title="' + esc(T.y.convertTip) + '"') + '>' + esc(Y.label(list[i])) +
            (list[i].direct ? (list[i].codec === 'hevc' ? '<i>HEVC</i>' : '') : '<i>H.264 ⟳</i>') + '</button>');
        }
        h.push('</div>');
        if (q && !q.direct && !yt.sec.on) { h.push('<div class="c-note y-warn">' + esc(yt.info.site === 'youtube' ? T.y.convertNote : T.y.convertOther) + '</div>'); }
      }
      var sec = ytSection();
      h.push('<div class="y-label">' + esc(T.y.sec.label) + '</div><div class="y-secrow"><div class="seg y-seg" role="group">' +
        '<button data-ysec="all"' + (yt.sec.on ? '' : ' class="on"') + '>' + esc(T.y.sec.all) + '</button>' +
        '<button data-ysec="part"' + (yt.sec.on ? ' class="on"' : '') + '>' + esc(T.y.sec.part) + '</button></div>');
      if (yt.sec.on) {
        h.push('<label class="y-time"><input id="yFrom" type="text" autocomplete="off" spellcheck="false" placeholder="0:00" value="' + esc(yt.sec.from) + '" aria-label="' + esc(T.y.sec.from) + '"><span>' + esc(T.y.sec.from) + '</span></label>' +
          '<label class="y-time"><input id="yTo" type="text" autocomplete="off" spellcheck="false" placeholder="' + esc(yt.info.duration ? Y.clock(yt.info.duration) : T.y.sec.toEnd) + '" value="' + esc(yt.sec.to) + '" aria-label="' + esc(T.y.sec.to) + '"><span>' + esc(T.y.sec.to) + '</span></label>');
      }
      h.push('</div>' + (yt.sec.on ? '<div id="ySecInfo" class="y-secinfo' + (sec && sec.error ? ' bad' : '') + '">' + esc(ytSecText()) + '</div>' : ''));
    } else if (p === 'error') {
      var e = yt.error || {}, code = T.y.err[e.code] ? e.code : 'ytFailed';
      h.push('<div class="y-err"><div class="y-big">' + esc(T.y.err[code]) + '</div>' + (e.message ? '<div class="c-note y-tech">' + esc(e.message) + '</div>' : '') +
        '<div class="c-actions"><button class="c-btn" data-yact="retry">' + esc(T.y.retry) + '</button>' +
        (e.code === 'ytLogin' && !yt.cookies ? '<button class="c-btn" data-yact="cookies">' + esc(T.y.cookies) + '</button>' : '') + '</div>' +
        (e.code === 'ytLogin' && !yt.cookies ? '<div class="c-note">' + esc(T.y.cookiesNote) + '</div>' : '') + '</div>');
    }
    $yMain.innerHTML = h.join('');
    $yUrl.disabled = $yPaste.disabled = p === 'setup' || p === 'install';
    $yGo.hidden = p === 'setup' || p === 'install';
    $yGo.disabled = !((p === 'info' && !(ytSection() || {}).error) || ((p === 'idle' || p === 'error') && Y.isUrl($yUrl.value)));
    $yGo.innerHTML = esc(p === 'info' ? (yt.job || ytWaiting() ? T.y.q.add : T.y.go) : T.y.fetch) + ' <kbd>↵</kbd>';
    $yDest.textContent = (yt.target && yt.target.saved) ? T.y.destSite(ytSiteName()) : (yt.target ? T.y.destUnsaved : '');
    $yDest.className = 'e-target' + (yt.target && !yt.target.saved ? ' y-unsaved' : '');
    $yDest.title = ytDir();
    $yStatus.textContent = p === 'info' ? ytSize() : '';
    $railDotY.hidden = !ytBusy();
    if (p === 'install') { ytProgress(); }
    renderYtQueue();
  }

  // ---- the queue strip
  function ytJobSub(j) {
    if (j.state === 'wait') { return T.y.q.wait; }
    if (j.state === 'error') { return (T.y.err[j.error && j.error.code] || T.y.err.ytFailed); }
    if (j.state === 'done') {
      var r = j.result || {};
      return (r.importError ? T.y.q.noImport : (r.existed ? T.y.q.existed : T.y.q.inProject)) + (r.bytes ? ' · ' + C.formatBytes(r.bytes) : '');
    }
    var g = j.prog || {}, spin = g.phase === 'merge' || g.phase === 'convert' || g.phase === 'fix' || (g.phase === 'download' && !g.part), bits = [g.label || T.y.part.start];
    if (!spin) {
      bits[0] += ' ' + Math.floor(Math.max(0, Math.min(100, g.overall || 0))) + '%';
      if (g.speed) { bits.push(String(g.speed).replace('iB', 'B')); }
      if (g.eta) { bits.push(T.y.left(g.eta)); }
    } else if (g.phase !== 'download') { bits.push(T.y.elapsed(Y.clock((Date.now() - g.since) / 1000))); }
    return bits.join(' · ');
  }
  function renderYtQueue() {
    var q = yt.queue, h = [], finished = 0, i;
    $yQueue.hidden = !q.length;
    if (!q.length) { $yQueue.innerHTML = ''; return; }
    for (i = 0; i < q.length; i++) { if (q[i].state === 'done' || q[i].state === 'error') { finished++; } }
    h.push('<div class="yq-head"><span>' + esc(T.y.q.title) + ' · ' + q.length + '</span>' +
      (finished ? '<button class="yq-clear" data-yq-clear="1">' + esc(T.y.q.clear) + '</button>' : '') + '</div><div class="yq-list">');
    for (i = 0; i < q.length; i++) {
      var j = q[i], ico = j.state === 'done' ? ((j.result || {}).importError ? '!' : '✓') : (j.state === 'error' ? '✕' : (j.state === 'wait' ? '' : ''));
      h.push('<div class="yq-row st-' + j.state + ((j.result || {}).importError ? ' warn' : '') + '" data-yjob="' + j.id + '"' +
        ((j.result || {}).importError ? ' title="' + esc(j.result.path) + '"' : (j.error && j.error.message ? ' title="' + esc(j.error.message) + '"' : '')) + '>' +
        '<span class="yq-ico">' + (j.state === 'down' ? '<span class="spinner"></span>' : (j.state === 'wait' ? '<i class="yq-dot"></i>' : ico)) + '</span>' +
        '<span class="yq-main"><span class="yq-title">' + esc(j.title) + '</span>' +
        '<span class="yq-sub"><b>' + esc(j.tag) + '</b><span class="yq-state">' + esc(ytJobSub(j)) + '</span></span></span>' +
        (j.state === 'error' ? '<button class="yq-btn" data-yq-retry="' + j.id + '" title="' + esc(T.y.q.retryTip) + '">↻</button>' : '') +
        '<button class="yq-btn" data-yq-x="' + j.id + '" title="' + esc(j.state === 'down' || j.state === 'wait' ? T.y.q.cancelTip : T.y.q.removeTip) + '">✕</button>' +
        (j.state === 'down' ? '<span class="yq-bar"><i></i></span>' : '') + '</div>');
    }
    h.push('</div>');
    $yQueue.innerHTML = h.join('');
    ytJobProgress();
  }
  /** The running row only: its text and its bar (no re-draw, so buttons do not jump under the mouse). */
  function ytJobProgress() {
    var j = yt.job;
    if (!j) { return; }
    var row = $yQueue.querySelector('[data-yjob="' + j.id + '"]');
    if (!row) { return; }
    var g = j.prog || {}, spin = g.phase === 'merge' || g.phase === 'convert' || g.phase === 'fix' || (g.phase === 'download' && !g.part);
    var st = row.querySelector('.yq-state'), bar = row.querySelector('.yq-bar');
    if (st) { st.textContent = ytJobSub(j); }
    if (bar) { bar.className = 'yq-bar' + (spin ? ' y-spin' : ''); bar.firstChild.style.width = (spin ? 100 : Math.max(0, Math.min(100, g.overall || 0))) + '%'; }
  }

  function ytProgress() {
    var g = yt.prog, $bar = $('yBar'), $phase = $('yPhase');
    if (!g || !$bar || !$phase) { return; }
    var spin = g.phase === 'merge' || g.phase === 'convert' || g.phase === 'fix' || (g.phase === 'download' && !g.part);
    var pct = Math.max(0, Math.min(100, g.overall || 0));
    $('yBarWrap').className = 'c-bar' + (spin ? ' y-spin' : '');
    $bar.style.width = (spin ? 100 : pct) + '%';
    $phase.textContent = g.label || '';
    $('yPct').textContent = spin ? '' : Math.floor(pct) + '%';
    var bits = [];
    if (!spin && g.speed) { bits.push(g.speed.replace('iB', 'B')); }
    if (!spin && g.eta) { bits.push(T.y.left(g.eta)); }
    if (!spin && g.cut && g.part) { bits.push(Y.clock(g.done || 0) + ' / ' + Y.clock(g.cut)); }
    if (spin && g.phase !== 'download') { bits.push(T.y.elapsed(Y.clock((Date.now() - g.since) / 1000))); }
    $('yRate').textContent = bits.join(' · ');
  }

  function ytFail(e) {
    yt.error = { code: (e && e.code) || 'ytFailed', message: (e && e.message) || '', log: (e && e.log) || '' };
    state.lastError = yt.error;
    yt.phase = 'error';
    renderYt();
  }

  /** Is the engine there? → 'setup' card when not. Also asks Premiere where downloads go. */
  function openYt() {
    var eng = ytEngine();
    if (yt.phase !== 'install') {
      if (!eng) { yt.error = { code: 'noNode', message: yt.engineError || '' }; yt.phase = 'error'; }
      else if (!eng.status().ready) { yt.phase = 'setup'; }
      else if (yt.phase === 'setup' || (yt.phase === 'error' && yt.error && yt.error.code === 'noNode')) { yt.phase = 'idle'; }
    }
    renderYt();
    B.call('ytTarget').then(function (r) { if (r && r.ok) { yt.target = r.data; if (state.view === 'yt') { renderYt(); } } });
    if (!$yUrl.disabled) { $yUrl.focus(); $yUrl.select(); }
  }

  function ytInstall() {
    var eng = ytEngine();
    if (!eng || yt.phase === 'install') { return; }
    yt.phase = 'install';
    yt.prog = { phase: 'download', part: 1, overall: 0, label: T.y.part.start, since: Date.now() };
    renderYt();
    eng.install(function (i, n, name, pct) {
      if (pct < 0) { yt.prog.phase = 'fix'; yt.prog.label = T.y.checking(name); }
      else { yt.prog.overall = (i + pct / 100) / n * 100; yt.prog.label = T.y.installing(i, n, name); }
      ytProgress();
    }).then(function () {
      state.settings.ytUpdated = Date.now(); save(LS.settings, state.settings);
      yt.phase = 'idle'; renderYt();
      toast('ok', T.y.installed);
      if (Y.isUrl($yUrl.value)) { ytFetch($yUrl.value); } else if (state.view === 'yt') { $yUrl.focus(); }
    }, function (e) {
      yt.phase = 'setup';
      ytFail({ code: e && e.code === 'ytToolBroken' ? 'ytToolBroken' : 'installFailed', message: String(e && e.message || e) });
    });
  }

  function ytSetUrl(text) {
    $yUrl.value = String(text || '').replace(/^\s+|\s+$/g, '');
    if (Y.isUrl($yUrl.value)) { ytFetch($yUrl.value); } else { renderYt(); }
  }

  function ytFetch(url) {
    var eng = ytEngine();
    url = String(url || '').replace(/^\s+|\s+$/g, '');
    if (!eng || yt.phase === 'install' || !Y.isUrl(url)) { return; }
    if (!eng.status().ready) { yt.phase = 'setup'; renderYt(); return; }
    var token = ++yt.token;
    if (url !== yt.url) { yt.cookies = ''; }
    if (url !== yt.url) { var t0 = Y.timeFromUrl(url); yt.sec = { on: false, from: t0 ? Y.clock(t0) : '', to: '' }; }
    yt.url = url; yt.info = null; yt.error = null; yt.result = null; yt.phase = 'loading';
    var stale = !yt.job && Date.now() - (Number(state.settings.ytUpdated) || 0) > YT_FRESH_MS;   // never swap the engine under a running download
    yt.updating = stale;
    renderYt();
    var first = !stale ? Promise.resolve() : eng.update().then(function () {
      state.settings.ytUpdated = Date.now(); save(LS.settings, state.settings);
    }, function () {}).then(function () { yt.updating = false; if (token === yt.token && state.view === 'yt') { renderYt(); } });
    first.then(function () { return eng.info(url, yt.cookies); }).then(function (info) {
      if (token !== yt.token) { return; }
      if (info.live) { ytFail({ code: 'ytLive' }); return; }
      yt.info = info;
      if (!info.qualities.length && info.hasAudio) { yt.mode = 'audio'; }
      else if (!info.hasAudio && yt.mode !== 'video') { yt.mode = 'video'; }
      yt.phase = 'info';
      renderYt();
    }, function (e) { if (token === yt.token && e.code !== 'ytCancelled') { ytFail(e); } });
  }

  function ytJobTag(mode, q, sec) {
    var bits = [];
    if (mode === 'audio') { bits.push(T.y.q.audio); }
    else { bits.push(Y.label(q)); if (mode === 'video') { bits.push(T.y.q.onlyVideo); } }
    if (sec) { bits.push(Y.clock(sec.start) + '–' + Y.clock(sec.end)); }
    return bits.join(' · ');
  }

  /** The chooser's button: put what is chosen into the queue. The chooser stays, so the next part or quality of the same video is one more click. */
  function ytStart() {
    var eng = ytEngine(), info = yt.info, q = ytChosen(), sec = ytSection();
    if (!eng || !info || yt.phase !== 'info' || (yt.mode !== 'audio' && !q) || (sec && sec.error)) { return; }
    var mode = yt.mode, both = mode === 'both', dir = ytDir(), base = Y.outBase(info, mode, q, sec), i;
    for (i = 0; i < yt.queue.length; i++) {
      var o = yt.queue[i];
      if ((o.state === 'wait' || o.state === 'down') && o.opts.dir === dir && o.opts.base === base) { toast('warn', T.y.q.dup, '', 2000); return; }
    }
    for (i = yt.queue.length - 1; i >= 0; i--) {                 // the same thing asked again after it finished or failed: one row, not two
      if (yt.queue[i].opts.dir === dir && yt.queue[i].opts.base === base) { yt.queue.splice(i, 1); }
    }
    var vBytes = (q && q.bytes) || 0, aBytes = info.audioBytes || 0;
    var ahead = ytWaiting() + (yt.job ? 1 : 0);
    yt.queue.push({
      id: ++yt.seq, state: 'wait', title: info.title || yt.url, tag: ytJobTag(mode, q, sec), mode: mode,
      w: !both ? [1] : (vBytes && aBytes ? [vBytes / (vBytes + aBytes), aBytes / (vBytes + aBytes)] : [0.92, 0.08]),
      cut: sec ? sec.end - sec.start : 0, prog: null, result: null, error: null,
      bin: info.siteName || 'YouTube',
      opts: { url: info.url || yt.url, mode: mode, height: q ? q.height : 0, px: q ? q.px : 0, fps: q ? q.fps : 0, direct: q ? q.direct : true,
        dir: dir, base: base, cookies: yt.cookies, section: sec, site: info.site || 'youtube', fid: q ? q.fid : '', sound: q ? !!q.sound : false }
    });
    if (ahead) { toast('ok', T.y.q.added(ahead), '', 1800); }
    ytPump();
    renderYt();
  }

  /** Starts the next waiting download when nothing is running. */
  function ytPump() {
    var eng = ytEngine(), job = null, i;
    if (!eng || yt.job || yt.phase === 'install') { return; }
    for (i = 0; i < yt.queue.length; i++) { if (yt.queue[i].state === 'wait') { job = yt.queue[i]; break; } }
    if (!job) { return; }
    var mode = job.mode, both = mode === 'both', w = job.w;
    function partLabel(n) { return mode === 'audio' || (both && n === 2) ? T.y.part.audio : T.y.part.video; }
    function finish() {
      yt.job = null;
      var left = ytWaiting();
      if (!left && state.view !== 'yt') {
        var done = 0;
        for (var k = 0; k < yt.queue.length; k++) { if (yt.queue[k].state === 'done') { done++; } }
        if (done) { toast('ok', done === 1 ? T.y.doneToast(job.title) : T.y.q.allDone(done), '', 3500); }
      }
      ytPump();
      if (state.view === 'yt') { renderYt(); } else { $railDotY.hidden = !ytBusy(); }
    }
    job.state = 'down'; yt.job = job;
    job.prog = { phase: 'download', part: 0, overall: 0, label: T.y.part.start, since: Date.now(), speed: '', eta: '', cut: job.cut, done: 0 };
    eng.download(job.opts, function (ev) {
      var g = job.prog;
      if (g.cut) {
        // a section is one ffmpeg run (picture and sound together): its clock is the progress
        if (ev.type === 'time') {
          g.part = 1; g.phase = 'download'; g.label = T.y.part.section;
          g.done = Math.min(ev.sec, g.cut); g.overall = g.done / g.cut * 100;
          g.eta = ev.speed > 0 ? Y.clock((g.cut - g.done) / ev.speed) : '';
        } else if (ev.type === 'phase') { g.phase = ev.phase; g.label = T.y.part[ev.phase] || ''; g.since = Date.now(); }
      }
      else if (ev.type === 'part') { g.part = Math.min(g.part + 1, w.length); g.phase = 'download'; g.label = partLabel(g.part); }
      else if (ev.type === 'progress') {
        if (!g.part) { g.part = 1; g.label = partLabel(1); }
        if (g.phase !== 'download') { return; }
        var before = 0;
        for (var k = 0; k < g.part - 1; k++) { before += w[k]; }
        if (ev.pct != null) { g.overall = (before + w[g.part - 1] * ev.pct / 100) * 100; }
        g.speed = ev.speed; g.eta = ev.eta;
      } else if (ev.type === 'phase') { g.phase = ev.phase; g.label = T.y.part[ev.phase] || ''; g.since = Date.now(); }
      if (state.view === 'yt') { ytJobProgress(); }
    }).then(function (res) {
      return B.call('ytImport', { path: res.path, bin: job.bin }).then(function (r) {
        job.result = { path: res.path, bytes: res.bytes, existed: !!res.existed, name: r && r.ok ? r.data.name : '', importError: !(r && r.ok) };
        if (!(r && r.ok)) { state.lastError = r; }
        state.lastResult = job.result;
        job.state = 'done';
        finish();
      });
    }, function (e) {
      if (e && e.code === 'ytCancelled') {
        var at = yt.queue.indexOf(job);
        if (at >= 0) { yt.queue.splice(at, 1); }
        if (state.view === 'yt') { toast('warn', T.y.cancelled, '', 1800); }
      } else {
        job.state = 'error';
        job.error = { code: (e && e.code) || 'ytFailed', message: (e && e.message) || '', log: (e && e.log) || '' };
        state.lastError = job.error;
      }
      finish();
    });
  }

  function ytPrimary() {
    if (yt.phase === 'info') { ytStart(); }
    else if (yt.phase === 'idle' || yt.phase === 'error') { ytFetch($yUrl.value); }
  }

  /** A link from the clipboard into the link field (whole field replaced) → looked up. False when the clipboard cannot be read this way. */
  function ytPasteLink() {
    var clip = ytClipboard();
    if (clip === null) { return false; }
    var v = clip.replace(/^\s+|\s+$/g, '').split(/\s/)[0] || '';
    if (!Y.isUrl(v)) { toast('warn', T.y.err.ytBadUrl, '', 2200); return true; }
    if ($yUrl.disabled) { return true; }
    $yUrl.value = v; clearTimeout(yt.timer);
    if (v !== yt.url || (yt.phase !== 'info' && yt.phase !== 'loading')) { ytFetch(v); }
    return true;
  }
  function isPasteKey(e) { return (e.metaKey || e.ctrlKey) && !e.altKey && (e.keyCode === 86 || e.code === 'KeyV'); }

  function ytKey(e) {
    // ⌘V anywhere on this screen (except while typing a time) pastes the link — read from the macOS clipboard,
    // so it works whatever Premiere thinks has keyboard focus
    if (isPasteKey(e) && !(document.activeElement && (document.activeElement.id === 'yFrom' || document.activeElement.id === 'yTo'))) {
      if (ytPasteLink()) { e.preventDefault(); } else if (!$yUrl.disabled) { $yUrl.focus(); $yUrl.select(); }
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false, true); }
      else if (document.activeElement && (document.activeElement.id === 'yFrom' || document.activeElement.id === 'yTo')) { document.activeElement.blur(); }
      else if (document.activeElement === $yUrl && $yUrl.value) { $yUrl.value = ''; yt.token++; yt.url = ''; yt.info = null; yt.phase = 'idle'; renderYt(); }
      else { switchTab('fx'); }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (document.activeElement && (document.activeElement.id === 'yFrom' || document.activeElement.id === 'yTo')) {
        if (document.activeElement.id === 'yFrom' && !yt.sec.to && $('yTo')) { $('yTo').focus(); }       // ↵ in "from" → on to "to"
        else if (!$yGo.disabled) { ytPrimary(); }
      }
      else if (document.activeElement === $yUrl && Y.isUrl($yUrl.value) && $yUrl.value.replace(/^\s+|\s+$/g, '') !== yt.url) { ytFetch($yUrl.value); }
      else if (!$yGo.disabled && !$yGo.hidden) { ytPrimary(); }
    }
  }

  $yUrl.addEventListener('input', function () {
    clearTimeout(yt.timer);
    var v = $yUrl.value.replace(/^\s+|\s+$/g, '');
    if (Y.isUrl(v) && v !== yt.url) { yt.timer = setTimeout(function () { ytFetch(v); }, 250); }
    else if (yt.phase !== 'setup' && yt.phase !== 'install') { $yGo.disabled = !((yt.phase === 'info' && !(ytSection() || {}).error) || ((yt.phase === 'idle' || yt.phase === 'error') && Y.isUrl(v))); }
  });
  $yUrl.addEventListener('paste', function (e) {
    var text = '';
    try { text = (e.clipboardData || window.clipboardData).getData('text') || ''; } catch (e2) { text = ''; }
    var v = text.replace(/^\s+|\s+$/g, '').split(/\s/)[0] || '';
    if (!v) { return; }
    e.preventDefault();
    $yUrl.value = v; clearTimeout(yt.timer);
    if (Y.isUrl(v) && (v !== yt.url || (yt.phase !== 'info' && yt.phase !== 'loading'))) { ytFetch(v); } else if (yt.phase !== 'info') { renderYt(); }
  });
  $yPaste.addEventListener('click', function () {
    $yUrl.focus(); $yUrl.select();
    var okPaste = false, clip = ytClipboard();
    if (clip !== null) { $yUrl.value = clip.replace(/^\s+|\s+$/g, '').split(/\s/)[0] || ''; okPaste = true; }
    else { try { okPaste = document.execCommand('paste'); } catch (e) { okPaste = false; } }
    var v = $yUrl.value.replace(/^\s+|\s+$/g, '');
    if (okPaste && v && !Y.isUrl(v)) { $yUrl.value = ''; toast('warn', T.y.err.ytBadUrl, '', 2500); return; }
    if (Y.isUrl(v) && v !== yt.url) { clearTimeout(yt.timer); ytFetch(v); }
  });
  $yMain.addEventListener('input', function (e) {
    if (!e.target || (e.target.id !== 'yFrom' && e.target.id !== 'yTo')) { return; }
    yt.sec[e.target.id === 'yFrom' ? 'from' : 'to'] = e.target.value;
    ytSecUpdate();
  });
  $yGo.addEventListener('click', ytPrimary);
  $yQueue.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-yq-x],[data-yq-retry],[data-yq-clear]') : null;
    if (!t) { return; }
    var i, id, job = null;
    if (t.hasAttribute('data-yq-clear')) {
      for (i = yt.queue.length - 1; i >= 0; i--) { if (yt.queue[i].state === 'done' || yt.queue[i].state === 'error') { yt.queue.splice(i, 1); } }
      renderYt(); return;
    }
    id = Number(t.getAttribute('data-yq-x') || t.getAttribute('data-yq-retry'));
    for (i = 0; i < yt.queue.length; i++) { if (yt.queue[i].id === id) { job = yt.queue[i]; break; } }
    if (!job) { return; }
    if (t.hasAttribute('data-yq-retry')) { job.state = 'wait'; job.error = null; ytPump(); renderYt(); return; }
    if (job.state === 'down') { var eng = ytEngine(); if (eng) { eng.cancel(); } return; }        // the row goes when the engine confirms
    yt.queue.splice(yt.queue.indexOf(job), 1);
    renderYt();
  });
  $yMain.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-ymode],[data-yq],[data-yact],[data-ysec]') : null;
    if (!t || t.disabled) { return; }
    if (t.hasAttribute('data-ysec')) {
      yt.sec.on = t.getAttribute('data-ysec') === 'part';
      renderYt();
      if (yt.sec.on && $('yFrom')) { var $f = yt.sec.from && !yt.sec.to ? $('yTo') : $('yFrom'); $f.focus(); $f.select(); }
      return;
    }
    if (t.hasAttribute('data-ymode')) { yt.mode = t.getAttribute('data-ymode'); state.settings.ytMode = yt.mode; save(LS.settings, state.settings); renderYt(); }
    else if (t.hasAttribute('data-yq')) { yt.height = Number(t.getAttribute('data-yq')); state.settings.ytHeight = yt.height; save(LS.settings, state.settings); renderYt(); }
    else {
      var act = t.getAttribute('data-yact');
      if (act === 'install') { ytInstall(); }
      else if (act === 'retry' || act === 'cookies') {
        if (act === 'cookies') { yt.cookies = 'chrome'; }
        var eng = ytEngine();
        if (!eng) { openYt(); }
        else if (!eng.status().ready) { ytInstall(); }
        else { ytFetch(yt.url || $yUrl.value); }
      }
    }
  });
  setInterval(function () { if (state.view === 'yt') { if (yt.phase === 'install') { ytProgress(); } if (yt.job) { ytJobProgress(); } } }, 1000);
  window.addEventListener('beforeunload', function () { try { if (yt.engine && yt.job) { yt.engine.cancel(); } } catch (e) {} });

  COMMANDS.push({ id: 'c:yt', name: T.y.cmd, kind: 'command', icon: 'yt', run: function () { switchTab('yt'); },
    alt: 'youtube tiktok download yt video audio mp3 mp4 link url watermark იუთუბი იუთუბიდან ტიკტოკი ტიკტოკიდან ჩამოტვირთვა ჩაწერა ვიდეო აუდიო ლინკი ბმული', meta: T.y.cmdMeta });

  // ------------------------------------------------------------------ sound effects: a folder library, audition, drop at the playhead
  var XF = window.QFXSfx;
  var $xQ = $('xQ'), $xCats = $('xCats'), $xList = $('xList'), $xGo = $('xGo'), $xAdd = $('xAdd'), $xPath = $('xPath'), $xStatus = $('xStatus');
  var sfx = { dir: '', cats: [], cat: 0, rows: [], row: 0, pick: {}, dur: {}, audio: null, playing: '', naming: false, busy: false, error: '', fs: undefined, loaded: 0 };

  /** The few file operations the library needs (Node inside the panel). */
  function sfxFs() {
    if (window.__QFX_SFX_FS) { return window.__QFX_SFX_FS; }
    if (sfx.fs !== undefined) { return sfx.fs; }
    sfx.fs = null;
    try {
      var req = nodeReq();
      if (!req) { throw new Error('node is not available'); }
      var fs = req('fs'), os = req('os');
      sfx.fs = {
        home: os.homedir(),
        list: function (dir) {
          var out = [], names = [];
          try { names = fs.readdirSync(dir); } catch (e) { return out; }
          for (var i = 0; i < names.length; i++) {
            if (names[i].charAt(0) === '.') { continue; }
            var st = null;
            try { st = fs.statSync(dir + '/' + names[i]); } catch (e2) { st = null; }
            if (st) { out.push({ name: names[i].normalize ? names[i].normalize('NFC') : names[i], raw: names[i], dir: st.isDirectory(), size: st.size }); }
          }
          return out;
        },
        exists: function (p) { try { fs.statSync(p); return true; } catch (e) { return false; } },
        size: function (p) { try { return fs.statSync(p).size; } catch (e) { return -1; } },
        mkdir: function (p) { var parts = String(p).split('/'), cur = ''; for (var i = 1; i < parts.length; i++) { cur += '/' + parts[i]; if (!this.exists(cur)) { fs.mkdirSync(cur); } } },
        copy: function (a, b) { fs.copyFileSync(a, b); }
      };
    } catch (e) { sfx.error = String(e && e.message || e); }
    return sfx.fs;
  }
  function sfxDiag() { var n = 0; for (var i = 0; i < sfx.cats.length; i++) { n += sfx.cats[i].count; } return { dir: sfx.dir, categories: sfx.cats.length, files: n, error: sfx.error }; }
  function sfxDir() {
    var f = sfxFs();
    return state.settings.sfxDir || ((f && f.home) ? f.home + '/Documents/Quick FX Sounds' : '');
  }

  /** Reads the folders (fast: names only). */
  function sfxLoad() {
    var f = sfxFs(), keep = sfx.cats[sfx.cat] ? sfx.cats[sfx.cat].name : '';
    sfx.dir = sfxDir(); sfx.cats = [];
    if (!f || !sfx.dir) { return; }
    var top = f.list(sfx.dir), loose = [], i;
    top.sort(function (a, b) { return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1; });
    for (i = 0; i < top.length; i++) {
      if (!top[i].dir) { if (XF.isAudio(top[i].name)) { loose.push(top[i].raw); } continue; }
      var inside = f.list(sfx.dir + '/' + top[i].raw), names = [];
      for (var k = 0; k < inside.length; k++) { if (!inside[k].dir && XF.isAudio(inside[k].raw)) { names.push(inside[k].raw); } }
      sfx.cats.push({ name: top[i].name, path: sfx.dir + '/' + top[i].raw, groups: XF.groups(names), count: names.length });
    }
    if (loose.length) { sfx.cats.push({ name: T.x.none, path: sfx.dir, groups: XF.groups(loose), count: loose.length, loose: true }); }
    sfx.cat = 0;
    for (i = 0; i < sfx.cats.length; i++) { if (sfx.cats[i].name === keep) { sfx.cat = i; } }
    sfx.loaded = Date.now();
  }

  function sfxRows() {
    var q = $xQ.value.replace(/^\s+|\s+$/g, ''), rows = [], c = sfx.cats[sfx.cat];
    if (q) { rows = XF.search(sfx.cats, q); for (var i = 0; i < rows.length; i++) { rows[i].path = sfxCatPath(rows[i].cat); rows[i].found = true; } }
    else if (c) { for (var g = 0; g < c.groups.length; g++) { rows.push({ cat: c.name, path: c.path, group: c.groups[g], items: c.groups[g].items }); } }
    sfx.rows = rows;
    if (sfx.row >= rows.length) { sfx.row = Math.max(0, rows.length - 1); }
    return rows;
  }
  function sfxCatPath(name) { for (var i = 0; i < sfx.cats.length; i++) { if (sfx.cats[i].name === name) { return sfx.cats[i].path; } } return sfx.dir; }
  function sfxKeyOf(r) { return r.cat + '/' + r.group.name; }
  function sfxVar(r) { var v = sfx.pick[sfxKeyOf(r)] || 0; return v < r.items.length ? v : 0; }
  function sfxCurrent() {
    var r = sfx.rows[sfx.row];
    if (!r) { return null; }
    var it = r.items[sfxVar(r)];
    return { row: r, item: it, path: r.path + '/' + it.file, name: r.group.name + (it.n ? ' ' + (it.n < 10 ? '0' : '') + it.n : '') };
  }

  function sfxStop() {
    if (sfx.audio) { try { sfx.audio.pause(); } catch (e) {} }
    if (sfx.playing) { sfx.playing = ''; if (state.view === 'sfx') { sfxMarkPlaying(); } }
  }
  function sfxPlay(path) {
    if (!path) { return; }
    if (!sfx.audio) {
      sfx.audio = new Audio();
      sfx.audio.addEventListener('ended', function () { sfx.playing = ''; sfxMarkPlaying(); });
      sfx.audio.addEventListener('error', function () { sfx.playing = ''; sfxMarkPlaying(); });
      sfx.audio.addEventListener('loadedmetadata', function () { if (sfx.playing && isFinite(sfx.audio.duration)) { sfx.dur[sfx.playing] = sfx.audio.duration; sfxDurations(); } });
    }
    try { sfx.audio.pause(); } catch (e) {}
    sfx.playing = path;
    sfx.audio.src = XF.fileUrl(path);
    try { sfx.audio.currentTime = 0; } catch (e2) {}
    var pr = null;
    try { pr = sfx.audio.play(); } catch (e3) { pr = null; }
    if (pr && pr['catch']) { pr['catch'](function () { if (sfx.playing === path) { sfx.playing = ''; sfxMarkPlaying(); } }); }
    sfxMarkPlaying();
  }
  function sfxToggle() { var c = sfxCurrent(); if (!c) { return; } if (sfx.playing === c.path) { sfxStop(); } else { sfxPlay(c.path); } }
  function sfxMarkPlaying() {
    var els = $xList.querySelectorAll('.x-row');
    for (var i = 0; i < els.length; i++) {
      var r = sfx.rows[i], on = false;
      if (r) { on = sfx.playing === r.path + '/' + r.items[sfxVar(r)].file; }
      els[i].className = 'x-row' + (i === sfx.row ? ' active' : '') + (on ? ' playing' : '');
    }
  }
  /** Lengths appear as they become known: a sound that was played, or (quietly, a few at a time) the ones on screen. */
  function sfxDurations() {
    var els = $xList.querySelectorAll('.x-row');
    for (var i = 0; i < els.length; i++) {
      var r = sfx.rows[i]; if (!r) { continue; }
      var p = r.path + '/' + r.items[sfxVar(r)].file, d = els[i].querySelector('.x-dur');
      if (d) { d.textContent = sfx.dur[p] ? XF.clock(sfx.dur[p]) : ''; }
    }
  }
  function sfxProbe() {
    if (sfx.probing || state.view !== 'sfx') { return; }
    var todo = [];
    for (var i = 0; i < sfx.rows.length && todo.length < 60; i++) { var r = sfx.rows[i], p = r.path + '/' + r.items[sfxVar(r)].file; if (sfx.dur[p] === undefined) { todo.push(p); } }
    if (!todo.length) { return; }
    sfx.probing = true;
    var at = 0;
    (function next() {
      if (at >= todo.length || state.view !== 'sfx') { sfx.probing = false; sfxDurations(); return; }
      var p = todo[at++], a = new Audio(), done = false;
      function fin(v) { if (done) { return; } done = true; sfx.dur[p] = v; a.src = ''; if (at % 8 === 0) { sfxDurations(); } next(); }
      a.preload = 'metadata';
      a.addEventListener('loadedmetadata', function () { fin(isFinite(a.duration) ? a.duration : 0); });
      a.addEventListener('error', function () { fin(0); });
      setTimeout(function () { fin(0); }, 1500);
      a.src = XF.fileUrl(p);
    })();
  }

  function renderSfx() {
    var f = sfxFs(), h = [], i;
    $xPath.textContent = sfx.dir ? sfx.dir.replace(f && f.home ? f.home : '\u0000', '~') : '';
    $xPath.title = T.x.pickDir + ': ' + sfx.dir;
    if (!f) {
      $xCats.innerHTML = ''; $xList.innerHTML = '<div class="y-err"><div class="y-big">' + esc(T.x.noNode) + '</div><div class="c-note y-tech">' + esc(sfx.error) + '</div></div>';
      $xGo.disabled = true; $xAdd.disabled = true; return;
    }
    // categories
    for (i = 0; i < sfx.cats.length; i++) {
      h.push('<button class="x-cat' + (i === sfx.cat && !$xQ.value ? ' on' : '') + '" data-xcat="' + i + '"><span>' + esc(sfx.cats[i].name) + '</span><i>' + sfx.cats[i].groups.length + '</i></button>');
    }
    h.push(sfx.naming ? '<input id="xNew" class="x-new" type="text" maxlength="60" placeholder="' + esc(T.x.newCatPh) + '">' : '<button class="x-cat x-add" data-xact="newcat">' + esc(T.x.newCat) + '</button>');
    $xCats.innerHTML = h.join('');
    // sounds
    var rows = sfxRows(), total = 0;
    for (i = 0; i < sfx.cats.length; i++) { total += sfx.cats[i].count; }
    h = [];
    if (!sfx.cats.length) {
      h.push('<div class="y-empty"><div class="y-big">' + esc(T.x.emptyTitle) + '</div><div class="c-note x-where">' + esc(sfx.dir) + '</div><ol>');
      for (i = 0; i < T.x.empty.length; i++) { h.push('<li>' + esc(T.x.empty[i]) + '</li>'); }
      h.push('</ol></div>');
    } else if (!rows.length) {
      h.push('<div class="y-empty"><div class="c-note">' + esc($xQ.value ? T.x.noMatch : T.x.emptyCat) + '</div></div>');
    }
    for (i = 0; i < rows.length; i++) {
      var r = rows[i], v = sfxVar(r), it = r.items[v], chips = '';
      if (r.items.length > 1) {
        for (var k = 0; k < r.items.length; k++) {
          chips += '<button class="x-var' + (k === v ? ' on' : '') + '" data-xvar="' + k + '" title="' + esc(r.items[k].note || r.items[k].file) + '">' + (r.items[k].n || (k + 1)) + '</button>';
        }
      }
      h.push('<div class="x-row' + (i === sfx.row ? ' active' : '') + '" data-xrow="' + i + '"><button class="x-play" data-xplay="1" aria-label="play"></button>' +
        '<span class="x-name">' + esc(r.group.name) + '</span><span class="x-note">' + esc((r.found ? r.cat + (it.note ? ' · ' : '') : '') + (it.note || '')) + '</span>' +
        '<span class="x-vars">' + chips + '</span><span class="x-dur"></span></div>');
    }
    $xList.innerHTML = h.join('');
    $xGo.disabled = !rows.length || sfx.busy;
    $xAdd.disabled = !sfx.cats.length;
    $xStatus.textContent = total ? T.x.sounds(total) : '';
    sfxMarkPlaying(); sfxDurations(); sfxProbe();
    var act = $xList.querySelector('.x-row.active');
    if (act && act.scrollIntoView) { try { act.scrollIntoView({ block: 'nearest' }); } catch (e) {} }
    if (sfx.naming && $('xNew')) { $('xNew').focus(); }
  }

  function openSfx() {
    sfxLoad();
    renderSfx();
    if (!sfx.naming) { $xQ.focus(); }
  }

  function sfxSelect(row, variation, play) {
    if (row < 0 || row >= sfx.rows.length) { return; }
    sfx.row = row;
    var r = sfx.rows[row];
    if (variation !== null && variation !== undefined) { sfx.pick[sfxKeyOf(r)] = Math.max(0, Math.min(r.items.length - 1, variation)); renderSfx(); }
    else {
      // only the highlight moves: the rows are not rebuilt, so a double-click still lands on the same row
      sfxMarkPlaying();
      var el = $xList.querySelector('.x-row.active');
      if (el && el.scrollIntoView) { try { el.scrollIntoView({ block: 'nearest' }); } catch (e) {} }
    }
    if (play) { var c = sfxCurrent(); if (c) { sfxPlay(c.path); } }
  }

  /** Into the project (a copy under Imported/SFX, so the project stays self-contained) and onto the timeline at the playhead. */
  function sfxInsert() {
    var c = sfxCurrent(), f = sfxFs();
    if (!c || !f || sfx.busy) { return; }
    sfx.busy = true; $xGo.disabled = true;
    B.call('ytTarget').then(function (t) {
      var path = c.path, pd = t && t.ok ? t.data.projectDir : '';
      if (pd && path.toLowerCase().indexOf(pd.toLowerCase() + '/') !== 0) {
        try {
          var dir = pd + '/Imported/SFX', dst = dir + '/' + c.item.file;
          f.mkdir(dir);
          if (!f.exists(dst) || f.size(dst) !== f.size(path)) { f.copy(path, dst); }
          path = dst;
        } catch (e) { /* cannot write next to the project: use the library file itself */ }
      }
      return B.call('sfxInsert', { path: path, bin: 'SFX', seconds: sfx.dur[c.path] || 0 });
    }).then(function (r) {
      sfx.busy = false; $xGo.disabled = !sfx.rows.length;
      if (!r || !r.ok) { state.lastError = r; toast('err', T.x.err[r && r.code] || T.errors.unknown || T.s.err.failed, (r && r.detail) || '', 3500); return; }
      state.lastResult = r.data;
      if (r.data.placed) { toast('ok', T.x.placed(c.name, r.data.track), '', 1600); }
      else { toast('warn', T.x.imported[r.data.why] || T.x.imported.importOnly, '', 3200); }
    }, function () { sfx.busy = false; $xGo.disabled = !sfx.rows.length; });
  }

  function sfxAddFiles() {
    var f = sfxFs(), cat = sfx.cats[sfx.cat];
    if (!f || !cat) { return; }
    var picked = typeof window.__QFX_PICK === 'function' ? window.__QFX_PICK({ many: true }) : B.pick({ many: true, title: T.x.addTitle, types: ['wav', 'mp3', 'm4a', 'aac', 'aif', 'aiff', 'flac', 'ogg'] });
    if (!picked || !picked.length) { return; }
    var have = [], list = f.list(cat.path), done = 0, i;
    for (i = 0; i < list.length; i++) { have.push(list[i].raw); }
    for (i = 0; i < picked.length; i++) {
      var src = String(picked[i]).replace(/\\/g, '/'), base = src.slice(src.lastIndexOf('/') + 1);
      if (!XF.isAudio(base)) { continue; }
      var name = XF.freeName(have, base);
      try { f.copy(src, cat.path + '/' + name); have.push(name); done++; } catch (e) { state.lastError = { code: 'sfxCopy', message: String(e && e.message || e) }; }
    }
    sfxLoad(); renderSfx();
    toast(done ? 'ok' : 'err', done ? T.x.added(done, cat.name) : T.x.addFailed, '', 2200);
  }

  function sfxMakeCat(text) {
    var f = sfxFs(), name = XF.cleanName(text);
    sfx.naming = false;
    if (!f || !name) { renderSfx(); return; }
    for (var i = 0; i < sfx.cats.length; i++) { if (sfx.cats[i].name.toLowerCase() === name.toLowerCase()) { sfx.cat = i; renderSfx(); toast('warn', T.x.catExists, '', 1800); return; } }
    try { f.mkdir(sfx.dir + '/' + name); } catch (e) { toast('err', T.x.addFailed, String(e && e.message || e), 3000); renderSfx(); return; }
    sfxLoad();
    for (i = 0; i < sfx.cats.length; i++) { if (sfx.cats[i].name === name) { sfx.cat = i; } }
    $xQ.value = ''; sfx.row = 0; renderSfx();
    toast('ok', T.x.catMade(name), '', 1800);
  }

  function sfxPickDir() {
    var picked = typeof window.__QFX_PICK === 'function' ? window.__QFX_PICK({ folder: true }) : B.pick({ folder: true, title: T.x.pickDir, start: sfx.dir });
    if (!picked || !picked.length) { return; }
    state.settings.sfxDir = String(picked[0]).replace(/\\/g, '/').replace(/\/+$/, '');
    save(LS.settings, state.settings);
    sfx.cat = 0; sfx.row = 0; sfxStop(); sfxLoad(); renderSfx();
  }

  function sfxKey(e) {
    var typing = document.activeElement === $xQ, naming = document.activeElement && document.activeElement.id === 'xNew';
    if (naming) {
      if (e.key === 'Enter') { e.preventDefault(); sfxMakeCat(document.activeElement.value); }
      else if (e.key === 'Escape') { e.preventDefault(); sfx.naming = false; renderSfx(); }
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false, true); }
      else if (sfx.playing) { sfxStop(); }
      else if ($xQ.value) { $xQ.value = ''; sfx.row = 0; renderSfx(); }
      else { switchTab('fx'); }
    }
    else if (e.key === 'Enter') { e.preventDefault(); sfxInsert(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); sfxSelect(Math.min(sfx.rows.length - 1, sfx.row + 1), null, true); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); sfxSelect(Math.max(0, sfx.row - 1), null, true); }
    else if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && (!typing || !$xQ.value)) {
      var r = sfx.rows[sfx.row];
      if (r && r.items.length > 1) { e.preventDefault(); sfxSelect(sfx.row, (sfxVar(r) + (e.key === 'ArrowRight' ? 1 : r.items.length - 1)) % r.items.length, true); }
    }
    else if ((e.key === ' ' || e.keyCode === 32) && (!typing || !$xQ.value)) { e.preventDefault(); sfxToggle(); }
  }

  $xQ.addEventListener('input', function () { sfx.row = 0; renderSfx(); });
  $xCats.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-xcat],[data-xact]') : null;
    if (!t) { return; }
    if (t.hasAttribute('data-xact')) { sfx.naming = true; renderSfx(); return; }
    sfx.cat = Number(t.getAttribute('data-xcat')); sfx.row = 0; $xQ.value = ''; sfxStop(); renderSfx();
  });
  $xCats.addEventListener('focusout', function (e) { if (e.target && e.target.id === 'xNew' && sfx.naming) { var v = e.target.value; setTimeout(function () { if (sfx.naming) { if (v) { sfxMakeCat(v); } else { sfx.naming = false; renderSfx(); } } }, 120); } });
  $xList.addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.x-row') : null;
    if (!row) { return; }
    var i = Number(row.getAttribute('data-xrow')), chip = e.target.closest('[data-xvar]'), btn = e.target.closest('[data-xplay]');
    if (chip) { sfxSelect(i, Number(chip.getAttribute('data-xvar')), true); return; }
    if (btn && i === sfx.row) { sfxToggle(); return; }
    sfxSelect(i, null, true);
  });
  $xList.addEventListener('dblclick', function (e) { if (e.target.closest && e.target.closest('.x-row') && !e.target.closest('[data-xvar]')) { sfxInsert(); } });
  $xGo.addEventListener('click', sfxInsert);
  $xAdd.addEventListener('click', sfxAddFiles);
  $xPath.addEventListener('click', sfxPickDir);
  window.addEventListener('focus', function () { if (state.view === 'sfx' && Date.now() - sfx.loaded > 3000 && !sfx.naming) { sfxLoad(); renderSfx(); } });

  COMMANDS.push({ id: 'c:sfx', name: T.x.cmd, kind: 'command', icon: 'sfx', run: function () { switchTab('sfx'); },
    alt: 'sound effects sfx sounds whoosh pop click ხმები ხმა საუნდ ეფექტები ეფექტი საუნდები', meta: T.x.cmdMeta });

  // ------------------------------------------------------------------ text animations
  // Three slots, as in the phone editors: how the text comes in, how it leaves, what it does in between.
  // The little stage previews exactly what will be written (same maths), and its orange frame says where the
  // text sits in the picture: scaling and turning use its middle, masks use its edges.
  var TX = window.QFXText;
  var $tSlots = $('tSlots'), $tCats = $('tCats'), $tList = $('tList'), $tStage = $('tStage'), $tClip = $('tClip'), $tText = $('tText'), $tBox = $('tBox');
  var $tGrip = $('tGrip'), $tNote = $('tNote'), $tPos = $('tPos'), $tHint = $('tHint'), $tCombo = $('tCombo'), $tDur = $('tDur'), $tDurV = $('tDurV'), $tDurRow = $('tDurRow');
  var $tK = $('tK'), $tKV = $('tKV'), $tMb = $('tMb'), $tStatus = $('tStatus'), $tKeys = $('tKeys'), $tOff = $('tOff'), $tGo = $('tGo');
  var $tStyle = $('tStyle'), $tLen = $('tLen'), $tLenV = $('tLenV'), $tHelp = $('tHelp'), $tSel = $('tSel');
  var LS_TXT = 'qfx.text.v1';
  var txt = (function () {
    var d = load(LS_TXT, {}), c = d.combo || {};
    return {
      slot: (d.slot === 'out' || d.slot === 'loop') ? d.slot : 'in', cat: { 'in': d.catIn || 0, out: d.catOut || 0 }, row: 0, rows: [],
      combo: { 'in': TX && TX.anim(c['in']) ? c['in'] : '', out: TX && TX.anim(c.out) ? c.out : '', loop: TX && TX.loop(c.loop) ? c.loop : '',
        inDur: Number(c.inDur) || 0, outDur: Number(c.outDur) || 0, k: Number(c.k) || 1, loopK: Number(c.loopK) || 1, mb: c.mb !== false },
      box: TX ? TX.fixBox(d.box) : null, boxSet: !!d.boxSet, seq: { aspect: 16 / 9, fps: 25, w: 1920, h: 1080, has: false }, clips: [],
      native: '', t0: 0, raf: 0, busy: false, drag: null, size: { w: 0, h: 0 },
      styles: [], style: d.style || '', len: Number(d.len) >= 1 ? Number(d.len) : 3, help: false, marker: '', fs: undefined, scanned: 0, dropping: false
    };
  })();
  function txtSave() { save(LS_TXT, { slot: txt.slot, catIn: txt.cat['in'], catOut: txt.cat.out, combo: txt.combo, box: txt.box, boxSet: txt.boxSet, style: txt.style, len: txt.len }); }
  function txtDiag() { return { combo: txt.combo, box: txt.box, seq: txt.seq, clips: txt.clips.length, style: txt.style, styles: txt.styles.length, marker: txt.marker, len: txt.len }; }

  // ---- text templates: what a new text clip is made from
  var TXT_LOCAL = '/Library/Application Support/Adobe/Common/Motion Graphics Templates', LS_TPL = 'qfx.text.tpl.v1';
  var TXT_PNG = 'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAEklEQVR42mNgGAWjYBSMAggAAAQQAAGvRYgsAAAAAElFTkSuQmCC';
  function txtFs() {
    if (window.__QFX_TXT_FS) { return window.__QFX_TXT_FS; }
    if (txt.fs !== undefined) { return txt.fs; }
    txt.fs = null;
    try {
      var req = nodeReq();
      if (!req) { return null; }
      var fs = req('fs'), os = req('os'), Buf = (window.cep_node && window.cep_node.Buffer) || req('buffer').Buffer;
      txt.fs = {
        home: os.homedir(),
        list: function (dir) {
          var out = [], names = [];
          try { names = fs.readdirSync(dir); } catch (e) { return out; }
          for (var i = 0; i < names.length; i++) {
            if (names[i].charAt(0) === '.') { continue; }
            var st = null;
            try { st = fs.statSync(dir + '/' + names[i]); } catch (e2) { st = null; }
            if (st) { out.push({ name: names[i], dir: st.isDirectory() }); }
          }
          return out;
        },
        exists: function (p) { try { return fs.statSync(p).isFile(); } catch (e) { return false; } },
        /** The end of a file as text: a .mogrt is a zip, and its list of contents sits at the end. */
        tail: function (p, n) {
          var fd = null;
          try {
            var size = fs.statSync(p).size, len = Math.min(size, n), buf = Buf.alloc(len);
            fd = fs.openSync(p, 'r'); fs.readSync(fd, buf, 0, len, size - len); fs.closeSync(fd);
            return buf.toString('latin1');
          } catch (e) { try { if (fd !== null) { fs.closeSync(fd); } } catch (e2) {} return ''; }
        }
      };
    } catch (e) { txt.fs = null; }
    return txt.fs;
  }
  /** Made in Premiere (plain, fully editable text) or in After Effects? */
  function txtKind(tail) { return tail.indexOf('.prgraphic') >= 0 ? 'pr' : (tail.indexOf('.aegraphic') >= 0 ? 'ae' : ''); }

  function txtScan() {
    var f = txtFs(), out = [], seen = {}, budget = 4000;
    txt.scanned = Date.now();
    function add(path, src) {
      var key = path.toLowerCase();
      if (seen[key] || !/\.mogrt$/i.test(path)) { return; }
      seen[key] = true;
      var base = path.substring(path.lastIndexOf('/') + 1).replace(/\.mogrt$/i, ''), kind = txtKind(f.tail(path, 65536));
      if (/^quick ?fx/i.test(base)) { src = 'mine'; }
      if (src !== 'mine' && kind !== 'pr') { return; }                 // other people's After Effects packs are not plain text
      out.push({ name: base.normalize ? base.normalize('NFC') : base, path: path, kind: kind, src: src });
    }
    function walk(dir, depth, src, skip) {
      if (budget <= 0) { return; }
      var list = f.list(dir), i;
      budget -= 1 + list.length / 50;
      for (i = 0; i < list.length; i++) { if (!list[i].dir) { add(dir + '/' + list[i].name, src); } }
      if (depth <= 0) { return; }
      for (i = 0; i < list.length; i++) {
        if (list[i].dir && !(skip && skip.test(list[i].name))) { walk(dir + '/' + list[i].name, depth - 1, src, skip); }
      }
    }
    if (f) {
      if (state.settings.textFile && f.exists(state.settings.textFile)) { add(state.settings.textFile, 'mine'); }
      walk(f.home + '/Documents/Quick FX Text', 1, 'mine');
      walk(f.home + TXT_LOCAL, 2, 'local');
      walk(TXT_LOCAL, 2, 'local');
      if (!out.length) {
        // nothing of the editor's own: look for the plain titles that come inside Premiere itself (once; remembered)
        var app = B.hostAppPath ? B.hostAppPath() : '', at = app.indexOf('.app/'), cache = load(LS_TPL, null), i;
        if (at > 0) {
          var root = app.substring(0, at + 4) + '/Contents';
          if (cache && cache.root === root && Date.now() - cache.at < 14 * 86400000) {
            for (i = 0; i < cache.paths.length; i++) { if (f.exists(cache.paths[i])) { add(cache.paths[i], 'premiere'); } }
          } else {
            walk(root, 6, 'premiere', /^(Frameworks|MacOS|_CodeSignature|Dictionaries|Plug-Ins|PlugIns)$|\.(lproj|framework|bundle|plugin)$/i);
            var paths = [];
            for (i = 0; i < out.length; i++) { paths.push(out[i].path); }
            save(LS_TPL, { root: root, at: Date.now(), paths: paths });
          }
        }
      }
    }
    function rank(x) { return x.src === 'mine' ? 0 : (/^basic title$/i.test(x.name) ? 1 : (/title/i.test(x.name) ? 2 : 3)); }
    out.sort(function (a, b) { return rank(a) - rank(b) || (a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1); });
    txt.styles = out.slice(0, 40);
    var keep = false;
    for (var k = 0; k < txt.styles.length; k++) { if (txt.styles[k].path === txt.style) { keep = true; } }
    if (!keep) { txt.style = txt.styles.length ? txt.styles[0].path : ''; }
    return txt.styles;
  }

  /** The tiny placeholder picture that is dragged onto the timeline (a panel may only drag files there). */
  function txtMarker() {
    if (txt.marker) { return txt.marker; }
    if (window.__QFX_TXT_MARKER) { txt.marker = window.__QFX_TXT_MARKER; return txt.marker; }
    try {
      var base = B.userDataPath();
      if (!base) { return ''; }
      var dir = base.replace(/\/+$/, '') + '/QuickFX/drag', file = dir + '/Quick FX Text.png';
      if (!B.fileExists(file)) { B.makeDirs(dir); B.writeBase64File(file, TXT_PNG); }
      if (B.fileExists(file)) { txt.marker = file; }
    } catch (e) {}
    return txt.marker;
  }

  /** Categories of the current slot: the library's, then Premiere's own per-letter tools. Loops have one list. */
  function txtCats() {
    if (txt.slot === 'loop') { return [{ id: 'loop', name: T.t.loops, hint: T.t.loopsHint }]; }
    return TX.CATS.concat([{ id: 'native', name: T.t.native, hint: T.t.nativeHint }]);
  }
  function txtRows() {
    var cats = txtCats(), c = cats[txt.slot === 'loop' ? 0 : Math.min(txt.cat[txt.slot], cats.length - 1)], rows = [], list, i;
    if (c.id === 'native') { for (i = 0; i < T.t.nativeItems.length; i++) { rows.push({ id: T.t.nativeItems[i].id, n: T.t.nativeItems[i].n, native: T.t.nativeItems[i] }); } }
    else {
      rows.push({ id: '', n: T.t.none, none: true });
      list = c.id === 'loop' ? TX.LOOPS : TX.inCategory(c.id);
      for (i = 0; i < list.length; i++) { rows.push({ id: list[i].id, n: list[i].n, def: list[i] }); }
    }
    txt.rows = rows;
    return rows;
  }
  function txtCurrentId() { return txt.native || txt.combo[txt.slot]; }

  function txtStageSize() {
    // an upright frame (Reels, TikTok) gets more height, or its picture would be a narrow strip
    var a = txt.seq.aspect, tall = a < 1, maxW = MODE === 'panel' ? 214 : 328, maxH = MODE === 'panel' ? (tall ? 210 : 120) : (tall ? 272 : 200), w = maxW, h = w / a;
    if (h > maxH) { h = maxH; w = h * a; }
    txt.size = { w: Math.round(w), h: Math.round(h) };
    $tStage.style.width = txt.size.w + 'px'; $tStage.style.height = txt.size.h + 'px';
  }
  function txtPlaceBox() {
    var b = txt.box, z = txt.size;
    $tBox.style.left = (b.x * z.w) + 'px'; $tBox.style.top = (b.y * z.h) + 'px';
    $tBox.style.width = (b.w * z.w) + 'px'; $tBox.style.height = (b.h * z.h) + 'px';
    var fs = Math.max(5, Math.min(b.h * z.h * 0.78, b.w * z.w / 3.6));
    $tText.style.fontSize = fs + 'px';
    var on = $tPos.querySelectorAll('button');
    for (var i = 0; i < on.length; i++) {
      var gx = i % 3, gy = Math.floor(i / 3), px = [0.06, (1 - b.w) / 2, 1 - b.w - 0.06][gx], py = [0.08, (1 - b.h) / 2, 1 - b.h - 0.08][gy];
      on[i].className = (Math.abs(b.x - px) < 0.012 && Math.abs(b.y - py) < 0.012) ? 'on' : '';
    }
  }

  /** One frame of the preview. */
  function txtDraw(S) {
    var z = txt.size, b = txt.box, cx = (b.x + b.w / 2) * z.w, cy = (b.y + b.h / 2) * z.h, K = TX.cropOf(S, b);
    $tText.style.transform = 'translate(' + (cx + S.dx * z.h) + 'px,' + (cy + S.dy * z.h) + 'px) translate(-50%,-50%) rotate(' + S.r + 'deg) scale(' + S.sx + ',' + S.sy + ')';
    $tText.style.opacity = S.o;
    $tText.style.filter = S.b > 0.4 ? 'blur(' + (S.b * z.h / 1080 * 2.2) + 'px)' : '';
    $tClip.style.clipPath = (K.l || K.t || K.r || K.b) ? 'inset(' + K.t + '% ' + K.r + '% ' + K.b + '% ' + K.l + '%)' : '';
    $tClip.style.webkitClipPath = $tClip.style.clipPath;
  }
  var TXT_REST = { dx: 0, dy: 0, sx: 1, sy: 1, r: 0, o: 1, b: 0, cl: -1, ct: -1, cr: -1, cb: -1 };
  function txtPreviewPlan() {
    var c = txt.combo, a = TX.anim(c['in']), o = TX.anim(c.out), l = TX.loop(c.loop);
    if (!a && !o && !l) { return null; }
    var ti = a ? (c.inDur || a.d) : 0, to = o ? (c.outDur || o.d) : 0, hold = l ? (l.span ? 3.2 : 2.6) : 0.9;
    return TX.plan(c, { dur: ti + to + hold, fps: 30, aspect: txt.seq.aspect, box: txt.box });
  }
  function txtStop() { if (txt.raf) { cancelAnimationFrame(txt.raf); txt.raf = 0; } }
  function txtPlay() {
    txtStop();
    var P = txtPreviewPlan();
    if (!P || txt.native || state.view !== 'txt') { txtDraw(TXT_REST); return; }
    txt.t0 = (window.__QFX_NOW || Date.now)();
    var gap = P.b ? 0.5 : 0.7;
    (function tick() {
      if (state.view !== 'txt') { txt.raf = 0; return; }
      if (!txt.drag) {
        var t = (((window.__QFX_NOW || Date.now)() - txt.t0) / 1000) % (P.dur + gap);
        if (t > P.dur) { if (P.b) { $tText.style.opacity = 0; } else { txtDraw(TX.stateAt(P, P.dur)); } }
        else { txtDraw(TX.stateAt(P, t)); }
      }
      txt.raf = requestAnimationFrame(tick);
    })();
  }

  function renderTxtSide() {
    var c = txt.combo, h = [], slots = ['in', 'out', 'loop'], i;
    for (i = 0; i < 3; i++) {
      var sl = slots[i], d = sl === 'loop' ? TX.loop(c.loop) : TX.anim(c[sl]);
      h.push('<button class="t-chip' + (sl === txt.slot ? ' on' : '') + '" data-tchip="' + sl + '"><em>' + esc(T.t.slot[sl]) + '</em><span' + (d ? '' : ' class="empty"') + '>' + esc(d ? d.n : T.t.empty) + '</span>' + (d ? '<b data-tclear="' + sl + '" title="×">×</b>' : '') + '</button>');
    }
    $tCombo.innerHTML = h.join('');
    var btns = $tSlots.querySelectorAll('button');
    for (i = 0; i < btns.length; i++) {
      var s2 = btns[i].getAttribute('data-tslot');
      btns[i].className = s2 === txt.slot ? 'on' : '';
      btns[i].innerHTML = esc(T.t.slot[s2]) + (c[s2] ? '<i></i>' : '');
    }
    var cur = txt.slot === 'loop' ? TX.loop(c.loop) : TX.anim(c[txt.slot]);
    if (txt.slot === 'loop') { $tDurRow.className = 't-ctl off'; $tDurV.textContent = ''; $tK.value = Math.round(c.loopK * 100); }
    else {
      $tDurRow.className = 't-ctl' + (cur ? '' : ' off');
      var dv = cur ? (txt.slot === 'in' ? (c.inDur || cur.d) : (c.outDur || cur.d)) : 0.5;
      $tDur.value = dv; $tDurV.textContent = cur ? T.t.sec(dv) : '';
      $tK.value = Math.round(c.k * 100);
    }
    $tKV.textContent = $tK.value + '%';
    $tMb.checked = c.mb !== false;
    var need = TX.needsBox(c);
    $tHint.className = 't-hint' + (need.mask && !txt.boxSet ? ' warn' : '');
    $tHint.textContent = need.mask ? T.t.hintMask : (need.anchor ? T.t.hintAnchor : ((c['in'] || c.out || c.loop) ? T.t.hintFree : T.t.hintBox));
    $tNote.hidden = !txt.native; $tNote.textContent = txt.native ? T.t.nativeNote : '';
    var so = '';
    for (i = 0; i < txt.styles.length; i++) { so += '<option value="' + i + '"' + (txt.styles[i].path === txt.style ? ' selected' : '') + '>' + esc(txt.styles[i].name) + '</option>'; }
    if (!txt.styles.length) { so = '<option value="-1" selected>' + esc(T.t.styleNone) + '</option>'; }
    $tStyle.innerHTML = so + '<option value="pick">' + esc(T.t.stylePick) + '</option>';
    $tLen.value = txt.len; $tLenV.textContent = T.t.sec(txt.len);
    $tHelp.className = 't-q' + (txt.help ? ' on' : '');
    $tSel.disabled = txt.busy;
    $tBox.style.display = txt.native ? 'none' : '';
    $tGo.disabled = txt.busy; $tOff.disabled = txt.busy;
  }

  function renderTxt() {
    if (!TX) { return; }
    var cats = txtCats(), h = [], i, ci = txt.slot === 'loop' ? 0 : Math.min(txt.cat[txt.slot], cats.length - 1);
    for (i = 0; i < cats.length; i++) {
      var cnt = cats[i].id === 'native' ? T.t.nativeItems.length : (cats[i].id === 'loop' ? TX.LOOPS.length : TX.inCategory(cats[i].id).length);
      h.push('<button class="x-cat' + (i === ci ? ' on' : '') + '" data-tcat="' + i + '" title="' + esc(cats[i].hint) + '"><span>' + esc(cats[i].name) + '</span><i>' + cnt + '</i></button>');
    }
    $tCats.innerHTML = h.join('');
    var rows = txtRows(), cur = txtCurrentId();
    txt.row = 0;
    for (i = 0; i < rows.length; i++) { if (rows[i].id === cur) { txt.row = i; } }
    h = [];
    if (txt.help || !txt.styles.length) {
      h.push('<div class="t-setup"><h4>' + esc(txt.styles.length ? T.t.helpTitle : T.t.setupTitle) + '</h4><p>' + esc(T.t.setupWhy) + '</p><ol>');
      for (i = 0; i < T.t.setupSteps.length; i++) { h.push('<li>' + esc(T.t.setupSteps[i]) + '</li>'); }
      h.push('</ol><p>' + esc(T.t.setupMore) + '</p><div class="t-row"><button class="c-btn primary" data-tsetup="check">' + esc(T.t.setupCheck) + '</button><button class="c-btn" data-tsetup="pick">' + esc(T.t.setupPick) + '</button>' +
        (txt.styles.length ? '<button class="c-btn" data-tsetup="close">' + esc(T.t.setupClose) + '</button>' : '') + '</div></div>');
    }
    h.push('<div class="t-cathint">' + esc(cats[ci].hint) + '</div>');
    if (txt.styles.length && cats[ci].id !== 'native') { h.push('<div class="t-drag-tip">' + esc(T.t.dragTip) + '</div>'); }
    for (i = 0; i < rows.length; i++) {
      var r = rows[i], tags = '';
      if (r.def && r.def['with'] && txt.slot === 'in') { tags += '<span class="t-tag box">კომბო</span>'; }
      if (r.def && r.def.box) { tags += '<span class="t-tag box">' + esc(T.t.box) + '</span>'; }
      if (r.def && r.def.d) { tags += '<span class="t-tag">' + esc(T.t.sec(r.def.d)) + '</span>'; }
      h.push('<div class="x-row' + (i === txt.row ? ' active' : '') + (r.none ? ' none' : '') + '" data-trow="' + i + '"' + (r.native ? '' : ' draggable="true"') + '><span class="x-name">' + esc(r.n) + '</span>' + tags + '</div>');
    }
    $tList.innerHTML = h.join('');
    $tKeys.textContent = T.t.keys;
    $tStatus.textContent = !txt.seq.has ? T.t.noSeq : (txt.clips.length ? T.t.selN(txt.clips.length) : T.t.selNone);
    $tStatus.className = 'z-status' + (txt.clips.length ? ' on' : '');
    txtStageSize(); txtPlaceBox(); renderTxtSide();
    var act = $tList.querySelector('.x-row.active');
    if (act && act.scrollIntoView) { try { act.scrollIntoView({ block: 'nearest' }); } catch (e) {} }
  }

  /** What is selected in Premiere (and the sequence's shape, for the stage). */
  function txtRefresh() {
    return B.call('animTargets').then(function (r) {
      if (!r || !r.ok) { return null; }
      var d = r.data, was = txt.seq.aspect, n = txt.clips.length, had = txt.seq.has;
      txt.seq.has = !!d.hasSequence; txt.clips = d.clips || [];
      if (d.hasSequence && d.width > 0 && d.height > 0) { txt.seq = { aspect: d.width / d.height, fps: d.fps || 25, w: d.width, h: d.height, has: true }; }
      if (state.view === 'txt' && (was !== txt.seq.aspect || n !== txt.clips.length || had !== txt.seq.has)) {
        $tStatus.textContent = !txt.seq.has ? T.t.noSeq : (txt.clips.length ? T.t.selN(txt.clips.length) : T.t.selNone);
        $tStatus.className = 'z-status' + (txt.clips.length ? ' on' : '');
        if (was !== txt.seq.aspect) { txtStageSize(); txtPlaceBox(); txtPlay(); }
      }
      return d;
    });
  }

  function openTxt() {
    if (!TX) { return; }
    if (!txt.scanned || Date.now() - txt.scanned > 15000) { txtScan(); }
    txtMarker();
    renderTxt(); txtPlay(); txtRefresh();
  }

  /**
   * Hands the keyframes to Premiere. The side of Premiere that adds effects can lag behind the timeline for a moment
   * (right after a drop or a new clip it may not see the clip yet), so clips it could not reach are tried again a few
   * times; for a text this plugin has just made, the last try may write the animation on the clip's own Motion instead.
   * → {ok, data: {clips, missing, notFound, motion, lost, why, tries}, fail}
   */
  function txtSend(jobs, opts) {
    opts = opts || {};
    var max = opts.onlyExisting ? 1 : (opts.fresh ? 4 : 3), gap = window.__QFX_TXT_GAP === undefined ? 350 : window.__QFX_TXT_GAP;
    var sum = { clips: 0, missing: [], notFound: [], added: [], motion: 0, lost: [], why: '', tries: 0, rounds: [] }, pending = jobs, fail = null;
    function add(list, more) { for (var i = 0; more && i < more.length; i++) { if (list.indexOf(more[i]) < 0) { list.push(more[i]); } } }
    function round(n) {
      var last = n >= max, useMotion = !!opts.fresh && last;
      return B.call('animApply', { jobs: pending, onlyExisting: !!opts.onlyExisting, motion: useMotion }).then(function (r) {
        var d = r ? (r.ok ? r.data : r.extra) : null, again = (d && d.retry) || [];
        sum.tries = n;
        if (d) { sum.rounds.push({ why: d.why || '', diag: d.diag || null, clips: d.clips || 0, motion: d.motion || 0 }); }
        if (r && r.ok) {
          sum.clips += d.clips || 0; sum.motion += d.motion || 0;
          add(sum.notFound, d.notFound); add(sum.added, d.added); add(sum.lost, d.lost);
          var rest = []; for (var i = 0; d.missing && i < d.missing.length; i++) { if (d.missing[i] !== 'Transform') { rest.push(d.missing[i]); } }
          add(sum.missing, rest);
        }
        if (d && d.why) { sum.why = d.why; }
        if (again.length && !last) {
          var next = []; for (var k = 0; k < again.length; k++) { if (pending[again[k]]) { next.push(pending[again[k]]); } }
          pending = next;
          var skip = d.why === 'noEffect' ? max : n + 1;                 // Premiere has no such effect: waiting will not help
          return new Promise(function (res) { setTimeout(res, d.why === 'noEffect' ? 0 : gap); }).then(function () { return round(skip); });
        }
        if (!r || !r.ok) { fail = r || { code: 'hostError' }; if (again.length && sum.clips) { add(sum.missing, ['Transform']); } }
        else if (again.length) { add(sum.missing, ['Transform']); }
        return { ok: sum.clips > 0, data: sum, fail: fail };
      });
    }
    if (opts.fresh && gap > 0) { return new Promise(function (res) { setTimeout(res, Math.round(gap / 3)); }).then(function () { return round(1); }); }
    return round(1);
  }
  /** What to tell after txtSend: true when everything went on as asked. */
  function txtReport(res, okMsg, okMs) {
    state.lastResult = res.data;
    if (!res.ok) { txtFail(res.fail || { code: 'animFailed' }, res.data); return false; }
    var d = res.data;
    if (d.motion) { toast('warn', T.t.viaMotion, d.lost.length ? T.t.lost(d.lost) : esc(T.t.whyOf(d.why)), 7000); return false; }
    if (d.missing.length) { toast('warn', T.t.partial(d.missing), esc(T.t.whyOf(d.why)), 6000); return false; }
    if (d.notFound.length) { toast('warn', T.t.params, esc(d.notFound.join(', ')), 6000); return false; }
    toast('ok', okMsg, '', okMs || 4200);
    return true;
  }

  /** Put the chosen combination on clips the host just made (or found). */
  function txtAnimate(clips, d, okMsg) {
    var c = txt.combo, jobs = [];
    if (!c['in'] && !c.out && !c.loop) { toast('ok', okMsg, '', 4200); return Promise.resolve(); }
    for (var k = 0; k < clips.length; k++) {
      var bk = TX.bake(c, { dur: clips[k].dur, fps: d.fps, aspect: d.width / d.height, height: d.height, box: txt.box });
      if (bk.ok) { jobs.push({ track: clips[k].track, start: clips[k].start, fresh: true, effects: bk.effects, show: { from: (c['in'] ? bk.plan.ti : 0), to: clips[k].dur - (c.out ? bk.plan.to : 0) } }); }
    }
    return txtSend(jobs, { fresh: true }).then(function (res) { txtReport(res, okMsg); });
  }

  /** A new text clip at the playhead, with the chosen animation on it. */
  function txtInsert() {
    if (txt.busy || !TX) { return; }
    if (txt.native) { txtApply(false); return; }
    if (!txt.style) { txt.help = true; renderTxt(); toast('warn', T.t.noStyle, '', 3600); return; }
    txt.busy = true; renderTxtSide();
    function done() { txt.busy = false; if (state.view === 'txt') { renderTxtSide(); } }
    var seq = null;
    txtRefresh().then(function (d) {
      if (!d) { done(); txtFail({ code: 'hostError' }); return null; }
      if (!d.hasSequence) { done(); toast('err', T.errors.noSequence, '', 3200); return null; }
      seq = d;
      return B.call('textInsert', { path: txt.style, seconds: txt.len });
    }).then(function (r) {
      if (r === null) { return; }
      if (!r || !r.ok) { done(); txtFail(r || { code: 'hostError' }); return; }
      state.lastResult = r.data;
      return txtAnimate(r.data.clips, seq, T.t.created(r.data.track)).then(function () { done(); txtRefresh(); });
    }).then(null, function (e) { done(); txtFail({ code: 'exception', message: String(e && e.message || e) }); });
  }

  /** After a drag: wait for Premiere to place the placeholder, then swap it for the text and animate it. */
  function txtDropPoll(n) {
    if (n > 16) { txt.dropping = false; return; }
    txt.dropping = true;
    setTimeout(function () {
      B.call('textDrop', { marker: txt.marker, path: txt.style, seconds: txt.len }).then(function (r) {
        if (!r || !r.ok) { txt.dropping = false; if (r && r.code !== 'noSequence' && r.code !== 'hostError') { txtFail(r); } return; }
        if (!r.data.found) { txtDropPoll(n + 1); return; }
        state.lastResult = r.data;
        var d = { fps: txt.seq.fps, width: txt.seq.w, height: txt.seq.h };
        txtAnimate(r.data.clips, d, r.data.clips.length > 1 ? T.t.createdN(r.data.clips.length) : T.t.created(r.data.clips[0].track + 1)).then(function () { txt.dropping = false; txtRefresh(); });
      });
    }, n ? 300 : 200);
  }
  function txtRescan(say) {
    txtScan(); txt.help = !txt.styles.length; txtSave(); renderTxt();
    if (say) { toast(txt.styles.length ? 'ok' : 'warn', txt.styles.length ? T.t.found(txt.styles.length) : T.t.notFound, '', 2600); }
  }
  function txtPickFile() {
    var got = (window.__QFX_PICK || B.pick)({ many: false, folder: false, title: T.t.pickTitle, types: ['mogrt'] });
    if (!got || !got.length) { renderTxtSide(); return; }
    state.settings.textFile = String(got[0]).replace(/\\/g, '/'); save(LS.settings, state.settings);
    txt.style = state.settings.textFile; txtRescan(true);
  }

  function txtPick(i) {
    var r = txt.rows[i];
    if (!r) { return; }
    txt.row = i;
    if (r.native) { txt.native = r.id; }
    else {
      txt.native = '';
      txt.combo[txt.slot] = r.id;
      if (txt.slot === 'in') { txt.combo.inDur = 0; } else if (txt.slot === 'out') { txt.combo.outDur = 0; }
      // a ready cinematic combination brings its slow move and its exit along
      var w = txt.slot === 'in' && r.def ? r.def['with'] : null;
      if (w) { if (w.loop) { txt.combo.loop = w.loop; } if (w.out) { txt.combo.out = w.out; txt.combo.outDur = 0; } }
    }
    var els = $tList.querySelectorAll('.x-row');
    for (var k = 0; k < els.length; k++) { els[k].classList.toggle('active', k === i); }
    if (els[i] && els[i].scrollIntoView) { try { els[i].scrollIntoView({ block: 'nearest' }); } catch (e) {} }
    txtSave(); renderTxtSide(); txtPlay();
  }
  function txtSlot(sl) { txt.slot = sl; txt.native = ''; txtSave(); renderTxt(); txtPlay(); }

  function txtFail(r, sum) {
    state.lastError = r;
    var code = r && r.code, msg = T.t.err[code] || T.errors[code] || T.errors.exception, sub = '';
    var why = (sum && sum.why) || (r && r.extra && r.extra.why) || '';
    if (code === 'animFxMissing' && why && why !== 'noEffect') { msg = T.t.err.animNoReach; sub = esc(T.t.whyOf(why)); }
    else if (code === 'animFxMissing' && r.message) { sub = esc(r.message); }
    else if ((code === 'exception' || code === 'hostError' || code === 'badReply' || code === 'animNativeFailed') && r.message) { sub = esc(r.message); }
    toast('err', msg, sub, 5200);
  }

  /** Put the chosen combination on the selected clips (off = take our animation off them). */
  function txtApply(off) {
    if (txt.busy || !TX) { return; }
    var nat = null, i;
    if (!off && txt.native) { for (i = 0; i < T.t.nativeItems.length; i++) { if (T.t.nativeItems[i].id === txt.native) { nat = T.t.nativeItems[i]; } } }
    if (!off && !nat && !txt.combo['in'] && !txt.combo.out && !txt.combo.loop) { toast('warn', T.t.pick, '', 2600); return; }
    txt.busy = true; renderTxtSide();
    function done() { txt.busy = false; if (state.view === 'txt') { renderTxtSide(); } }
    txtRefresh().then(function (d) {
      if (!d) { done(); txtFail({ code: 'hostError' }); return null; }
      if (!d.hasSequence) { done(); toast('err', T.errors.noSequence, '', 3200); return null; }
      if (!d.clips.length) { done(); toast('warn', T.t.noSel, '', 3200); return null; }
      if (nat) {
        var cur = TX.anim(txt.combo[txt.slot]), secs = Number($tDur.value) || 0.8;
        return B.call('animNative', { names: nat.names, atEnd: txt.slot === 'out', frames: Math.round((cur ? secs : 0.8) * (d.fps || 25)) }).then(function (r) {
          done();
          if (!r || !r.ok) { txtFail(r || { code: 'hostError' }); return; }
          state.lastResult = r.data; toast('ok', T.t.nativeOk(r.data.name, r.data.applied), '', 4200);
        });
      }
      var jobs = [];
      for (var k = 0; k < d.clips.length; k++) {
        var c = d.clips[k], bk = off ? TX.neutral() : TX.bake(txt.combo, { dur: c.dur, fps: d.fps, aspect: d.width / d.height, height: d.height, box: txt.box });
        if (bk.ok) { jobs.push({ track: c.track, start: c.start, effects: bk.effects }); }
      }
      return txtSend(jobs, { onlyExisting: !!off }).then(function (res) {
        done();
        txtReport(res, off ? T.t.removed(res.data.clips) : T.t.applied(res.data.clips), 1800);
        txtRefresh();
      });
    }).then(null, function (e) { done(); txtFail({ code: 'exception', message: String(e && e.message || e) }); });
  }

  function txtKey(e) {
    if (e.isComposing) { return; }
    if (e.metaKey || e.ctrlKey || e.altKey) { return; }
    if (document.activeElement === $tStyle && e.key !== 'Escape') { return; }
    if (e.key === 'Escape') { e.preventDefault(); if (!$menu.hidden) { openMenu(false, true); } else if (txt.help && txt.styles.length) { txt.help = false; renderTxt(); } else { switchTab('fx'); } }
    else if (e.key === 'Enter') { e.preventDefault(); if (e.shiftKey) { txtApply(false); } else { txtInsert(); } }
    else if (e.key === 'ArrowDown') { e.preventDefault(); txtPick(Math.min(txt.rows.length - 1, txt.row + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); txtPick(Math.max(0, txt.row - 1)); }
    else if (e.key === 'ArrowRight' || e.key === 'ArrowLeft' || e.key === 'Tab') {
      e.preventDefault();
      var order = ['in', 'out', 'loop'], at = 0;
      for (var i = 0; i < 3; i++) { if (order[i] === txt.slot) { at = i; } }
      txtSlot(order[(at + ((e.key === 'ArrowLeft' || e.shiftKey) ? 2 : 1)) % 3]);
    }
    else if (e.key === 'Backspace' || e.key === 'Delete') { e.preventDefault(); txt.native = ''; txt.combo[txt.slot] = ''; txtSave(); renderTxt(); txtPlay(); }
  }

  if (TX) {
    (function () { var h = ''; for (var i = 0; i < 9; i++) { h += '<button data-tpos="' + i + '" tabindex="-1"></button>'; } $tPos.innerHTML = h; })();
    $tSlots.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-tslot]') : null; if (b) { txtSlot(b.getAttribute('data-tslot')); } });
    $tCats.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-tcat]') : null;
      if (!b || txt.slot === 'loop') { return; }
      txt.cat[txt.slot] = Number(b.getAttribute('data-tcat')); txt.native = ''; txtSave(); renderTxt();
    });
    $tList.addEventListener('click', function (e) {
      var su = e.target.closest ? e.target.closest('[data-tsetup]') : null, r = e.target.closest ? e.target.closest('[data-trow]') : null;
      if (su) {
        var act = su.getAttribute('data-tsetup');
        if (act === 'check') { txtRescan(true); } else if (act === 'pick') { txtPickFile(); } else { txt.help = false; renderTxt(); }
        return;
      }
      if (r) { txtPick(Number(r.getAttribute('data-trow'))); }
    });
    $tList.addEventListener('dblclick', function (e) { var r = e.target.closest ? e.target.closest('[data-trow]') : null; if (r && !txt.rows[Number(r.getAttribute('data-trow'))].none) { txtInsert(); } });
    // drag an animation onto the timeline: Premiere receives a placeholder picture, which is then swapped for the text
    $tList.addEventListener('dragstart', function (e) {
      var el = e.target.closest ? e.target.closest('[data-trow]') : null, i = el ? Number(el.getAttribute('data-trow')) : -1, r = txt.rows[i];
      if (!r || r.native) { e.preventDefault(); return; }
      if (!txt.style || !txtMarker()) { e.preventDefault(); txt.help = true; renderTxt(); toast('warn', T.t.noStyle, '', 3600); return; }
      if (i !== txt.row || txtCurrentId() !== r.id) { txtPick(i); }
      try {
        e.dataTransfer.effectAllowed = 'copy';
        e.dataTransfer.setData('com.adobe.cep.dnd.file.0', txt.marker);
        e.dataTransfer.setData('text/plain', r.n);
      } catch (e2) {}
      el.classList.add('dragging');
    });
    $tList.addEventListener('dragend', function (e) {
      var el = e.target.closest ? e.target.closest('[data-trow]') : null;
      if (el) { el.classList.remove('dragging'); }
      if (txt.style && txt.marker && !txt.dropping) { txtDropPoll(0); }
    });
    $tStyle.addEventListener('change', function () {
      if ($tStyle.value === 'pick') { txtPickFile(); return; }
      var st = txt.styles[Number($tStyle.value)];
      if (st) { txt.style = st.path; txtSave(); }
    });
    $tLen.addEventListener('input', function () { txt.len = Number($tLen.value) || 3; $tLenV.textContent = T.t.sec(txt.len); txtSave(); });
    $tHelp.addEventListener('click', function () { txt.help = !txt.help || !txt.styles.length; renderTxt(); });
    $tSel.addEventListener('click', function () { txtApply(false); });
    $tCombo.addEventListener('click', function (e) {
      var x = e.target.closest ? e.target.closest('[data-tclear]') : null, c = e.target.closest ? e.target.closest('[data-tchip]') : null;
      if (x) { txt.combo[x.getAttribute('data-tclear')] = ''; txt.native = ''; txtSave(); renderTxt(); txtPlay(); return; }
      if (c) { txtSlot(c.getAttribute('data-tchip')); }
    });
    $tDur.addEventListener('input', function () {
      var v = Number($tDur.value);
      if (txt.slot === 'in') { txt.combo.inDur = v; } else if (txt.slot === 'out') { txt.combo.outDur = v; }
      $tDurV.textContent = T.t.sec(v); txtSave(); txtPlay();
    });
    $tK.addEventListener('input', function () {
      var v = Number($tK.value) / 100;
      if (txt.slot === 'loop') { txt.combo.loopK = v; } else { txt.combo.k = v; }
      $tKV.textContent = $tK.value + '%'; txtSave(); txtPlay();
    });
    $tMb.addEventListener('change', function () { txt.combo.mb = $tMb.checked; txtSave(); });
    $tPos.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-tpos]') : null;
      if (!b) { return; }
      var i = Number(b.getAttribute('data-tpos')), bx = txt.box;
      bx.x = [0.06, (1 - bx.w) / 2, 1 - bx.w - 0.06][i % 3]; bx.y = [0.08, (1 - bx.h) / 2, 1 - bx.h - 0.08][Math.floor(i / 3)];
      txt.box = TX.fixBox(bx); txt.boxSet = true; txtSave(); txtPlaceBox(); renderTxtSide(); txtPlay();
    });
    // drag the frame to where the text is; the corner changes its size
    $tBox.addEventListener('mousedown', function (e) {
      e.preventDefault();
      txt.drag = { resize: e.target === $tGrip, x: e.clientX, y: e.clientY, box: { x: txt.box.x, y: txt.box.y, w: txt.box.w, h: txt.box.h } };
      $tBox.classList.add('drag'); txtDraw(TXT_REST);
    });
    window.addEventListener('mousemove', function (e) {
      var d = txt.drag;
      if (!d) { return; }
      var dx = (e.clientX - d.x) / txt.size.w, dy = (e.clientY - d.y) / txt.size.h, b = d.box;
      txt.box = d.resize ? TX.fixBox({ x: b.x, y: b.y, w: Math.min(Math.max(0.06, b.w + dx), 1 - b.x), h: Math.min(Math.max(0.04, b.h + dy), 1 - b.y) })
        : TX.fixBox({ x: b.x + dx, y: b.y + dy, w: b.w, h: b.h });
      txtPlaceBox(); txtDraw(TXT_REST);
    });
    window.addEventListener('mouseup', function () {
      if (!txt.drag) { return; }
      txt.drag = null; txt.boxSet = true; $tBox.classList.remove('drag'); txtSave(); renderTxtSide(); txtPlay();
    });
    $tGo.addEventListener('click', function () { txtInsert(); });
    $tOff.addEventListener('click', function () { txtApply(true); });
    window.addEventListener('focus', function () { if (state.view === 'txt') { txtRefresh(); } });
    COMMANDS.push({ id: 'c:txt', name: T.t.cmd, kind: 'command', icon: 'txt', run: function () { switchTab('txt'); },
      alt: 'text animation animations title titles typography mogrt preset ტექსტი ანიმაცია ანიმაციები სათაური ტიტრი ტიტრები წარწერა სუბტიტრები', meta: T.t.cmdMeta });
  }

  // ------------------------------------------------------------------ background watcher
  function autoState() {
    var a = Store.read('auto-state.json', null);
    return { settings: Store.settings(), state: a, alive: !!(a && a.alive && Date.now() - a.alive < 15000) };
  }

  /** The watcher normally starts with Premiere; if it is not running, opening Quick FX starts it. */
  function wakeWatcher() {
    if (!B.available) { return; }
    var a = autoState();
    if (a.settings.auto && !a.alive) { B.openExtension(AUTO_ID); }
  }

  function autoInfoHtml() {
    var a = autoState();
    if (!a.settings.auto) { return esc(T.auto.off); }
    if (!a.alive) { return '<span style="color:var(--err)">' + esc(T.auto.dead) + '</span>'; }
    var out = esc(T.auto.on), st = a.state, i;
    if (st.queue) { out += '<br>' + esc(T.auto.copying(st.current || '…', st.queue)); }
    for (i = (st.log || []).length - 1; i >= 0; i--) {
      if (st.log[i].kind === 'ok' || st.log[i].kind === 'err') {
        out += '<br>' + esc(T.auto.last) + ' ' + (st.log[i].kind === 'err' ? '✕ ' : '') + esc(st.log[i].text);
        break;
      }
    }
    return out;
  }

  // ------------------------------------------------------------------ menu
  function updateMenuInfo() {
    var fxCount = (state.effects.video || []).length + (state.effects.audio || []).length;
    var lines = [];
    lines.push('ეფექტები: ' + fxCount + ' · პრესეტები: ' + state.presets.length);
    if (state.presetFile) { lines.push('პრესეტების ფაილი: ' + esc(state.presetFile.path)); }
    else { lines.push('პრესეტების ფაილი ვერ მოიძებნა'); }
    if (state.presetError) { lines.push('<span style="color:var(--err)">' + esc(state.presetError) + '</span>'); }
    lines.push(autoInfoHtml());
    if (state.info) { lines.push('Premiere ' + esc(state.info.appVersion) + ' · Quick FX ' + VERSION); }
    lines.push('<span class="menu-brand">MELIA VISION PLUGIN</span>');
    $menuInfo.innerHTML = lines.join('<br>');
  }

  function openMenu(open, keepFocus) {
    $menu.hidden = !open;
    $menuBtn.classList.toggle('open', open);
    if (open) { updateMenuInfo(); B.call('debugDump').then(function (r) { state.debug = r && r.ok ? r.data : null; }, function () { state.debug = null; }); }
    else if (!keepFocus && state.view === 'list') { $q.focus(); }
  }

  // ------------------------------------------------------------------ graphics: timers, lower thirds, social call-outs
  // The panel draws these itself (js/gfx.js) and renders the chosen one into a small transparent movie with ffmpeg;
  // Premiere only receives the finished file. Text, font and colours are changed here, then it is rendered again.
  var GX = window.QFXGfx;
  var $gDurN = $('gDurN'), $gIn = $('gIn'), $gOut = $('gOut'), $gIoHint = $('gIoHint');
  var $gFace = $('gFace'), $gTT = $('gTT'), $gTs = $('gTs'), $gTsV = $('gTsV'), $gTrack = $('gTrack'), $gTrackV = $('gTrackV'), $gFontNote = $('gFontNote');
  var $gCats = $('gCats'), $gList = $('gList'), $gCanvas = $('gCanvas'), $gFields = $('gFields'), $gFont = $('gFont'), $gPos = $('gPos'), $gHint = $('gHint'),
    $gAccent = $('gAccent'), $gColor = $('gColor'), $gBg = $('gBg'), $gSize = $('gSize'), $gSizeV = $('gSizeV'), $gDur = $('gDur'), $gDurV = $('gDurV'), $gDurRow = $('gDurRow'),
    $gGo = $('gGo'), $gLogo = $('gLogo'), $gKeys = $('gKeys'), $gStatus = $('gStatus'), $gBusy = $('gBusy'), $gQ = $('gQ');
  var GFX_LS = 'qfx.gfx.v1';
  var GFX_FONTS = [
    ['Helvetica Neue', '"Helvetica Neue", Helvetica, Arial, sans-serif'], ['სისტემური (SF)', '-apple-system, "SF Pro Display", "Helvetica Neue", sans-serif'],
    ['Avenir Next', '"Avenir Next", Avenir, "Helvetica Neue", sans-serif'], ['Futura', 'Futura, "Trebuchet MS", sans-serif'],
    ['DIN Condensed', '"DIN Condensed", "DIN Alternate", Impact, sans-serif'], ['Impact', 'Impact, "Arial Black", sans-serif'],
    ['Arial Rounded', '"Arial Rounded MT Bold", "Helvetica Neue", sans-serif'], ['Georgia', 'Georgia, "Times New Roman", serif'], ['Menlo (მონო)', 'Menlo, "SF Mono", "Courier New", monospace']
  ];
  var gfx = { cat: 0, row: 0, rows: [], q: '', id: {}, texts: {}, timer: { total: 30, down: true, fmt: 'auto' }, dur: {}, players: null, pn: 4, pick: 0, noIn: false, noOut: false, fam: '', face: '', fs: { b: false, i: false, caps: false, sc: false, u: false }, ts: 100, track: 0, fams: null, alias: {}, probe: {}, accent: '#FD4A00', color: '#FFFFFF', bg: '#111111',
    size: 100, pos: { timer: 2, lt: 6, net: 6, cta: 7 }, logoPath: '', logo: null, files: null, loaded: {}, seq: { w: 1920, h: 1080, fps: 30, has: false }, busy: false, raf: 0, t0: 0, drag: null, opened: false };
  var TG = {
    keys: '←→↑↓ არჩევა · Tab კატეგორია · ↵ ჩასმა · ან გადაათრიე timeline-ზე', noSeq: 'სექვენსი გახსნილი არ არის', rendering: function (p) { return 'ვამზადებ… ' + Math.round(p * 100) + '%'; },
    placed: function (track) { return 'ჩაისვა V' + track + '-ზე'; }, placedN: function (n) { return n + ' ადგილას ჩაისვა'; }, noEngine: 'გრაფიკის მოსამზადებლად ძრავა (ffmpeg) სჭირდება — გახსენი „ჩაწერა“ და ერთხელ დააყენე',
    renderFailed: 'გრაფიკა ვერ მომზადდა', placeFailed: 'Premiere-ში ვერ ჩაისვა', busy: 'ჯერ წინა მზადდება', logoOn: 'ლოგო…', logoOff: 'ლოგოს მოხსნა', logoTitle: 'აირჩიე ლოგო ან ავატარი',
    labels: { t1: 'ტექსტი', t2: 'მეორე ხაზი', t3: 'ღილაკი', t4: 'დაჭერის შემდეგ' }, ltLabels: { t1: 'სახელი', t2: 'ქვედა ხაზი' }, comboLabels: { t1: '1-ლი', t2: 'მე-2', t3: 'მე-3' },
    time: 'დრო', dir: 'მიმართულება', down: 'უკუთვლა', up: 'წინ თვლა', fmt: 'ფორმატი', fmts: { auto: 'ავტომატური', s: 'წამები (45)', 'm:ss': '0:45', 'mm:ss': '00:45', 'h:mm:ss': '0:00:45', 'ss.cc': 'მეასედებით (45.00)' },
    hint: function (w, h, sec) { return w + '×' + h + ' · ' + GX.mmss(sec); }, longTimer: 'გრძელი წამზომის მომზადებას შეიძლება რამდენიმე წუთი დასჭირდეს',
    fontFiles: '— შენი ფონტები —', moved: 'თუ გრაფიკა ზედმეტად დიდი გამოჩნდა: კლიპზე მარჯვენა ღილაკი → Scale to Frame Size მოხსენი'
  };
  (function () {
    var v = load(GFX_LS, null);
    if (!v) { return; }
    var keys = ['players', 'pn', 'pick', 'noIn', 'noOut', 'favs', 'cat', 'id', 'texts', 'timer', 'dur', 'fam', 'face', 'fs', 'ts', 'track', 'accent', 'color', 'bg', 'size', 'pos', 'logoPath'];
    for (var i = 0; i < keys.length; i++) { if (v[keys[i]] !== undefined && v[keys[i]] !== null) { gfx[keys[i]] = v[keys[i]]; } }
  })();
  function gfxSave() {
    save(GFX_LS, { players: gfx.players, pn: gfx.pn, pick: gfx.pick, noIn: gfx.noIn, noOut: gfx.noOut, favs: gfx.favs || [], cat: gfx.cat, id: gfx.id, texts: gfx.texts, timer: gfx.timer, dur: gfx.dur, fam: gfx.fam, face: gfx.face, fs: gfx.fs, ts: gfx.ts, track: gfx.track, accent: gfx.accent, color: gfx.color, bg: gfx.bg, size: gfx.size, pos: gfx.pos, logoPath: gfx.logoPath });
  }
  function gfxDiag() { return { design: gfxCur() ? gfxCur().id : '', seq: gfx.seq, size: gfx.size, font: { family: gfx.fam, face: gfx.face, css: gfxFontCss(), families: gfx.fams ? gfx.fams.length : -1, probe: gfx.probe[gfxFontCss()] || null, error: gfx.fontError || '' }, ffmpeg: gfxFfmpeg(), last: gfx.last || null }; }
  function gfxCatId() { return GX.CATS[Math.min(gfx.cat, GX.CATS.length - 1)].id; }
  function gfxCur() { return gfx.rows[gfx.row] || null; }
  var GFX_FALLBACK = '"Helvetica Neue", Helvetica, Arial, sans-serif';
  /** Families installed on this computer (read from the font files), or the short built-in list when they cannot be read. */
  function gfxFamilies() {
    if (gfx.fams) { return gfx.fams; }
    gfx.fams = [];
    try {
      if (window.__QFX_GFX_FONTS) { gfx.fams = window.__QFX_GFX_FONTS; }
      else { var req = nodeReq(); gfx.fams = window.QFXFonts.scan(req('fs'), window.QFXFonts.macDirs(req('os').homedir())); }
    } catch (e) { gfx.fontError = String(e && e.message || e); gfx.fams = []; }
    if (!gfx.fams.length) { for (var i = 0; i < GFX_FONTS.length; i++) { gfx.fams.push({ family: GFX_FONTS[i][0], css: GFX_FONTS[i][1], faces: [] }); } }
    return gfx.fams;
  }
  function gfxFamily() { var f = gfxFamilies(); for (var i = 0; i < f.length; i++) { if (f[i].family === gfx.fam) { return f[i]; } } return null; }
  function gfxFace() { var f = gfxFamily(); if (!f || !gfx.face) { return null; } for (var i = 0; i < f.faces.length; i++) { if ((f.faces[i].ps || f.faces[i].full) === gfx.face) { return f.faces[i]; } } return null; }
  /** The css family the designs are drawn with: one exact style when chosen, otherwise the family (weights by design). */
  function gfxFontCss() {
    var fam = gfxFamily(), face = gfxFace();
    if (face && gfx.alias[gfx.face]) { return '"' + gfx.alias[gfx.face] + '", ' + GFX_FALLBACK; }
    if (fam) { return fam.css || ('"' + fam.family.replace(/"/g, '') + '", ' + GFX_FALLBACK); }
    return GFX_FALLBACK;
  }
  /** One exact style, by the names the system knows it by; every weight a design asks for maps to it (no fake bold). */
  function gfxLoadFace(then) {
    var face = gfxFace();
    if (!face || gfx.alias[gfx.face]) { if (then) { then(); } return; }
    var key = gfx.face, name = 'QFXA' + (Object.keys(gfx.alias).length + 1), src = [];
    if (face.full) { src.push('local("' + face.full.replace(/["\\]/g, '') + '")'); }
    if (face.ps) { src.push('local("' + face.ps.replace(/["\\]/g, '') + '")'); }
    try {
      new FontFace(name, src.join(', '), { weight: '1 1000' }).load().then(function (f) { document.fonts.add(f); gfx.alias[key] = name; if (then) { then(); } },
        function (e) { gfx.fontError = face.full + ': ' + String(e && e.message || e); if (then) { then(); } });
    } catch (e2) { gfx.fontError = String(e2); if (then) { then(); } }
  }
  /** Does the canvas really draw with this font — and does the font have Georgian letters and their capitals? */
  function gfxProbe(css) {
    if (gfx.probe[css]) { return gfx.probe[css]; }
    var first = css.split(',')[0], c = (gfx.pc || (gfx.pc = document.createElement('canvas'))).getContext('2d');
    function w(font, str) { c.font = '40px ' + font; return c.measureText(str).width; }
    function has(str) { return Math.abs(w(first + ', monospace', str) - w(first + ', serif', str)) < 0.01 && Math.abs(w('monospace', str) - w('serif', str)) > 0.01; }
    var r = { ok: has('Quick 0189 WMil'), geo: has('აბგდევზთიკ'), caps: has('ᲐᲑᲒᲓᲔᲕ') };
    if (document.fonts && document.fonts.status === 'loaded') { gfx.probe[css] = r; }
    return r;
  }
  function gfxFontNote() {
    var fam = gfxFamily(), css = gfxFontCss(), msg = '';
    if (fam) {
      var r = gfxProbe(css);
      if (gfx.face && !gfx.alias[gfx.face]) { msg = 'ეს სტილი ვერ ჩაიტვირთა — ნაჩვენებია ოჯახის ჩვეულებრივი სტილი'; }
      else if (!r.ok) { msg = 'ფონტი ვერ ჩაიტვირთა — ნაჩვენებია სათადარიგო'; }
      else if (!r.geo) { msg = 'ამ ფონტს ქართული ასოები არ აქვს: ლათინური და ციფრები ამ ფონტით იწერება, ქართული — სისტემურით'; }
    }
    $gFontNote.hidden = !msg; $gFontNote.textContent = msg;
  }
  function gfxLoadLogo(path) {
    gfx.logo = null;
    if (!path) { gfx.logoPath = ''; $gLogo.textContent = TG.logoOn; return; }
    var img = new Image();
    img.onload = function () { gfx.logo = img; gfx.logoPath = path; $gLogo.textContent = TG.logoOff; gfxSave(); gfxThumbs(); };
    img.onerror = function () { gfx.logoPath = ''; gfx.logo = null; $gLogo.textContent = TG.logoOn; gfxSave(); };
    img.src = gfxImageSrc(path);
  }
  /** Where a typed text is kept: a name typed once shows on every name design, a @handle on every platform; the rest belongs to its design. */
  function gfxTextKey(d, field) {
    if (d.cat === 'lt' && d.defs.t1 === 'გოგა მელია') { return 'lt'; }
    if (d.cat === 'net' && field === 't1') { return 'net'; }
    if (d.cat === 'cta' && /^fol-/.test(d.id) && field === 't1') { return 'net'; }
    return d.id;
  }
  var GFX_PAL = ['#FD4A00', '#1877F2', '#2ECC71', '#FFC400', '#9146FF', '#FF2D55'];
  /** The competitors: n name, s points, a points they get now ('' = none), c their own colour ('' = the main colour). */
  function gfxPlayers() {
    var i, fresh = !gfx.players || !gfx.players.length;
    if (fresh) { gfx.players = JSON.parse(JSON.stringify(GX.PLAYERS)); }
    while (gfx.players.length < 6) { gfx.players.push(JSON.parse(JSON.stringify(GX.PLAYERS[gfx.players.length]))); }
    if (gfx.players[0].a === undefined) { gfx.players[0].a = '1'; }                // saved by a version that had no "points to add"
    for (i = 0; i < gfx.players.length; i++) { var p = gfx.players[i]; if (p.a === undefined || p.a === null) { p.a = ''; } if (!/^#[0-9a-f]{6}$/i.test(p.c || '')) { p.c = ''; } }
    return gfx.players;
  }
  /**
   * A picture file as something the render may read back. A file:// picture drawn on a canvas "taints" it and the frames
   * can no longer be read for the movie, so the file is read with Node and handed over as a data: URL. HEIC (iPhone) goes through macOS sips.
   */
  function gfxImageSrc(path) {
    if (/^(data:|https?:)/.test(path)) { return path; }
    try {
      var req = nodeReq(), fs = req('fs'), p = String(path).replace(/^file:\/\//, ''), ext = (/\.([a-z0-9]+)$/i.exec(p) || [0, ''])[1].toLowerCase();
      if (ext === 'heic' || ext === 'heif') {
        var out = req('path').join(req('os').tmpdir(), 'qfx-photo-' + gfxHash(p) + '.jpg');
        req('child_process').execFileSync('/usr/bin/sips', ['-s', 'format', 'jpeg', p, '--out', out]); p = out; ext = 'jpg';
      }
      var mime = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml' }[ext] || 'image/png';
      return 'data:' + mime + ';base64,' + fs.readFileSync(p).toString('base64');
    } catch (e) { return 'file://' + encodeURI(path); }
  }
  /** Their photos: the path is kept with the player (p.ph); the loaded pictures (made small — they are drawn on every frame) are here. */
  var gfxPhotos = {};
  function gfxPhotoLoad(path, done) {
    if (!path || gfxPhotos[path]) { if (done) { done(!!path && gfxPhotos[path] !== 'bad'); } return; }
    var img = new Image();
    img.onload = function () {
      var k = Math.min(1, 640 / Math.max(img.naturalWidth, img.naturalHeight, 1)), c = document.createElement('canvas'), keep = img;
      try { c.width = Math.max(1, Math.round(img.naturalWidth * k)); c.height = Math.max(1, Math.round(img.naturalHeight * k)); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); c.qfxUrl = c.toDataURL('image/jpeg', 0.8); keep = c; } catch (e) {}
      gfxPhotos[path] = keep;
      if (done) { done(true); } else { gfxThumbs(); gfxPlay(); if (gfxCur() && gfxCur().defs.players) { renderGfxSide(); } }
    };
    img.onerror = function () { gfxPhotos[path] = 'bad'; if (done) { done(false); } };
    img.src = gfxImageSrc(path);
  }
  function gfxPhotoUrl(path) { var im = gfxPhotos[path]; return im && im.qfxUrl ? im.qfxUrl : (/^(data:|file:|https?:)/.test(path) ? path : 'file://' + encodeURI(path)); }
  /** The players as the designs take them: with the loaded photo next to its path. */
  function gfxPlayerList() {
    var pl = gfxPlayers(), out = [], i;
    for (i = 0; i < pl.length; i++) { var im = pl[i].ph ? gfxPhotos[pl[i].ph] : null; if (pl[i].ph && !im) { gfxPhotoLoad(pl[i].ph); } out.push({ n: pl[i].n, s: pl[i].s, a: pl[i].a, c: pl[i].c, ph: im && im !== 'bad' ? pl[i].ph : '', img: im && im !== 'bad' ? im : null }); }
    return out;
  }
  function gfxColoured() { var pl = gfxPlayers(); for (var i = 0; i < pl.length; i++) { if (pl[i].c) { return true; } } return false; }
  /** What the current design is drawn with. */
  function gfxParams(d) {
    var css = gfxFontCss(), U = { font: css, fs: gfx.fs, ts: gfx.ts / 100, track: gfx.track, geoCaps: gfx.fs.caps ? gfxProbe(css).caps : false, players: gfxPlayerList(), pn: gfx.pn, pick: gfx.pick, noIn: gfx.noIn, noOut: gfx.noOut, accent: gfx.accent, color: gfx.color, bg: gfx.bg, fps: gfx.seq.fps, logo: gfx.logo, timer: gfx.timer, dur: gfx.dur[d.id] }, ks = ['t1', 't2', 't3', 't4'];
    for (var i = 0; i < ks.length; i++) { var tx = gfx.texts[gfxTextKey(d, ks[i])]; if (tx && tx[ks[i]] !== undefined) { U[ks[i]] = tx[ks[i]]; } }
    if (d.defs.timer && d.defs.total && !gfx.timerSet) { U.timer = { total: d.defs.total, down: gfx.timer.down, fmt: d.defs.fmt || gfx.timer.fmt }; }
    else if (d.defs.timer && d.defs.fmt && gfx.timer.fmt === 'auto') { U.timer = { total: gfx.timer.total, down: gfx.timer.down, fmt: d.defs.fmt }; }
    return GX.params(d, U);
  }
  function gfxRows() {
    gfx.rows = GX.tagged(gfx.q ? GX.search(gfx.q) : GX.inCategory(gfxCatId()), gfx.tag || '');
    var want = gfx.id[gfxCatId()]; gfx.row = 0;
    for (var i = 0; i < gfx.rows.length; i++) { if (gfx.rows[i].id === want) { gfx.row = i; } }
    return gfx.rows;
  }
  function gfxThumbs() {
    var list = $gList.querySelectorAll('canvas[data-gthumb]'), at = 0, run = (gfx.thumbRun = (gfx.thumbRun || 0) + 1);
    function batch() {
      if (run !== gfx.thumbRun) { return; }
      var until = Date.now() + 14;
      while (at < list.length && Date.now() < until) {
        var c = list[at++], d = GX.design(c.getAttribute('data-gthumb'));
        if (!d) { continue; }
        var P = gfxParams(d), k = Math.min(300 / d.w, 88 / d.h);
        c.width = Math.ceil(d.w * k); c.height = Math.ceil(d.h * k);
        try { GX.paint(c.getContext('2d'), d, d.defs.timer ? Math.min(P.dur * 0.4, 7.4) : Math.min(P.dur * 0.62, 2.7), P, k); } catch (e) {}
      }
      if (at < list.length) { (window.requestAnimationFrame || setTimeout)(batch); }
    }
    batch();
  }
  function renderGfx() {
    if (!GX) { return; }
    var h = [], i;
    for (i = 0; i < GX.CATS.length; i++) {
      h.push('<button class="x-cat' + (i === gfx.cat && !gfx.q ? ' on' : '') + '" data-gcat="' + i + '" title="' + esc(GX.CATS[i].hint) + '"><span>' + esc(GX.CATS[i].name) + '</span><i>' + GX.inCategory(GX.CATS[i].id).length + '</i></button>');
    }
    $gCats.innerHTML = h.join('');
    var rows = gfxRows(); h = [];
    if (!gfx.q) { h.push('<div class="t-cathint">' + esc(GX.CATS[gfx.cat].hint) + '</div>'); }
    var pool = gfx.q ? GX.search(gfx.q) : GX.inCategory(gfxCatId()), chips = '<button class="g-tag' + (gfx.tag ? '' : ' on') + '" data-gtag="">ყველა <i>' + pool.length + '</i></button>';
    for (i = 0; i < GX.TAGS.length; i++) { var cnt = GX.tagged(pool, GX.TAGS[i].id).length; if (cnt) { chips += '<button class="g-tag' + (gfx.tag === GX.TAGS[i].id ? ' on' : '') + '" data-gtag="' + GX.TAGS[i].id + '">' + esc(GX.TAGS[i].name) + ' <i>' + cnt + '</i></button>'; } }
    h.push('<div class="g-tags">' + chips + '</div>');
    for (i = 0; i < rows.length; i++) {
      h.push('<div class="g-card' + (i === gfx.row ? ' active' : '') + '" data-grow="' + i + '" draggable="true" title="' + esc(rows[i].name) + '"><span class="g-thumb"><canvas data-gthumb="' + esc(rows[i].id) + '"></canvas></span><span class="g-name">' + esc(rows[i].name) + '</span></div>');
    }
    $gList.innerHTML = h.join('');
    $gKeys.textContent = TG.keys;
    $gStatus.textContent = gfx.seq.has ? gfx.seq.w + '×' + gfx.seq.h : TG.noSeq;
    gfxThumbs(); renderGfxSide();
  }
  function gfxField(key, label, val) { return '<label class="g-f"><span>' + esc(label) + '</span><input type="text" data-gtext="' + key + '" value="' + esc(val) + '" spellcheck="false"></label>'; }
  function renderGfxSide() {
    var d = gfxCur(), h = [], k, i;
    if (!d) { $gFields.innerHTML = ''; return; }
    var P = gfxParams(d), labels = d.defs.labels || (d.cat === 'lt' ? TG.ltLabels : (/^combo/.test(d.id) ? TG.comboLabels : TG.labels));
    if (d.defs.timer) {
      var tm = P.timer, opt = '';
      for (k in TG.fmts) { if (TG.fmts.hasOwnProperty(k)) { opt += '<option value="' + k + '"' + (k === (gfx.timer.fmt || 'auto') ? ' selected' : '') + '>' + esc(TG.fmts[k]) + '</option>'; } }
      h.push('<label class="g-f"><span>' + esc(TG.time) + '</span><span class="g-two"><input type="text" data-gtime="1" value="' + esc(GX.mmss(tm.total)) + '" title="მაგ. 0:30, 1:30, 90">' +
        '<select data-gdir="1"><option value="down"' + (tm.down ? ' selected' : '') + '>' + esc(TG.down) + '</option><option value="up"' + (tm.down ? '' : ' selected') + '>' + esc(TG.up) + '</option></select></span></label>');
      h.push('<label class="g-f"><span>' + esc(TG.fmt) + '</span><select data-gfmt="1">' + opt + '</select></label>');
    }
    if (d.defs.players) {
      var pl = gfxPlayers(), pn = P.players.length, row = '<div class="g-f"><span>მონაწილე</span><span class="g-pn">';
      for (i = 2; i <= 6; i++) { row += '<button data-gpn="' + i + '" class="' + (i === pn ? 'on' : '') + '" tabindex="-1">' + i + '</button>'; }
      h.push(row + '<button data-gpal="1" class="g-palb" tabindex="-1" title="' + (gfxColoured() ? 'ყველას ისევ მთავარი ფერი' : 'ყველას თავისი ფერი — მერე თითოს ფერს კვადრატზე დაჭერით ცვლი') + '">' + (gfxColoured() ? 'ერთი ფერი' : 'ფერადი') + '</button></span></div>');
      for (i = 0; i < pn; i++) {
        h.push('<div class="g-pl"><input type="color" data-gplc="' + i + '" value="' + esc(String(pl[i].c || gfx.accent).toLowerCase()) + '" title="' + esc(pl[i].n) + ' — ფერი"><button class="g-ph' + (P.players[i].img ? ' has' : '') + '" data-gph="' + i + '" tabindex="-1"' + (P.players[i].img ? ' style="background-image:url(&quot;' + esc(gfxPhotoUrl(pl[i].ph)) + '&quot;)"' : '') + ' title="' + (P.players[i].img ? 'ფოტოს მოშორება' : esc(pl[i].n) + ' — ფოტოს არჩევა (სახელის პირველი ასოს ნაცვლად)') + '"></button><input type="text" data-gpl="' + i + ':n" value="' + esc(pl[i].n) + '" placeholder="სახელი" spellcheck="false"><input type="text" class="g-ps" data-gpl="' + i + ':s" value="' + esc(pl[i].s) + '" placeholder="ქულა" title="ქულა (დამატებამდე)" spellcheck="false">' +
          (d.defs.adds ? '<input type="text" class="g-pa' + (P.players[i].a ? ' on' : '') + '" data-gpl="' + i + ':a" value="' + esc(pl[i].a) + '" placeholder="+" title="რამდენი ქულა ემატება ამ მონაწილეს: 1, 3, -1… ცარიელი — არაფერი" spellcheck="false">' : '') +
          (d.defs.pick ? '<button data-gpick="' + i + '" class="' + (i === P.pick ? 'on' : '') + '" tabindex="-1" title="ეს დიზაინი ამ მონაწილეზეა">●</button>' : '') + '</div>');
      }
      if (d.defs.adds) { h.push('<div class="g-plnote"><span>„+“ ველი: რამდენი ემატება (1, 3, -1). ცარიელი — არ ემატება.</span><button data-gapply="1" tabindex="-1"' + (P.adds ? '' : ' disabled') + ' title="დამატებული ქულები ჩაიწერება ქულებში და „+“ ველები გასუფთავდება — შემდეგი რაუნდისთვის">ქულებში გადატანა</button></div>'); }
    }
    var keys = ['t1', 't2', 't3', 't4'];
    for (i = 0; i < keys.length; i++) {
      if (d.defs[keys[i]] !== undefined || (d.cat === 'lt' && i < 2)) { h.push(gfxField(keys[i], labels[keys[i]] || TG.labels[keys[i]], P[keys[i]])); }
    }
    $gFields.innerHTML = h.join('');
    var fam = gfxFamily(), fo;
    $gFont.innerHTML = '<option value="">' + esc(fam ? fam.family : 'Helvetica Neue (საწყისი)') + '</option>';
    fo = '<option value="">ავტომატური (დიზაინის მიხედვით)</option>';
    for (i = 0; fam && i < fam.faces.length; i++) { var fk = fam.faces[i].ps || fam.faces[i].full; fo += '<option value="' + esc(fk) + '"' + (fk === gfx.face ? ' selected' : '') + '>' + esc(fam.faces[i].style) + '</option>'; }
    $gFace.innerHTML = fo; $gFace.disabled = !fam || !fam.faces.length;
    var tb = $gTT.querySelectorAll('button');
    for (i = 0; i < tb.length; i++) { tb[i].classList.toggle('on', !!gfx.fs[tb[i].getAttribute('data-gfs')]); }
    $gTs.value = gfx.ts; $gTsV.textContent = gfx.ts + '%'; $gTrack.value = gfx.track; $gTrackV.textContent = String(gfx.track);
    gfxFontNote();
    $gAccent.value = gfx.accent; $gColor.value = gfx.color; $gBg.value = gfx.bg;
    $gSize.value = gfx.size; $gSizeV.textContent = gfx.size + '%';
    $gDurRow.hidden = !!d.defs.timer; $gDur.value = Math.min(60, P.dur); if (document.activeElement !== $gDurN) { $gDurN.value = String(Math.round(P.dur * 10) / 10); }
    $gIn.checked = !gfx.noIn; $gOut.checked = !gfx.noOut;
    $gIoHint.textContent = d.defs.timer ? '' : (gfx.noOut ? 'ბოლოს უცებ ქრება' : 'გასვლა იწყება ' + (Math.round((P.dur - 0.5) * 10) / 10) + ' წამზე');
    $gLogo.textContent = gfx.logo ? TG.logoOff : TG.logoOn;
    var on = $gPos.querySelectorAll('button'), pi = gfxPosIdx(d);
    for (i = 0; i < on.length; i++) { on[i].classList.toggle('on', i === pi); }
    var o = GX.output(d, gfx.seq.w, gfx.seq.h, gfx.size / 100);
    $gHint.textContent = TG.hint(o.w, o.h, P.dur) + (d.defs.timer && P.dur > 300 ? ' · ' + TG.longTimer : '');
    gfxPlay();
  }
  function gfxStop() { if (gfx.raf) { cancelAnimationFrame(gfx.raf); gfx.raf = 0; } }
  function gfxPlay() {
    gfxStop();
    var d = gfxCur();
    if (!d || state.view !== 'gfx') { return; }
    var P = gfxParams(d), box = $gCanvas.parentNode.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    var k = Math.min((box.width - 16) / d.w, (box.height - 12) / d.h);
    if (!(k > 0)) { k = 0.3; }
    $gCanvas.width = Math.ceil(d.w * k * dpr); $gCanvas.height = Math.ceil(d.h * k * dpr);
    $gCanvas.style.width = Math.ceil(d.w * k) + 'px'; $gCanvas.style.height = Math.ceil(d.h * k) + 'px';
    var ctx = $gCanvas.getContext('2d'), now = window.__QFX_NOW || function () { return performance.now(); };
    gfx.t0 = now();
    var loop = P.dur + 0.7;
    (function frame() {
      var t = ((now() - gfx.t0) / 1000) % loop;
      try { GX.paint(ctx, d, Math.min(t, P.dur), P, k * dpr); } catch (e) {}
      if (t > P.dur) { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, $gCanvas.width, $gCanvas.height); }
      gfx.raf = requestAnimationFrame(frame);
    })();
  }
  function gfxRefreshSeq() {
    return B.call('animTargets').then(function (r) {
      var d = r && r.ok ? r.data : null, was = gfx.seq.w + 'x' + gfx.seq.h + (gfx.seq.has ? 'y' : 'n');
      if (d && d.hasSequence) { gfx.seq = { w: d.width, h: d.height, fps: d.fps || 30, has: true }; } else { gfx.seq.has = false; }
      if (was !== gfx.seq.w + 'x' + gfx.seq.h + (gfx.seq.has ? 'y' : 'n') && state.view === 'gfx') { $gStatus.textContent = gfx.seq.has ? gfx.seq.w + '×' + gfx.seq.h : TG.noSeq; renderGfxSide(); }
    }, function () {});
  }
  function openGfx() {
    if (!gfx.opened) {
      gfx.opened = true;
      if (gfx.logoPath) { gfxLoadLogo(gfx.logoPath); }
      gfxPlayerList();                                            // their photos start loading now, not at the first render
      if (gfx.face) { gfxLoadFace(function () { if (state.view === 'gfx') { renderGfx(); } }); }
    }
    renderGfx(); gfxRefreshSeq().then(function () { return zones.state ? null : refreshZones(); }).then(gfxFixShow, gfxFixShow);   // the project's folder must be known: that is where the movies go
  }
  function gfxPickRow(i) {
    if (i < 0 || i >= gfx.rows.length) { return; }
    gfx.row = i; gfx.id[gfx.rows[i].cat] = gfx.rows[i].id; if (!gfx.q) { gfx.id[gfxCatId()] = gfx.rows[i].id; }
    var list = $gList.querySelectorAll('[data-grow]');
    for (var k = 0; k < list.length; k++) { list[k].classList.toggle('active', k === i); }
    if (list[i] && list[i].scrollIntoView) { list[i].scrollIntoView({ block: 'nearest' }); }
    gfxSave(); renderGfxSide();
  }
  function gfxFfmpeg() { try { var eng = ytEngine(); return eng ? eng.binDir + '/ffmpeg' : ''; } catch (e) { return ''; } }
  function gfxHash(s) { var h = 5381; for (var i = 0; i < s.length; i++) { h = ((h << 5) + h + s.charCodeAt(i)) >>> 0; } return h.toString(36); }
  function gfxOutDir() {
    var pd = zones && zones.state && zones.state.projectDir ? zones.state.projectDir : '';
    return pd ? pd + '/Quick FX/Graphics' : (Store.dir() ? Store.dir() + '/graphics' : '');
  }
  function gfxProgress(p) {
    if (p === null) { $gBusy.hidden = true; return; }
    $gBusy.hidden = false; $gBusy.innerHTML = esc(TG.rendering(p)) + '<i style="width:' + Math.round(p * 100) + '%"></i>';
  }
  /**
   * The design as a transparent movie. Frames are painted here and piped to ffmpeg as raw pixels (ProRes 4444 keeps
   * the transparency). The same settings give the same file name, so a second insert is instant.
   * → Promise of { path, seconds, w, h }
   */
  /**
   * The movie is written with QuickTime Animation (RGB + alpha, lossless). ProRes 4444 from this ffmpeg (6.1) is read on many
   * Apple-silicon Macs with the alpha fully opaque — a black box behind the graphic — and its colours went through a YUV matrix
   * that Premiere reads differently; Animation has neither problem and, for flat graphics, is smaller too.
   * The second choice (only if the first fails) is ProRes with the Rec.709 matrix and tags.
   */
  var GFX_CODEC = ['-c:v', 'qtrle', '-pix_fmt', 'argb'];
  var GFX_CODEC_2 = ['-vf', 'scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuva444p10le,setparams=color_primaries=bt709:color_trc=bt709:colorspace=bt709', '-c:v', 'prores_ks', '-profile:v', '4444', '-pix_fmt', 'yuva444p10le', '-vendor', 'apl0', '-qscale:v', '11', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709'];
  /** Where rendered graphics are kept: the project's folder and, when the project folder was not known, the plugin's own. */
  function gfxDirs() { var a = [], d = gfxOutDir(), s = ''; try { s = Store.dir() ? Store.dir() + '/graphics' : ''; } catch (e) { s = ''; } if (d) { a.push(d); } if (s && s !== d) { a.push(s); } return a; }
  /** Graphics made by 1.20–1.26 (ProRes): [{ path, name }]. */
  function gfxOldFiles() {
    var out = [], dirs = gfxDirs(), k;
    for (k = 0; k < dirs.length; k++) { gfxOldIn(dirs[k], out); }
    return out;
  }
  function gfxOldIn(dir, out) {
    try {
      var req = nodeReq(), fs = req('fs'), names = dir && fs.existsSync(dir) ? fs.readdirSync(dir) : [], i;
      for (i = 0; i < names.length; i++) {
        if (!/\.mov$/i.test(names[i]) || /\.(part|fix)\.mov$/i.test(names[i])) { continue; }
        var path = dir + '/' + names[i], fd = fs.openSync(path, 'r'), Buf = (window.cep_node && window.cep_node.Buffer) || req('buffer').Buffer, b = Buf.alloc(512), got = fs.readSync(fd, b, 0, 512, 0);
        fs.closeSync(fd);
        if (b.slice(0, got).indexOf('icpf') >= 0) { out.push({ path: path, name: names[i] }); }   // a ProRes frame starts right after the file header
      }
    } catch (e) {}
  }
  /** Rewrites those files in place as Animation — the clips already on timelines then show right after Premiere is reopened. */
  function gfxFixOld(list, tick) {
    var req = nodeReq(), fs = req('fs'), cp = req('child_process'), ff = gfxFfmpeg(), done = 0, failed = 0;
    return new Promise(function (resolve) {
      function next(i) {
        if (i >= list.length) { resolve({ done: done, failed: failed }); return; }
        if (tick) { tick(i, list.length); }
        var src = list[i].path, tmp = src.replace(/\.mov$/i, '.fix.mov'), proc, err = '';
        try { proc = cp.spawn(ff, ['-y', '-loglevel', 'error', '-i', src, '-an', '-fps_mode', 'passthrough'].concat(GFX_CODEC, [tmp])); } catch (e) { failed++; next(i + 1); return; }
        proc.stderr.on('data', function (b) { if (err.length < 400) { err += String(b); } });
        proc.on('error', function () { failed++; next(i + 1); });
        proc.on('close', function (code) {
          try { if (code === 0 && fs.statSync(tmp).size > 2000) { fs.renameSync(tmp, src); done++; } else { failed++; try { fs.unlinkSync(tmp); } catch (e1) {} } } catch (e2) { failed++; }
          next(i + 1);
        });
      }
      if (!ff || !fs.existsSync(ff)) { resolve({ done: 0, failed: list.length, noEngine: true }); return; }
      next(0);
    });
  }
  var $gFix = $('gFix');
  function gfxFixShow() {
    if (!$gFix) { return; }
    var list = window.__QFX_GFX_OLD ? window.__QFX_GFX_OLD() : gfxOldFiles();
    gfx.old = list; $gFix.hidden = !list.length || !!gfx.fixing;
    $gFix.textContent = 'ძველი გრაფიკის გასწორება · ' + list.length;
  }
  function gfxRender(d, P, sizePct) {
    var o = GX.output(d, gfx.seq.w, gfx.seq.h, sizePct / 100), fps = gfx.seq.fps || 30, frames = Math.max(1, Math.round(P.dur * fps));
    var key = gfxHash(JSON.stringify([P.players || 0, P.pick || 0, d.id, P.t1, P.t2, P.t3, P.t4, P.font, gfx.fam, gfx.face, P.fs, P.ts, P.track, P.geoCaps, P.accent, P.color, P.bg, P.noIn, P.noOut, P.timer, P.dur, o.w, o.h, fps, gfx.logoPath, VERSION]));
    var res = { seconds: frames / fps, w: o.w, h: o.h, path: '' };
    if (window.__QFX_GFX_RENDER) { return window.__QFX_GFX_RENDER(d, P, o, key).then(function (p) { res.path = p; return res; }); }
    return new Promise(function (resolve, reject) {
      var req = nodeReq(), ff = gfxFfmpeg(), dir = gfxOutDir();
      if (!req || !ff || !dir) { reject({ code: 'gfxNoEngine' }); return; }
      var fs = req('fs'), cp = req('child_process');
      if (!fs.existsSync(ff)) { reject({ code: 'gfxNoEngine' }); return; }
      try { fs.mkdirSync(dir, { recursive: true }); } catch (e0) {}
      var out = dir + '/' + d.id + ' ' + o.w + 'x' + o.h + ' ' + key + '.mov', tmp = out.replace(/\.mov$/, '.part.mov');
      res.path = out;
      try { if (fs.existsSync(out) && fs.statSync(out).size > 2000) { resolve(res); return; } } catch (e1) {}
      var canvas = document.createElement('canvas'); canvas.width = o.w; canvas.height = o.h;
      var ctx = canvas.getContext('2d'), Buf = (window.cep_node && window.cep_node.Buffer) || req('buffer').Buffer, err = '', done = false;
      function run(codec) {
        var args = ['-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', o.w + 'x' + o.h, '-r', GX.fpsArg(fps), '-i', '-', '-an'].concat(codec, [tmp]);
        var proc = cp.spawn(ff, args), i = 0;
        err = '';
        proc.stderr.on('data', function (b) { if (err.length < 800) { err += String(b); } });
        proc.stdin.on('error', function () {});
        proc.on('error', function (e) { if (!done) { done = true; reject({ code: 'gfxRenderFailed', message: String(e) }); } });
        proc.on('close', function (code) {
          if (done) { return; }
          if (code === 0 && fs.existsSync(tmp)) { done = true; try { fs.renameSync(tmp, out); } catch (e2) { reject({ code: 'gfxRenderFailed', message: String(e2) }); return; } resolve(res); return; }
          if (codec === GFX_CODEC) { run(GFX_CODEC_2); return; }
          done = true; reject({ code: 'gfxRenderFailed', message: err || ('ffmpeg ' + code) });
        });
        function feed() {
          if (done) { return; }
          var started = Date.now();
          while (i < frames) {
            GX.paint(ctx, d, i / fps, P, o.k);
            var px = ctx.getImageData(0, 0, o.w, o.h).data, buf;
            try { buf = Buf.from(px.buffer, px.byteOffset, px.byteLength); } catch (e3) { buf = Buf.from(px); }
            i++;
            var more = proc.stdin.write(buf);
            if (!more) { proc.stdin.once('drain', feed); if (onTick) { onTick(i / frames); } return; }
            if (Date.now() - started > 60) { if (onTick) { onTick(i / frames); } setTimeout(feed, 0); return; }
          }
          if (onTick) { onTick(1); }
          proc.stdin.end();
        }
        feed();
      }
      var onTick = gfxProgress;
      run(GFX_CODEC);
    });
  }
  function gfxPosIdx(d) { var def = { timer: 2, lt: 6, net: 6, cta: 7, auto: 6, num: 4, stk: 4, co: 4 }; return gfx.pos[d.cat] !== undefined ? gfx.pos[d.cat] : (def[d.cat] === undefined ? 4 : def[d.cat]); }
  function gfxPosition(d) {
    var o = GX.output(d, gfx.seq.w, gfx.seq.h, gfx.size / 100), ew = o.w / gfx.seq.w, eh = o.h / gfx.seq.h, tall = gfx.seq.h > gfx.seq.w;
    var pi = gfxPosIdx(d), gx = pi % 3, gy = Math.floor(pi / 3), mx = 0.04, mt = tall ? 0.1 : 0.06, mb = tall ? 0.16 : 0.08;
    var x = [mx + ew / 2, 0.5, 1 - mx - ew / 2][gx], y = [mt + eh / 2, 0.5, 1 - mb - eh / 2][gy];
    return [Math.round(Math.min(Math.max(x, ew / 2), 1 - ew / 2) * 10000) / 10000, Math.round(y * 10000) / 10000];
  }
  function gfxFail(e) {
    var code = e && e.code, msg = code === 'gfxNoEngine' ? TG.noEngine : (code === 'gfxRenderFailed' ? TG.renderFailed : (code === 'noSequence' ? TG.noSeq : (T.errors[code] || TG.placeFailed)));
    state.lastError = e; gfx.last = { error: code || String(e), message: e && e.message ? String(e.message).substring(0, 300) : '' };
    toast('err', msg, e && e.message && code !== 'gfxNoEngine' ? esc(String(e.message).substring(0, 160)) : '', 7000);
  }
  function gfxDone(r, d) {
    gfx.last = r.data; state.lastResult = r.data;
    var c = r.data.clips;
    toast('ok', c.length > 1 ? TG.placedN(c.length) : TG.placed(c[0].track + 1), d.name, 3200);
  }
  /** At the playhead, on the first free track above the picture. */
  function gfxInsert() {
    var d = gfxCur();
    if (!d) { return; }
    if (gfx.busy) { toast('warn', TG.busy); return; }
    gfx.busy = true; $gGo.disabled = true;
    function end() { gfx.busy = false; $gGo.disabled = false; gfxProgress(null); }
    gfxRefreshSeq().then(function () {
      if (!gfx.seq.has) { throw { code: 'noSequence' }; }
      var P = gfxParams(d);
      return gfxRender(d, P, gfx.size).then(function (f) {
        return B.call('gfxPlace', { path: f.path, seconds: f.seconds, pos: gfxPosition(d) }).then(function (r) {
          if (!r || !r.ok) { throw r || { code: 'hostError' }; }
          gfxDone(r, d);
        });
      });
    }).then(end, function (e) { end(); gfxFail(e); });
  }
  /** After a drag: wait until Premiere has dropped the placeholder, then swap it for the rendered movie. */
  function gfxDropPoll(n, job) {
    if (n > 16) { gfx.busy = false; gfxProgress(null); return; }
    setTimeout(function () {
      B.call('gfxPlace', { marker: job.marker, probe: true }).then(function (r) {
        if (!r || !r.ok) { gfx.busy = false; gfxProgress(null); return; }
        if (!r.data.found) { gfxDropPoll(n + 1, job); return; }
        job.render.then(function (f) {
          return B.call('gfxPlace', { marker: job.marker, path: f.path, seconds: f.seconds, pos: gfxPosition(job.d) }).then(function (r2) {
            if (!r2 || !r2.ok) { throw r2 || { code: 'hostError' }; }
            if (r2.data.found) { gfxDone(r2, job.d); }
          });
        }).then(function () { gfx.busy = false; gfxProgress(null); }, function (e) { gfx.busy = false; gfxProgress(null); gfxFail(e); });
      });
    }, n ? 300 : 200);
  }
  function gfxKey(e) {
    if (e.isComposing || e.metaKey || e.ctrlKey || e.altKey) { return; }
    var el = document.activeElement, typing = el && (el.tagName === 'INPUT' && el.type === 'text' || el.tagName === 'SELECT');
    if (e.key === 'Escape') { e.preventDefault(); if (!$menu.hidden) { openMenu(false, true); } else if (typing) { el.blur(); } else { switchTab('fx'); } return; }
    if (typing && el !== $gQ) { if (e.key === 'Enter' && el.tagName === 'INPUT') { e.preventDefault(); el.blur(); } return; }
    if (e.key === 'Enter') { e.preventDefault(); gfxInsert(); }
    else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      // the list is a grid: up and down move by a whole row
      e.preventDefault();
      var cards = $gList.querySelectorAll('[data-grow]'), cols = 1;
      while (cols < cards.length && Math.abs(cards[cols].getBoundingClientRect().top - cards[0].getBoundingClientRect().top) < 2) { cols++; }
      var to = gfx.row + (e.key === 'ArrowDown' ? cols : -cols);
      if (to >= 0 && to < gfx.rows.length) { gfxPickRow(to); } else if (e.key === 'ArrowDown') { gfxPickRow(gfx.rows.length - 1); }
    }
    else if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && el !== $gQ) { e.preventDefault(); gfxPickRow(Math.max(0, Math.min(gfx.rows.length - 1, gfx.row + (e.key === 'ArrowRight' ? 1 : -1)))); }
    else if (e.key === 'Tab' && el !== $gQ) { e.preventDefault(); gfx.q = ''; $gQ.value = ''; gfx.cat = (gfx.cat + (e.shiftKey ? GX.CATS.length - 1 : 1)) % GX.CATS.length; gfxSave(); renderGfx(); }
  }
  if (GX && $gList) {
    (function () { var h = ''; for (var i = 0; i < 9; i++) { h += '<button data-gpos="' + i + '" tabindex="-1"></button>'; } $gPos.innerHTML = h; })();
    $gCats.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-gcat]') : null;
      if (b) { gfx.q = ''; $gQ.value = ''; gfx.cat = Number(b.getAttribute('data-gcat')); gfxSave(); renderGfx(); }
    });
    $gList.addEventListener('click', function (e) {
      var tg = e.target.closest ? e.target.closest('[data-gtag]') : null;
      if (tg) { gfx.tag = tg.getAttribute('data-gtag'); $gList.scrollTop = 0; renderGfx(); return; }
      var r = e.target.closest ? e.target.closest('[data-grow]') : null;
      if (r) { gfxPickRow(Number(r.getAttribute('data-grow'))); }
    });
    $gList.addEventListener('dblclick', function (e) { var r = e.target.closest ? e.target.closest('[data-grow]') : null; if (r) { gfxPickRow(Number(r.getAttribute('data-grow'))); gfxInsert(); } });
    $gList.addEventListener('dragstart', function (e) {
      var r = e.target.closest ? e.target.closest('[data-grow]') : null, marker = txtMarker();
      if (!r || !marker || gfx.busy || !gfx.seq.has) { e.preventDefault(); if (gfx.busy) { toast('warn', TG.busy); } return; }
      gfxPickRow(Number(r.getAttribute('data-grow')));
      var d = gfxCur();
      try { e.dataTransfer.effectAllowed = 'copy'; e.dataTransfer.setData('com.adobe.cep.dnd.file.0', marker); e.dataTransfer.setData('text/plain', d.name); } catch (e2) {}
      gfx.busy = true;
      var render = gfxRender(d, gfxParams(d), gfx.size);
      render.then(function () {}, function () {});                       // a failure is reported when the drop is handled
      gfx.drag = { d: d, marker: marker, render: render };
    });
    $gList.addEventListener('dragend', function () { var job = gfx.drag; gfx.drag = null; if (job) { gfxDropPoll(0, job); } });
    $gPos.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-gpos]') : null, d = gfxCur();
      if (b && d) { gfx.pos[d.cat] = Number(b.getAttribute('data-gpos')); gfxSave(); renderGfxSide(); }
    });
    $gFields.addEventListener('input', function (e) {
      var d = gfxCur(), el = e.target;
      if (!d) { return; }
      if (el.getAttribute('data-gplc')) { gfxPlayers()[Number(el.getAttribute('data-gplc'))].c = String(el.value).toUpperCase(); gfxSave(); gfxPlay(); return; }
      if (el.getAttribute('data-gpl')) {
        var pp = el.getAttribute('data-gpl').split(':'); gfxPlayers()[Number(pp[0])][pp[1]] = el.value; gfxSave(); gfxPlay();
        if (pp[1] === 'a') { var P2 = gfxParams(d), ap = $gFields.querySelector('[data-gapply]'); el.className = 'g-pa' + (P2.players[Number(pp[0])] && P2.players[Number(pp[0])].a ? ' on' : ''); if (ap) { ap.disabled = !P2.adds; } }
        return;
      }
      var f = el.getAttribute('data-gtext'), key = f ? gfxTextKey(d, f) : '';
      if (f) { if (!gfx.texts[key]) { gfx.texts[key] = {}; } gfx.texts[key][f] = el.value; gfxSave(); gfxPlay(); }
    });
    $gFields.addEventListener('change', function (e) {
      var d = gfxCur(), el = e.target;
      if (!d) { return; }
      if (el.getAttribute('data-gtime')) { var v = GX.parseTime(el.value); if (v >= 1) { gfx.timer.total = Math.min(6 * 3600, Math.round(v)); gfx.timerSet = true; } }
      else if (el.getAttribute('data-gdir')) { gfx.timer.down = el.value !== 'up'; }
      else if (el.getAttribute('data-gfmt')) { gfx.timer.fmt = el.value; }
      else { gfxThumbs(); return; }
      gfxSave(); renderGfxSide(); gfxThumbs();
    });
    function gfxTypeChanged() { gfxSave(); gfxThumbs(); renderGfxSide(); }
    $gFace.addEventListener('change', function () { gfx.face = $gFace.value; gfxLoadFace(gfxTypeChanged); });
    $gTT.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-gfs]') : null;
      if (b) { var k = b.getAttribute('data-gfs'); gfx.fs[k] = !gfx.fs[k]; if (k === 'caps' && gfx.fs.caps) { gfx.fs.sc = false; } if (k === 'sc' && gfx.fs.sc) { gfx.fs.caps = false; } gfxTypeChanged(); }
    });
    $gTs.addEventListener('input', function () { gfx.ts = Number($gTs.value); $gTsV.textContent = gfx.ts + '%'; gfxSave(); gfxPlay(); });
    $gTs.addEventListener('change', function () { gfxThumbs(); });
    $gTrack.addEventListener('input', function () { gfx.track = Number($gTrack.value); $gTrackV.textContent = String(gfx.track); gfxSave(); gfxPlay(); });
    $gTrack.addEventListener('change', function () { gfxThumbs(); });
    // ---- drop-down lists drawn by the panel itself: the system's own pop-up lists do not open in this window.
    // Any <select> gets one (its options, same change event); the font field gets a richer one, like Premiere's.
    var $qMenu = document.createElement('div');
    $qMenu.className = 'q-menu'; $qMenu.hidden = true; document.body.appendChild($qMenu);
    var qMenu = { anchor: null, onKey: null, pick: null };
    function qMenuClose() { if ($qMenu.hidden) { return; } var done = qMenu.onClose; $qMenu.hidden = true; $qMenu.innerHTML = ''; qMenu.anchor = null; qMenu.onKey = null; qMenu.pick = null; qMenu.onClose = null; if (done) { try { done(); } catch (e) {} } }
    function qMenuPlace(anchor, w, h) {
      var r = anchor.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
      w = Math.min(vw - 12, Math.max(w, r.width));
      var left = Math.min(Math.max(6, r.left), vw - w - 6), below = vh - r.bottom - 10, above = r.top - 10, up = below < Math.min(h, 240) && above > below, mh = Math.max(110, Math.min(h, up ? above : below));
      $qMenu.style.width = w + 'px'; $qMenu.style.left = left + 'px'; $qMenu.style.maxHeight = mh + 'px'; $qMenu.style.height = '';
      if (up) { $qMenu.style.top = ''; $qMenu.style.bottom = (vh - r.top + 4) + 'px'; } else { $qMenu.style.bottom = ''; $qMenu.style.top = (r.bottom + 4) + 'px'; }
      return mh;
    }
    function qSelectOpen(sel) {
      var h = '', i, n = 0;
      for (i = 0; i < sel.options.length; i++) {
        var o = sel.options[i];
        if (o.disabled) { h += '<div class="q-head">' + esc(o.textContent) + '</div>'; }
        else { h += '<button class="q-item' + (o.selected ? ' on hi' : '') + '" data-qi="' + i + '" tabindex="-1">' + esc(o.textContent) + '</button>'; n++; }
      }
      $qMenu.className = 'q-menu'; $qMenu.innerHTML = h; $qMenu.hidden = false; qMenu.anchor = sel;
      qMenuPlace(sel, 170, Math.min(380, sel.options.length * 30 + 12));
      var cur = $qMenu.querySelector('.on');
      if (cur && cur.scrollIntoView) { cur.scrollIntoView({ block: 'nearest' }); }
      qMenu.pick = function (idx) { sel.selectedIndex = idx; qMenuClose(); sel.dispatchEvent(new Event('change', { bubbles: true })); };
      qMenu.onKey = function (e) {
        var items = $qMenu.querySelectorAll('.q-item'), at = -1, k;
        for (k = 0; k < items.length; k++) { if (items[k].classList.contains('hi')) { at = k; } }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          e.preventDefault();
          var to = Math.max(0, Math.min(items.length - 1, at + (e.key === 'ArrowDown' ? 1 : -1)));
          for (k = 0; k < items.length; k++) { items[k].classList.toggle('hi', k === to); }
          if (items[to] && items[to].scrollIntoView) { items[to].scrollIntoView({ block: 'nearest' }); }
        } else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (items[at]) { qMenu.pick(Number(items[at].getAttribute('data-qi'))); } }
        else if (e.key === 'Escape' || e.key === 'Tab') { e.preventDefault(); qMenuClose(); }
      };
    }
    var FONT_W = [100, 100, 200, 200, 300, 400, 400, 400, 400, 500, 600, 600, 700, 800, 800, 900, 900];
    function gfxFontPicker() {
      var fams = gfxFamilies(), favOnly = false, q = '', open = {}, items = [], hi = 0, rowH = 30;
      if (!gfx.favs) { gfx.favs = []; }
      $qMenu.className = 'q-menu q-fonts'; $qMenu.hidden = false; qMenu.anchor = $gFont;
      $qMenu.innerHTML = '<div class="q-fhead"><input id="qFontQ" type="text" placeholder="მოძებნე ფონტი…" spellcheck="false" autocomplete="off"><button id="qFav" title="მხოლოდ რჩეულები" tabindex="-1">★</button></div>' +
        '<div id="qFList" class="q-flist"><div id="qFPad" class="q-fpad"></div></div>';
      var mh = qMenuPlace($gFont, 430, 440);
      $qMenu.style.height = mh + 'px';
      var $fq = $qMenu.querySelector('#qFontQ'), $list = $qMenu.querySelector('#qFList'), $pad = $qMenu.querySelector('#qFPad'), $fav = $qMenu.querySelector('#qFav');
      function css(name) { return "'" + String(name).replace(/['\\]/g, '') + "', 'Helvetica Neue', sans-serif"; }
      function draw() {
        var first = Math.max(0, Math.floor($list.scrollTop / rowH) - 4), last = Math.min(items.length, first + Math.ceil(($list.clientHeight || 360) / rowH) + 8), h = '', i;
        for (i = first; i < last; i++) {
          var it = items[i], cls = 'q-frow' + (i === hi ? ' hi' : ''), top = ' style="top:' + (i * rowH) + 'px"';
          if (it.def) { h += '<div class="' + cls + (gfx.fam ? '' : ' on') + '"' + top + ' data-fi="' + i + '"><i class="q-star"></i><i class="q-exp"></i><span class="q-fname">Helvetica Neue (საწყისი)</span><span class="q-fsample" style="font-family:' + esc(css('Helvetica Neue')) + '">Sample</span></div>'; continue; }
          if (it.face) {
            var wi = window.QFXFonts ? window.QFXFonts.weightOf(it.face.style) : 6, it2 = wi % 1 ? 'italic' : 'normal', key = it.face.ps || it.face.full;
            h += '<div class="' + cls + ' face' + (gfx.fam === it.fam.family && gfx.face === key ? ' on' : '') + '"' + top + ' data-fi="' + i + '"><span class="q-fname">' + esc(it.face.style) + '</span><span class="q-fsample" style="font-family:' + esc(css(it.fam.family)) + ';font-weight:' + FONT_W[Math.floor(wi)] + ';font-style:' + it2 + '">Sample</span></div>';
            continue;
          }
          var fav = gfx.favs.indexOf(it.fam.family) >= 0, many = it.fam.faces && it.fam.faces.length > 1;
          h += '<div class="' + cls + (gfx.fam === it.fam.family && !gfx.face ? ' on' : '') + '"' + top + ' data-fi="' + i + '"><button class="q-star' + (fav ? ' on' : '') + '" data-fav="' + i + '" tabindex="-1" title="რჩეული">' + (fav ? '★' : '☆') + '</button>' +
            (many ? '<button class="q-exp' + (open[it.fam.family] ? ' open' : '') + '" data-exp="' + i + '" tabindex="-1" title="სტილები">›</button>' : '<i class="q-exp"></i>') +
            '<span class="q-fname">' + esc(it.fam.family) + '</span><span class="q-fsample" style="font-family:' + esc(it.fam.css || css(it.fam.family)) + '">Sample</span></div>';
        }
        $pad.innerHTML = h;
      }
      function build(keep) {
        items = [];
        if (!favOnly && !q) { items.push({ def: true }); }
        for (var i = 0; i < fams.length; i++) {
          var f = fams[i];
          if (favOnly && gfx.favs.indexOf(f.family) < 0) { continue; }
          if (q && f.family.toLowerCase().indexOf(q) < 0) { continue; }
          items.push({ fam: f });
          if (open[f.family]) { for (var j = 0; j < f.faces.length; j++) { items.push({ fam: f, face: f.faces[j] }); } }
        }
        $pad.style.height = (items.length * rowH) + 'px';
        if (!keep) { hi = 0; for (var k = 0; k < items.length; k++) { if (items[k].fam && items[k].fam.family === gfx.fam && !items[k].face) { hi = k; } } }
        hi = Math.max(0, Math.min(items.length - 1, hi));
        draw();
      }
      function see() { var y = hi * rowH; if (y < $list.scrollTop) { $list.scrollTop = y; } else if (y + rowH > $list.scrollTop + $list.clientHeight) { $list.scrollTop = y + rowH - $list.clientHeight; } draw(); }
      function pick(i) {
        var it = items[i];
        if (!it) { return; }
        gfx.fam = it.def ? '' : it.fam.family; gfx.face = it.face ? (it.face.ps || it.face.full) : '';
        qMenuClose();
        if (gfx.face) { gfxLoadFace(gfxTypeChanged); } else { gfxTypeChanged(); }
        if (document.fonts && document.fonts.ready) { document.fonts.ready.then(function () { if (state.view === 'gfx') { gfxThumbs(); gfxFontNote(); gfxPlay(); } }); }
        setTimeout(function () { if (state.view === 'gfx') { gfx.probe = {}; gfxThumbs(); gfxFontNote(); gfxPlay(); } }, 500);
      }
      function toggle(i) { var it = items[i]; if (it && it.fam && !it.face) { open[it.fam.family] = !open[it.fam.family]; hi = i; build(true); } }
      $list.addEventListener('scroll', draw);
      $pad.addEventListener('click', function (e) {
        var t = e.target, b = t.closest ? t.closest('[data-fav]') : null;
        if (b) { var name = items[Number(b.getAttribute('data-fav'))].fam.family, at = gfx.favs.indexOf(name); if (at >= 0) { gfx.favs.splice(at, 1); } else { gfx.favs.push(name); } gfxSave(); build(true); return; }
        b = t.closest ? t.closest('[data-exp]') : null;
        if (b) { toggle(Number(b.getAttribute('data-exp'))); return; }
        b = t.closest ? t.closest('[data-fi]') : null;
        if (b) { pick(Number(b.getAttribute('data-fi'))); }
      });
      $fq.addEventListener('input', function () { q = $fq.value.toLowerCase().replace(/^\s+|\s+$/g, ''); $list.scrollTop = 0; build(false); });
      $fav.addEventListener('click', function () { favOnly = !favOnly; $fav.classList.toggle('on', favOnly); $list.scrollTop = 0; build(false); $fq.focus(); });
      qMenu.onKey = function (e) {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); hi = Math.max(0, Math.min(items.length - 1, hi + (e.key === 'ArrowDown' ? 1 : -1))); see(); }
        else if (e.key === 'Enter') { e.preventDefault(); pick(hi); }
        else if (e.key === 'Escape') { e.preventDefault(); qMenuClose(); }
        else if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && !$fq.value) { var it = items[hi]; if (it && it.fam && !it.face && it.fam.faces.length > 1 && (!!open[it.fam.family]) !== (e.key === 'ArrowRight')) { e.preventDefault(); toggle(hi); } }
      };
      build(false);
      $list.scrollTop = Math.max(0, hi * rowH - 3 * rowH); draw();
      try { $fq.focus(); } catch (e0) {}
    }
    var Q_SW = ['#FD4A00', '#FFFFFF', '#111111', '#000000', '#E5202B', '#FF2D55', '#FF9500', '#FFC400', '#FFD400', '#2ECC71', '#1DB954', '#00C2A8', '#1AB7EA', '#1877F2', '#1B3FA6', '#5865F2', '#9146FF', '#FF4FD8', '#8E8E93', '#3A3A3A', '#F5F5F0', '#C9A227', '#7A1F1F', '#0B3D2E'];
    function qHsv(hex) {
      var m = /^#?([0-9a-f]{6})$/i.exec(hex || '') || [0, '000000'], n = parseInt(m[1], 16), r = (n >> 16) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
      if (d) { h = mx === r ? ((g - b) / d) % 6 : (mx === g ? (b - r) / d + 2 : (r - g) / d + 4); h = (h * 60 + 360) % 360; }
      return { h: h, s: mx ? d / mx : 0, v: mx };
    }
    function qHex(h, s2, v) {
      var c = v * s2, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c, r = [c, x, 0, 0, x, c][Math.floor(h / 60) % 6], g = [x, c, c, x, 0, 0][Math.floor(h / 60) % 6], b = [0, 0, x, c, c, x][Math.floor(h / 60) % 6], out = '#', a = [r, g, b];
      for (var i = 0; i < 3; i++) { var t = Math.round((a[i] + m) * 255).toString(16); out += t.length < 2 ? '0' + t : t; }
      return out.toUpperCase();
    }
    function qColorOpen(inp) {
      var c = qHsv(inp.value), start = inp.value, sw = '', i;
      for (i = 0; i < Q_SW.length; i++) { sw += '<button data-sw="' + Q_SW[i] + '" style="background:' + Q_SW[i] + '" title="' + Q_SW[i] + '" tabindex="-1"></button>'; }
      $qMenu.className = 'q-menu q-color'; $qMenu.hidden = false; qMenu.anchor = inp;
      $qMenu.innerHTML = '<canvas id="qSV" width="232" height="132"></canvas><canvas id="qHue" width="232" height="16"></canvas><div class="q-sw">' + sw + '</div><div class="q-hexrow"><i id="qNow"></i><input id="qHexIn" type="text" maxlength="7" spellcheck="false"></div>';
      qMenuPlace(inp, 252, 330);
      var $sv = $qMenu.querySelector('#qSV'), $hue = $qMenu.querySelector('#qHue'), $hex = $qMenu.querySelector('#qHexIn'), $now = $qMenu.querySelector('#qNow');
      function paint() {
        var x = $sv.getContext('2d'), g = x.createLinearGradient(0, 0, 232, 0), g2 = x.createLinearGradient(0, 0, 0, 132), k;
        x.fillStyle = qHex(c.h, 1, 1); x.fillRect(0, 0, 232, 132);
        g.addColorStop(0, '#FFFFFF'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 232, 132);
        g2.addColorStop(0, 'rgba(0,0,0,0)'); g2.addColorStop(1, '#000000'); x.fillStyle = g2; x.fillRect(0, 0, 232, 132);
        x.beginPath(); x.arc(c.s * 232, (1 - c.v) * 132, 7, 0, Math.PI * 2); x.lineWidth = 2; x.strokeStyle = c.v > 0.6 && c.s < 0.5 ? '#000000' : '#FFFFFF'; x.stroke();
        var y = $hue.getContext('2d'), gh = y.createLinearGradient(0, 0, 232, 0);
        for (k = 0; k <= 6; k++) { gh.addColorStop(k / 6, qHex((k * 60) % 360, 1, 1)); }
        y.fillStyle = gh; y.fillRect(0, 0, 232, 16); y.fillStyle = '#FFFFFF'; y.fillRect(c.h / 360 * 232 - 2, 0, 4, 16); y.strokeStyle = '#000000'; y.lineWidth = 1; y.strokeRect(c.h / 360 * 232 - 2.5, 0.5, 5, 15);
      }
      function set(hex, keepField) {
        inp.value = hex.toLowerCase(); $now.style.background = hex; if (!keepField) { $hex.value = hex.toUpperCase(); }
        inp.dispatchEvent(new Event('input', { bubbles: true })); paint();
      }
      function drag(el, fn) {
        el.addEventListener('mousedown', function (e) {
          e.preventDefault();
          function move(ev) { var r = el.getBoundingClientRect(); fn(Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)), Math.max(0, Math.min(1, (ev.clientY - r.top) / r.height))); }
          function up() { document.removeEventListener('mousemove', move, true); document.removeEventListener('mouseup', up, true); }
          document.addEventListener('mousemove', move, true); document.addEventListener('mouseup', up, true); move(e);
        });
      }
      drag($sv, function (x, y) { c.s = x; c.v = 1 - y; set(qHex(c.h, c.s, c.v)); });
      drag($hue, function (x) { c.h = Math.min(359.9, x * 360); if (c.v < 0.05) { c.v = 1; } if (c.s < 0.05) { c.s = 1; } set(qHex(c.h, c.s, c.v)); });
      $qMenu.querySelector('.q-sw').addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-sw]') : null; if (b) { c = qHsv(b.getAttribute('data-sw')); set(b.getAttribute('data-sw')); } });
      $hex.addEventListener('input', function () { var v = $hex.value.replace(/^\s+|\s+$/g, ''); if (v.charAt(0) !== '#') { v = '#' + v; } if (/^#[0-9a-f]{6}$/i.test(v)) { c = qHsv(v); set(v.toUpperCase(), true); } });
      qMenu.onKey = function (e) { if (e.key === 'Escape') { e.preventDefault(); c = qHsv(start); set(start.toUpperCase()); qMenuClose(); } else if (e.key === 'Enter') { e.preventDefault(); qMenuClose(); } };
      qMenu.onClose = function () { inp.dispatchEvent(new Event('change', { bubbles: true })); };
      $now.style.background = inp.value; $hex.value = String(inp.value).toUpperCase(); paint();
    }
    document.addEventListener('click', function (e) { var col = e.target.closest ? e.target.closest('input[type=color]') : null; if (col) { e.preventDefault(); } }, true);
    $qMenu.addEventListener('click', function (e) { var b = e.target.closest ? e.target.closest('[data-qi]') : null; if (b && qMenu.pick) { qMenu.pick(Number(b.getAttribute('data-qi'))); } });
    document.addEventListener('mousedown', function (e) {
      if (!$qMenu.hidden) {
        if ($qMenu.contains(e.target)) { return; }
        var same = qMenu.anchor && qMenu.anchor.contains(e.target);
        qMenuClose();
        if (same) { e.preventDefault(); return; }
      }
      var col = e.target.closest ? e.target.closest('input[type=color]') : null;
      if (col && !col.disabled) { e.preventDefault(); qColorOpen(col); return; }
      var sel = e.target.closest ? e.target.closest('select') : null;
      if (!sel || sel.disabled) { return; }
      e.preventDefault();
      try { sel.focus(); } catch (e1) {}
      if (sel === $gFont) { gfxFontPicker(); } else { qSelectOpen(sel); }
    }, true);
    document.addEventListener('keydown', function (e) {
      if (!$qMenu.hidden && qMenu.onKey) { qMenu.onKey(e); e.stopPropagation(); return; }
      var sel = document.activeElement;
      if (sel && sel.tagName === 'SELECT' && !sel.disabled && (e.key === ' ' || e.key === 'Enter' || e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        e.preventDefault(); e.stopPropagation();
        if (sel === $gFont) { gfxFontPicker(); } else { qSelectOpen(sel); }
      }
    }, true);
    window.addEventListener('blur', qMenuClose);
    window.addEventListener('resize', qMenuClose);

    function gfxColor(el, key) { el.addEventListener('input', function () { gfx[key] = el.value; gfxSave(); gfxPlay(); }); el.addEventListener('change', function () { gfxThumbs(); }); }
    gfxColor($gAccent, 'accent'); gfxColor($gColor, 'color'); gfxColor($gBg, 'bg');
    $gSize.addEventListener('input', function () { gfx.size = Number($gSize.value); gfxSave(); renderGfxSide(); });
    if ($gFix) {
      $gFix.addEventListener('click', function () {
        var list = gfx.old || [];
        if (!list.length || gfx.fixing) { return; }
        gfx.fixing = true; $gFix.disabled = true;
        (window.__QFX_GFX_FIX || gfxFixOld)(list, function (i, n) { $gFix.textContent = 'სწორდება… ' + (i + 1) + ' / ' + n; }).then(function (r) {
          gfx.fixing = false; $gFix.disabled = false; gfxFixShow();
          if (r.noEngine) { toast('err', TG.noEngine, '', 6000); }
          else if (r.failed) { toast('warn', 'გასწორდა ' + r.done + ', ვერ გასწორდა ' + r.failed, 'Premiere დახურე, თავიდან გახსენი და კიდევ ერთხელ სცადე', 8000); }
          else { toast('ok', 'გასწორდა ' + r.done + ' ფაილი', 'Premiere დახურე (⌘Q) და თავიდან გახსენი — timeline-ზე უკვე ჩასმული გრაფიკა გამჭვირვალე გახდება', 9000); }
        });
      });
    }
    $gDur.addEventListener('input', function () { var d = gfxCur(); if (d) { gfx.dur[d.id] = Number($gDur.value); gfxSave(); renderGfxSide(); } });
    $gDurN.addEventListener('change', function () { var d = gfxCur(), v = GX.parseTime($gDurN.value); if (d && v >= 1.5) { gfx.dur[d.id] = Math.min(600, Math.round(v * 10) / 10); gfxSave(); } $gDurN.blur(); renderGfxSide(); });
    $gIn.addEventListener('change', function () { gfx.noIn = !$gIn.checked; gfxSave(); gfxThumbs(); renderGfxSide(); });
    $gOut.addEventListener('change', function () { gfx.noOut = !$gOut.checked; gfxSave(); renderGfxSide(); });
    $gFields.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-gpn]') : null;
      if (b) { gfx.pn = Number(b.getAttribute('data-gpn')); gfx.pick = Math.min(gfx.pick, gfx.pn - 1); gfxSave(); renderGfxSide(); gfxThumbs(); return; }
      b = e.target.closest ? e.target.closest('[data-gpick]') : null;
      if (b) { gfx.pick = Number(b.getAttribute('data-gpick')); gfxSave(); renderGfxSide(); gfxThumbs(); return; }
      var pl = gfxPlayers(), i;
      b = e.target.closest ? e.target.closest('[data-gph]') : null;
      if (b) {
        var who = pl[Number(b.getAttribute('data-gph'))];
        if (who.ph && gfxPhotos[who.ph] && gfxPhotos[who.ph] !== 'bad') { who.ph = ''; gfxSave(); renderGfxSide(); gfxThumbs(); return; }
        var got = (window.__QFX_PICK || B.pick)({ many: false, folder: false, title: who.n + ' — ფოტო', types: ['png', 'jpg', 'jpeg', 'heic', 'heif', 'webp', 'gif', 'bmp'] });
        if (got && got.length) {
          var path = String(got[0]).replace(/\\/g, '/');
          delete gfxPhotos[path];
          gfxPhotoLoad(path, function (okay) {
            if (!okay) { toast('err', 'ამ ფაილის გახსნა ვერ მოხერხდა', 'აირჩიე PNG ან JPG სურათი', 2600); return; }
            who.ph = path; gfxSave(); renderGfxSide(); gfxThumbs();
          });
        }
        return;
      }
      b = e.target.closest ? e.target.closest('[data-gpal]') : null;
      if (b) { var was = gfxColoured(); for (i = 0; i < pl.length; i++) { pl[i].c = was ? '' : GFX_PAL[i % GFX_PAL.length]; } gfxSave(); renderGfxSide(); gfxThumbs(); return; }
      b = e.target.closest ? e.target.closest('[data-gapply]') : null;
      if (b && !b.disabled) {
        for (i = 0; i < pl.length; i++) {
          var add = parseFloat(String(pl[i].a).replace(',', '.').replace(/[−–]/, '-').replace(/^\+/, '')), cur = parseFloat(String(pl[i].s).replace(',', '.'));
          if (add && i < gfx.pn) { pl[i].s = String(Math.round(((isNaN(cur) ? 0 : cur) + add) * 100) / 100); }
          if (i < gfx.pn) { pl[i].a = ''; }
        }
        gfxSave(); renderGfxSide(); gfxThumbs(); toast('ok', 'ქულები განახლდა', '„+“ ველები გასუფთავდა — შემდეგი რაუნდისთვის', 1800);
      }
    });
    $gGo.addEventListener('click', function () { gfxInsert(); });
    $gLogo.addEventListener('click', function () {
      if (gfx.logo) { gfxLoadLogo(''); gfxSave(); gfxThumbs(); gfxPlay(); return; }
      var got = (window.__QFX_PICK || B.pick)({ many: false, folder: false, title: TG.logoTitle, types: ['png', 'jpg', 'jpeg', 'svg', 'webp'] });
      if (got && got.length) { gfxLoadLogo(String(got[0]).replace(/\\/g, '/')); }
    });
    $gQ.addEventListener('input', function () { gfx.q = $gQ.value.replace(/^\s+|\s+$/g, ''); renderGfx(); });
    setInterval(function () { if (state.view === 'gfx' && !gfx.busy) { gfxRefreshSeq(); } }, 3000);
    COMMANDS.push({ id: 'c:gfx', name: 'გრაფიკა — წამზომები და ქვედა ტიტრები', kind: 'command', icon: 'txt', run: function () { switchTab('gfx'); },
      alt: 'timer countdown stopwatch lower third subscribe like follow bell social წამზომი ტაიმერი უკუთვლა ქვედა ტიტრი გამოწერა ლაიქი გრაფიკა', meta: '⌘6' });
  }

  function copyDiagnostics() {
    var d = {
      quickfx: VERSION, mode: MODE, extensionId: extId,
      info: state.info,
      effects: { video: (state.effects.video || []).length, audio: (state.effects.audio || []).length },
      presetFile: state.presetFile, presets: state.presets.length,
      presetSkipped: state.presetSkipped.length, presetError: state.presetError,
      lastError: state.lastError, lastResult: state.lastResult,
      selected: state.debug || null,
      collect: { phase: collect.phase, engine: collect.engine || null, node: !!nodeFs() },
      auto: autoState(),
      zones: zones.state,
      youtube: ytDiag(),
      graphics: gfxDiag(),
      sounds: sfxDiag(),
      text: txtDiag(),
      ease: { file: ease.info && ease.info.project ? easePath(ease.info.project) : '', where: easeCache.data ? easeCache.data.where : '', records: easeCache.data ? easeCache.data.records.length : 0, undo: easeCache.data ? easeCache.data.undo.length : 0 },
      userAgent: navigator.userAgent
    };
    var ta = document.createElement('textarea');
    ta.value = JSON.stringify(d, null, 2);
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { /* ignore */ }
    document.body.removeChild(ta);
    openMenu(false);
    toast('ok', T.diagCopied);
  }

  // ------------------------------------------------------------------ events
  $q.addEventListener('input', function () {
    if (Y && Y.isUrl($q.value)) { var link = $q.value; $q.value = ''; switchTab('yt'); ytSetUrl(link); return; }
    state.active = 0; render();
  });

  $q.addEventListener('keydown', function (e) {
    if (e.isComposing) { return; }
    if (tabKey(e)) { return; }
    if (isPasteKey(e)) {
      var clip = ytClipboard(), link = clip === null ? '' : (clip.replace(/^\s+|\s+$/g, '').split(/\s/)[0] || '');
      if (Y.isUrl(link)) { e.preventDefault(); e.stopPropagation(); switchTab('yt'); ytSetUrl(link); }
      return;
    }
    var k = e.key;
    if (k === 'ArrowDown' || (e.ctrlKey && (k === 'n' || k === 'j'))) { setActive(state.active + 1); e.preventDefault(); }
    else if (k === 'ArrowUp' || (e.ctrlKey && (k === 'p' || k === 'k'))) { setActive(state.active - 1); e.preventDefault(); }
    else if (k === 'PageDown') { setActive(state.active + 8); e.preventDefault(); }
    else if (k === 'PageUp') { setActive(state.active - 8); e.preventDefault(); }
    else if (k === 'Tab') { setActive(state.active + (e.shiftKey ? -1 : 1)); e.preventDefault(); }
    else if (k === 'Enter') { apply(state.rows[state.active], e.shiftKey || MODE === 'panel'); e.preventDefault(); }
    else if (k === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false); }
      else if ($q.value) { $q.value = ''; state.active = 0; render(); }
      else if (MODE === 'popup') { closeWindow(); }
    }
    else if ((e.metaKey || e.ctrlKey) && (k === 'r' || k === 'R')) { e.preventDefault(); loadEverything(true); }
    else if ((e.metaKey || e.ctrlKey) && !e.altKey && (e.keyCode === 68 || e.code === 'KeyD')) { e.preventDefault(); toggleFav(state.rows[state.active] && state.rows[state.active].item); }
  });

  // typing anywhere goes to the search field
  document.addEventListener('keydown', function (e) {
    if (document.activeElement !== $q && document.activeElement !== $('eName') && document.activeElement !== $('yUrl') && document.activeElement !== $('xQ') && tabKey(e)) { return; }
    if (state.view === 'collect') { collectKey(e); return; }
    if (state.view === 'zones') { zonesKey(e); return; }
    if (state.view === 'ease') { easeKey(e); return; }
    if (state.view === 'yt') { ytKey(e); return; }
    if (state.view === 'gfx') { gfxKey(e); return; }
    if (state.view === 'sfx') { sfxKey(e); return; }
    if (state.view === 'txt') { txtKey(e); return; }
    if (document.activeElement === $q || e.metaKey || e.ctrlKey || e.altKey) { return; }
    if (e.key === 'Escape') { if (!$menu.hidden) { openMenu(false); } else if (MODE === 'popup') { closeWindow(); } return; }
    if (e.key && e.key.length === 1) { $q.focus(); }
  });

  var lastMouse = { x: -1, y: -1 };
  $list.addEventListener('mousemove', function (e) {
    if (e.clientX === lastMouse.x && e.clientY === lastMouse.y) { return; }
    lastMouse = { x: e.clientX, y: e.clientY };
    var row = e.target.closest ? e.target.closest('.row') : null;
    if (row) { setActive(Number(row.getAttribute('data-i'))); }
  });
  $list.addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.row') : null;
    if (!row) { return; }
    var i = Number(row.getAttribute('data-i'));
    if (e.target.closest('[data-star]')) { toggleFav(state.rows[i] && state.rows[i].item); $q.focus(); return; }
    state.active = i;
    apply(state.rows[i], e.shiftKey || MODE === 'panel');
  });

  $menuBtn.addEventListener('click', function () { openMenu($menu.hidden); });
  $menu.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button[data-act]') : null;
    if (!b) { return; }
    var act = b.getAttribute('data-act');
    if (act === 'refresh') { openMenu(false); loadEverything(true); }
    if (act === 'diag') { copyDiagnostics(); }
  });
  $files.addEventListener('click', function (e) {
    var cb = e.target.closest ? e.target.closest('[data-cact]') : null;
    if (cb) { collectAction(cb.getAttribute('data-cact')); }
  });
  $files.addEventListener('change', function (e) {
    if (!e.target || e.target.id !== 'autoCollect') { return; }
    Store.write('settings.json', { auto: e.target.checked });
    if (e.target.checked) { state.openedAt = Date.now(); wakeWatcher(); }
    updateAuto();
  });
  $('rail').addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('.rail-btn[data-tab]') : null;
    if (b && !b.disabled) { switchTab(b.getAttribute('data-tab')); }
  });
  $closeOnBlur.checked = !!state.settings.closeOnBlur;
  $closeOnBlur.addEventListener('change', function () {
    state.settings.closeOnBlur = $closeOnBlur.checked;
    save(LS.settings, state.settings);
  });
  document.addEventListener('mousedown', function (e) {
    if (!$menu.hidden && !$menu.contains(e.target) && !$menuBtn.contains(e.target)) { openMenu(false); }
  });

  window.addEventListener('focus', function () {
    state.hadFocus = true;
    if (state.view !== 'list') { return; }
    if ($menu.hidden) { $q.focus(); }
    refreshSelection();
  });

  window.addEventListener('blur', function () {
    if (MODE !== 'popup' || !state.settings.closeOnBlur || !state.hadFocus || state.busy || collectBusy()) { return; }
    if (Date.now() - state.openedAt < 900) { return; }
    setTimeout(function () {
      if (!document.hasFocus() && !state.busy && !collectBusy()) { closeWindow(); }
    }, 200);
  });

  // ------------------------------------------------------------------ init
  function init() {
    document.documentElement.classList.add('mode-' + MODE);
    if (MODE === 'panel') {
      $blurOpt.hidden = true;
    }
    B.registerKeys();

    // instant results from the last session while Premiere answers
    var cached = load(LS.effects, null);
    if (cached && cached.data) { state.effects = cached.data; buildItems(); }
    render();
    switchTab('fx');
    updateAuto();
    $q.focus();
    setTimeout(function () { if (state.view === 'list') { $q.focus(); } }, 60);

    if (!B.available) { state.loaded = true; render(); return; }
    loadEverything(false);
    setTimeout(wakeWatcher, 1500);
    setTimeout(refreshZones, 900);
    setInterval(function () { if (!document.hidden) { updateAuto(); } }, 2000);
    setInterval(function () { if (!document.hidden && state.view === 'zones' && !zones.busy) { refreshZones(); } }, 2500);
    setInterval(function () { if (!document.hidden && state.view === 'ease' && !ease.busy && !ease.drag) { refreshEase(); } }, 1800);
    setInterval(function () { if (!document.hidden && state.view === 'txt' && !txt.busy && !txt.drag && !txt.dropping) { txtRefresh(); } }, 2000);
    if (MODE === 'panel') {
      setInterval(function () { if (!document.hidden && !state.busy && state.view === 'list') { refreshSelection(); } }, 2500);
    }
  }

  // exposed for tests / debugging
  window.QuickFXUI = { state: state, render: render, apply: apply, loadEverything: loadEverything, mode: MODE };

  init();
})();
