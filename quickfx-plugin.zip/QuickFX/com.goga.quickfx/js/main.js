/*
 * Quick FX — panel UI.
 * Popup mode (Modeless window): type, Enter, it applies and closes.
 * Panel mode (docked): stays open.
 */
(function () {
  'use strict';

  var B = window.QFXBridge, S = window.QFXSearch, P = window.QFXPresets;
  var VERSION = '1.2.0';
  var extId = B.extensionId();
  var MODE = /\.panel$/.test(extId) ? 'panel' : 'popup';
  var LS = { usage: 'qfx.usage.v1', effects: 'qfx.effects.v1', settings: 'qfx.settings.v1' };
  var RESULT_LIMIT = 80;
  var EMPTY_EFFECT_LIMIT = 120;

  var T = {
    videoFx: 'ვიდეო ეფექტი',
    audioFx: 'აუდიო ეფექტი',
    preset: 'პრესეტი',
    recent: 'ბოლოს გამოყენებული',
    myPresets: 'ჩემი პრესეტები',
    effects: 'ეფექტები',
    loading: 'იტვირთება…',
    nothing: function (q) { return 'ვერაფერი მოიძებნა: <strong>' + esc(q) + '</strong>'; },
    moreHint: 'აკრიფე სახელი, რომ ყველა ეფექტში მოძებნო…',
    noSeq: 'სექვენსი არ არის გახსნილი',
    noSel: 'კლიპი არ არის მონიშნული',
    selected: function (v, a) {
      var parts = [];
      if (v) { parts.push(v + ' ვიდეო'); }
      if (a) { parts.push(a + ' აუდიო'); }
      return parts.join(' · ') + ' მონიშნულია';
    },
    appliedFx: function (name, n) { return '<b>' + esc(name) + '</b> დაედო ' + n + ' კლიპს'; },
    appliedPreset: function (name, n) { return '«' + esc(name) + '» დაედო ' + n + ' კლიპს'; },
    failedSome: function (n) { return n + ' კლიპზე ვერ დაედო'; },
    skippedParams: function (n) { return n + ' პარამეტრი ვერ გადმოვიდა (Lumetri-ს curves/wheels, მასკები და მისთ.)'; },
    missingFx: function (list) { return 'არ არის დაყენებული: ' + list.join(', '); },
    errors: {
      noSequence: 'სექვენსი არ არის გახსნილი',
      noSelection: 'ჯერ მონიშნე კლიპი timeline-ზე',
      noVideoSelected: 'მონიშნულია მხოლოდ აუდიო — ვიდეო ეფექტისთვის ვიდეო კლიპი მონიშნე',
      noAudioSelected: 'მონიშნულია მხოლოდ ვიდეო — აუდიო ეფექტისთვის აუდიო კლიპი მონიშნე',
      effectNotFound: 'ეფექტი ვერ მოიძებნა',
      applyFailed: 'ეფექტი ვერ დაედო',
      presetFailed: 'პრესეტი ვერ დაედო',
      noQE: 'Premiere-ის შიდა API ვერ ჩაირთო',
      hostError: 'Premiere-მა არ უპასუხა — დახურე და თავიდან გახსენი Quick FX',
      badReply: 'Premiere-მა გაუგებარი პასუხი დააბრუნა',
      exception: 'შეცდომა'
    },
    diagCopied: 'დიაგნოსტიკა დაკოპირდა — ჩასვი ჩატში',
    refreshed: function (fx, pr) { return 'განახლდა: ' + fx + ' ეფექტი · ' + pr + ' პრესეტი'; }
  };

  // ------------------------------------------------------------------ state
  var state = {
    effects: { video: [], audio: [] },
    presets: [],
    presetSkipped: [],
    presetFile: null,
    presetError: null,
    info: null,
    items: [],
    rows: [],            // rendered rows (selectable ones only)
    active: 0,
    busy: false,
    loaded: false,
    hadFocus: false,
    openedAt: Date.now(),
    lastError: null,
    lastResult: null,
    usage: load(LS.usage, {}),
    settings: assign({ closeOnBlur: true }, load(LS.settings, {}))
  };

  // ------------------------------------------------------------------ DOM
  function $(id) { return document.getElementById(id); }
  var $q = $('q'), $list = $('list'), $sel = $('sel'), $toast = $('toast');
  var $menu = $('menu'), $menuBtn = $('menuBtn'), $busy = $('busy'), $menuInfo = $('menuInfo');
  var $closeOnBlur = $('closeOnBlur'), $blurOpt = $('blurOpt');

  // ------------------------------------------------------------------ utils
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function assign(a, b) { for (var k in b) { if (Object.prototype.hasOwnProperty.call(b, k)) { a[k] = b[k]; } } return a; }
  function load(key, dflt) {
    try { var v = window.localStorage.getItem(key); return v ? JSON.parse(v) : dflt; } catch (e) { return dflt; }
  }
  function save(key, val) {
    try { window.localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* storage full or unavailable */ }
  }
  function highlight(text, idx) {
    if (!idx || !idx.length) { return esc(text); }
    var set = {}, i, out = '', open = false;
    for (i = 0; i < idx.length; i++) { set[idx[i]] = true; }
    for (i = 0; i < text.length; i++) {
      var on = !!set[i];
      if (on && !open) { out += '<mark>'; open = true; }
      if (!on && open) { out += '</mark>'; open = false; }
      out += esc(text.charAt(i));
    }
    if (open) { out += '</mark>'; }
    return out;
  }

  // ------------------------------------------------------------------ items
  function buildItems() {
    var items = [], i;
    for (i = 0; i < state.presets.length; i++) {
      var p = state.presets[i];
      var sum = P.summary(p);
      var kf = P.keyframeCount(p);
      items.push({
        id: p.id, name: p.name, kind: 'preset', ref: p,
        alt: (p.folder ? p.folder + ' ' : '') + sum,
        meta: (p.folder ? p.folder + ' · ' : '') + sum + (kf ? ' · ◆' + kf : '')
      });
    }
    var v = state.effects.video || [], a = state.effects.audio || [];
    for (i = 0; i < v.length; i++) { items.push({ id: 'v:' + v[i], name: v[i], kind: 'video', meta: T.videoFx }); }
    for (i = 0; i < a.length; i++) { items.push({ id: 'a:' + a[i], name: a[i], kind: 'audio', meta: T.audioFx }); }
    state.items = items;
  }

  // ------------------------------------------------------------------ render
  function rowHtml(r, i) {
    var it = r.item;
    var badge = it.kind === 'preset' ? '<span class="badge preset"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l2.7 5.6 6.1.8-4.5 4.3 1.1 6.1L12 16.9 6.6 19.8l1.1-6.1L3.2 9.4l6.1-.8z"/></svg></span>'
      : (it.kind === 'audio' ? '<span class="badge audio">AU</span>' : '<span class="badge video">FX</span>');
    return '<div class="row' + (i === state.active ? ' active' : '') + '" data-i="' + i + '" role="option">' +
      badge +
      '<span class="name">' + highlight(it.name, r.idx) + '</span>' +
      '<span class="meta">' + esc(it.meta || '') + '</span>' +
      '<span class="ret">↵</span>' +
      '</div>';
  }

  function render() {
    var q = $q.value;
    var html = [], rows = [], i;
    function section(label) { html.push('<div class="section">' + esc(label) + '</div>'); }
    function push(r) { html.push(rowHtml(r, rows.length)); rows.push(r); }

    if (!state.items.length) {
      html.push('<div class="empty">' + (!state.loaded ? T.loading
        : (state.lastError ? errorText(state.lastError) : T.errors.noQE)) + '</div>');
    } else if (!S.cleanQuery(q)) {
      var rec = S.recents(state.items, state.usage, 6);
      var shown = {};
      if (rec.length) {
        section(T.recent);
        for (i = 0; i < rec.length; i++) { push(rec[i]); shown[rec[i].item.id] = true; }
      }
      var presetRows = [], fxRows = [];
      for (i = 0; i < state.items.length; i++) {
        var it = state.items[i];
        if (shown[it.id]) { continue; }
        if (it.kind === 'preset') { presetRows.push({ item: it, idx: [] }); }
        else if (fxRows.length < EMPTY_EFFECT_LIMIT) { fxRows.push({ item: it, idx: [] }); }
      }
      if (presetRows.length) {
        section(T.myPresets + ' · ' + presetRows.length);
        for (i = 0; i < presetRows.length; i++) { push(presetRows[i]); }
      }
      if (fxRows.length) {
        section(T.effects);
        for (i = 0; i < fxRows.length; i++) { push(fxRows[i]); }
        html.push('<div class="more">' + esc(T.moreHint) + '</div>');
      }
    } else {
      var res = S.rank(state.items, q, state.usage, RESULT_LIMIT);
      if (!res.length) { html.push('<div class="empty">' + T.nothing(q) + '</div>'); }
      for (i = 0; i < res.length; i++) { push(res[i]); }
    }

    state.rows = rows;
    if (state.active >= rows.length) { state.active = rows.length ? rows.length - 1 : 0; }
    $list.innerHTML = html.join('');
    scrollActiveIntoView();
  }

  function setActive(i) {
    if (!state.rows.length) { return; }
    var n = state.rows.length;
    i = Math.max(0, Math.min(n - 1, i));
    if (i === state.active) { return; }
    var prev = $list.querySelector('.row.active');
    if (prev) { prev.classList.remove('active'); }
    state.active = i;
    var el = $list.querySelector('.row[data-i="' + i + '"]');
    if (el) { el.classList.add('active'); }
    scrollActiveIntoView();
  }

  function scrollActiveIntoView() {
    var el = $list.querySelector('.row.active');
    if (!el) { return; }
    var top = el.offsetTop, bottom = top + el.offsetHeight;
    var prevSection = el.previousElementSibling;
    if (state.active === 0) { $list.scrollTop = 0; return; }
    if (prevSection && prevSection.classList.contains('section')) { top = prevSection.offsetTop; }
    if (top < $list.scrollTop) { $list.scrollTop = top - 6; }
    else if (bottom > $list.scrollTop + $list.clientHeight) { $list.scrollTop = bottom - $list.clientHeight + 6; }
  }

  // ------------------------------------------------------------------ selection status
  function setSelection(d) {
    var cls = 'sel', text;
    if (!d || !d.hasSequence) { cls += ' none'; text = T.noSeq; }
    else if (!d.video && !d.audio) { cls += ' none'; text = T.noSel; }
    else { cls += ' ok'; text = T.selected(d.video, d.audio); }
    $sel.className = cls;
    $sel.querySelector('.sel-text').textContent = text;
  }

  function refreshSelection() {
    return B.call('selection').then(function (r) { if (r && r.ok) { setSelection(r.data); } });
  }

  // ------------------------------------------------------------------ toast
  var toastTimer = null;
  function toast(kind, html, sub, ms) {
    var icon = kind === 'ok' ? '✓' : (kind === 'warn' ? '!' : '✕');
    $toast.className = 'toast ' + kind;
    $toast.innerHTML = '<span class="ti">' + icon + '</span><span>' + html +
      (sub ? '<span class="tsub">' + sub + '</span>' : '') + '</span>';
    $toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { $toast.hidden = true; }, ms || (kind === 'ok' ? 2200 : 5000));
  }

  function errorText(res) {
    var base = T.errors[res.code] || T.errors.exception;
    var extra = '';
    if (res.code === 'effectNotFound' || res.code === 'applyFailed') { extra = res.message ? ': ' + esc(res.message) : ''; }
    else if (res.code === 'exception' || res.code === 'hostError' || res.code === 'badReply') { extra = res.message ? '<span class="tsub">' + esc(res.message) + '</span>' : ''; }
    else if (res.code === 'presetFailed' && res.extra && res.extra.missing && res.extra.missing.length) {
      extra = '<span class="tsub">' + esc(T.missingFx(res.extra.missing)) + '</span>';
    }
    return base + extra;
  }

  // ------------------------------------------------------------------ busy / host
  function setBusy(on) { state.busy = on; $busy.hidden = !on; }

  function ensureHost() {
    return B.evalScript('typeof QuickFX').then(function (r) {
      if (r === 'object') { return true; }
      var path = B.extensionPath() + '/jsx/host.jsx';
      return B.evalScript('$.evalFile(' + JSON.stringify(path) + ')').then(function () { return true; });
    });
  }

  function choosePresetFile(files, appVersion) {
    if (!files || !files.length) { return null; }
    var major = String(appVersion || '').split('.')[0];
    var same = files.filter(function (f) { return String(f.version).split('.')[0] === major; });
    var pool = (same.length ? same : files).slice();
    pool.sort(function (a, b) { return (b.modified || 0) - (a.modified || 0); });
    return pool[0];
  }

  function loadPresets() {
    var f = choosePresetFile(state.info && state.info.presetFiles, state.info && state.info.appVersion);
    state.presetFile = f;
    state.presetError = null;
    if (!f) { state.presets = []; return; }
    var text = B.readTextFile(f.path);
    if (text == null) { state.presetError = 'cannot read ' + f.path; state.presets = []; return; }
    try {
      var res = P.parse(text);
      state.presets = res.presets;
      state.presetSkipped = res.skipped;
    } catch (e) {
      state.presetError = String(e && e.message || e);
      state.presets = [];
    }
  }

  function loadEverything(announce) {
    setBusy(true);
    return ensureHost()
      .then(function () { return Promise.all([B.call('info'), B.call('listEffects'), B.call('selection')]); })
      .then(function (r) {
        var info = r[0], fx = r[1], sel = r[2];
        if (info.ok) { state.info = info.data; } else { state.lastError = info; }
        if (fx.ok) {
          state.effects = fx.data;
          save(LS.effects, { at: Date.now(), app: state.info && state.info.appVersion, data: fx.data });
        } else { state.lastError = fx; }
        if (sel.ok) { setSelection(sel.data); }
        loadPresets();
        state.loaded = true;
        buildItems();
        render();
        updateMenuInfo();
        setBusy(false);
        if (announce) { toast('ok', T.refreshed((state.effects.video || []).length + (state.effects.audio || []).length, state.presets.length)); }
      })
      .catch(function (e) {
        setBusy(false);
        state.loaded = true;
        state.lastError = { code: 'exception', message: String(e && e.message || e) };
        render();
      });
  }

  // ------------------------------------------------------------------ apply
  function recordUsage(item) {
    var u = state.usage[item.id] || { count: 0, last: 0 };
    u.count += 1;
    u.last = Date.now();
    state.usage[item.id] = u;
    var keys = Object.keys(state.usage);
    if (keys.length > 600) {
      keys.sort(function (a, b) { return state.usage[a].last - state.usage[b].last; });
      for (var i = 0; i < keys.length - 500; i++) { delete state.usage[keys[i]]; }
    }
    save(LS.usage, state.usage);
  }

  function apply(row, keepOpen) {
    if (!row || state.busy) { return; }
    var item = row.item;
    setBusy(true);
    var call = item.kind === 'preset'
      ? B.call('applyPreset', { preset: P.compact(item.ref) })
      : B.call('applyEffect', { kind: item.kind, name: item.name });

    call.then(function (res) {
      setBusy(false);
      state.lastResult = { item: item.id, res: res, at: new Date().toISOString() };
      if (!res || !res.ok) {
        state.lastError = res;
        toast('err', errorText(res || { code: 'hostError' }));
        return;
      }
      recordUsage(item);
      var d = res.data, sub = [], kind = 'ok', msg;
      if (item.kind === 'preset') {
        msg = T.appliedPreset(item.name, d.clips);
        if (d.missing && d.missing.length) { sub.push(esc(T.missingFx(d.missing))); kind = 'warn'; }
        if (d.paramsSkipped) { sub.push(esc(T.skippedParams(d.paramsSkipped))); kind = 'warn'; }
        if (d.clips < d.total) { sub.push(esc(T.failedSome(d.total - d.clips))); kind = 'warn'; }
      } else {
        msg = T.appliedFx(item.name, d.applied);
        if (d.failed) { sub.push(esc(T.failedSome(d.failed))); kind = 'warn'; }
      }
      toast(kind, msg, sub.join('<br>'), kind === 'ok' ? 1600 : 4500);

      if (MODE === 'popup' && !keepOpen) {
        setTimeout(function () { B.close(); }, kind === 'ok' ? 380 : 2600);
      } else {
        refreshSelection();
        $q.focus();
        $q.select();
      }
    });
  }

  // ------------------------------------------------------------------ menu
  function updateMenuInfo() {
    var fxCount = (state.effects.video || []).length + (state.effects.audio || []).length;
    var lines = [];
    lines.push('ეფექტები: ' + fxCount + ' · პრესეტები: ' + state.presets.length);
    if (state.presetFile) { lines.push('პრესეტების ფაილი: ' + esc(state.presetFile.path)); }
    else { lines.push('პრესეტების ფაილი ვერ მოიძებნა'); }
    if (state.presetError) { lines.push('<span style="color:var(--err)">' + esc(state.presetError) + '</span>'); }
    if (state.info) { lines.push('Premiere ' + esc(state.info.appVersion) + ' · Quick FX ' + VERSION); }
    $menuInfo.innerHTML = lines.join('<br>');
  }

  function openMenu(open) {
    $menu.hidden = !open;
    $menuBtn.classList.toggle('open', open);
    if (open) { updateMenuInfo(); }
    else { $q.focus(); }
  }

  function copyDiagnostics() {
    var d = {
      quickfx: VERSION, mode: MODE, extensionId: extId,
      info: state.info,
      effects: { video: (state.effects.video || []).length, audio: (state.effects.audio || []).length },
      presetFile: state.presetFile, presets: state.presets.length,
      presetSkipped: state.presetSkipped.length, presetError: state.presetError,
      lastError: state.lastError, lastResult: state.lastResult,
      userAgent: navigator.userAgent
    };
    var ta = document.createElement('textarea');
    ta.value = JSON.stringify(d, null, 2);
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { /* ignore */ }
    document.body.removeChild(ta);
    openMenu(false);
    toast('ok', T.diagCopied);
  }

  // ------------------------------------------------------------------ events
  $q.addEventListener('input', function () { state.active = 0; render(); });

  $q.addEventListener('keydown', function (e) {
    if (e.isComposing) { return; }
    var k = e.key;
    if (k === 'ArrowDown' || (e.ctrlKey && (k === 'n' || k === 'j'))) { setActive(state.active + 1); e.preventDefault(); }
    else if (k === 'ArrowUp' || (e.ctrlKey && (k === 'p' || k === 'k'))) { setActive(state.active - 1); e.preventDefault(); }
    else if (k === 'PageDown') { setActive(state.active + 8); e.preventDefault(); }
    else if (k === 'PageUp') { setActive(state.active - 8); e.preventDefault(); }
    else if (k === 'Tab') { setActive(state.active + (e.shiftKey ? -1 : 1)); e.preventDefault(); }
    else if (k === 'Enter') { apply(state.rows[state.active], e.shiftKey || MODE === 'panel'); e.preventDefault(); }
    else if (k === 'Escape') {
      e.preventDefault();
      if (!$menu.hidden) { openMenu(false); }
      else if ($q.value) { $q.value = ''; state.active = 0; render(); }
      else if (MODE === 'popup') { B.close(); }
    }
    else if ((e.metaKey || e.ctrlKey) && (k === 'r' || k === 'R')) { e.preventDefault(); loadEverything(true); }
  });

  // typing anywhere goes to the search field
  document.addEventListener('keydown', function (e) {
    if (document.activeElement === $q || e.metaKey || e.ctrlKey || e.altKey) { return; }
    if (e.key === 'Escape') { if (!$menu.hidden) { openMenu(false); } else if (MODE === 'popup') { B.close(); } return; }
    if (e.key && e.key.length === 1) { $q.focus(); }
  });

  var lastMouse = { x: -1, y: -1 };
  $list.addEventListener('mousemove', function (e) {
    if (e.clientX === lastMouse.x && e.clientY === lastMouse.y) { return; }
    lastMouse = { x: e.clientX, y: e.clientY };
    var row = e.target.closest ? e.target.closest('.row') : null;
    if (row) { setActive(Number(row.getAttribute('data-i'))); }
  });
  $list.addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.row') : null;
    if (!row) { return; }
    var i = Number(row.getAttribute('data-i'));
    state.active = i;
    apply(state.rows[i], e.shiftKey || MODE === 'panel');
  });

  $menuBtn.addEventListener('click', function () { openMenu($menu.hidden); });
  $menu.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('button[data-act]') : null;
    if (!b) { return; }
    var act = b.getAttribute('data-act');
    if (act === 'refresh') { openMenu(false); loadEverything(true); }
    if (act === 'diag') { copyDiagnostics(); }
  });
  $closeOnBlur.checked = !!state.settings.closeOnBlur;
  $closeOnBlur.addEventListener('change', function () {
    state.settings.closeOnBlur = $closeOnBlur.checked;
    save(LS.settings, state.settings);
  });
  document.addEventListener('mousedown', function (e) {
    if (!$menu.hidden && !$menu.contains(e.target) && !$menuBtn.contains(e.target)) { openMenu(false); }
  });

  window.addEventListener('focus', function () {
    state.hadFocus = true;
    if ($menu.hidden) { $q.focus(); }
    refreshSelection();
  });

  window.addEventListener('blur', function () {
    if (MODE !== 'popup' || !state.settings.closeOnBlur || !state.hadFocus || state.busy) { return; }
    if (Date.now() - state.openedAt < 900) { return; }
    setTimeout(function () {
      if (!document.hasFocus() && !state.busy) { B.close(); }
    }, 200);
  });

  // ------------------------------------------------------------------ init
  function init() {
    document.documentElement.classList.add('mode-' + MODE);
    if (MODE === 'panel') {
      $blurOpt.hidden = true;
    }
    B.registerKeys();

    // instant results from the last session while Premiere answers
    var cached = load(LS.effects, null);
    if (cached && cached.data) { state.effects = cached.data; buildItems(); }
    render();
    $q.focus();
    setTimeout(function () { $q.focus(); }, 60);

    if (!B.available) { state.loaded = true; render(); return; }
    loadEverything(false);
    if (MODE === 'panel') {
      setInterval(function () { if (!document.hidden && !state.busy) { refreshSelection(); } }, 2500);
    }
  }

  // exposed for tests / debugging
  window.QuickFXUI = { state: state, render: render, apply: apply, loadEverything: loadEverything, mode: MODE };

  init();
})();
